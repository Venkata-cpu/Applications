<p align="center">
  <img src="https://img.shields.io/badge/🍸_Martini-FFA116?style=for-the-badge&logo=bt&logoColor=blueviolet&labelColor=e6edeb" alt="Martini" />
  <img src="https://img.shields.io/badge/Ansible-EE0000?style=for-the-badge&logo=ansible&logoColor=white" alt="Ansible" />
  <img src="https://img.shields.io/badge/Kafka-231F20?style=for-the-badge&logo=apachekafka&logoColor=white" alt="Kafka" />
  <img src="https://img.shields.io/badge/ClickHouse-FFCC01?style=for-the-badge&logo=clickhouse&logoColor=black" alt="ClickHouse" />
  <img src="https://img.shields.io/badge/Kubernetes-326CE5?style=for-the-badge&logo=kubernetes&logoColor=white" alt="Kubernetes" />
  <img src="https://img.shields.io/badge/Grafana-F46800?style=for-the-badge&logo=grafana&logoColor=white" alt="Grafana" />
  <img src="https://img.shields.io/badge/Prometheus-E6522C?style=for-the-badge&logo=prometheus&logoColor=white" alt="Prometheus" />
  <img src="https://img.shields.io/badge/Supabase-3ECF8E?style=for-the-badge&logo=supabase&logoColor=white" alt="Supabase" />
  <img src="https://img.shields.io/badge/FalkorDB-6C3483?style=for-the-badge&logo=redis&logoColor=white" alt="FalkorDB" />
</p>

<h1 align="center">⚙️ MAT Ansible — Infrastructure Automation Platform</h1>

<p align="center">
  <i>One repo to provision, configure, and monitor the entire MAT data pipeline — from Kafka ingestion to Grafana dashboards.</i>
</p>

---

## 📑 Table of Contents

- [🔭 Overview](#-overview)
- [🏗️ Architecture & Data Pipeline](#️-architecture--data-pipeline)
- [📂 Project Structure](#-project-structure)
- [🌍 Supported Modules & Environments](#-supported-modules--environments)
- [🚀 CI/CD Pipeline](#-cicd-pipeline)
- [🧰 Roles & Playbooks Catalog](#-roles--playbooks-catalog)
- [📊 Grafana — Data Dip Investigation](#-grafana--data-dip-investigation)
- [🛠️ Setup](#️-setup)
- [📖 Usage](#-usage)

---

## 🔭 Overview

Ansible-powered automation platform for the **Martini / MAT** ecosystem at BT. Eliminates manual server provisioning, reduces human error, and provides repeatable, auditable infrastructure deployments across all environments.

> **Key Principle:** Each module (MAT RAN, Fixed Network, Barista, Bhrigu, MAT Common, etc.) uses dedicated pipeline routing and inventory configurations — keeping blast radius small and deployments safe.

---

## 🏗️ Architecture & Data Pipeline

The platform automates the full data pipeline stack that powers the **Data Dip Investigation** dashboards:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          EMS → APPLICATION PIPELINE HEALTH                      │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│   ┌──────────┐    ┌──────────────┐    ┌────────────┐    ┌──────────────────┐   │
│   │  ATLAS   │───▶│ KAFKA BROKER │───▶│  HERCULES  │───▶│   CLICKHOUSE     │   │
│   │Collector │    │  (KRaft)     │    │ Processor  │    │  Server/Keeper   │   │
│   │ /Parser  │    │              │    │            │    │                  │   │
│   └──────────┘    └──────────────┘    └────────────┘    └──────────────────┘   │
│        │                │                   │                    │              │
│        ▼                ▼                   ▼                    ▼              │
│   ┌──────────┐    ┌──────────────┐    ┌────────────┐    ┌──────────────────┐   │
│   │ Kafdrop  │    │Kafka Exporter│    │ JMX Export │    │    HAProxy       │   │
│   │   UI     │    │  /JMX Agent  │    │            │    │  (Load Balance)  │   │
│   └──────────┘    └──────────────┘    └────────────┘    └──────────────────┘   │
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    MONITORING & OBSERVABILITY                            │   │
│   │  Prometheus ──▶ Grafana ──▶ Data Dip Investigation Dashboard            │   │
│   │  Node Exporter │ Process Exporter │ Blackbox Exporter │ Pushgateway     │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    KUBERNETES ORCHESTRATION                              │   │
│   │  Master Setup │ Worker Setup │ Ingress │ Helm │ Longhorn │ Headlamp     │   │
│   │  Strimzi Kafka │ MongoDB │ Supabase │ LibreFS │ FalkorDB │ Grafana K8s  │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │                    DATA ANALYTICS (OLAP)                                │   │
│   │  Druid (OLAP) │ HDFS (Deep Storage) │ ZooKeeper │ MySQL (Metadata)     │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 📂 Project Structure

```
mat_ansible/
├── 📁 inventories/              # Per-module, per-environment host definitions
│   ├── mat_fixed_network/       #   └── test / prod / dr
│   ├── mat_ran/                 #   └── test / pre_prod / prod / dr / geo_prod
│   ├── mat_ran_fn/              #   └── pre_prod
│   ├── mat_common/              #   └── test / pre_prod
│   ├── martini/                 #   └── test / prod / dr
│   ├── barista/                 #   └── pre_prod / prod
│   ├── bhrigu/                  #   └── test / pre_prod / prod / secondary
│   ├── netrep/                  #   └── prod / dr
│   ├── eenpm/                   #   └── dr
│   ├── ran/                     #   └── test
│   └── monitoring/              #   └── hosts
├── 📁 playbook/                 # 70+ entrypoint YAML playbooks (one per service)
│   ├── _global_vars/            # Shared vars loaded across playbooks
│   ├── _misc/                   # Maintenance/utility playbooks
│   ├── kubernetes/              # Kubernetes sub-playbooks
│   ├── database/                # Database sub-playbooks
│   ├── data_storage/            # Storage sub-playbooks
│   ├── monitoring/              # Monitoring sub-playbooks
│   ├── load_balancing/          # Load balancer sub-playbooks
│   ├── platform/                # Platform tools sub-playbooks
│   ├── frontend/                # Frontend/UI sub-playbooks
│   └── elk/                     # ELK stack sub-playbooks
├── 📁 roles/                    # 55+ reusable Ansible roles
│   ├── _misc/                   # Utility roles (disable_external_repos, falcon_memory_limit, k8s_cleanup, static_route)
│   ├── kafka/                   # Kafka KRaft broker, exporter, schema registry
│   ├── database/                # ClickHouse (server/keeper), MySQL, Druid
│   ├── coordination/            # ZooKeeper
│   ├── data_storage/            # HDFS, MinIO, LibreFS, NFS
│   ├── elk/                     # Elasticsearch, Kibana, Loki
│   ├── kubernetes/              # Cluster, database, falkordb, frontend, networking, operations, platform, storage, streaming
│   ├── monitoring/              # Prometheus, exporters, pushgateway, blackbox
│   ├── frontend/                # Grafana (standalone)
│   ├── load_balancing/          # HAProxy
│   └── platform/                # Java, GitLab Runner, Gradle, nerdctl, Docker, NVD Sync, OnePatch
├── 📁 pipeline/                 # GitLab CI stage definitions
│   ├── martini-ran-ci.yml       #   Jobs for RAN instance
│   ├── mat-fn-ci.yml            #   Jobs for Fixed Network instance
│   ├── mat-common-ci.yml        #   Jobs for MAT Common instance
│   ├── barista-ci.yml           #   Jobs for Barista instance
│   ├── bhrigu-ci.yml            #   Jobs for Bhrigu instance
│   ├── martini-ran-fn-ci.yml    #   Jobs for RAN-FN instance
│   └── default-ci.yml           #   Fallback jobs
├── 📁 grafana_dashboards/       # Version-controlled Grafana JSON models
│   ├── data_dip_investigation/  #   Pipeline health dashboards (prod, preprod, dr)
│   ├── elasticsearch_monitoring/#   ES cluster health
│   └── mysql_monitoring/        #   MySQL overview
├── 📁 config/                   # Shared configuration
├── 📁 templates/                # Jinja2 templates
└── 📄 .gitlab-ci.yml            # CI entrypoint — routes to pipeline/*.yml based on APP_INSTANCE
```

---

## 🌍 Supported Modules & Environments

| Module | Test | Pre-Prod | Prod | DR | Geo-Prod |
|:-------|:----:|:--------:|:----:|:--:|:--------:|
| **MAT RAN** | ✅ | ✅ | ✅ | ✅ | ✅ |
| **MAT RAN FN** | — | ✅ | — | — | — |
| **MAT Common** | ✅ | ✅ | — | — | — |
| **Fixed Network** | ✅ | — | ✅ | ✅ | — |
| **Martini** | ✅ | — | ✅ | ✅ | — |
| **Barista** | — | ✅ | ✅ | — | — |
| **Bhrigu** | ✅ | ✅ | ✅ | — | — |
| **Netrep** | — | — | ✅ | ✅ | — |
| **EEnpm** | — | — | — | ✅ | — |
| **RAN** | ✅ | — | — | — | — |

---

## 🚀 CI/CD Pipeline

Triggered via **GitLab CI** with parameterized variables. All jobs are **manual** — no auto-deploy.

### Trigger Variables

| Variable | Options |
|:---------|:--------|
| `APP_INSTANCE` | `RAN` · `Fixed Network` · `Barista` · `Bhrigu` · `RAN-FN` · `MAT Common` |
| `ENV` | `Test` · `Pre-Prod` · `Dr` · `Prod` · `Geo-Prod` |
| `ZONE` | `zone-1` (HAProxy/LB tier) · `zone-2` (service tier) |
| `APP_GROUP` | Playbook subfolder (e.g., `kubernetes`, `monitoring`, `kafka`, `elk`, `database`, `data_storage`, `load_balancing`, `frontend`, `platform`) |
| `APP` | Playbook name (without `.yaml` extension) |
| `TARGET_HOST` | Optional host group override |
| `ANSIBLE_USER` | SSH user for remote execution |

### Pipeline Routing

| APP_INSTANCE | Pipeline File |
|:-------------|:--------------|
| `RAN` | `pipeline/martini-ran-ci.yml` |
| `Fixed Network` | `pipeline/mat-fn-ci.yml` |
| `Barista` | `pipeline/barista-ci.yml` |
| `Bhrigu` | `pipeline/bhrigu-ci.yml` |
| `RAN-FN` | `pipeline/martini-ran-fn-ci.yml` |
| `MAT Common` | `pipeline/mat-common-ci.yml` |

### Runner Tags

`MAT-Ansible-TEST` · `MAT-Ansible-DRZ1` · `MAT-Ansible-DRZ2` · `barista-test-ansible-z1` · `barista-test-ansible-z2` · `barista-prod-ansible-z2`

---

## 🧰 Roles & Playbooks Catalog

<details>
<summary>🔴 <b>Data Streaming & Messaging</b></summary>

| Role | Description |
|:-----|:------------|
| `kafka/kafka_kraft` | Kafka KRaft (ZooKeeper-less) — broker, exporter, schema registry sub-roles |
| `kafka` | Apache Kafka (legacy ZooKeeper mode) |
| `kafka_airborne` | Kafka Airborne variant |
| `kafka_exporter` / `kafka_airborne_exporter` | Prometheus exporters for Kafka |
| `kafdrop` / `kafdrop_kraft` / `kafdrop_airborne` | Kafka UI for topic inspection |
| `coordination/zookeeper` | Apache ZooKeeper ensemble |
| `kubernetes/streaming/kafka` | Strimzi Kafka on Kubernetes |
| `kubernetes/streaming/kafka_ui` | Kafbat Kafka UI on Kubernetes |
| `kubernetes/streaming/kafdrop` | Kafdrop on Kubernetes with HAProxy Ingress |

</details>

<details>
<summary>🟠 <b>Data Storage & Databases</b></summary>

| Role | Description |
|:-----|:------------|
| `database/clickhouse/server` | ClickHouse Server (18 shards × 2 replicas in prod) |
| `database/clickhouse/keeper` | ClickHouse Keeper (consensus cluster) |
| `database/mysql` | MySQL install, upgrade & user setup |
| `database/druid` | Apache Druid OLAP analytics cluster |
| `data_storage/hdfs` | Hadoop HDFS with HA (dual NameNode) |
| `data_storage/minio` | MinIO S3-compatible object storage (standalone) |
| `data_storage/librefs` | LibreFS S3-compatible object storage (standalone) |
| `data_storage/nfs_server` / `nfs_mount` | NFS shared storage |
| `kubernetes/database/elasticsearch` | Elasticsearch on Kubernetes |
| `kubernetes/database/loki` | Loki log aggregation on Kubernetes |
| `kubernetes/database/postgres` | CloudNativePG PostgreSQL on Kubernetes |
| `kubernetes/database/supabase` | Supabase Backend-as-a-Service on Kubernetes |
| `kubernetes/database/mongodb` | Percona MongoDB on Kubernetes |
| `kubernetes/storage/longhorn` | Longhorn distributed block storage |
| `kubernetes/storage/minio` | MinIO on Kubernetes |
| `kubernetes/storage/librefs` | LibreFS on Kubernetes |
| `kubernetes/falkordb` | FalkorDB graph database (Redis Sentinel HA) |

</details>

<details>
<summary>🟢 <b>Monitoring & Observability</b></summary>

| Role | Description |
|:-----|:------------|
| `monitoring/prometheus` | Prometheus server + AlertManager |
| `frontend/grafana` | Grafana dashboards (standalone/systemd) |
| `monitoring/node-exporter` | System-level metrics |
| `monitoring/process-exporter` | Per-process metrics |
| `monitoring/blackbox_exporter` | HTTP/TCP/ICMP endpoint probing |
| `monitoring/pushgateway` | Batch job metrics |
| `jmx_server_exporter` / `jmx_agent_exporter` | JVM metrics |
| `elk/elasticsearch` | Elasticsearch (standalone) — service + exporter sub-roles |
| `database/mysql/mysql-exporter` | MySQL metrics exporter |
| `kubernetes/operations/monitoring` | In-cluster Prometheus, KSM, Metrics Server, AlertManager, Node Exporter |
| `kubernetes/operations/logging` | Fluent Bit log collection on Kubernetes |
| `kubernetes/frontend/grafana` | Grafana on Kubernetes |

</details>

<details>
<summary>🔵 <b>Kubernetes & Orchestration</b></summary>

| Role | Description |
|:-----|:------------|
| `kubernetes/cluster/docker_less` | Containerd-based K8s setup (no Docker) |
| `kubernetes/cluster/master_setup` | Master node initialisation & join |
| `kubernetes/cluster/worker_setup` | Worker node join |
| `kubernetes/cluster/upgrade` | Kubernetes version upgrades |
| `kubernetes/cluster/helm` | Helm CLI installation |
| `kubernetes/networking/ingress-controller` | HAProxy Ingress Controller |
| `kubernetes/operations/label_management` | Node label management |
| `kubernetes/operations/image_cleanup` | Container image cleanup |
| `kubernetes/platform/harbor` | Harbor container registry |
| `kubernetes/frontend/headlamp` | Headlamp K8s web UI |
| `kubernetes/database/pgadmin` | pgAdmin web UI |

</details>

<details>
<summary>🟣 <b>Platform & Utilities</b></summary>

| Role | Description |
|:-----|:------------|
| `load_balancing/haproxy` | HAProxy load balancer (source-compiled with Prometheus metrics) |
| `haproxy_click` | HAProxy for ClickHouse load balancing |
| `elk/kibana` | Kibana dashboarding |
| `elk/loki` | Grafana Loki log aggregation (standalone) |
| `platform/java` | Java OpenJDK provisioning |
| `platform/java_folder` | Java from local archive |
| `platform/gitlab_runner` | GitLab Runner (shell executor) |
| `platform/gradle` | Gradle build tool |
| `platform/containerd_nerdctl` | nerdctl + rootless BuildKit |
| `platform/docker` | Docker CE for CI/CD |
| `platform/nvd_sync` | NVD vulnerability database sync |
| `platform/onepatch` | BT OS patching automation |
| `platform/crypto_policy` | Cryptographic policy management |
| `sftp_setup` | Dedicated SFTP daemon (sshd_lock) |
| `add_user` | User provisioning |
| `firewalld` | Firewall rules management |
| `housekeep` / `cron_tab` | Maintenance automation |
| `copy_to_aws` / `copy_via_ssh` | Data transfer |
| `_misc/disable_external_repos` | Disable unreachable yum repos |
| `_misc/falcon_memory_limit` | CrowdStrike Falcon sensor memory/CPU limits |
| `_misc/k8s_cleanup` | Kubernetes cluster cleanup/decommission |
| `_misc/static_route` | Persistent static network routes |

</details>

---

## 📊 Grafana — Data Dip Investigation

The pipeline health is monitored via the **Data Dip Investigation** Grafana dashboard, which provides a step-by-step investigation flow:

| Step | Panel | What It Checks |
|:-----|:------|:---------------|
| 🚦 | Pipeline Status Indicator | Overall pipeline health (live) |
| 0 | Data Dip Detection | PROD vs DR data comparison |
| 2 | Pod Status & Restarts | K8s pod health |
| 3 | ATLAS (Collector/Parser) | Kafka consumer & producer metrics |
| 4 | HERCULES (Processor) | Last push, consumer & producer metrics |
| 7 | Kafka Broker | Broker status, errors, lag |
| 8 | ClickHouse | Server health, per-node data, replication |
| 9 | Kubernetes & Server Level | Node status |
| 🌳 | Investigation Decision Tree | Quick reference for troubleshooting |

> Dashboard JSON is version-controlled in `grafana_dashboards/` with per-environment variants (prod, preprod, dr).

---

## 🛠️ Setup

### 1️⃣ Nexus Repository Access
Ensure you have access to the Nexus repository. Contact the team if not.

### 2️⃣ Install Ansible
```bash
# RHEL/CentOS
sudo yum install ansible

# Or via pip
pip install ansible
```

### 3️⃣ Create Vault File
```bash
# Create the vault password file (get password from team members)
echo '<vault_password>' > .vault
chmod 600 .vault
```

### 4️⃣ Manage Encrypted Variables
```bash
# Create new encrypted vars file
ansible-vault create new_var_file.yml

# Edit existing encrypted vars file
ansible-vault edit existing_var_file.yml
```
> ⚠️ Always use the password stored in `.vault` when prompted.

---

## 📖 Usage

### Local Execution

```bash
# Run a playbook against a specific environment
ansible-playbook -i inventories/mat_fixed_network/test/hosts \
  playbook/<app_name>.yaml \
  --vault-password-file .vault

# Override target hosts
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/database/clickhouse_server.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=clickhouse_server_port"

# Run with APP_GROUP subfolder path
ansible-playbook -i inventories/barista/pre_prod/hosts \
  playbook/kubernetes/longhorn.yaml \
  --vault-password-file .vault \
  -e "ansible_user=app-manager"

# Run a misc/utility playbook
ansible-playbook -i inventories/mat_common/test/hosts \
  playbook/_misc/falcon_memory_limit.yaml \
  --vault-password-file .vault
```

### CI/CD Execution

Trigger via **GitLab CI** by selecting `APP_INSTANCE`, `ENV`, `ZONE`, `APP_GROUP`, and `APP` from the pipeline variables.

The CI command pattern:
```bash
INVENTORY_PATH="inventories/<module>/${INVENTORY_ENV}/hosts"
PLAYBOOK_PATH="playbook/${APP_GROUP}/${APP}.yaml"
ansible-playbook -f ${FORKS:-4} --extra-vars="target_host=$TARGET_HOST" -D \
  --vault-password-file .vault \
  -e "ansible_user=$ANSIBLE_USER" \
  -i "$INVENTORY_PATH" \
  "$PLAYBOOK_PATH"
```

---

## 🔑 Key Software Versions (Prod — Fixed Network)

| Component | Version |
|:----------|:--------|
| Kafka KRaft | 8.3.0 |
| ClickHouse Server/Keeper | 26.5.5.8 |
| Elasticsearch | 9.3.6 |
| Kubernetes | 1.36.2 |
| Prometheus | 3.5.0 |
| Grafana | 12.1.1 |
| HAProxy | 3.2.0 |
| Longhorn | 1.12.0 |
| PostgreSQL | 18.4 |
| Druid | 37.0.0 |
| Hadoop HDFS | 3.4.3 |

---

## 📐 Conventions

1. **One playbook per service** — keeps blast radius small
2. **target_host override** — all playbooks accept `--extra-vars="target_host=<group>"`
3. **Environment isolation** — each env has its own inventory, configs, and secrets
4. **Vault for secrets** — all passwords/tokens encrypted with ansible-vault
5. **Manual CI triggers** — no auto-deploy to any environment
6. **Zone separation** — zone-1 for load balancers, zone-2 for backend services
7. **Version pinning** — all software versions defined in `versions.yml`
8. **Config files in inventory** — service configs stored per-environment under `configs/`
9. **Grafana dashboards as code** — JSON models version-controlled
10. **All services under `/apps`** — consistent base path across all nodes

---

<p align="center">
  <sub>Built with ❤️ by the <b>Martini Platform Engineering</b> team</sub>
</p>

## Table Of Content

- [Discription](#discription)
- [Miscellaneous](#_misc)
- [Add User](#add_user)
- [NVD Sync](#nvd_sync)
- [Crypto Policy](#crypto_policy)
- [Druid](#druid)
- [Elasticsearch](#elasticsearch)
- [Elasticsearch Exporter](#elasticsearch_exporter)
- [Grafana](#grafana)
- [Haproxy](#haproxy)
- [Hdfs](#hdfs)
- [Helm](#helm)
- [Java](#java)
- [Java Folder](#java_folder)
- [Jmx Agent Exporter](#jmx_agent_exporter)
- [Jmx Server Exporter](#jmx_server_exporter)
- [Kafdrop](#kafdrop)
- [Kafka](#kafka)
- [Kafka Exporter](#kafka_exporter)
- [Kibana](#kibana)
- [Kubernetes-ingress-controller](#kubernetes-ingress-controller)
- [Kubernetes Logging](#kubernetes_logging)
- [Kubernetes Master Setup](#kubernetes_master_setup)
- [Kubernetes Monitoring](#kubernetes_monitoring)
- [Kubernetes Worker Setup](#kubernetes_worker_setup)
- [Logstash](#logstash)
- [Mysql-exporter](#mysql-exporter)
- [Mysql Install](#mysql_install)
- [Mysql User Setup](#mysql_user_setup)
- [Node Exporter](#node_exporter)
- [Onepatch](#onepatch)
- [Prometheus](#prometheus)
- [Pushgateway](#pushgateway)
- [Python3](#python3)
- [Superset](#superset)
- [Zookeeper](#zookeeper)

## discription
Change tracker for any modification made on Role or inventory level for any APP.\
Please note chnage only involving specific inventory configs are not needed to be recorded here.

## _misc

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 25-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

20-01-2024: Demo changes made in demo file.\
25-01-2024: Added ports.demo.demo variable in netowrks config\
03-07-2026: New role `k8s_cleanup` created — universal Kubernetes cluster cleanup utility supporting 4 actions via K8S_CLEANUP_ACTION env var: remove_workers (drain+delete from cluster), cleanup_worker (kubeadm reset + dir cleanup), docker_remove (remove Docker keep containerd), cleanup_master (full master teardown). Includes kubelet volume unmounting, iptables flush, CNI cleanup, crictl container removal, cert renewal cron removal. Standard for all environments.
10-07-2026: New role `postfix_fix` created — resolves Postfix crashing on BT pre-prod servers. Applies 4 fixes: (1) smtp_host_lookup=dns to bypass SSSD/native resolution hangs, (2) disable+mask sendmail to prevent port 25 conflict, (3) sender_canonical_maps for professional From address, (4) postfix_monitor.sh cron for auto-restart safety net.

## nvd_sync

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 15-06-2026 |

15-06-2026: New role created — NVD CVE data sync to PostgreSQL via OWASP Dependency-Check CLI. Supports init (schema setup + full pull) and sync (daily delta) modes. Includes cron scheduling, logrotate, version-pinned install of DC CLI and PG JDBC driver.

## add_user

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## crypto_policy

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## druid

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

30-06-2026: Complete rewrite as production-ready role under `roles/database/druid/`. Moved from deprecated `roles/_depricated/druid/`. New role targets Druid 37.0.0 (latest), follows project standards. Major changes: replaced single `supervise.service` with individual systemd services per daemon (druid-coordinator, druid-overlord, druid-broker, druid-router, druid-historical, druid-middlemanager). Simplified host groups to per-service groups. Role-local templates for all config files (common.runtime.properties, per-service runtime.properties + jvm.config). HDFS config (core-site.xml, hdfs-site.xml) derived from inventory groups. Config source: `config_database.druid.*`. Auth credentials moved to vault. MySQL Connector/J downloaded automatically. Prometheus emitter bundled (contrib extension). Variable prefix `druid_*`.

## elasticsearch

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

11-06-2026: Role refactored to standards — added validate.yml (including memory_limit > heap_size check), split verify.yml from service.yml, version-based cleanup (no patterns), Restart=on-failure, # Managed by Ansible headers, defaults reordered per standard

## elasticsearch_exporter

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

11-06-2026: Role refactored to standards — added validate.yml, split verify.yml from service.yml, configurable memory_limit/nofile_limit, Restart=on-failure, # Managed by Ansible header, defaults reordered per standard

## grafana

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

20-06-2026: Full role rewrite — merged monitor/ and user/ sub-roles into single unified role driven by grafana_instance_name playbook variable. Added validate.yml (version, base dir, instance, config exists in inventory), pre_install.yml (version-based), service.yml (conditional restart, MemoryMax, proxy vars from config not hardcoded), verify.yml (/api/health check). Removed hardcoded proxy from systemd template. Config stays in inventory at configs/grafana/<instance>/. Created README.md. Config convention: config_frontend.grafana.*

## haproxy

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

19-06-2026: Role brought to production standards — added pre_verify.yml, README.md, enriched task file comment headers (what/how/execution order), fixed playbook gather_facts to true (uses ansible_host in verify)

## hdfs

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

30-06-2026: Complete rewrite as production-ready role under `roles/data_storage/hdfs/`. Moved from deprecated `roles/_depricated/hdfs/`. New role targets Hadoop 3.4.3 (latest stable), follows project standards (validate → create_user → pre_install → migrate_data → install → cleanup → config → service → verify). Role-local templates replace old config. Config source moved from `config.hadoop.*` in app_configs.yml to `config_data_storage.hdfs.*` in new config_data_storage.yml. Variable prefix `hdfs_*`. Added data migration from inside version dir to persistent /apps/hdfs_data/ (namenode, datanode, journalnode). Added proper systemd hardening (MemoryMax, LimitNOFILE, Restart=always, PIDFile) for all 4 daemons. G1GC with heap dump on OOM. Separate heap settings per daemon type. Logrotate for log files. Comprehensive verify with HA state detection. Initialisation (namenode format, zkfc formatZK) excluded — only runs on fresh clusters manually.

## helm

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## java

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## java_folder

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## jmx_agent_exporter

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## jmx_server_exporter

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## kafdrop

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## kafka

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

11-06-2026: kafka_kraft/kafka-broker role fully rewritten — moved templates from inventory to role, auto-generated quorum voters from hosts, persistent data/metadata dirs, single template with SSL conditionals, schema_registry separated, validate/pre_install/cleanup/verify added, idempotent cluster init, configurable resource limits

11-06-2026: kafka_kraft/schema_registry sub-role created — config-only (no install), uses kafka-broker's binary and SSL certs, auto-generates bootstrap.servers from host group, validate/config/service/verify

02-07-2026: kafka_kraft/kafka-broker — moved tarball download from install.yml to pre_install.yml (before service stop). Service now stays running during download to minimise downtime. Standard pattern: version check → download → stop → extract → symlink.

02-07-2026: Applied download-before-stop standard across all tarball-based roles: elasticsearch/service, elasticsearch/exporter, loki, grafana, zookeeper, druid, hdfs, haproxy, minio, librefs, kafka_exporter, mysql-exporter, node-exporter, process-exporter, pushgateway, blackbox_exporter. Service stays running during download, reducing upgrade downtime.

16-07-2026: mat_fixed_network/dr config_kafka.yml confirmed ready for Kafka KRaft 8.3.0 upgrade — version already at 8.3.0 in versions.yml, config_kafka.yml already has all required settings (DR-specific nofile_limit 500000/250000, download_timeout 1800 intentionally higher than prod for slower DR network).

16-07-2026: schema_registry sub-role enhanced to support production features — added: standalone install mode (own /apps/schema_registry/ directory vs shared /apps/kafka/), DNS-based advertised hostnames, dual listeners (HTTP + HTTPS), inter-instance protocol, master eligibility, CORS access control, response mediatype, Confluent Metrics Reporter with SSL, configurable SSL endpoint identification, per-host cert paths (direct, not copied). All new features are opt-in via config_kafka.schema_registry.* settings — existing environments using the basic config are unaffected.

16-07-2026: kafka_kraft playbook fixed — kafka_host_group_name now auto-resolves from target_host (previously hardcoded to 'kafka_kraft', causing SSL cluster to get plaintext config when running with TARGET_HOST=kafka_kraft_ssl). Also increased kafka-exporter verify retries from 3×5s to 6×10s for post-upgrade startup delay.

## kafka_exporter

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

11-06-2026: kafka_exporter refactored to standards — added validate/pre_install/cleanup/verify, version-based cleanup (no patterns), configurable memory_limit/nofile_limit, connects to localhost only, Restart=on-failure, template moved to templates root

## kibana

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

20-06-2026: Full role rewrite to production standards — added validate.yml, pre_install.yml (version-based), service.yml (conditional restart), verify.yml (service active, port, /api/status). Moved config template from inventory to role (kibana.yml.j2). Added systemd override template for MemoryMax/LimitNOFILE/NODE_OPTIONS. Installed via Elastic yum repo (yum_repository module) instead of direct RPM download. Fixed playbook gather_facts. Created README.md.

## kubernetes-ingress-controller

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## kubernetes_logging

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

19-06-2026: README updated to standard — added Latest Version table, Prerequisites table, Upgrade Process, Post-Deployment Verification, and Security Notes sections

## kubernetes_master_setup

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

15-07-2026: Added clean_environment_proxy.yml prerequisite — removes HTTP_PROXY/HTTPS_PROXY/NO_PROXY from /etc/environment to prevent kube-apiserver from inheriting stale proxy vars that break webhook TLS verification (root cause of Longhorn CrashLoopBackOff on Bhrigu preprod)

## kubernetes_monitoring

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## kubernetes_worker_setup

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## logstash

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## mysql-exporter

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

20-06-2026: Full role rewrite to production standards — added validate.yml, pre_install.yml (version-based), install.yml (conditional download), cleanup.yml (version-targeted, no globs), service.yml (conditional restart), verify.yml (service, port, /metrics). Replaced generic 'exporter' user with dedicated 'mysql-exporter' system user. Added MemoryMax/LimitNOFILE to systemd template. Made collectors list configurable. Config convention: config_database.mysql_exporter.*. Created README.md.

## mysql_install

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

20-06-2026: Full role rewrite to production standards — unified install + upgrade into single role. Targets MySQL 8.4 LTS (v8.4.8). Supports OEL 8 and OEL 9 (auto-detects OS, uses correct repo RPM). Added validate.yml (version, base dir, port, OS check), pre_install.yml (version-based upgrade logic with config backup), service.yml (root password setup, conditional restart), verify.yml (service active, port, version). Moved my.cnf from inventory to role template. Added systemd override for MemoryMax/LimitNOFILE. Used get_url instead of wget. Replaced deprecated default-authentication-plugin with mysql_native_password=ON. innodb_log_file_size replaced with innodb_redo_log_capacity (8.4 change). Config convention: config_database.mysql.*

## mysql_user_setup

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

20-06-2026: Role refactored to standards — added validate.yml (MySQL running, root can connect), renamed account-setup.yml to setup.yml with proper structure (databases → users → exporter → grants → flush), added verify.yml (list DBs/users, test exporter). User passwords now referenced via vault variable names. Config convention: config_database.mysql.*. Created README.md.

## node_exporter

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

11-06-2026: Role refactored to standards — added validate.yml, split verify.yml from service.yml, version-based cleanup (no patterns), Restart=on-failure, # Managed by Ansible header, conditional restart
17-07-2026: Bhrigu Secondary (DR) inventory prepared for node_exporter upgrade 1.6.1 → 1.11.1 — bumped version in versions.yml, created config_monitoring.yml (empty defaults), added process_exporter to paths.yml and networks.yml

## onepatch

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |
| Barista     | 05-08-2026   |

05-08-2026: Role cleanup — added validate.yml (pre-flight checks: URL defined, mode valid, cron vars when enabled). Moved addons repo persistence cron jobs from setup.yml to cron.yml (single file for all scheduled tasks). Removed duplicate stat checks in cron.yml (reuses ol8_stat/ol9_stat from setup.yml). Updated README to reflect current file structure, correct config path (config_platform.onepatch.*), and document cron functionality. Cleaned trailing whitespace in setup.yml.

## prometheus

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 30-01-2024   |
| Netrap      | 01-01-2024   |

30-01-2024: Prometheus Retention variable added -> config.prometheus.retention in app_configs.yml (mat ran test config file for reference)
11-06-2026: Full role refactoring — split into prometheus/ and alertmanager/ subdirs, added validate.yml + pre_install.yml + cleanup.yml (version-based) + verify.yml per component, persistent TSDB data dir, configurable memory_limit/nofile_limit, webhook from config, Restart=on-failure, # Managed by Ansible headers

## pushgateway

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

11-06-2026: Role made production-ready — added validate.yml, pre_install.yml (version-based), cleanup.yml (no patterns), configurable memory_limit/nofile_limit in systemd, conditional restart, verify.yml with health checks, detailed README

## sftp_setup

11-06-2026: Role created — multi-user SFTP with password/key auth, SELinux, firewall, hardened crypto, split into validate/install/users/config/service/verify

## process_exporter

11-06-2026: Role refactored to standards — added validate.yml, split config.yml and verify.yml from service.yml, version-based cleanup (no patterns), configurable memory_limit/nofile_limit, conditional restart, Restart=on-failure

## blackbox_exporter

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 20-06-2026 |

20-06-2026: Full role rewrite — all tasks were commented out (dead code). Implemented standard flow: validate → create_user → pre_install → install → cleanup → config → service → verify. Dedicated blackbox-exporter system user (not shared prometheus user). Version-based upgrade logic. Production blackbox.yml with http/tcp/icmp/dns/ssh probe modules. Systemd with CAP_NET_RAW, ProtectSystem=strict, MemoryMax. Created README.md.

## python3

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## superset

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

## label_management

| Application | Release Used |
|-------------|--------------|
| Barista     | 19-06-2026   |

19-06-2026: Fixed host group resolution — `nodes` entries that match inventory group names (e.g., `kafka_workers`) are now expanded to the actual hostnames in that group before being passed to `kubectl label node`. Previously, group names were passed verbatim causing "nodes not found" errors. Updated add_group.yml, remove_group.yml, and verify.yml.
19-06-2026: README updated to standard — added Latest Version, Prerequisites table, Upgrade Process, and Security Notes sections

## kubernetes_strimzi_kafka

| Application | Release Used |
|-------------|--------------|
| Barista     | 19-06-2026   |

19-06-2026: Replaced `kubernetes.core.k8s` module usage in deploy.yml with `template` + `kubectl apply` pattern. The k8s module requires the Python `kubernetes` library which is not installed on target hosts. Now uses the same shell-based approach as the rest of the project's K8s roles. Also created playbook at `playbook/kubernetes/kubernetes_strimzi_kafka.yaml` and added to `.gitlab-ci.yml` APP options.
19-06-2026: Moved `resources` from `spec.kafka` in kafka-values.yml.j2 (invalid with node pools enabled) to kafka-broker.yml.j2 KafkaNodePool spec. Controller pool already had resources defined correctly. Fixes Strimzi strict decoding error for `spec.kafka.resources`.

## kubernetes_kafka_connect

| Application | Release Used |
|-------------|--------------|
| Barista     | 24-07-2026   |

24-07-2026: New role created — `roles/kubernetes/streaming/kafka_connect`. Deploys Strimzi `KafkaConnect` CR with full topology/rack/multi-DC support inherited from the Kafka cluster config. Two actions: `install` (default, deploys Connect cluster) and `deploy_connector` (deploys `KafkaConnector` CRs from inventory list). Supports Strimzi Build (download connector JARs from Maven/URL and build custom image) or pre-built image. Includes JMX Prometheus metrics ConfigMap, auto-restart, and pause support for connectors. Playbook at `playbook/kubernetes/kubernetes_kafka_connect.yaml` reads `KAFKA_CONNECT_ACTION` env var.

## zookeeper

| Application | Release Used |
|-------------|--------------|
| Martini     | 01-01-2024   |
| Bhrigu      | 01-01-2024   |
| EEnpm       | 01-01-2024   |
| Mat Ran     | 01-01-2024   |
| Netrap      | 01-01-2024   |

30-06-2026: Complete rewrite as production-ready role under `roles/coordination/zookeeper/`. Moved from deprecated `roles/_depricated/add_user/zookeeper/`. New role targets ZooKeeper 3.9.5 (latest), follows project standards (validate → create_user → pre_install → migrate_data → install → cleanup → config → service → verify). Role-local templates replace per-inventory zoo.cfg.j2 files. Config source moved from `config.zookeeper.*` in app_configs.yml to `config_coordination.zookeeper.*` in new config_coordination.yml. Variable prefix `zk_*`. Added data migration step (moves data from inside version dir to persistent /apps/zookeeper_data, surviving upgrades). Logs remain inside version dir (non-persistent, acceptable). Added JVM env config (java.env), proper log4j.properties, systemd hardening (MemoryMax, LimitNOFILE, Restart=always), separate data/txnlog directories, autopurge settings, Prometheus metrics provider, admin server support, logrotate, and comprehensive verify step with mode detection.

## loki

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 19-06-2026 |

19-06-2026: Role brought to production standards — added pre_verify.yml, README.md, enriched task file comment headers (what/how/execution order) across all task files

## nfs_mount

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 19-06-2026 |
| Mat RAN | 19-06-2026 |

19-06-2026: Full role rewrite to production standards — replaced hardcoded numbered mount slots (primary/secondary/tertiary/quaternary/fifth/sixth) with loop-based list variable (nfs_mounts). Added validate.yml (list check, field check, server connectivity). Replaced test.yml with proper verify.yml (df check, write test). Unified config-fn.yml + config-ran.yml into single config.yml. Added production-safe mount options (soft, _netdev, noatime, bg). Removed all commented-out dead code. Created README.md.

## nfs_server

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 19-06-2026 |

19-06-2026: Full role rewrite to production standards — replaced single hardcoded export path with loop-based list variable (nfs_exports). Added validate.yml, config.yml (template-based /etc/exports), service.yml, verify.yml. Created exports.j2 template. Added README.md. Removed commented-out main.yml and hardcoded OEL8 repo references.

## clickhouse_keeper

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 19-06-2026 |

19-06-2026: Full role rewrite to production standards — removed destructive delete_data.yml and removeOldVersion.yml from flow. Added validate.yml (version, base dir, ports, zkId, memory format), pre_install.yml (version-based upgrade logic), service.yml (conditional restart), verify.yml (service active, TCP/Raft ports, ruok health check). Fixed create_user.yml to use system user with nologin shell. Added MemoryMax to systemd template. Fixed systemd unit mode to 0644. Used yum_repository module instead of yum-config-manager command. All variables now have | default() fallback. Created README.md.

## clickhouse_server

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 19-06-2026 |
| Mat RAN | 19-06-2026 |

19-06-2026: Full role rewrite to production standards — eliminated all env-specific task folders (prod/, dr/, test/, pre_prod/, test_old/) and replaced with dynamic config-driven approach. Clusters/sub-clusters now defined as list in config_database.clickhouse_server.clusters (name + host_group) and shard maps built dynamically via loop. Users defined as list with type (admin/app/readonly) and vault password reference — password hashes generated at runtime. server_config.xml.j2 and users.xml.j2 moved from inventory to role templates. Added os_tuning.yml with full Linux kernel tuning (THP=madvise, sysctl for vm/net/fs, swap disable, CPU governor). Added validate.yml, pre_install.yml (version-based), service.yml (dynamic RAM-based MemoryMax), verify.yml (HTTP query test). Removed all legacy files (tp-service.service, removeOldVersion, disableSwap, install_service variants).

## kafka_ui

| Application | Release Used |
|-------------|--------------|
| Barista     | 19-06-2026   |

19-06-2026: README updated to standard — added Latest Version table, Prerequisites table, Upgrade Process, Post-Deployment Verification, Troubleshooting, and Security Notes sections

## kubernetes_loki

| Application | Release Used |
|-------------|--------------|
| Barista     | 19-06-2026   |

19-06-2026: README created to standard — full documentation with all 12 required sections (Latest Version, Prerequisites, How to Run, Variable Reference, What Gets Deployed, Task Flow, Fluent Bit/Grafana Integration, Post-Deployment Verification, Upgrade Process, Troubleshooting, File Structure, Security Notes)


## longhorn

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 29-06-2026 |
| Mat RAN FN | 29-06-2026 |
| Barista | 29-06-2026 |
| Bhrigu | 29-06-2026 |
| MAT Common | 29-06-2026 |

29-06-2026: Added node restriction — Longhorn now only runs on nodes in the designated host group. Added node labelling (node.longhorn.io/create-default-disk=true), injected create-default-disk-labeled-nodes and system-managed-components-node-selector settings into ConfigMap, patched longhorn-manager DaemonSet with nodeSelector. New nodes joining the cluster will NOT get Longhorn unless explicitly added to the host group and playbook re-run. Added longhorn_node_label_key/longhorn_node_label_value defaults.
29-06-2026: Added optional zone-aware replica spreading for multi-rack/multi-DC clusters. When config_k8s.longhorn.zone.enabled=true, labels nodes with topology.kubernetes.io/zone, injects replica-zone-soft-anti-affinity and replica-auto-balance settings into Longhorn ConfigMap. Ensures volume replicas are distributed across zones for fault tolerance.

## kubernetes_monitoring

29-06-2026: Added optional node-exporter DaemonSet deployment (disabled by default). When enabled via `config_k8s.monitoring.node_exporter.enabled: true`, deploys node-exporter as a DaemonSet with hostNetwork/hostPID for host-level metrics (CPU, memory, disk, network). Prometheus scrape config auto-includes the node-exporter job. Adds configurable version, port, and resource limits.

## librefs

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 29-06-2026 |
| Mat RAN FN | 29-06-2026 |
| Barista | 29-06-2026 |
| MAT Common | 29-06-2026 |

29-06-2026: Added optional zone-aware topology spread for multi-rack/multi-DC clusters. When config_k8s.librefs.topology.zone_spread_enabled=true, adds topologySpreadConstraints to the StatefulSet to distribute pods evenly across zones (using topology.kubernetes.io/zone label). Configurable max skew (default 1). Uses ScheduleAnyway (soft) to avoid blocking scheduling when zone balance isn't perfect.

## postgres (CNPG)

| Application | Release Used |
|-------------|--------------|
| Mat Fixed Network | 29-06-2026 |
| Mat RAN FN | 29-06-2026 |
| Barista | 29-06-2026 |
| Bhrigu | 29-06-2026 |
| MAT Common | 29-06-2026 |

29-06-2026: Made podAntiAffinityType configurable via config_k8s.postgres.topology.pod_anti_affinity_type (default 'required'). Allows switching to 'preferred' when instances exceed available zones (e.g., 3 instances across 2 DCs). Previously hardcoded to 'required' which would block scheduling in multi-DC setups with fewer zones than instances.


## MongoDB (Percona Operator)

| App Instance | Environment |
|:---:|:---:|
| Barista | Test, Prod |

09-07-2026: Fixed external replica set connectivity — replaced splitHorizons (requires TLS+SNI) with replsetOverrides for external hostname advertising. Added per-member NodePort services with fixed ports for LB integration. Added TLS cert rotation playbook. Updated deploy.yml to clear stale horizons before applying replsetOverrides. Added allowConnectionsWithoutCertificates to mongod TLS config. Updated README with external access documentation.

## Inventories — Barista

13-07-2026: Migrated K8s deployment configs from `app_configs.yml` (under legacy `config.kubernetes.*` path) to `config_kubernetes.yml` (under `config_k8s:` root key) for both Barista Test and Barista Pre-Prod. Added missing sections to align with prod design: `docker_less` (cluster config, cert renewal, containerd, kubelet), `ingress_controller`, `logging` (Fluent Bit), `node_labels`, `monitoring`. Moved: longhorn, kafka (Strimzi), mongodb (Percona), supabase. Pre-prod also got `librefs` section added. Left legacy `config.kubernetes` stub in app_configs.yml with note pointing to new location.

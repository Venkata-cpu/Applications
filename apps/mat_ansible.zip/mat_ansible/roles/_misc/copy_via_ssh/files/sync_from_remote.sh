#!/bin/bash

source /apps/martinilive/script/print_logs.sh

REMOTE_BASE="$1"
LOCAL_BASE="$2"
REMOTE_USER="$3"
REMOTE_HOST="$4"
REMOTE_PORT=$5
PASSWORD="$6"
MAX_PARALLEL=$7
MAX_DEPTH=$8
FOLDER_REGEX=$9
TMP_COUNT_FILE="${10}"
TMP_SIZE_FILE="${11}"
FILE_TYPE="${12}"
FILE_NAME="${13}"

export SSHPASS=$PASSWORD
TOTAL_COUNT=0

# Ensure destination base exists
mkdir -p "$LOCAL_BASE"
rm -f "$TMP_COUNT_FILE"

# Function to limit parallel jobs
function wait_for_jobs {
  while (( $(jobs -r | wc -l) >= MAX_PARALLEL )); do
    sleep 1
  done
}

if [ "$FILE_TYPE" = "INVENTORY" ]; then
  LOCAL_BASE="$LOCAL_BASE/$(date +%d%m%y%H)"
  mkdir -p "$LOCAL_BASE"
fi

export REMOTE_USER REMOTE_HOST REMOTE_PORT REMOTE_BASE LOCAL_BASE SSHPASS TMP_COUNT_FILE MAX_DEPTH FOLDER_REGEX TMP_SIZE_FILE FILE_TYPE FILE_NAME

if [ "$FILE_TYPE" = "PM_DATA" ]; then
  # Get list of top-level folders from remote
  while read -r remote_folder; do
    folder_name="${remote_folder#$REMOTE_BASE/}"

    if [[ "$folder_name" =~ $FOLDER_REGEX ]]; then
      wait_for_jobs   # Wait if max parallel jobs reached
      bash -c "source sync_utils.sh; sync_folder \"$folder_name\"" &
    else
      log "$folder_name skipped as not matched with folder regex"
    fi
  done < <(sshpass -e ssh -o StrictHostKeyChecking=no -p $REMOTE_PORT "$REMOTE_USER@$REMOTE_HOST" "find $REMOTE_BASE -mindepth 1 -maxdepth $MAX_DEPTH -type d")
else
    bash -c "source sync_utils.sh; sync_folder \"\" \"$FILE_NAME\"" &
fi

# Wait for all background jobs to finish before script exits
wait
log "All Background Jobs completed"
sleep 5


#!/bin/bash
set +e
source /apps/martinilive/script/print_logs.sh
CONFIG_FILE="input.csv"

if [[ ! -f "$CONFIG_FILE" ]]; then
  log "Config file '$CONFIG_FILE' not found!"
  exit 1
fi

get_total_file_count() {
  local file="$1"
  local count=0

  if [[ -f "$file" ]]; then
    count=$(awk '{s+=$1} END {print s}' "$file")
    log "Total files copied: $count"
  else
    log "No files were copied."
  fi

  echo "$count"
}

get_total_file_size() {
  local file="$1"
  local size=0

  if [[ -f "$file" ]]; then
    size=$(awk '{s+=$1} END {if (s=="") print 0; else print s}' "$file")
  fi

  log "Total File Size: $size"
  echo "$size"
}


mapfile -t lines < "$CONFIG_FILE"


INVOKE_TIME=$(date +"%Y-%m-%d %H:%M:00")
TMP_COUNT_FILE="/apps/martinilive/tmp/rsync_file_counts.txt"
TMP_SIZE_FILE="/apps/martinilive/tmp/rsync_file_size.txt"

for line in "${lines[@]}"; do
  IFS=',' read -r REMOTE_BASE LOCAL_BASE REMOTE_USER REMOTE_HOST REMOTE_PORT PASSWORD MAX_PARALLEL MAX_DEPTH FOLDER_REGEX VENDOR TYPE FILE_TYPE FILE_NAME<<< "$line"
  # Skip header, empty lines, or lines starting with #
  [[ "$REMOTE_BASE" == "REMOTE_BASE" || -z "$REMOTE_BASE" || "$REMOTE_BASE" =~ ^# ]] && continue

  log "Starting sync for $REMOTE_USER@$REMOTE_HOST:$REMOTE_BASE to $LOCAL_BASE"
  mkdir -p "$LOCAL_BASE"

  start_time=$(date +%s)
  STATUS="SUCCESS"

  > "$TMP_COUNT_FILE"
  > "$TMP_SIZE_FILE"

  files_count=0
  files_size=0

  ./sync_from_remote.sh "$REMOTE_BASE" "$LOCAL_BASE" "$REMOTE_USER" "$REMOTE_HOST" $REMOTE_PORT "$PASSWORD" $MAX_PARALLEL $MAX_DEPTH "$FOLDER_REGEX" "$TMP_COUNT_FILE" "$TMP_SIZE_FILE" "$FILE_TYPE" "$FILE_NAME"

  if [ $? -ne 0 ]; then
    log "Error occurred in processing of $REMOTE_USER@$REMOTE_HOST:$REMOTE_BASE"
    STATUS="ERROR"
  fi

  end_time=$(date +%s)
  duration=$((end_time - start_time))

  minutes=$((duration / 60))
  seconds=$((duration % 60))

  log "Sync completed for $REMOTE_HOST:$REMOTE_BASE in ${minutes}m ${seconds}s"
  files_count=$(get_total_file_count "$TMP_COUNT_FILE")
  files_size=$(get_total_file_size "$TMP_SIZE_FILE")

./insert_into_mysql.sh "$REMOTE_HOST" "$REMOTE_BASE" $files_count $duration "$STATUS" "$INVOKE_TIME" "$VENDOR" "$TYPE" "$LOCAL_BASE" $files_size "$FILE_TYPE"

done

log "Process Completed"

#!/bin/bash

base_dir="$1"
file_retention_days=30
log_file="/apps/martinilive/script/logs/cleanup.log"
max_parallel=15
job_count=0

if [ -d "$base_dir" ]; then
  # Find directories at depth 1 and process 5 in parallel
  find "$base_dir" -mindepth 1 -maxdepth 1 -type d -print0 | \
  while IFS= read -r -d '' dir; do
    {
      find "$dir" -type f -mtime +${file_retention_days} -delete
    } &
    ((job_count++))
    
    # Limit to 5 concurrent directory processes
    if (( job_count >= max_parallel )); then
      wait
      job_count=0
    fi
  done
  
  # Wait for remaining jobs
  wait

  # Clean up empty directories
  find "$base_dir" -depth -type d -empty -delete

else
    echo "Directory does not exist: $base_dir"
fi

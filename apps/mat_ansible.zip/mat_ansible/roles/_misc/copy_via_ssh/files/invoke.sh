cd /apps/martinilive/script/
./start_sync.sh >> logs/sync.out 2>&1 &
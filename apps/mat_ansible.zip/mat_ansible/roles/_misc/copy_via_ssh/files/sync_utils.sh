#!/bin/bash

source /apps/martinilive/script/print_logs.sh

sync_folder() {
  local folder_name=""
  local src_path=""
  local dest_path=""
  local include="$2"
  if [ -z "$1" ]; then
    src_path="$REMOTE_USER@$REMOTE_HOST:$REMOTE_BASE/"
    dest_path="$LOCAL_BASE/"
  else
    folder_name="$1"
    src_path="$REMOTE_USER@$REMOTE_HOST:$REMOTE_BASE/$folder_name/"
    dest_path="$LOCAL_BASE/$folder_name/"
  fi

  mkdir -p "$dest_path"

  local output
  if [ -z "$include" ]; then
    output=$(sshpass -e rsync -azt --stats -e "ssh -p $REMOTE_PORT" --out-format="%n" "$src_path" "$dest_path")
  else
    output=$(sshpass -e rsync -azt --stats -e "ssh -p $REMOTE_PORT" --include="$include" --exclude='*' --out-format="%n" "$src_path" "$dest_path")
  fi

  local count=$(echo "$output" | grep "Number of regular files transferred" | awk -F': ' '{print $2}' | awk '{print $1}' | tr -d ',')
  local total_size=$(echo "$output" | grep "Total transferred file size" | awk -F': ' '{print $2}' | awk '{print $1}' | tr -d ',')

  echo "$count" >> "$TMP_COUNT_FILE"
  echo "$total_size" >> "$TMP_SIZE_FILE"
  log "Copied $count files, Size - $total_size bytes from $folder_name"
}

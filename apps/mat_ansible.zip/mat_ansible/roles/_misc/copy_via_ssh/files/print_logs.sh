#!/bin/bash

LOG_FILE="/apps/martinilive/script/logs/sync.log"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

log "Starting process for Huawei"
INVOKE_TIME=$1

base_input_dir="/apps/martinilive/backup/huawei"
input_date=$(date -d "yesterday" +"%Y-%m-%d")

formatted_date=$(date -d "$input_date" +%d%m%Y)

log "formated date : $formatted_date"

subdirs=($(find "$base_input_dir" -mindepth 1 -maxdepth 1 -type d))

for dir in "${subdirs[@]}"; do
    log "Processing directory: $dir"
    server_name=$(basename "$dir")
   ./copy_upload_hwe.sh "$INVOKE_TIME" "$dir" "$formatted_date" "$server_name"
done

wait

log "Process completed for date - $input_date"

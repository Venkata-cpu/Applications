#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

INVOKE_TIME=$1
SERVER_DIR="$2"
FORMATTED_DATE="$3"
SERVER_NAME="$4"

base_output_dir="/apps/martinilive/aws/work/hwe/${SERVER_NAME}"
rm -rf "$base_output_dir"
log "work Directory : $base_output_dir"

mkdir -p "$base_output_dir"

day=$(echo "$FORMATTED_DATE" | cut -c1-2)
month=$(echo "$FORMATTED_DATE" | cut -c3-4)
year=$(echo "$FORMATTED_DATE" | cut -c5-8)

pattern_date="${year}${month}${day}"
log "Pattern Date - $pattern_date"

FOLDER_NAME="neexport_${pattern_date}"
SOURCE_DIR="${SERVER_DIR}/pmneexport/${FOLDER_NAME}"
log "Source Dir : $SOURCE_DIR"

STATUS="SUCCESS"
totalSize=0
total=0
if [ -d "$SOURCE_DIR" ]; then
  zipFile="$base_output_dir/$FOLDER_NAME.zip"
  zip -r "$zipFile" "$SOURCE_DIR"
  totalSize=$(stat -c%s "$zipFile")
  ./uploadToAws.sh "Huawei" "$FORMATTED_DATE" "$zipFile" "$SERVER_NAME"
  if [ $? -ne 0 ]; then
    STATUS="ERROR"
  fi
  rm -rf "$zipFile"
  total=$(find "$SOURCE_DIR" -type f | wc -l)

else
    log "Directory does not exist: $SOURCE_DIR"
fi

./insert_into_mysql.sh "$INVOKE_TIME" "HUAWEI" "ALL" "$FORMATTED_DATE" "$STATUS" "$totalSize" "$total" "$SERVER_NAME"
if [ $? -ne 0 ]; then
  log "Error occurred in inserting in Mysql"
fi
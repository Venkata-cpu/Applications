#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

INVOKE_TIME=$1
SERVER_DIR="$2"
PMIC="$3"
FORMATTED_DATE="$4"
SERVER_NAME="$5"

pmic_xml="XML"
pmic_ebsl="ebsl/data"
pmic_ebsn="ebsn/data"
pmic_asn1="asn1/apg_sts_processed"

log "Processing for $PMIC and asn1"
./copy_upload_ee.sh "$INVOKE_TIME" "$SERVER_DIR" "$PMIC" "$FORMATTED_DATE" "$pmic_asn1" "C" "asn1" "$SERVER_NAME"
log "Processing for $PMIC and ebsl"
./copy_upload_ee.sh "$INVOKE_TIME" "$SERVER_DIR" "$PMIC" "$FORMATTED_DATE" "$pmic_ebsl" "A" "ebsl" "$SERVER_NAME"
log "Processing for $PMIC and ebsn"
./copy_upload_ee.sh "$INVOKE_TIME" "$SERVER_DIR" "$PMIC" "$FORMATTED_DATE" "$pmic_ebsn" "A" "ebsn" "$SERVER_NAME"
log "Processing for $PMIC and xml"
./copy_upload_ee.sh "$INVOKE_TIME" "$SERVER_DIR" "$PMIC" "$FORMATTED_DATE" "$pmic_xml" "A" "xml" "$SERVER_NAME"

log "process completed for $PMIC"
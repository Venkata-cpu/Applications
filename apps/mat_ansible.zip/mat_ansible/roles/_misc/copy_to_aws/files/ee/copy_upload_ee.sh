#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

INVOKE_TIME=$1
SERVER_DIR="$2"
PMIC="$3"
FORMATTED_DATE="$4"
SUB_DIR="$5"
PREFIX="$6"
FILE_TYPE="$7"
SERVER_NAME="$8"

base_output_dir="/apps/martinilive/aws/work/ee/${SERVER_NAME}/${PMIC}_${FILE_TYPE}"
result_file="/apps/martinilive/aws/tmp/ee_results_${PMIC}_${FILE_TYPE}.txt"
echo "0" > "$result_file"
rm -rf "$base_output_dir"
log "work Directory : $base_output_dir"

mkdir -p "$base_output_dir"

copy_files() {
    local src_folder="$1"
    local pattern="$2"
    local destination_folder="$base_output_dir"
    local count=0

    # Use nullglob to avoid issues with no matches
    shopt -s nullglob
    # Find all files matching the pattern
    currPattern="$src_folder"/"$pattern"
    files=( $currPattern )
    # copy files
    local count=0
    for file in "${files[@]}"; do
        if [[ -f "$file" ]]; then
            cp "$file" "$destination_folder/"
            ((count++))
        fi
    done
   echo "$count" >> "$result_file"
   log "Done for $src_folder Total Files copied : $count"
}

day=$(echo "$FORMATTED_DATE" | cut -c1-2)
month=$(echo "$FORMATTED_DATE" | cut -c3-4)
year=$(echo "$FORMATTED_DATE" | cut -c5-8)

pattern_date="${year}${month}${day}"
log "Pattern Date - $pattern_date"

PATTERN_PREFIX="${PREFIX}${pattern_date}*"
log "Pattern Prefix - $PATTERN_PREFIX"

FULL_DIR="${SERVER_DIR}/${PMIC}/${SUB_DIR}"

log "Full Dir : $FULL_DIR"

nodedirs=($(find "$FULL_DIR" -mindepth 1 -maxdepth 1 -type d))


max_jobs=8
job_count=0

for dir in "${nodedirs[@]}"; do
    copy_files "$dir" "$PATTERN_PREFIX" &
    ((job_count++))
    if (( job_count >= max_jobs )); then
        wait -n  # Wait for any one job to finish
        ((job_count--))
    fi

done

wait

STATUS="SUCCESS"
totalSize=0

if find "${base_output_dir}" -type f | grep -q .; then
  zipFile="${base_output_dir}.zip"
  zip -r "$zipFile" "$base_output_dir"
  rm -rf "$base_output_dir"
  log "Compression done, compressed file - $zipFile"
  totalSize=$(stat -c%s "$zipFile")
  ./uploadToAws.sh "Ericsson" "$FORMATTED_DATE" "$zipFile" "$SERVER_NAME"
  if [ $? -ne 0 ]; then
    STATUS="ERROR"
  fi
  rm -rf "$zipFile"
else
    log "No files found in ${base_output_dir}"
fi

total=0
while read -r line; do
  total=$((total + line))
done < "$result_file"

./insert_into_mysql.sh "$INVOKE_TIME" "ERICSSON" "${PMIC}_${FILE_TYPE}" "$FORMATTED_DATE" "$STATUS" "$totalSize" "$total" "$SERVER_NAME"
if [ $? -ne 0 ]; then
  log "Error occurred in inserting in Mysql"
fi
#!/bin/bash

LOG_FILE="/apps/martinilive/aws/script/logs/job.log"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

#!/bin/bash
set -e  # Exit on any error

source /apps/martinilive/aws/script/print_logs.sh

export https_proxy="http://cloudproxy-d.nat.bt.com:8080"

vendor="$1"
data_date="$2"
zipFile="$3"
server="$4"
uname="$5"
rname="$6"



case "$vendor" in
  "Ericsson"|"Huawei")
    s3_path="s3://bttv-btmbl-dev-npmran-bucket-historic-2/$vendor/$server/$data_date/"
    ;;

  "NOKIA_CSG")
    s3_path="s3://bttv-btmbl-dev-npmran-bucket-historic-2/$vendor/"
    ;;

  "Nokia")
      s3_path="s3://bttv-btmbl-dev-npmran-bucket-historic-2/$vendor/$server/$uname/$rname/$data_date/"
      ;;

  *)
    echo "Unknown vendor: $vendor"
    exit 1
    ;;
esac

/usr/local/bin/aws s3 cp "$zipFile" "$s3_path"
log "$zipFile uploaded to $s3_path"

echo "SUCCESS"


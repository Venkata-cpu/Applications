#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

log "Starting process for Nokia"
INVOKE_TIME=$1

base_input_dir="/apps/martinilive/backup/nokia"
input_date=$(date -d "yesterday" +"%Y-%m-%d")

formatted_date=$(date -d "$input_date" +%d%m%Y)

log "formated date : $formatted_date"

process_release_dir() {
  local server_name="$1"
  local udir_name="$2"
  local rdir="$3"
  local invoke_time="$4"
  local f_date="$5"

  local rdir_name
  rdir_name=$(basename "$rdir")

  log "Processing release directory: $rdir_name"
  ./copy_upload_nokia.sh "$invoke_time" "$f_date" "$server_name" "$udir_name" "$rdir_name" "$rdir"
}


process_user_dir() {
  local server_name="$1"
  local udir="$2"
  local invoke_time="$3"
  local f_date="$4"

  local udir_name
  udir_name=$(basename "$udir")

  log "Processing user directory: $udir_name"

  local reldirs
  mapfile -t reldirs < <(find "$udir" -mindepth 1 -maxdepth 1 -type d)

  for rdir in "${reldirs[@]}"; do
    process_release_dir "$server_name" "$udir_name" "$rdir" "$invoke_time" "$f_date"
  done
}


process_server_dir() {
  local dir="$1"
  local invoke_time="$2"
  local f_date="$3"

  local server_name
  server_name=$(basename "$dir")

  local userdirs
  mapfile -t userdirs < <(find "$dir" -mindepth 1 -maxdepth 1 -type d)

  for udir in "${userdirs[@]}"; do
    process_user_dir "$server_name" "$udir" "$invoke_time" "$f_date"
  done
}


subdirs=($(find "$base_input_dir" -mindepth 1 -maxdepth 1 -type d))

for dir in "${subdirs[@]}"; do
    log "Processing directory: $dir"
    process_server_dir "$dir" "$INVOKE_TIME" "$formatted_date"
done

wait

log "Process completed for date - $input_date"

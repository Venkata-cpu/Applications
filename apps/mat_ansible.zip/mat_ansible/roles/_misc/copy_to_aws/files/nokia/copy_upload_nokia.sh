#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

INVOKE_TIME=$1
FORMATTED_DATE="$2"
SERVER_NAME="$3"
UNAME="$4"
REL_NAME="$5"
REL_DIR="$6"

base_output_dir="/apps/martinilive/aws/work/nokia/${SERVER_NAME}_${UNAME}_${REL_NAME}"
rm -rf "$base_output_dir"
log "work Directory : $base_output_dir"

mkdir -p "$base_output_dir"

day=$(echo "$FORMATTED_DATE" | cut -c1-2)
month=$(echo "$FORMATTED_DATE" | cut -c3-4)
year=$(echo "$FORMATTED_DATE" | cut -c5-8)

pattern_date="${year}${month}${day}"
log "Pattern Date - $pattern_date"

max_jobs=4
job_count=0

for hour in $(seq -w 0 23); do
  (
    FOLDER_NAME="${pattern_date}${hour}00_36"
    SOURCE_DIR="${REL_DIR}/${FOLDER_NAME}"
    total=0
    totalSize=0
    STATUS="SUCCESS"

    if [ -d "$SOURCE_DIR" ]; then
      zipFile="$base_output_dir/${FOLDER_NAME}.zip"
      zip -r "$zipFile" "$SOURCE_DIR"
      log "Compression done, compressed file - $zipFile"
      totalSize=$(stat -c%s "$zipFile")

      ./uploadToAws.sh "Nokia" "$FORMATTED_DATE" "$zipFile" "$SERVER_NAME" "$UNAME" "$REL_NAME"
      if [ $? -ne 0 ]; then
        STATUS="ERROR"
      fi

      rm -rf "$zipFile"
      total=$(find "$SOURCE_DIR" -type f | wc -l)
    else
      log "Directory not exists : $SOURCE_DIR"
      STATUS="ERROR"
    fi

    ./insert_into_mysql.sh "$INVOKE_TIME" "NOKIA" "${UNAME}_${REL_NAME}_${hour}" "$FORMATTED_DATE" "$STATUS" "$totalSize" "$total" "$SERVER_NAME"
    if [ $? -ne 0 ]; then
      log "Error occurred in inserting in Mysql"
    fi
  ) &

  ((job_count++))
  if (( job_count >= max_jobs )); then
    wait -n  # Wait for any one job to finish
    ((job_count--))
  fi
done

wait  # Final wait to ensure all jobs complete

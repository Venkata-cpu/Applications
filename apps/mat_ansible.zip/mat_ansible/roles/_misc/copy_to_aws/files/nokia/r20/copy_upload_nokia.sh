#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

INVOKE_TIME=$1
FORMATTED_DATE="$2"
SERVER_NAME="$3"
UNAME="$4"
REL_NAME="$5"
REL_DIR="$6"

day=$(echo "$FORMATTED_DATE" | cut -c1-2)
month=$(echo "$FORMATTED_DATE" | cut -c3-4)
year=$(echo "$FORMATTED_DATE" | cut -c5-8)

pattern_date="${year}${month}${day}"
log "Pattern Date - $pattern_date"

base_output_dir="/apps/martinilive/aws/work/nokia/${SERVER_NAME}_${UNAME}_${REL_NAME}"
rm -rf "$base_output_dir"
log "work Directory : $base_output_dir"
out_dir="${base_output_dir}/${pattern_date}"
mkdir -p "$out_dir"

total=0
for dir in "$REL_DIR"/${pattern_date}*/; do
    if [ -d "$dir" ]; then
        cp -r "$dir" "$out_dir"
        log "Copied: $dir"
        file_count=$(find "$dir" -type f | wc -l)
        total=$((total_files + file_count))
    fi
done
STATUS="SUCCESS"
if [ "$total" -gt 0 ]; then
    log "Total files copied: $total"
    zipFile="$base_output_dir/${pattern_date}.zip"
    zip -r "$zipFile" "$out_dir"
    log "Compression done, compressed file - $zipFile"
    totalSize=$(stat -c%s "$zipFile")

    ./uploadToAws.sh "Nokia" "$FORMATTED_DATE" "$zipFile" "$SERVER_NAME" "$UNAME" "$REL_NAME"
    if [ $? -ne 0 ]; then
      STATUS="ERROR"
    fi

    rm -rf "$zipFile"
    rm -rf "$out_dir"
else
    STATUS="NO DATA"
    log "No files were copied."
fi

./insert_into_mysql.sh "$INVOKE_TIME" "NOKIA" "${UNAME}_${REL_NAME}" "$FORMATTED_DATE" "$STATUS" "$totalSize" "$total" "$SERVER_NAME"


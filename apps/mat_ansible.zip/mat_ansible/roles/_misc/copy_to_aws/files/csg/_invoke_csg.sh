#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

log "Starting process for Nokia CSG"
INVOKE_TIME=$1

base_input_dir="/apps/martinilive/backup/nokia_csg/172_22_99_45"
input_date=$(date -d "yesterday" +"%Y-%m-%d")
base_output_dir="/apps/martinilive/aws/work/ncsg/172_22_99_45"

rm -rf "$base_output_dir"

log "old output dir deleted"

formatted_date=$(date -d "$input_date" +%d%m%Y)
output_path="${base_output_dir}/${formatted_date}"
mkdir -p "$output_path"

out_acc_dir="${output_path}/accounting_backup"
out_perf_dir="${output_path}/performance_backup"
mkdir -p "$out_acc_dir"
mkdir -p "$out_perf_dir"

in_acc_dir="${base_input_dir}/accounting_backup"
in_perf_dir="${base_input_dir}/performance_backup"
result_file="/apps/martinilive/aws/tmp/ncg_results.txt"
echo "0" > "$result_file"
STATUS="SUCCESS"

./copy_csg.sh "$in_acc_dir" "$input_date" "$out_acc_dir" "accounting_backup" "$result_file" &
./copy_csg.sh "$in_perf_dir" "$input_date" "$out_perf_dir" "performance_backup" "$result_file" &

wait

if [ $? -ne 0 ]; then
  STATUS="ERROR"
fi

total=0
while read -r line; do
  total=$((total + line))
done < "$result_file"

log "Total files copied: $total"

totalSize=0
if find "${output_path}" -type f | grep -q .; then
    zipFile="${output_path}.zip"
    zip -r "$zipFile" "$output_path"
    rm -rf "$output_path"
    log "Compression done, compressed file - $zipFile"
    totalSize=$(stat -c%s "$zipFile")
    ./uploadToAws.sh "NOKIA_CSG" "" "$zipFile" ""
     if [ $? -ne 0 ]; then
       STATUS="ERROR"
     fi
     rm -rf "$zipFile"
else
    log "No files found in ${output_path}"
fi

./insert_into_mysql.sh "$INVOKE_TIME" "NOKIA" "csg" "$formatted_date" "$STATUS" "$totalSize" "$total" ""
if [ $? -ne 0 ]; then
  log "Error occurred in inserting in Mysql"
fi

log "Process completed for date - $input_date"

#!/bin/bash

source /apps/martinilive/aws/script/print_logs.sh

input_dir="$1"
input_date="$2"
output_path="$3"
prefix="$4"
result_file="$5"

# Convert input date to start and end timestamps in milliseconds

start_date="${input_date} 00:00:00"
end_date="${input_date} 23:59:59"

now_ts=$(date +%Y%m%d_%H%M%S)

start_marker="/apps/martinilive/aws/tmp/${prefix}_start_marker_${now_ts}"
end_marker="/apps/martinilive/aws/tmp/${prefix}_end_marker_${now_ts}"
file_list="/apps/martinilive/aws/tmp/${prefix}_filelist_${now_ts}.txt"

touch -d "$start_date" "$start_marker"
touch -d "$end_date" "$end_marker"

cd "$input_dir" || exit 1
find . -type f -newer "$start_marker" ! -newer "$end_marker" -print > "$file_list"

# Use rsync to copy flat files only (no dirs)
rsync -a --files-from="$file_list" ./ "$output_path/"

total_count=$(wc -l < "$file_list")

# Cleanup
rm -f "$start_marker" "$end_marker" "$file_list"

log "job completed for $input_dir"

echo "$total_count" >> "$result_file"

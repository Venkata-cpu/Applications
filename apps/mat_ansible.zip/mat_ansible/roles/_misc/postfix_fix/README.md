# Postfix Fix

Resolves Postfix mail service crashing on BT servers. Addresses two root causes: SSSD/native name resolution hangs causing Postfix child processes to timeout and die, and sendmail port 25 conflict that kills Postfix when sendmail attempts to start.

## Problem Description

### Root Cause 1: SSSD Name Resolution Hangs

When Postfix resolves the relay host (`smtp.intra.bt.com`), it defaults to `smtp_host_lookup = dns, native`. The "native" path goes through SSSD → Active Directory. On BT servers joined to AD, this path intermittently hangs indefinitely. After 5 minutes, Postfix's master process kills the hung child. Repeated hangs crash the entire Postfix daemon.

### Root Cause 2: Sendmail Port Conflict

Sendmail is installed and enabled on some servers. When it starts (via cron, timer, or system event), it tries to bind port 25 — already used by Postfix. The system stops Postfix to free the port. Sendmail then fails (misconfigured relay: `mail.bt.com` instead of `smtp.intra.bt.com`). Both services end up dead.

## How to Run

```bash
# Apply to all hosts in an inventory
ansible-playbook -i inventories/mat_ran/pre_prod/hosts playbook/_misc/postfix_fix.yaml \
  --vault-password-file .vault -e "ansible_user=app-manager"

# Apply to a specific host group
ansible-playbook -i inventories/mat_ran/pre_prod/hosts playbook/_misc/postfix_fix.yaml \
  --vault-password-file .vault -e "ansible_user=app-manager" \
  -e "target_host=jupiter_nifi"

# Apply to a single host
ansible-playbook -i inventories/mat_ran/pre_prod/hosts playbook/_misc/postfix_fix.yaml \
  --vault-password-file .vault -e "ansible_user=app-manager" \
  -e "target_host=blp20919390"
```

## Variable Reference

### Optional Variables (with defaults)

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|------------------|
| `postfix_fix_relayhost` | `[smtp.intra.bt.com]:25` | Relay host (display only, not modified) | N/A — informational |
| `postfix_fix_sender_canonical_enabled` | `true` | Enable From address rewriting | Disable if sender address should remain as `root@hostname` |
| `postfix_fix_sender_from` | `root` | Original sender to rewrite | Change to match a different local user |
| `postfix_fix_sender_to` | `noreply.martini@bt.com` | Rewritten From address | Change for different team/project email |
| `postfix_fix_monitor_enabled` | `true` | Deploy auto-restart cron script | Disable if not needed (Postfix is stable after DNS fix) |
| `postfix_fix_monitor_interval` | `*/5` | Cron minute field for monitor | Increase for less frequent checks |
| `postfix_fix_monitor_log` | `/var/log/postfix_monitor.log` | Monitor script log path | Change if /var/log is space-constrained |
| `postfix_fix_disable_sendmail` | `true` | Disable and mask sendmail | Set false if sendmail is needed for other purposes (unlikely) |

## What Gets Applied

```
/etc/postfix/main.cf                ← smtp_host_lookup = dns + sender_canonical_maps
/etc/postfix/sender_canonical       ← From address mapping
/etc/postfix/sender_canonical.db    ← Compiled hash database
/usr/local/bin/postfix_monitor.sh   ← Auto-restart monitor script
/var/log/postfix_monitor.log        ← Monitor log file
(cron) root: */5 * * * *           ← Monitor cron job
sendmail.service                    ← masked (cannot start)
```

## Task Execution Flow

```
validate (check postfix installed)
  │
  ├─ Fix 1: smtp_host_lookup = dns (lineinfile in main.cf)
  │
  ├─ Fix 2: sender_canonical_maps (lineinfile + file + postmap)
  │
  ├─ Fix 3: stop + disable + mask sendmail
  │
  ├─ Fix 4: deploy monitor script + cron
  │
  ├─ restart postfix (if config changed)
  │
  └─ verify (postfix running, smtp_host_lookup confirmed, sendmail masked)
```

## Post-Deployment Verification

1. Check Postfix is running:
   ```bash
   systemctl status postfix
   ```

2. Verify DNS-only lookup:
   ```bash
   postconf smtp_host_lookup
   # Expected: smtp_host_lookup = dns
   ```

3. Verify sendmail is masked:
   ```bash
   systemctl is-enabled sendmail
   # Expected: masked
   ```

4. Check monitor log:
   ```bash
   tail -5 /var/log/postfix_monitor.log
   # Expected: "Postfix is running." entries every 5 minutes
   ```

5. Test email delivery:
   ```bash
   echo "Test from $(hostname)" | mail -s "Postfix Fix Test" your.email@bt.com
   ```

## Troubleshooting

### Postfix still crashing after applying fix

Check if another service is conflicting on port 25:
```bash
ss -tlnp | grep :25
```

Check Postfix logs:
```bash
journalctl -u postfix --no-pager -n 50
journalctl -u postfix -p err
```

### Sendmail keeps restarting despite being masked

Check if a cron or systemd timer is unmasking it:
```bash
grep -r sendmail /etc/cron* /var/spool/cron/
systemctl list-timers | grep -i sendmail
```

### Monitor script reporting restarts

Check what's killing Postfix:
```bash
grep "DOWN" /var/log/postfix_monitor.log
journalctl -u postfix --since "1 week ago" | grep -i "stop\|kill\|signal"
```

Monthly restarts at 01:15–01:30 on 2nd Sunday are expected (OS patching).

### Service Account Access

The monitor script runs as root via cron. No service account is created by this role.

## File Structure

```
roles/_misc/postfix_fix/
├── defaults/
│   └── main.yml          # Role variables with defaults
├── tasks/
│   └── main.yml          # All fix tasks (validate, fix, verify)
└── README.md             # This file
```

## Security Notes

- The role modifies `/etc/postfix/main.cf` — a system configuration file. Changes are idempotent (safe to re-run).
- Sendmail is masked at the systemd level — cannot be accidentally re-enabled without `systemctl unmask sendmail`.
- The monitor script runs as root (required to restart systemd services).
- No secrets are involved in this role.

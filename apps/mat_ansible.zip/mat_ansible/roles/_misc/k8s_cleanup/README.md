# Kubernetes Cluster Cleanup Role

Action-driven Kubernetes cluster cleanup controlled by the `K8S_CLEANUP_ACTION` environment variable. Supports selective worker removal or master teardown. Worker nodes must be explicitly specified to prevent accidental cluster deletion.

## Prerequisites

| Requirement | Details | How to Check |
|------------|---------|--------------|
| Root access | `become: true` in playbook | Ansible user has sudo |
| kubectl | Available on master node | `kubectl version --client` |
| kubeadm | Available on all nodes | `kubeadm version` |

## How to Run

### GitLab CI

| CI Variable | Value |
|-------------|-------|
| APP_GROUP | `_misc` |
| APP | `k8s_cleanup` |

### Environment Variables

| Variable | Required | Values | Description |
|----------|:--------:|--------|-------------|
| `K8S_CLEANUP_ACTION` | Yes | `worker` / `master` | Controls which cleanup steps run |
| `WORKER_NODES` | Yes (for `worker`) | Comma-separated hostnames | Workers to remove — must be explicitly listed |

### Actions

| Action | What it does | WORKER_NODES required? |
|--------|-------------|:----------------------:|
| `worker` | Drain + delete specified workers from cluster, then kubeadm reset + docker remove locally on those nodes | Yes |
| `master` | Full master teardown (kubeadm reset, dirs, iptables, CNI, docker remove) | No |

### Behaviour Matrix

| Scenario | Play 1 (master) | Play 2 (workers) | Play 3 (master) |
|----------|----------------|-----------------|----------------|
| `action=worker`, `WORKER_NODES=blp20919390` | drain+delete blp20919390 | cleanup only on blp20919390 | skipped |
| `action=worker`, `WORKER_NODES=blp20919390,blp20919391` | drain+delete both | cleanup on both | skipped |
| `action=worker`, no WORKER_NODES | **FAILS** — WORKER_NODES required | — | — |
| `action=master` | skipped | skipped | full master teardown + docker remove |

### Examples

```bash
# Remove specific workers
K8S_CLEANUP_ACTION=worker WORKER_NODES=blp20919390,blp20919391

# Remove all workers (you must list them explicitly)
K8S_CLEANUP_ACTION=worker WORKER_NODES=blp20919390,blp20919391,blp20919407,blp20919408,blp20919409,blp20919904,blp20919905,blp20919906,blp20919907,blp20919908,blp20919909,blp20919910

# Master teardown only
K8S_CLEANUP_ACTION=master
```

### Extra Vars (Optional Overrides)

| Variable | Default | Description |
|----------|---------|-------------|
| `master_host` | `kubernetes_master_init` | Override master target group |
| `worker_host` | `kubernetes_worker` | Override worker target group |

## Execution Sequence

### Action: `worker`

```
Play 1: remove_workers.yml     → runs on kubernetes_master_init
         ├─ Validate WORKER_NODES is set (fails if empty)
         ├─ Parse comma-separated hostname list
         ├─ Cordon each worker node
         ├─ Drain each worker node (ignore daemonsets, force, disable-eviction)
         └─ Delete each worker node from cluster

Play 2: cleanup_worker.yml     → runs on kubernetes_worker (filtered to WORKER_NODES only)
         ├─ Disable external repos (prevents yum timeouts)
         ├─ kubeadm reset --force
         ├─ Stop and disable kubelet, docker, containerd
         ├─ Remove /etc/kubernetes, /etc/cni, /opt/cni, /var/lib/etcd, /var/lib/kubelet
         ├─ Remove ~/.kube
         ├─ Remove docker-ce packages (keep containerd)
         └─ Remove /var/lib/docker
```

### Action: `master`

```
Play 3: cleanup_master.yml     → runs on kubernetes_master_init
         ├─ Disable external repos (prevents yum timeouts)
         ├─ Drain master node (best-effort)
         ├─ kubeadm reset -f --cleanup-tmp-dir
         ├─ Stop kubelet and containerd
         ├─ Unmount kubelet volumes (prevents "Device busy")
         ├─ Remove /etc/kubernetes, /var/lib/kubelet, /var/lib/etcd, /apps/kubernetes_data
         ├─ Remove kubeconfig (~/.kube)
         ├─ Remove CNI (/etc/cni, /var/lib/cni, /opt/cni)
         ├─ Flush iptables + ip6tables
         ├─ Remove virtual interfaces (cali+, tunl0, vxlan.calico, flannel.1)
         ├─ Remove all containers/pods via crictl
         ├─ Remove pod/container logs
         ├─ Remove cert renewal cron + script
         ├─ Restart containerd (clean state)
         ├─ Remove docker-ce packages (keep containerd)
         └─ Remove /var/lib/docker
```

## Safety Design

- **No `all` action** — prevents accidental full cluster deletion in a single command
- **WORKER_NODES is mandatory** — no auto-discovery, you must explicitly list which nodes to remove
- **Separate actions** — worker cleanup and master cleanup are independent operations
- **All CI jobs are manual** — no auto-trigger

## Variable Reference

### Role Defaults

| Variable | Default | Description |
|----------|---------|-------------|
| `k8s_cleanup_ansible_user` | `app-manager` | User for kubectl commands (sudo -u pattern) |
| `k8s_cleanup_data_dir` | `/apps/kubernetes_data` | K8s data directory to remove on master |
| `k8s_cleanup_drain_timeout` | `300` | Drain timeout in seconds |
| `k8s_cleanup_drain_grace_period` | `30` | Pod termination grace period |
| `k8s_cleanup_docker_data_dir` | `/var/lib/docker` | Docker data directory to remove |
| `k8s_cleanup_restart_containerd` | `true` | Restart containerd after master cleanup |
| `k8s_cleanup_worker_dirs` | See defaults | List of directories to remove on workers |
| `k8s_cleanup_master_dirs` | See defaults | List of directories to remove on master |
| `k8s_cleanup_docker_packages` | See defaults | Docker packages to uninstall |
| `k8s_cleanup_cert_renewal_cron` | `/etc/cron.d/k8s-cert-renewal` | Cert renewal cron file path |
| `k8s_cleanup_cert_renewal_script` | `/usr/local/bin/k8s-cert-renew.sh` | Cert renewal script path |

## Post-Cleanup — Re-initialize

After cleanup, re-run the setup pipelines to rebuild the cluster:

```bash
# 1. Master setup
APP_GROUP=kubernetes  APP=kubernetes_master_setup_dockerless

# 2. Worker setup
APP_GROUP=kubernetes  APP=kubernetes_worker_setup
```

## File Structure

```
roles/_misc/k8s_cleanup/
├── defaults/main.yml          # Configurable parameters
├── tasks/
│   ├── main.yml               # Documentation — playbook imports tasks directly
│   ├── remove_workers.yml     # Drain + delete workers from cluster (runs on master)
│   ├── cleanup_worker.yml     # Worker local cleanup: kubeadm reset + dirs
│   ├── docker_remove.yml      # Remove Docker packages, keep containerd
│   └── cleanup_master.yml     # Master full teardown
├── README.md
playbook/_misc/k8s_cleanup.yaml  # Multi-play playbook (entry point)
```

## Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| "K8S_CLEANUP_ACTION is not set" | Env var missing | Set `K8S_CLEANUP_ACTION=worker` or `K8S_CLEANUP_ACTION=master` |
| "WORKER_NODES is not set" | Missing for worker action | Provide `WORKER_NODES=node1,node2` |
| Drain hangs >5 min | Pods stuck in Terminating | `--disable-eviction` and `--skip-wait-for-delete-timeout=10` handle this (already included) |
| yum stucks on worker node | Oracle CDN repos unreachable | `disable_external_repos` runs first; manually disable `oracle-linux-ol8.repo` if needed |
| "Device or resource busy" | kubelet volumes still mounted | cleanup_master handles this automatically via /proc/mounts |

### Service Account Access

The cleanup role uses `sudo -u app-manager` for kubectl operations. To debug manually:

```bash
# Switch to the ansible user (from root)
su -s /bin/bash app-manager

# Run kubectl as the ansible user
su -s /bin/bash -c "kubectl get nodes" app-manager
```

## Security Notes

- This playbook is **destructive** — permanently deletes K8s state on targeted nodes
- No `all` action exists — prevents accidental full cluster wipe
- WORKER_NODES must be explicitly listed — no auto-discovery
- All GitLab CI jobs are manual — no auto-trigger
- containerd is preserved and restarted (needed for re-initialization)
- kubelet/kubeadm binaries preserved (needed for re-join)
- iptables flushed during master cleanup — firewall rules lost until re-apply
- No secrets are logged — all operations use shell commands without exposing credentials

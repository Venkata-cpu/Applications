#!/bin/bash

LOG_FILE="/apps/housekeep/script/logs/house_keep.log"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"
}

# NFS Server Role

Configures an NFS server with any number of exports defined via a list variable. Installs `nfs-utils` and `rpcbind`, creates export directories, templates `/etc/exports`, and verifies the service is listening on port 2049.

---

## Latest Version

This role uses the OS-provided `nfs-utils` package. No external binary version to track.

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Disk** | Sufficient space on export paths | `df -h` |
| **Firewall** | Port 2049 (TCP/UDP) open to NFS clients | `firewall-cmd --list-ports` |
| **Inventory** | `config_data_storage.nfs_server.exports` defined in `app_configs.yml` | See below |

---

## How to Run

```bash
# Standard deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/nfs_server.yaml \
  --vault-password-file .vault

# Override target host
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/data_storage/nfs_server.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=nfs_server"
```

---

## Variable Reference

### Required Variables (from inventory)

Define in `app_configs.yml` under `config_data_storage.nfs_server`:

```yaml
config_data_storage:
  nfs_server:
    exports:
      - path: "/export/mat_data"
        clients: "10.6.97.0/24(rw,sync,no_subtree_check,no_root_squash)"

      - path: "/export/backup"
        clients: "10.6.101.0/24(rw,sync,no_subtree_check,no_root_squash) 10.54.105.0/24(ro,sync)"
        owner: app-manager
        group: app-manager
        mode: "0775"
```

Each export entry:

| Field | Required | Example | Description |
|-------|:--------:|---------|-------------|
| `path` | ✅ | `/export/mat_data` | Local directory to export |
| `clients` | ✅ | `10.6.97.0/24(rw,sync,no_root_squash)` | Client spec with NFS options (written directly to `/etc/exports`) |
| `owner` | ❌ | `root` | Directory owner (default: `root`) |
| `group` | ❌ | `root` | Directory group (default: `root`) |
| `mode` | ❌ | `0755` | Directory permissions (default: `0755`) |

### Export Options Reference

| Option | Description | Recommendation |
|--------|-------------|----------------|
| `rw` | Read-write access | Use for data shares |
| `ro` | Read-only access | Use for backup/archive shares clients should not modify |
| `sync` | Write to disk before replying | **Always use** — prevents data corruption on crash |
| `no_subtree_check` | Don't check parent dirs | **Always use** — improves performance and reliability |
| `no_root_squash` | Allow remote root access | Use when clients need root write (e.g., Ansible managed) |
| `root_squash` | Map remote root to nobody | **Safer** — use for user-facing shares |
| `all_squash` | Map all users to nobody | Most restrictive — use for anonymous access |

### Client Specification Format

```
# Single host
10.6.97.50(rw,sync,no_subtree_check)

# Subnet
10.6.97.0/24(rw,sync,no_subtree_check,no_root_squash)

# Multiple clients (space-separated)
10.6.97.0/24(rw,sync) 10.54.105.0/24(ro,sync)

# Wildcard (all hosts — NOT recommended for production)
*(rw,sync,no_root_squash)

# Hostname pattern
*.mat.bt.com(rw,sync,no_subtree_check)
```

---

## What Gets Installed

After a successful run:

```
# Packages:
nfs-utils, rpcbind

# Services (enabled + started):
rpcbind.service
nfs-server.service

# Export directories (created by role):
/export/mat_data/    (root:root 0755)
/export/backup/      (app-manager:app-manager 0775)

# Configuration:
/etc/exports         (managed by Ansible template)
```

---

## Task Execution Flow

```
validate.yml → install.yml → config.yml → service.yml → verify.yml
      │              │              │              │              │
      ├─ list check  ├─ nfs-utils   ├─ mkdir       ├─ rpcbind     ├─ nfs-server active
      ├─ field check └─ rpcbind     └─ /etc/exports├─ nfs-server  ├─ rpcbind active
      └─ summary                       (template)  └─ exportfs -ra├─ port 2049
                                                                   └─ export list
```

- **Template-based /etc/exports:** Entire file is managed by Ansible (not lineinfile). Adding/removing exports is clean.
- **Idempotent:** Running twice with no config change produces zero changes.
- **Handler:** Config template change triggers `exportfs -ra` via handler.

---

## Post-Deployment Verification

### 1. Check service status

```bash
systemctl status nfs-server
systemctl status rpcbind
```

### 2. Check exports are active

```bash
exportfs -v

# Expected output:
# /export/mat_data   10.6.97.0/24(rw,sync,wdelay,no_root_squash,no_subtree_check,...)
# /export/backup     10.6.101.0/24(rw,sync,wdelay,no_root_squash,no_subtree_check,...)
```

### 3. Check port is listening

```bash
ss -tlnp | grep 2049

# Expected:
# LISTEN  0  64  *:2049  *:*
```

### 4. Test from a client

```bash
# From an NFS client host:
showmount -e <nfs-server-ip>

# Expected: lists all exported paths

# Test mount:
mount -t nfs4 <server-ip>:/export/mat_data /mnt/test
ls /mnt/test
umount /mnt/test
```

---

## Upgrade Process

No binary to upgrade. To modify exports:

1. Add, change, or remove entries in `config.nfs_server.exports`
2. Re-run the playbook
3. `/etc/exports` is re-templated and `exportfs -ra` applies changes live (no restart needed)

**To remove an export:** Remove it from the list and re-run. The export line is removed from `/etc/exports`. Existing clients with the old mount will get "stale file handle" on next access.

---

## Troubleshooting

### Checking Logs

```bash
# NFS server logs
journalctl -u nfs-server --no-pager -n 50

# RPC logs
journalctl -u rpcbind --no-pager -n 50

# Kernel NFS messages
dmesg | grep -i nfs
```

### Client gets "Permission denied"

```bash
# Check export allows the client's IP
exportfs -v | grep <export-path>

# Check client IP matches the allowed subnet
# Check firewall on server allows 2049
firewall-cmd --list-ports
firewall-cmd --add-port=2049/tcp --permanent
firewall-cmd --reload
```

### Client gets "No route to host"

```bash
# Check rpcbind is running
systemctl status rpcbind

# Check NFS port
ss -tlnp | grep 2049

# Check firewall
firewall-cmd --list-all
```

### Export not appearing after playbook run

```bash
# Check /etc/exports content
cat /etc/exports

# Force re-export
exportfs -ra

# Check for syntax errors
exportfs -v
```

---

## File Structure

```
roles/data_storage/nfs_server/
├── defaults/main.yml          # Export list variable, proxy
├── handlers/main.yml          # reload nfs exports, restart nfs-server
├── tasks/
│   ├── main.yml               # Orchestrator (validate → install → config → service → verify)
│   ├── validate.yml           # Pre-flight checks (list, fields)
│   ├── install.yml            # nfs-utils + rpcbind packages
│   ├── config.yml             # Create dirs + template /etc/exports
│   ├── service.yml            # Enable/start services + exportfs
│   └── verify.yml             # Service active, port listening, export list
├── templates/
│   └── exports.j2             # /etc/exports template (loop-based)
└── README.md                  # This file
```

---

## Security Notes

- `no_root_squash` grants remote root full access — use only when necessary (e.g., Ansible-managed hosts)
- Use subnet restrictions (`10.6.97.0/24`) instead of wildcard (`*`) in production
- NFS traffic is unencrypted by default — consider NFSv4 with Kerberos for sensitive data
- `/etc/exports` is fully managed by Ansible — manual edits will be overwritten
- Export directories are created with explicit owner/group/mode — never world-writable

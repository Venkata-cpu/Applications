# libreFS Object Storage Role

Installs and configures [libreFS](https://librefs.org/) — the actively maintained community fork of MinIO. Provides a fully S3-compatible object storage server with WebUI, LDAP/OIDC, and distributed erasure coding, all under AGPL-3.0. Drop-in replacement for MinIO with continued security patches and bug fixes.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **libreFS Server** | https://github.com/libreFS/libreFS/releases | Check `version.librefs.server` |
| **lc CLI** | https://github.com/libreFS/librefs-cli/releases | Check `version.librefs.cli` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (`/apps`) | `ls -la /apps` |
| **Data disk** | Dedicated disk/mount recommended for data | `df -h /apps/librefs_data` |
| **Network** | API + console ports reachable | `telnet <host> 61062` |
| **Proxy** | For GitHub download | `all_secrets.yml` |
| **Nodes (distributed)** | Minimum 4 nodes in host group | Check `hosts` file |

---

## How to Run

```bash
# Single-node deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/librefs.yaml \
  --vault-password-file .vault

# Distributed deployment (4+ nodes)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/librefs.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=librefs"
```

### Playbook Example

```yaml
- hosts: "{{ target_host | default('librefs') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
    librefs_host_group_name: "{{ target_host | default('librefs') }}"
  roles:
    - { role: roles/data_storage/librefs }
```

### Hosts File Example

```ini
# Single-node
[librefs]
blp20919900  ansible_host=10.6.122.50

# Distributed (4-node erasure coding)
[librefs]
blp20919900  ansible_host=10.6.122.50
blp20919901  ansible_host=10.6.122.51
blp20919902  ansible_host=10.6.122.52
blp20919903  ansible_host=10.6.122.53
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.librefs.server` | `1.0.0` | libreFS server version |
| `versions.yml` | `version.librefs.cli` | `1.0.0` | lc CLI version |
| `paths.yml` | `paths.librefs.base_dir` | `/apps` | Install directory |
| `all_secrets.yml` | `librefs_root_password_vault` | (vault encrypted) | Root password |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.librefs.mode` | `single-node` | Deployment mode | `distributed` requires 4+ nodes |
| `config.librefs.root_user` | `libreadmin` | S3 access key | |
| `config.librefs.data_dir` | `/apps/librefs_data` | Data directory (single-node) | |
| `config.librefs.data_dirs` | `[data_dir]` | Data directories list | Multiple dirs for erasure within single node |
| `config.librefs.listen_address` | `0.0.0.0` | Bind address | |
| `config.librefs.console_enabled` | `true` | Web console on/off | |
| `config.librefs.memory_limit` | `2G` | Systemd `MemoryMax` | |
| `config.librefs.nofile_limit` | `65536` | Systemd `LimitNOFILE` | |
| `config.librefs.buckets` | `['longhorn-backup']` | Auto-created buckets | |
| `config.librefs.arch` | `linux-amd64` | Binary architecture | |
| `config.librefs.download_timeout` | `120` | Download timeout (seconds) | |
| `ports.librefs.api` | `61062` | S3 API port | |
| `ports.librefs.console` | `61063` | Web console port | |

---

## Web Console (UI)

libreFS preserves the full embedded web management console that MinIO moved to its commercial product. It's enabled by default on port `61063`.

**Features:**
- Browse and manage buckets and objects
- Create/delete buckets, upload/download files
- User and policy management (including LDAP/OIDC integration)
- Server health and performance monitoring
- Bucket lifecycle, replication, and ILM settings
- Multi-user access with group-based policies

**Access:** `http://<host>:61063`
**Login:** Use the root credentials (`libreadmin` / vault password)

To disable the console, set `config.librefs.console_enabled: false` in `app_configs.yml`.

---

## What Gets Installed

```
/apps/librefs/
├── librefs            # Server binary
└── lc                 # libreFS Client binary (for bucket management)

/apps/librefs_data/    # Data directory (persistent)

/etc/librefs/
└── librefs.env        # Environment config (credentials, volumes, ports)

/etc/systemd/system/librefs.service  # Systemd unit
```

---

## Task Execution Flow

```
main.yml
├── validate.yml         # Version, ports, base_dir, password, distributed node count
├── create_user.yml      # librefs user/group (system, nologin)
├── pre_install.yml      # Version check from binary --version + stop if upgrade
├── install.yml          # Download server + lc binary, create data dirs, backup old
├── config.yml           # Environment file + systemd unit
├── service.yml          # daemon_reload + enable + start + conditional restart
├── verify.yml           # Service + API port + console port + health endpoint
├── cleanup.yml          # Remove backup binary after successful upgrade
└── buckets.yml          # Configure lc alias + create configured buckets
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status librefs

# 2. Health check
curl -s http://localhost:61062/minio/health/live
# Expected: 200 OK

# 3. Cluster health (distributed mode)
curl -s http://localhost:61062/minio/health/cluster
# Expected: 200 OK

# 4. Console UI
# Open in browser: http://<host>:61063
# Login: libreadmin / <vault password>

# 5. List buckets via lc
/apps/librefs/lc alias set local http://localhost:61062 libreadmin <password>
/apps/librefs/lc ls local/

# 6. Test upload/download
echo "test" > /tmp/test.txt
/apps/librefs/lc cp /tmp/test.txt local/longhorn-backup/test.txt
/apps/librefs/lc cat local/longhorn-backup/test.txt
/apps/librefs/lc rm local/longhorn-backup/test.txt
```

---

## Longhorn Integration

After libreFS is deployed, configure Longhorn to use it as backup target:

```yaml
# In Longhorn settings (via UI or kubectl)
backup-target: s3://longhorn-backup@us-east-1/
backup-target-credential-secret: librefs-secret
```

Create the K8s secret on your cluster:
```bash
kubectl create secret generic librefs-secret \
  --from-literal=AWS_ACCESS_KEY_ID=libreadmin \
  --from-literal=AWS_SECRET_ACCESS_KEY=<password> \
  --from-literal=AWS_ENDPOINTS=http://<librefs-host>:61062 \
  -n longhorn-system
```

---

## Migration from MinIO

libreFS is a drop-in replacement. To migrate:

1. Stop MinIO service
2. Deploy libreFS pointing at the same data directory
3. Update Longhorn backup target endpoint (port change if different)
4. libreFS reads existing MinIO data format natively — no migration needed

---

## Upgrade Process

1. Update `version.librefs.server` (and optionally `version.librefs.cli`) in `versions.yml`
2. Re-run playbook:
   - Detects version mismatch → stops service → backs up binary → downloads new → starts → verifies
   - Data directory is NEVER touched
3. If upgrade fails, backup binary exists at `/apps/librefs/librefs.bak` for manual rollback

---

## Troubleshooting

### Checking Logs

libreFS does **not** write log files by default — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u librefs --no-pager -n 50

# Follow live
journalctl -u librefs -f

# Errors only
journalctl -u librefs -p err

# Since last boot
journalctl -u librefs -b

# Specific time range
journalctl -u librefs --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Service won't start
```bash
journalctl -u librefs --no-pager -n 50
# Common: data dir permissions, port conflict, bad credentials in env file
```

### Distributed mode won't form cluster
```bash
# Check all nodes are reachable on API port
for ip in 10.6.122.50 10.6.122.51 10.6.122.52 10.6.122.53; do
  curl -s http://$ip:61062/minio/health/live && echo " OK: $ip" || echo " FAIL: $ip"
done
```

### Bucket creation fails
```bash
# Check lc alias is configured
/apps/librefs/lc alias list local
# Test connectivity
/apps/librefs/lc admin info local
```

---

## File Structure

```
roles/data_storage/librefs/
├── defaults/main.yml              # All variables
├── handlers/main.yml              # restart librefs
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks
│   ├── create_user.yml            # System user/group
│   ├── pre_install.yml            # Version check + stop
│   ├── install.yml                # Download server + lc binary
│   ├── cleanup.yml                # Remove backup after upgrade
│   ├── config.yml                 # Environment file + systemd
│   ├── service.yml                # Enable + start + conditional restart
│   ├── verify.yml                 # Health checks
│   └── buckets.yml                # Auto-create buckets via lc
├── templates/
│   ├── librefs.env.j2            # Environment config (credentials, volumes, ports)
│   └── librefs.service.j2        # Systemd unit
└── README.md                      # This file
```

---

### Service Account Access

The `librefs` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as librefs
su -s /bin/bash librefs

# Run a single command as librefs
su -s /bin/bash -c "whoami" librefs
```

---

## Security Notes

- Service runs as unprivileged `librefs` user
- Credentials stored in vault-encrypted secrets, deployed to `/etc/librefs/librefs.env` with mode `0640`
- `MemoryMax` prevents runaway memory usage
- `NoNewPrivileges=true` and `ProtectHome=true` in systemd unit
- Console UI has no auth bypass — requires root credentials
- No SSL by default (designed to run behind SSL-terminating proxy)
- Binary downloaded from GitHub releases (cert validation disabled for proxy compatibility)
- No telemetry — libreFS is community-governed with no phone-home
- AGPL-3.0 licensed — free forever

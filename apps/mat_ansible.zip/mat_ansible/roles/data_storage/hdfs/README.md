# Apache Hadoop HDFS

Deploys Apache Hadoop HDFS as a High-Availability distributed file system using systemd services. Provides replicated, fault-tolerant block storage for large datasets. The HA architecture uses two NameNodes (active/standby) with automatic failover via ZooKeeper Failover Controller (ZKFC), JournalNodes for shared edit logs, and DataNodes for block storage.

Used by Druid (deep storage), NiFi (staging), and other data pipeline components in the MAT ecosystem.

---

## Latest Version

| Component | Version | Check Latest |
|-----------|---------|--------------|
| Apache Hadoop | 3.4.3 | [Apache Releases](https://hadoop.apache.org/releases.html) |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Java 17+ | OpenJDK must be installed (via `platform/java` role or system) | `java -version` |
| Base directory | `/apps` must exist | `ls -la /apps` |
| ZooKeeper | Running ensemble (for HA failover + ZKFC) | `echo ruok \| nc <zk_host> 2181` |
| Network | Ports 9000, 8485, 61002 open between HDFS nodes | `ss -tlnp \| grep -E '9000\|8485\|61002'` |
| Inventory groups | `hdfs_name_node1`, `hdfs_name_node2`, `hdfs_journal_node`, `hdfs_data_node` | Check `hosts` file |
| Inventory config | `config_data_storage.hdfs` section in `config_data_storage.yml` | Check `group_vars/all/config_data_storage.yml` |

---

## How to Run

```bash
# Normal deployment/upgrade (existing cluster)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/hdfs.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>"

# Fresh cluster initialisation (format namenode + zkfc + bootstrap standby)
HDFS_ACTION=init ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/hdfs.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>"

# Target specific host group (e.g., only datanodes)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/hdfs.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>" \
  --extra-vars="target_host=hdfs_data_node"

# Via GitLab CI
APP_INSTANCE=<instance> ENV=<env> APP_GROUP=data_storage APP=hdfs
# For init: set HDFS_ACTION=init in CI variables
```

---

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.hadoop` | `3.4.3` | Hadoop version to install |
| `paths.yml` | `paths.hadoop.base_dir` | `/apps` | Base installation directory |
| `networks.yml` | `ports.hadoop.rpc` | `9000` | NameNode RPC port |
| `networks.yml` | `ports.hadoop.http` | `61002` | NameNode HTTP UI port |
| `config_data_storage.yml` | `config_data_storage.hdfs.cluster_name` | `MartiniEERan` | HDFS HA cluster/nameservice ID |
| `config_data_storage.yml` | `config_data_storage.hdfs.replication` | `2` | Block replication factor |
| `hosts` | Host groups | See below | Defines which nodes run which daemons |

### Host Groups Required in Inventory

| Group | Purpose | Min Nodes |
|-------|---------|:---------:|
| `hdfs_name_node1` | Active NameNode (runs `namenode -format` on init) | 1 |
| `hdfs_name_node2` | Standby NameNode (runs `-bootstrapStandby` on init) | 1 |
| `hdfs_name_node` | Parent group (children: `hdfs_name_node1`, `hdfs_name_node2`) | 2 |
| `hdfs_journal_node` | JournalNodes for shared edit log | 3 (odd) |
| `hdfs_data_node` | DataNodes for block storage | 1+ |
| `hdfs` | Parent group (children: `hdfs_name_node`, `hdfs_journal_node`, `hdfs_data_node`) | — |

### Optional Variables (with defaults)

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|------------------|
| `hdfs_namenode_heap_mb` | `2048` | NameNode JVM heap (MB) | Increase for larger namespaces (more files/blocks) |
| `hdfs_datanode_heap_mb` | `2048` | DataNode JVM heap (MB) | Increase for nodes with many blocks |
| `hdfs_journalnode_heap_mb` | `1024` | JournalNode JVM heap (MB) | Rarely needs increase |
| `hdfs_namenode_memory_limit` | `4G` | NameNode systemd MemoryMax | Must exceed heap — kills process if exceeded |
| `hdfs_datanode_memory_limit` | `4G` | DataNode systemd MemoryMax | Must exceed heap |
| `hdfs_journalnode_memory_limit` | `2G` | JournalNode systemd MemoryMax | Must exceed heap |
| `hdfs_nofile_limit` | `65536` | Systemd LimitNOFILE (all daemons) | Increase if "too many open files" errors |
| `hdfs_replication` | `2` | Block replication factor | Higher = more redundancy + disk usage |
| `hdfs_journalnode_rpc_port` | `8485` | JournalNode RPC port | Used in QJournal URI |
| `hdfs_zookeeper_port` | `2181` | ZooKeeper client port | Must match ZK ensemble config |
| `hdfs_zookeeper_group` | `zookeeper` | Inventory group for ZK ensemble | Change if using different group name |
| `hdfs_ha_fencing_method` | `shell(/bin/true)` | HA fencing method | `shell(/bin/true)` is safe for managed environments |
| `hdfs_trash_interval` | `4320` | Minutes before trash is permanently deleted | 4320 = 3 days |
| `hdfs_trash_checkpoint_interval` | `2880` | Minutes between trash checkpoint cycles | Must be ≤ trash_interval |
| `hdfs_acls_enabled` | `true` | Enable POSIX ACLs on HDFS | Required for fine-grained permissions |
| `hdfs_java_home` | `/usr` | JAVA_HOME path | Change if Java is in a custom location |
| `hdfs_download_timeout` | `600` | Download timeout in seconds | Hadoop tarball is ~700MB — needs time |
| `hdfs_log_rotation_size` | `100M` | Max log file size before rotation | Larger = less rotation overhead |
| `hdfs_log_rotation_count` | `5` | Rotated log files to retain | More = longer history |

---

## What Gets Installed

```
/apps/
├── hadoop-3.4.3/                      # Extracted distribution
│   ├── bin/                            # Binaries (hdfs, hadoop)
│   ├── etc/hadoop/
│   │   ├── core-site.xml              # Core config (Ansible-managed)
│   │   ├── hdfs-site.xml              # HDFS config (Ansible-managed)
│   │   ├── hadoop-env.sh             # JVM/env config (Ansible-managed)
│   │   └── workers                    # DataNode list (Ansible-managed)
│   ├── lib/                            # Java libraries
│   ├── logs/                           # Application logs (NOT persisted across upgrades)
│   ├── pids/                           # PID files (NOT persisted across upgrades)
│   └── share/                          # Documentation, examples
├── hdfs -> hadoop-3.4.3/              # Symlink (current version)
└── hdfs_data/                          # Persistent data — survives upgrades
    ├── namenode/                       # NameNode fsimage + edits
    ├── datanode/                       # DataNode blocks
    ├── journalnode/                    # JournalNode shared edits
    └── tmp/                            # Hadoop temp files

/etc/systemd/system/namenode.service    # NameNode systemd unit
/etc/systemd/system/datanode.service    # DataNode systemd unit
/etc/systemd/system/journalnode.service # JournalNode systemd unit
/etc/systemd/system/zkfc.service        # ZKFC systemd unit
/etc/logrotate.d/hdfs                   # Log rotation config
```

---

## Task Execution Flow

```
main.yml
├── validate.yml        Check version, dirs, ports, heap/memory validation
├── create_user.yml     Create hadoop system user/group
├── pre_install.yml     Detect current version, set upgrade facts, stop services if upgrading
├── migrate_data.yml    Move data from inside version dir to persistent /apps/hdfs_data/
├── install.yml         Download tarball, extract, symlink, create data dirs
├── cleanup.yml         Remove old version directory and tarball
├── config.yml          Template core-site.xml, hdfs-site.xml, hadoop-env.sh, workers, systemd units
├── service.yml         Enable and start services (journal → namenode → zkfc → datanode)
├── initialise.yml      [ONLY when HDFS_ACTION=init] Format namenode + ZKFC + bootstrap standby
└── verify.yml          Service active, ports listening, HA state detection
```

---

## HDFS_ACTION Environment Variable

| Value | Behaviour | When to Use |
|-------|-----------|-------------|
| `install` (default) | Normal deploy/upgrade. No format. | Existing clusters, upgrades, config changes |
| `init` | Fresh cluster setup. Formats namenode + ZKFC, bootstraps standby. | New cluster only |

**Safety:** Even with `HDFS_ACTION=init`, the format is skipped if `<namenode_dir>/current` already exists. Running `init` on an existing cluster does nothing destructive.

---

## Post-Deployment Verification

1. Check all services:
   ```bash
   systemctl status namenode datanode journalnode zkfc
   ```

2. Verify NameNode HA state:
   ```bash
   su -s /bin/bash -c "/apps/hdfs/bin/hdfs haadmin -getServiceState nn1" hadoop
   # Expected: active
   su -s /bin/bash -c "/apps/hdfs/bin/hdfs haadmin -getServiceState nn2" hadoop
   # Expected: standby
   ```

3. Check cluster health:
   ```bash
   su -s /bin/bash -c "/apps/hdfs/bin/hdfs dfsadmin -report" hadoop
   # Shows: live datanodes, capacity, used space
   ```

4. Verify filesystem:
   ```bash
   su -s /bin/bash -c "/apps/hdfs/bin/hdfs dfs -ls /" hadoop
   ```

5. Check NameNode web UI:
   ```
   http://<namenode_ip>:61002
   ```

6. Verify JournalNode health:
   ```bash
   curl -s http://<journalnode_ip>:8480/jmx | grep State
   ```

---

## Upgrade Process

1. Update `version.hadoop` in `versions.yml` for the target environment.
2. Run the playbook — it will:
   - Detect the version mismatch
   - Stop all HDFS services (datanode → namenode → zkfc → journalnode)
   - **Migrate data** from inside old version dir to persistent `/apps/hdfs_data/` (if not already migrated)
   - Download and extract the new Hadoop version
   - Update the symlink
   - Clean up old version files
   - Apply configuration (core-site, hdfs-site, hadoop-env, workers, systemd units)
   - Start services in correct order (journalnode → namenode → zkfc → datanode)
3. Verify HA state: one NameNode should be active, the other standby.
4. **Rolling upgrade:** For zero-downtime, use `--limit` to target node groups separately:
   ```bash
   # 1. Upgrade JournalNodes first
   --extra-vars="target_host=hdfs_journal_node"
   # 2. Then standby NameNode (nn2)
   --extra-vars="target_host=hdfs_name_node2"
   # 3. Failover: hdfs haadmin -failover nn1 nn2
   # 4. Then old active (nn1)
   --extra-vars="target_host=hdfs_name_node1"
   # 5. Finally DataNodes
   --extra-vars="target_host=hdfs_data_node"
   ```
5. **Note:** Logs and PID files inside the version directory are NOT preserved across upgrades. Data (namenode/datanode/journalnode) is persistent.

---

## Troubleshooting

### Checking Logs

```bash
# Recent logs (journald)
journalctl -u namenode --no-pager -n 50
journalctl -u datanode --no-pager -n 50
journalctl -u journalnode --no-pager -n 50
journalctl -u zkfc --no-pager -n 50

# Follow in real time
journalctl -u namenode -f

# Errors only
journalctl -u namenode -p err

# Application log files (inside version dir — lost on upgrade)
tail -100 /apps/hdfs/logs/hadoop-hadoop-namenode-*.log
tail -100 /apps/hdfs/logs/hadoop-hadoop-datanode-*.log
tail -100 /apps/hdfs/logs/hadoop-hadoop-journalnode-*.log
```

### Common Issues

| Problem | Diagnostic | Solution |
|---------|-----------|----------|
| NameNode won't start | `journalctl -u namenode -n 50` | Check if JournalNodes are running first |
| Both NameNodes standby | `hdfs haadmin -getServiceState nn1` | Check ZKFC: `journalctl -u zkfc -n 50`, verify ZK connectivity |
| DataNode not connecting | `hdfs dfsadmin -report` | Verify RPC port, check firewall between DN and NN |
| Format fails | Check error output | Ensure JournalNodes are running before format |
| Standby bootstrap fails | Check NameNode 1 is active | NN1 must be formatted and running before NN2 bootstrap |
| Split-brain (both active) | `hdfs haadmin -getServiceState nn1/nn2` | Check ZK quorum, ZKFC logs, fencing method |
| Disk full on DataNode | `df -h /apps` | Add more DataNodes or increase disk |
| Slow writes | `hdfs dfsadmin -report` | Check replication, network between nodes |

### Service Account Access

```bash
# Switch to the hadoop service account (from root)
su -s /bin/bash hadoop

# Run HDFS commands as hadoop user
su -s /bin/bash -c "/apps/hdfs/bin/hdfs dfs -ls /" hadoop
su -s /bin/bash -c "/apps/hdfs/bin/hdfs dfsadmin -report" hadoop
su -s /bin/bash -c "/apps/hdfs/bin/hdfs haadmin -getServiceState nn1" hadoop
```

---

## File Structure

```
roles/data_storage/hdfs/
├── defaults/
│   └── main.yml                   # All configurable variables with defaults
├── handlers/
│   └── main.yml                   # Restart handlers (namenode, datanode, journalnode, zkfc)
├── tasks/
│   ├── main.yml                   # Entrypoint — imports all task files in order
│   ├── validate.yml               # Pre-flight checks
│   ├── create_user.yml            # Service user/group creation
│   ├── pre_install.yml            # Version detection and upgrade facts
│   ├── migrate_data.yml           # Move data from version dir to persistent location
│   ├── install.yml                # Download, extract, symlink
│   ├── cleanup.yml                # Remove old version artifacts
│   ├── config.yml                 # Configuration and systemd deployment
│   ├── service.yml                # Start/restart services
│   ├── initialise.yml             # Fresh cluster format (HDFS_ACTION=init only)
│   └── verify.yml                 # Health checks
├── templates/
│   ├── core-site.xml.j2           # Hadoop core config (FS, ZK quorum, trash)
│   ├── hdfs-site.xml.j2           # HDFS config (HA, replication, data dirs)
│   ├── hadoop-env.sh.j2           # JVM settings (heap, GC, log/pid dirs)
│   ├── workers.j2                 # DataNode host list
│   ├── namenode.service.j2        # NameNode systemd unit
│   ├── datanode.service.j2        # DataNode systemd unit
│   ├── journalnode.service.j2     # JournalNode systemd unit
│   ├── zkfc.service.j2            # ZKFC systemd unit
│   └── logrotate.j2               # Log rotation configuration
└── README.md                      # This file
```

---

## Security Notes

- HDFS runs as an unprivileged system user (`hadoop`) with `/sbin/nologin` shell.
- `dfs.permissions` is set to `false` (no HDFS-level permission enforcement) — relies on network isolation.
- POSIX ACLs are enabled (`dfs.namenode.acls.enabled=true`) for applications that need them.
- HA fencing uses `shell(/bin/true)` — a no-op fence. Safe in managed environments where split-brain is prevented by ZooKeeper. For untrusted networks, consider SSH fencing.
- No Kerberos/SASL authentication — relies on network-level isolation.
- Download uses `validate_certs: false` due to corporate proxy MITM interception.
- DataNode data directory is mode `0700` (only hadoop user can read blocks).

# NFS Mount Role

Configures NFS client mounts on target hosts. Supports any number of mounts via a simple list variable — no hardcoded mount slots. Each mount gets production-safe options by default (`soft`, `_netdev`, `noatime`) to prevent boot hangs and indefinite I/O waits.

---

## Latest Version

This role does not install a versioned binary — it uses the OS-provided `nfs-utils` package. No version tracking needed.

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **NFS server** | Exporting the target paths, reachable on port 2049 | `showmount -e <server-ip>` |
| **Network** | Target hosts can reach the NFS server | `telnet <server-ip> 2049` |
| **Inventory** | `config_data_storage.nfs_mount.mounts` defined in `app_configs.yml` | See Variable Reference below |

---

## How to Run

```bash
# Standard deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/nfs_mount.yaml \
  --vault-password-file .vault

# Override target host
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/data_storage/nfs_mount.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=clickhouse_server_port"
```

---

## Variable Reference

### Required Variables (from inventory)

Define in `app_configs.yml` under `config_data_storage.nfs_mount`:

```yaml
config_data_storage:
  nfs_mount:
    mounts:
      - server: "10.6.97.50"
        remote_path: "/export/mat_data"
        local_path: "/apps/nfs/mat_data"

      - server: "10.6.97.51"
        remote_path: "/export/backup"
        local_path: "/apps/nfs/backup"
        fstype: nfs            # override default nfs4
        opts: "defaults,_netdev"  # override default mount options
```

Each mount entry requires:

| Field | Required | Example | Description |
|-------|:--------:|---------|-------------|
| `server` | ✅ | `10.6.97.50` | NFS server IP or hostname |
| `remote_path` | ✅ | `/export/mat_data` | Export path on the NFS server |
| `local_path` | ✅ | `/apps/nfs/mat_data` | Mount point on the local host |
| `fstype` | ❌ | `nfs4` | Override filesystem type (default: `nfs4`) |
| `opts` | ❌ | `rw,soft,...` | Override mount options (default: see below) |

### Optional Variables (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_data_storage.nfs_mount.default_fstype` | `nfs4` | Default filesystem type for all mounts | `nfs` for NFSv3 compatibility |
| `config_data_storage.nfs_mount.default_opts` | `rw,soft,timeo=30,retrans=3,intr,bg,_netdev,noatime,rsize=1048576,wsize=1048576` | Default mount options | See Mount Options section |

### Mount Options Explained

| Option | Purpose | Why it matters |
|--------|---------|----------------|
| `rw` | Read-write access | |
| `soft` | Return error on timeout | **Prevents indefinite I/O hang** if NFS server goes down |
| `timeo=30` | 3-second timeout (deciseconds) | How long to wait before retrying |
| `retrans=3` | 3 retries before failing | Total wait = 3 × 3s = 9s before error |
| `intr` | Allow signal interrupt | Lets users Ctrl+C hung operations. Note: deprecated on Linux 5.x+ (OEL 9) — ignored silently, no harm. |
| `bg` | Background retry on boot | **Prevents boot hang** if NFS server is temporarily down |
| `_netdev` | Wait for network before mount | Ensures network is up before attempting mount |
| `noatime` | Don't update access times | Reduces NFS traffic significantly |
| `rsize=1048576` | 1MB read buffer | Performance — larger buffers = fewer round-trips |
| `wsize=1048576` | 1MB write buffer | Performance — larger buffers = fewer round-trips |

---

## What Gets Installed

After a successful run:

```
# On target host:
/apps/nfs/mat_data/     # mount point (created by role)
/apps/nfs/backup/       # mount point (created by role)

# In /etc/fstab:
10.6.97.50:/export/mat_data  /apps/nfs/mat_data  nfs4  rw,soft,timeo=30,...  0 0
10.6.97.51:/export/backup    /apps/nfs/backup    nfs4  rw,soft,timeo=30,...  0 0
```

---

## Task Execution Flow

```
validate.yml → install.yml → config.yml → verify.yml
      │              │              │              │
      ├─ list check  ├─ nfs-utils   ├─ mkdir       ├─ df check
      ├─ field check ├─ nfs-client  └─ mount       ├─ write test
      └─ server ping    target                     └─ summary
```

- **Loop-based:** All tasks iterate over `nfs_mounts` list — supports 1 to N mounts with no code changes.
- **Idempotent:** Running twice produces zero changes if mounts are already configured.
- **Validate warns but doesn't block** on server connectivity (mount may succeed via background retry with `bg` option).

---

## Post-Deployment Verification

### 1. Check mounts are active

```bash
df -h | grep nfs

# Expected:
# 10.6.97.50:/export/mat_data   500G  120G  380G  24% /apps/nfs/mat_data
# 10.6.97.51:/export/backup     1.0T  200G  800G  20% /apps/nfs/backup
```

### 2. Check fstab entries

```bash
grep nfs /etc/fstab

# Expected: one line per configured mount
```

### 3. Test write access

```bash
touch /apps/nfs/mat_data/test_file && rm /apps/nfs/mat_data/test_file
echo "OK: write access confirmed"
```

### 4. Check mount options

```bash
mount | grep nfs

# Expected: shows your configured options (soft, noatime, etc.)
```

---

## Upgrade Process

This role has no versioned binary. To change mounts:

1. Add, modify, or remove entries in `config_data_storage.nfs_mount.mounts`
2. Re-run the playbook
3. New mounts are created; existing mounts are unchanged if already correct

**To remove a mount:** Remove it from the list and manually unmount on the host:
```bash
umount /apps/nfs/old_mount
# Remove from fstab
sed -i '/old_mount/d' /etc/fstab
rmdir /apps/nfs/old_mount
```

---

## Troubleshooting

### Mount hangs during playbook

```bash
# NFS server likely unreachable. Check connectivity:
telnet <server-ip> 2049

# If server is down and mount uses 'soft' option, it will error (not hang).
# If you see a hang, the mount options may be 'hard' (default without our opts).
```

### "Permission denied" on mount

```bash
# Check NFS server exports allow this client
showmount -e <server-ip>

# Check firewall on NFS server allows port 2049 from this host's IP
```

### Mount disappears after reboot

```bash
# Check fstab entry exists
grep <mount_path> /etc/fstab

# Check nfs-client.target is enabled
systemctl is-enabled nfs-client.target

# If using _netdev, ensure NetworkManager is up before mounts
systemctl status NetworkManager
```

### "Stale file handle" errors

```bash
# NFS server restarted or export changed
umount -f /apps/nfs/stale_mount
mount /apps/nfs/stale_mount

# Or re-run the playbook — it will remount
```

### nfs-utils install fails

```bash
# Check yum repos are available
yum repolist

# If behind proxy, ensure http_proxy is set
echo $http_proxy
```

---

## File Structure

```
roles/data_storage/nfs_mount/
├── defaults/main.yml      # Mount list, default options, proxy
├── tasks/
│   ├── main.yml           # Orchestrator (validate → install → config → verify)
│   ├── validate.yml       # Pre-flight checks (list, fields, server connectivity)
│   ├── install.yml        # nfs-utils package + enable nfs-client.target
│   ├── config.yml         # Create dirs + mount (loop-based)
│   └── verify.yml         # df check + write test + summary
└── README.md              # This file
```

---

## Security Notes

- Mount points created as root:root mode `0755`
- NFS traffic is unencrypted by default (NFSv4 supports Kerberos if configured on server)
- `soft` mount option ensures a compromised/slow NFS server can't hang the entire host
- No secrets handled by this role
- The role does NOT configure the NFS server exports — that must be done separately

# MinIO Object Storage Role

Installs and configures [MinIO](https://min.io/) Community Edition — a high-performance S3-compatible object storage server. Supports single-node and distributed (erasure coding) deployments. Designed as a backup target for Longhorn volumes and general-purpose S3 storage.

**Note:** MinIO Community Edition's last release is `RELEASE.2025-09-07T16-13-09Z`. The upstream repo is archived. For actively maintained builds, see the `librefs` role.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **MinIO Server** | https://github.com/minio/minio/releases (archived) | `RELEASE.2025-09-07T16-13-09Z` |
| **mc Client** | https://github.com/minio/mc/releases (archived) | Check `version.minio.mc` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (`/apps`) | `ls -la /apps` |
| **Data disk** | Dedicated disk/mount recommended for data | `df -h /apps/minio_data` |
| **Network** | API + console ports reachable | `telnet <host> 61060` |
| **Proxy** | For dl.min.io download | `all_secrets.yml` |
| **Nodes (distributed)** | Minimum 4 nodes in host group | Check `hosts` file |

---

## How to Run

```bash
# Single-node deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/minio.yaml \
  --vault-password-file .vault

# Distributed deployment (4+ nodes)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/data_storage/minio.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=minio"
```

### Playbook Example

```yaml
- hosts: "{{ target_host | default('minio') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
    minio_host_group_name: "{{ target_host | default('minio') }}"
  roles:
    - { role: roles/data_storage/minio }
```

### Hosts File Example

```ini
# Single-node
[minio]
blp20919900  ansible_host=10.6.122.50

# Distributed (4-node erasure coding)
[minio]
blp20919900  ansible_host=10.6.122.50
blp20919901  ansible_host=10.6.122.51
blp20919902  ansible_host=10.6.122.52
blp20919903  ansible_host=10.6.122.53
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.minio.server` | `2025-09-07T16-13-09Z` | MinIO server release tag |
| `versions.yml` | `version.minio.mc` | `2025-08-13T08-35-41Z` | mc client release tag |
| `paths.yml` | `paths.minio.base_dir` | `/apps` | Install directory |
| `all_secrets.yml` | `minio_root_password_vault` | (vault encrypted) | Root password |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.minio.mode` | `single-node` | Deployment mode | `distributed` requires 4+ nodes |
| `config.minio.root_user` | `minioadmin` | S3 access key | |
| `config.minio.data_dir` | `/apps/minio_data` | Data directory (single-node) | |
| `config.minio.data_dirs` | `[data_dir]` | Data directories list | Multiple dirs for erasure within single node |
| `config.minio.listen_address` | `0.0.0.0` | Bind address | |
| `config.minio.console_enabled` | `true` | Web console on/off | |
| `config.minio.memory_limit` | `2G` | Systemd `MemoryMax` | |
| `config.minio.nofile_limit` | `65536` | Systemd `LimitNOFILE` | |
| `config.minio.buckets` | `['longhorn-backup']` | Auto-created buckets | |
| `config.minio.arch` | `linux-amd64` | Binary architecture | |
| `config.minio.download_timeout` | `120` | Download timeout (seconds) | MinIO binary is ~107MB |
| `ports.minio.api` | `61060` | S3 API port | |
| `ports.minio.console` | `61061` | Web console port | |

---

## Web Console (UI)

MinIO includes a built-in web management console, enabled by default on port `61061`.

**Features:**
- Browse and manage buckets and objects
- Create/delete buckets, upload/download files
- User and policy management
- Server health and performance monitoring
- Bucket lifecycle and replication settings

**Access:** `http://<host>:61061`
**Login:** Use the root credentials (`minioadmin` / vault password)

To disable the console, set `config.minio.console_enabled: false` in `app_configs.yml`.

---

## What Gets Installed

```
/apps/minio/
├── minio              # Server binary (single file, versioned by content)
└── mc                 # MinIO Client binary (for bucket management)

/apps/minio_data/      # Data directory (persistent)

/etc/minio/
└── minio.env          # Environment config (credentials, volumes, ports)

/etc/systemd/system/minio.service  # Systemd unit
```

---

## Task Execution Flow

```
main.yml
├── validate.yml         # Version, ports, base_dir, password, distributed node count
├── create_user.yml      # minio user/group (system, nologin)
├── pre_install.yml      # Version check from binary --version + stop if upgrade
├── install.yml          # Download server + mc binary, create data dirs, backup old
├── config.yml           # Environment file + systemd unit
├── service.yml          # daemon_reload + enable + start + conditional restart
├── verify.yml           # Service + API port + console port + /minio/health/live
├── cleanup.yml          # Remove backup binary after successful upgrade
└── buckets.yml          # Configure mc alias + create configured buckets
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status minio

# 2. Health check
curl -s http://localhost:61060/minio/health/live
# Expected: 200 OK

# 3. Cluster health (distributed mode)
curl -s http://localhost:61060/minio/health/cluster
# Expected: 200 OK

# 4. Console UI
# Open in browser: http://<host>:61061
# Login: minioadmin / <vault password>

# 5. List buckets via mc
/apps/minio/mc alias set local http://localhost:61060 minioadmin <password>
/apps/minio/mc ls local/

# 6. Test upload/download
echo "test" > /tmp/test.txt
/apps/minio/mc cp /tmp/test.txt local/longhorn-backup/test.txt
/apps/minio/mc cat local/longhorn-backup/test.txt
/apps/minio/mc rm local/longhorn-backup/test.txt
```

---

## Longhorn Integration

After MinIO is deployed, configure Longhorn to use it as backup target:

```yaml
# In Longhorn settings (via UI or kubectl)
backup-target: s3://longhorn-backup@us-east-1/
backup-target-credential-secret: minio-secret
```

Create the K8s secret on your cluster:
```bash
kubectl create secret generic minio-secret \
  --from-literal=AWS_ACCESS_KEY_ID=minioadmin \
  --from-literal=AWS_SECRET_ACCESS_KEY=<password> \
  --from-literal=AWS_ENDPOINTS=http://<minio-host>:61060 \
  -n longhorn-system
```

---

## Upgrade Process

1. Update `version.minio.server` (and optionally `version.minio.mc`) in `versions.yml`
2. Re-run playbook:
   - Detects version mismatch → stops service → backs up binary → downloads new → starts → verifies
   - Data directory is NEVER touched
3. If upgrade fails, backup binary exists at `/apps/minio/minio.bak` for manual rollback

---

## Troubleshooting

### Checking Logs

MinIO does **not** write log files by default — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u minio --no-pager -n 50

# Follow live
journalctl -u minio -f

# Errors only
journalctl -u minio -p err

# Since last boot
journalctl -u minio -b

# Specific time range
journalctl -u minio --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Service won't start
```bash
journalctl -u minio --no-pager -n 50
# Common: data dir permissions, port conflict, bad credentials in env file
```

### Distributed mode won't form cluster
```bash
# Check all nodes are reachable on API port
for ip in 10.6.122.50 10.6.122.51 10.6.122.52 10.6.122.53; do
  curl -s http://$ip:61060/minio/health/live && echo " OK: $ip" || echo " FAIL: $ip"
done
```

### Bucket creation fails
```bash
# Check mc alias is configured
/apps/minio/mc alias list local
# Test connectivity
/apps/minio/mc admin info local
```

---

## File Structure

```
roles/data_storage/minio/
├── defaults/main.yml              # All variables
├── handlers/main.yml              # restart minio
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks
│   ├── create_user.yml            # System user/group
│   ├── pre_install.yml            # Version check + stop
│   ├── install.yml                # Download server + mc binary
│   ├── cleanup.yml                # Remove backup after upgrade
│   ├── config.yml                 # Environment file + systemd
│   ├── service.yml                # Enable + start + conditional restart
│   ├── verify.yml                 # Health checks
│   └── buckets.yml                # Auto-create buckets via mc
├── templates/
│   ├── minio.env.j2              # Environment config (credentials, volumes, ports)
│   └── minio.service.j2          # Systemd unit
└── README.md                      # This file
```

---

### Service Account Access

The `minio` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as minio
su -s /bin/bash minio

# Run a single command as minio
su -s /bin/bash -c "whoami" minio
```

---

## Security Notes

- Service runs as unprivileged `minio` user
- Credentials stored in vault-encrypted secrets, deployed to `/etc/minio/minio.env` with mode `0640`
- `MemoryMax` prevents runaway memory usage
- `NoNewPrivileges=true` and `ProtectHome=true` in systemd unit
- Console UI has no auth bypass — requires root credentials
- No SSL by default (designed to run behind SSL-terminating proxy)
- Binary downloaded from official MinIO CDN (cert validation disabled for proxy compatibility)

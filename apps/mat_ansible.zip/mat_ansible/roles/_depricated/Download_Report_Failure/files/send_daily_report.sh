#!/bin/bash

HTML_REPORT="/tmp/download_report_failure.html"
PYTHON_SCRIPT="/opt/scripts/health_check_reporter.py"

FROM="$MAIL_FROM"
TO="$MAIL_TO"
SUBJECT="Download Report Failure – Last 24 Hours"

python3 $PYTHON_SCRIPT

# Send mail only if FAILED entries exist
if grep -q "Failed" "$HTML_REPORT"; then
sendmail -t <<EOF
From: $FROM
To: $TO
Subject: $SUBJECT
MIME-Version: 1.0
Content-Type: text/html

$(cat $HTML_REPORT)
EOF
fi
#!/usr/bin/env python3

import os
import mysql.connector

OUTPUT_FILE = "/tmp/download_report_failure.html"

def get_failed_reports():
    conn = mysql.connector.connect(
        host=os.environ["DB_HOST"],
        port=int(os.environ.get("DB_PORT", 3306)),
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"]
    )

    cursor = conn.cursor(dictionary=True)

    query = """
    SELECT
        service_name AS report_name,
        report_date,
        vendor,
        granularity,
        report_status,
        user_ein,
        report_id
    FROM REPORT_DOWNLOAD_DATA
    WHERE report_status = 'Failed'
      AND report_date >= NOW() - INTERVAL 1 DAY
    ORDER BY report_date DESC;
    """

    cursor.execute(query)
    data = cursor.fetchall()

    cursor.close()
    conn.close()
    return data


def generate_html(data):
    html = """
    <html>
    <body>
    <h3>Download Report Failure – Last 24 Hours</h3>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr style="background-color:#f2f2f2">
            <th>Report Name</th>
            <th>Report Date & Time</th>
            <th>Vendor</th>
            <th>Granularity</th>
            <th>Status</th>
            <th>User EIN</th>
            <th>Report ID</th>
        </tr>
    """

    if not data:
        html += """
        <tr>
            <td colspan="7" align="center">
                No failed reports found in last 24 hours
            </td>
        </tr>
        """
    else:
        for row in data:
            html += f"""
            <tr>
                <td>{row['report_name']}</td>
                <td>{row['report_date']}</td>
                <td>{row['vendor']}</td>
                <td>{row['granularity']}</td>
                <td style="color:red;font-weight:bold">{row['report_status']}</td>
                <td>{row['user_ein']}</td>
                <td>{row['report_id']}</td>
            </tr>
            """

    html += """
    </table>
    </body>
    </html>
    """

    with open(OUTPUT_FILE, "w") as f:
        f.write(html)


if __name__ == "__main__":
    failed_reports = get_failed_reports()
    generate_html(failed_reports)
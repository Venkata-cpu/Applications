#!/bin/bash

# Full path to pgrep and ionice
PGREP=/usr/bin/pgrep
IONICE=/usr/bin/ionice

# Find all PIDs of processes matching 'logmon'
pids=$($PGREP -f logmon)

# Loop through each PID and set I/O priority to idle class
for pid in $pids; do
    echo "Setting I/O priority for PID $pid to idle class..."
    $IONICE -c3 -p $pid
done

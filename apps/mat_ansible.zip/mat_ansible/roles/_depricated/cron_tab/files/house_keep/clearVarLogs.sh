echo "Staring script $(date +"%d-%m-%y %H:%M")"
cd /var/log
rm -rf *.log-*
rm -rf messages-202*.gz
rm -rf vmware-vmsvc-root.*.log
rm -rf sssd/*.log-*
truncate -s 0 messages-202*
truncate -s 0 warn
truncate -s 0 sssd/sssd_nss.log
truncate -s 0 sssd/sssd_iuser.iroot.adidom.com.log
truncate -s 0 sssd/ldap_child.log
echo "Script complete $(date +"%d-%m-%y %H:%M")"
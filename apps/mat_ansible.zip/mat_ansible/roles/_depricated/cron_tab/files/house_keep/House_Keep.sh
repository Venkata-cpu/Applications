#!/bin/bash

CONFIG_FILE="/apps/script/House_keep_input.txt"

if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "Config file '$CONFIG_FILE' not found!"
  exit 1
fi

while IFS=',' read -r FOLDER RETENTION MAX_DEPTH PATTERN; do
  # Skip empty lines and comments
  [[ -z "$FOLDER" || "$FOLDER" =~ ^# ]] && continue

  echo "Processing: Folder=$FOLDER | Retention=$RETENTION days | Depth=$MAX_DEPTH | Pattern=$PATTERN"

  if [[ -d "$FOLDER" ]]; then
    find "$FOLDER" -type f -name "$PATTERN" -mtime +"$RETENTION" -maxdepth "$MAX_DEPTH" -print -exec rm -f {} \;
  else
    echo "Warning: Folder '$FOLDER' does not exist. Skipping."
  fi

done < <(cat "$CONFIG_FILE"; echo)


echo "Cleanup process completed."

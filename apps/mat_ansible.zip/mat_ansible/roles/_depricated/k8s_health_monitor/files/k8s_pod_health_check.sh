#!/bin/bash
# Kubernetes Pod Health Check Script - Remote execution

REPORT_FILE="/tmp/k8s_pod_health_report.txt"
NAMESPACE="ran-preprod"
RESTART_THRESHOLD=3
LOG_FILE="/opt/health_check_reporter/logs/k8s_check.log"
K8S_MASTER="blp20919615"

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

echo "$(date): Starting Kubernetes health check via SSH to $K8S_MASTER" >> "$LOG_FILE"

# Clear previous report
> "$REPORT_FILE"

# Execute kubectl commands on K8s master server via SSH
ssh root@$K8S_MASTER << 'EOF' > "$REPORT_FILE" 2>>"$LOG_FILE"
NAMESPACE="ran-preprod"
RESTART_THRESHOLD=3

# Get Warning events with specific issue patterns
kubectl get events -n "$NAMESPACE" --sort-by=.lastTimestamp | \
  awk '
    BEGIN {IGNORECASE=1}
    NR>1 {
      type=$3
      reason=$4
      if (type=="Warning" && (reason ~ /CrashLoopBackOff|BackOff|Evicted|ImagePullBackOff|ErrImagePull|OOMKilled/)) {
          pod_name=$5
          gsub(/.*\//, "", pod_name)
          if (pod_name != "") {
              print pod_name
          }
      }
    }' | sort -u | \
while read -r pod_name; do
    if [[ -n "$pod_name" ]]; then
        pod_info=$(kubectl get pod "$pod_name" -n "$NAMESPACE" -o wide --no-headers 2>/dev/null)
        if [[ -n "$pod_info" ]]; then
            read -r name ready status restarts age ip node nominated readiness <<< "$pod_info"
            restart_count=$(echo "$restarts" | cut -d' ' -f1)
            echo "$name|$NAMESPACE|$status|$node|$restart_count|RecentEvent"
        fi
    fi
done

# Get all currently unhealthy pods
kubectl get pods -n "$NAMESPACE" --field-selector=status.phase!=Running,status.phase!=Succeeded -o wide --no-headers 2>/dev/null | \
while read -r name ready status restarts age ip node nominated readiness; do
    if [[ -n "$name" ]]; then
        restart_count=$(echo "$restarts" | cut -d' ' -f1)
        echo "$name|$NAMESPACE|$status|$node|$restart_count|CurrentlyUnhealthy"
    fi
done

# Check for pods with high restart counts
kubectl get pods -n "$NAMESPACE" -o wide --no-headers 2>/dev/null | \
while read -r name ready status restarts age ip node nominated readiness; do
    if [[ -n "$name" ]]; then
        restart_count=$(echo "$restarts" | cut -d' ' -f1)
        if [[ "$restart_count" -gt "$RESTART_THRESHOLD" ]]; then
            echo "$name|$NAMESPACE|$status|$node|$restart_count|HighRestarts"
        fi
    fi
done
EOF

# Remove duplicates
sort -u "$REPORT_FILE" -o "$REPORT_FILE"

# Check results
if [[ -s "$REPORT_FILE" ]] && ! grep -q "No issues found" "$REPORT_FILE"; then
    echo "$(date): Found $(wc -l < "$REPORT_FILE") issues in $NAMESPACE" >> "$LOG_FILE"
    exit 1
else
    echo "$(date): No issues found in $NAMESPACE" >> "$LOG_FILE"
    echo "No issues found" > "$REPORT_FILE"
    exit 0
fi
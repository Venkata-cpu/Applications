#!/bin/bash

# Optimized Status Report - Fixes timeout issues
# Minimal implementation with fast timeouts and parallel processing

SCRIPT_DIR="/apps/status_monitoring/scripts"
LOG_DIR="/apps/status_monitoring/logs"
REPORT_DIR="/apps/status_monitoring/reports"
REPORT_LOG="$LOG_DIR/status_report.log"

# Email configuration
EMAILS=("asritha.2.meka@bt.com")
SUBJECT="Consolidated Counter Restart Report - All Servers"

# Server IPs
declare -A SERVER_IPS=(
    ["blp20919390"]="10.54.106.76"
    ["blp20919391"]="10.54.106.77"
    ["blp20919407"]="10.54.106.78"
    ["blp20919408"]="10.54.106.79"
    ["blp20919409"]="10.54.106.80"
    ["blp20919904"]="10.6.103.172"
    ["blp20919905"]="10.6.103.173"
    ["blp20919906"]="10.6.103.174"
    ["blp20919907"]="10.6.103.175"
    ["blp20919908"]="10.6.103.176"
    ["blp20919909"]="10.6.103.177"
    ["blp20919910"]="10.6.103.178"
)

SERVERS=("${!SERVER_IPS[@]}")
SERVICES=("kafka" "zookeeper" "druid-coordinator" "druid-broker" "druid-historical")
CURRENT_TIME=$(date '+%Y-%m-%d %H:%M:%S GMT')

# Fast service status check with 3-second timeout
get_service_status() {
    local server=$1
    local service=$2
    local server_ip="${SERVER_IPS[$server]}"
    
    if [[ "$server" == "$(hostname)" ]] || [[ "$server" == "blp20919390" ]]; then
        local status=$(systemctl is-active "$service" 2>/dev/null)
        local restart_count=$(systemctl show "$service" --property=NRestarts --value 2>/dev/null)
    else
        local status=$(timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server_ip" "systemctl is-active '$service'" 2>/dev/null)
        local restart_count=$(timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server_ip" "systemctl show '$service' --property=NRestarts --value" 2>/dev/null)
    fi
    
    echo "$status|$restart_count"
}

# Generate HTML report
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
th { background-color: #f2f2f2; }
.ok { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
</style>
</head>
<body>
<h2>🖥️ Consolidated Counter Restart Report - All Servers</h2>
<h3>🔍 Detailed Service Status by Server</h3>
<table>
<tr><th>Server</th><th>Service</th><th>Restart Count</th><th>Status</th><th>Last Check</th></tr>"

echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting optimized status report" >> "$REPORT_LOG"

for server in "${SERVERS[@]}"; do
    SERVER_IP="${SERVER_IPS[$server]}"
    
    # Quick ping check with 1-second timeout
    if ! timeout 1 ping -c 1 "$SERVER_IP" &>/dev/null; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Server $server unreachable" >> "$REPORT_LOG"
        for service in "${SERVICES[@]}"; do
            HTML_CONTENT+="<tr><td>$server</td><td>$service</td><td>-</td><td class='error'>❌ SERVER UNREACHABLE</td><td>$CURRENT_TIME</td></tr>"
        done
        continue
    fi
    
    # Check services
    for service in "${SERVICES[@]}"; do
        SERVICE_INFO=$(get_service_status "$server" "$service")
        IFS='|' read -r STATUS RESTART_COUNT <<< "$SERVICE_INFO"
        
        if [[ "$STATUS" == "active" ]]; then
            STATUS_DISPLAY="<span class='ok'>✅ OK</span>"
            RESTART_DISPLAY="${RESTART_COUNT:-0}"
        else
            STATUS_DISPLAY="<span class='error'>❌ DOWN</span>"
            RESTART_DISPLAY="-"
        fi
        
        HTML_CONTENT+="<tr><td>$server</td><td>$service</td><td>$RESTART_DISPLAY</td><td>$STATUS_DISPLAY</td><td>$CURRENT_TIME</td></tr>"
        echo "$(date '+%Y-%m-%d %H:%M:%S') - $server:$service = $STATUS" >> "$REPORT_LOG"
    done
done

HTML_CONTENT+="</table></body></html>"

# Save and send report
REPORT_FILE="$REPORT_DIR/status_report_$(date '+%Y%m%d_%H%M%S').html"
echo "$HTML_CONTENT" > "$REPORT_FILE"

for email in "${EMAILS[@]}"; do
    {
        echo "To: $email"
        echo "Subject: $SUBJECT"
        echo "MIME-Version: 1.0"
        echo "Content-Type: text/html; charset=UTF-8"
        echo ""
        echo "$HTML_CONTENT"
    } | /usr/sbin/sendmail "$email" 2>/dev/null
done

echo "Optimized status report completed and sent."
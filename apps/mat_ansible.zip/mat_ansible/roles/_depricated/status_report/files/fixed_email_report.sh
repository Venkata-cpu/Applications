#!/bin/bash

# Smart email report - only sends if there are reachable servers with issues
EMAIL="asritha.2.meka@bt.com"
SUBJECT="Service Status Alert - Reachable Servers Only"
TEMP_REPORT="/tmp/smart_status_$(date '+%Y%m%d_%H%M%S').html"

SERVERS="blp20919390 blp20919391 blp20919407 blp20919408 blp20919409 blp20919904 blp20919905 blp20919906 blp20919907 blp20919908 blp20919909 blp20919910"
SERVICES="kafka zookeeper druid-coordinator druid-broker druid-historical"

REACHABLE_COUNT=0
ISSUES_FOUND=0

# Create HTML report
cat > "$TEMP_REPORT" << 'EOF'
<!DOCTYPE html>
<html><head><style>
body { font-family: Arial; margin: 20px; }
.ok { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
table { border-collapse: collapse; width: 100%; }
th, td { border: 1px solid #ddd; padding: 8px; }
th { background-color: #f2f2f2; }
</style></head><body>
<h2>🖥️ Service Status Report</h2>
<p><strong>Generated:</strong> $(date)</p>
EOF

# Check each server
for server in $SERVERS; do
    if ping -c 1 -W 1 "$server" >/dev/null 2>&1 && timeout 2 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server" "echo test" >/dev/null 2>&1; then
        REACHABLE_COUNT=$((REACHABLE_COUNT + 1))
        
        echo "<h3>✅ $server (Reachable)</h3><table><tr><th>Service</th><th>Status</th></tr>" >> "$TEMP_REPORT"
        
        for service in $SERVICES; do
            if ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server" "systemctl is-active $service" >/dev/null 2>&1; then
                echo "<tr><td>$service</td><td class='ok'>✅ OK</td></tr>" >> "$TEMP_REPORT"
            else
                echo "<tr><td>$service</td><td class='error'>❌ FAILED</td></tr>" >> "$TEMP_REPORT"
                ISSUES_FOUND=$((ISSUES_FOUND + 1))
            fi
        done
        echo "</table>" >> "$TEMP_REPORT"
    fi
done

echo "<p><strong>Summary:</strong> $REACHABLE_COUNT servers reachable, $ISSUES_FOUND service issues found</p>" >> "$TEMP_REPORT"
echo "</body></html>" >> "$TEMP_REPORT"

# Only send email if there are reachable servers
if [ $REACHABLE_COUNT -gt 0 ]; then
    if command -v mail >/dev/null 2>&1; then
        mail -s "$SUBJECT" -a "Content-Type: text/html" "$EMAIL" < "$TEMP_REPORT"
        echo "Smart email sent to $EMAIL ($REACHABLE_COUNT servers, $ISSUES_FOUND issues)"
    else
        echo "Mail command not available"
    fi
else
    echo "No reachable servers found - email not sent"
fi

rm -f "$TEMP_REPORT"
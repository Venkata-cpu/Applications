#!/bin/bash

# Application Status Check Script
# Checks application-specific health endpoints and metrics

APP_NAME="$1"
SERVER_IP="$2"

if [[ -z "$APP_NAME" ]]; then
    echo "Usage: $0 <app_name> [server_ip]"
    exit 1
fi

# Function to check HTTP endpoint
check_http_endpoint() {
    local url="$1"
    local timeout="${2:-10}"
    
    local response=$(curl -s -w "%{http_code}" -m "$timeout" "$url" 2>/dev/null)
    local http_code="${response: -3}"
    local body="${response%???}"
    
    if [[ "$http_code" == "200" ]]; then
        echo "UP"
    else
        echo "DOWN"
    fi
}

# Application-specific health checks
case "$APP_NAME" in
    "kafka")
        # Check Kafka JMX port
        if nc -z "${SERVER_IP:-localhost}" 9999 2>/dev/null; then
            echo "UP"
        else
            echo "DOWN"
        fi
        ;;
    "druid-broker")
        # Check Druid broker health
        check_http_endpoint "http://${SERVER_IP:-localhost}:8082/status/health"
        ;;
    "druid-coordinator")
        # Check Druid coordinator health
        check_http_endpoint "http://${SERVER_IP:-localhost}:8081/status/health"
        ;;
    "elasticsearch")
        # Check Elasticsearch health
        check_http_endpoint "http://${SERVER_IP:-localhost}:9200/_cluster/health"
        ;;
    "grafana")
        # Check Grafana health
        check_http_endpoint "http://${SERVER_IP:-localhost}:3000/api/health"
        ;;
    "clickhouse-server")
        # Check ClickHouse HTTP interface
        check_http_endpoint "http://${SERVER_IP:-localhost}:8123/ping"
        ;;
    *)
        # Default: check if service is active
        systemctl is-active "$APP_NAME" 2>/dev/null
        ;;
esac
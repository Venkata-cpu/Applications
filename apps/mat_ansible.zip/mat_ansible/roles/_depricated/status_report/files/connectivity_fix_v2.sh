#!/bin/bash

# Enhanced connectivity checker with detailed diagnostics
SERVERS="blp20919390 blp20919391 blp20919407 blp20919408 blp20919409 blp20919904 blp20919905 blp20919906 blp20919907 blp20919908 blp20919909 blp20919910"

echo "=== Server Connectivity Analysis ==="
echo "Timestamp: $(date)"

REACHABLE=0
UNREACHABLE=0

for server in $SERVERS; do
    echo "Testing $server..."
    
    # Test DNS
    if ! nslookup "$server" >/dev/null 2>&1; then
        echo "  ❌ DNS resolution failed"
        UNREACHABLE=$((UNREACHABLE + 1))
        continue
    fi
    
    # Test ping with very short timeout
    if ping -c 1 -W 1 "$server" >/dev/null 2>&1; then
        echo "  ✅ Ping successful"
        
        # Test SSH
        if timeout 2 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server" "echo 'test'" >/dev/null 2>&1; then
            echo "  ✅ SSH successful"
            REACHABLE=$((REACHABLE + 1))
        else
            echo "  ❌ SSH failed (but ping works)"
            UNREACHABLE=$((UNREACHABLE + 1))
        fi
    else
        echo "  ❌ Ping failed"
        UNREACHABLE=$((UNREACHABLE + 1))
    fi
    echo
done

echo "=== Summary ==="
echo "Reachable servers: $REACHABLE"
echo "Unreachable servers: $UNREACHABLE"

if [ $UNREACHABLE -gt 0 ]; then
    echo
    echo "=== Troubleshooting Steps ==="
    echo "1. Check if servers are in different network segments"
    echo "2. Verify firewall rules allow SSH (port 22)"
    echo "3. Check if SSH keys are properly configured"
    echo "4. Verify network routing between runner and target servers"
fi
#!/bin/bash

EMAIL="asritha.2.meka@bt.com"
SUBJECT="Service Status Report - Reachable Servers Only"
TEMP_REPORT="/tmp/filtered_status_$(date '+%Y%m%d_%H%M%S').html"

# Generate filtered report with only reachable servers
cat > "$TEMP_REPORT" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .summary { background-color: #e8f5e8; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .unreachable { background-color: #ffe8e8; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .ok { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h2>🖥️ Service Status Report</h2>
        <p><strong>Generated:</strong> $(date)</p>
    </div>
EOF

# Check reachable servers and their services
REACHABLE_COUNT=0
UNREACHABLE_COUNT=0
REACHABLE_SERVERS=""
UNREACHABLE_SERVERS=""

SERVERS="blp20919390 blp20919391 blp20919407 blp20919408 blp20919409 blp20919904 blp20919905 blp20919906 blp20919907 blp20919908 blp20919909 blp20919910"

for server in $SERVERS; do
    if ping -c 1 -W 2 "$server" >/dev/null 2>&1; then
        REACHABLE_COUNT=$((REACHABLE_COUNT + 1))
        REACHABLE_SERVERS="$REACHABLE_SERVERS $server"
    else
        UNREACHABLE_COUNT=$((UNREACHABLE_COUNT + 1))
        UNREACHABLE_SERVERS="$UNREACHABLE_SERVERS $server"
    fi
done

# Add summary
cat >> "$TEMP_REPORT" << EOF
    <div class="summary">
        <h3>📊 Summary</h3>
        <p><strong>Reachable Servers:</strong> $REACHABLE_COUNT</p>
        <p><strong>Unreachable Servers:</strong> $UNREACHABLE_COUNT</p>
    </div>
EOF

# Add reachable servers section
if [ $REACHABLE_COUNT -gt 0 ]; then
    cat >> "$TEMP_REPORT" << 'EOF'
    <h3>✅ Reachable Servers - Service Status</h3>
    <table>
        <tr><th>Server</th><th>Service</th><th>Status</th><th>Restart Count</th></tr>
EOF

    for server in $REACHABLE_SERVERS; do
        SERVICES="kafka zookeeper druid-coordinator druid-broker druid-historical"
        for service in $SERVICES; do
            if ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no "$server" "systemctl is-active $service" >/dev/null 2>&1; then
                RESTART_COUNT=$(ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no "$server" "systemctl show $service --property=NRestarts --value" 2>/dev/null || echo "0")
                cat >> "$TEMP_REPORT" << EOF
        <tr><td>$server</td><td>$service</td><td class="ok">✅ OK</td><td>$RESTART_COUNT</td></tr>
EOF
            else
                cat >> "$TEMP_REPORT" << EOF
        <tr><td>$server</td><td>$service</td><td class="error">❌ FAILED</td><td>-</td></tr>
EOF
            fi
        done
    done

    echo "    </table>" >> "$TEMP_REPORT"
fi

# Add unreachable servers section
if [ $UNREACHABLE_COUNT -gt 0 ]; then
    cat >> "$TEMP_REPORT" << 'EOF'
    <div class="unreachable">
        <h3>❌ Unreachable Servers</h3>
        <p>The following servers are not responding to ping:</p>
        <ul>
EOF
    for server in $UNREACHABLE_SERVERS; do
        echo "            <li>$server</li>" >> "$TEMP_REPORT"
    done
    cat >> "$TEMP_REPORT" << 'EOF'
        </ul>
    </div>
EOF
fi

# Close HTML
cat >> "$TEMP_REPORT" << 'EOF'
</body>
</html>
EOF

# Send email
if command -v mail >/dev/null 2>&1; then
    mail -s "$SUBJECT" -a "Content-Type: text/html" "$EMAIL" < "$TEMP_REPORT"
    echo "Filtered email sent to $EMAIL"
else
    echo "Mail command not available"
fi

# Cleanup
rm -f "$TEMP_REPORT"
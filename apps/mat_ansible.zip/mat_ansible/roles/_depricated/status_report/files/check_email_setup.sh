#!/bin/bash

echo "=== Email System Diagnostics ==="
echo "Server: $(hostname)"
echo "Date: $(date)"
echo

echo "=== Mail Command Check ==="
if command -v mail >/dev/null 2>&1; then
    echo "✅ mail command available"
else
    echo "❌ mail command not found"
fi

echo "=== Sendmail Check ==="
if command -v sendmail >/dev/null 2>&1; then
    echo "✅ sendmail available"
else
    echo "❌ sendmail not found"
fi

echo "=== Postfix Check ==="
if systemctl is-active postfix >/dev/null 2>&1; then
    echo "✅ postfix service active"
else
    echo "❌ postfix service not active"
fi

echo "=== Mail Logs ==="
if [ -f /var/log/maillog ]; then
    echo "Recent mail log entries:"
    tail -5 /var/log/maillog 2>/dev/null || echo "No recent mail logs"
else
    echo "❌ No mail log file found"
fi

echo "=== Test Simple Email ==="
echo "Test email from $(hostname)" | mail -s "Test from $(hostname)" asritha.2.meka@bt.com 2>&1 || echo "❌ Mail send failed"
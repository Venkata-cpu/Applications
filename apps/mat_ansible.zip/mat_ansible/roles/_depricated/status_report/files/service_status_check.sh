#!/bin/bash

# Service Status Check Script
# Checks individual service status and returns structured data

SERVICE_NAME="$1"
if [[ -z "$SERVICE_NAME" ]]; then
    echo "Usage: $0 <service_name>"
    exit 1
fi

# Get service information
STATUS=$(systemctl is-active "$SERVICE_NAME" 2>/dev/null)
ENABLED=$(systemctl is-enabled "$SERVICE_NAME" 2>/dev/null)
RESTART_COUNT=$(systemctl show "$SERVICE_NAME" --property=NRestarts --value 2>/dev/null)
UPTIME=$(systemctl show "$SERVICE_NAME" --property=ActiveEnterTimestamp --value 2>/dev/null)
MEMORY=$(systemctl show "$SERVICE_NAME" --property=MemoryCurrent --value 2>/dev/null)
CPU_TIME=$(systemctl show "$SERVICE_NAME" --property=CPUUsageNSec --value 2>/dev/null)

# Output structured data
echo "SERVICE:$SERVICE_NAME"
echo "STATUS:$STATUS"
echo "ENABLED:$ENABLED"
echo "RESTARTS:$RESTART_COUNT"
echo "UPTIME:$UPTIME"
echo "MEMORY:$MEMORY"
echo "CPU_TIME:$CPU_TIME"
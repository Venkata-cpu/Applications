#!/bin/bash

echo "=== Network Diagnostics Report ==="
echo "Generated: $(date)"
echo "Runner IP: $(hostname -I | awk '{print $1}')"
echo

SERVERS="blp20919390 blp20919391 blp20919407 blp20919408 blp20919409 blp20919904 blp20919905 blp20919906 blp20919907 blp20919908 blp20919909 blp20919910"

echo "=== DNS Resolution Test ==="
for server in $SERVERS; do
    if nslookup "$server" >/dev/null 2>&1; then
        IP=$(nslookup "$server" | grep -A1 "Name:" | tail -1 | awk '{print $2}')
        echo "✅ $server -> $IP"
    else
        echo "❌ $server -> DNS FAILED"
    fi
done

echo
echo "=== Ping Test (2 second timeout) ==="
for server in $SERVERS; do
    if ping -c 1 -W 2 "$server" >/dev/null 2>&1; then
        echo "✅ $server -> PING OK"
    else
        echo "❌ $server -> PING FAILED"
    fi
done

echo
echo "=== SSH Test (3 second timeout) ==="
for server in $SERVERS; do
    if timeout 3 ssh -o ConnectTimeout=3 -o StrictHostKeyChecking=no "$server" "echo 'SSH OK'" >/dev/null 2>&1; then
        echo "✅ $server -> SSH OK"
    else
        echo "❌ $server -> SSH FAILED"
    fi
done

echo
echo "=== Network Route Test ==="
echo "Default gateway: $(ip route | grep default | awk '{print $3}')"
echo "Network interfaces:"
ip addr show | grep -E "inet.*scope global" | awk '{print $2, $NF}'
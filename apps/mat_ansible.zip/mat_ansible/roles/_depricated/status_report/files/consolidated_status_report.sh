#!/bin/bash

# Consolidated Service Status Report - All Servers
# Generates comprehensive status report including service status, uptime, and restart counters

SCRIPT_DIR="/apps/status_monitoring/scripts"
LOG_DIR="/apps/status_monitoring/logs"
REPORT_DIR="/apps/status_monitoring/reports"
REPORT_LOG="$LOG_DIR/status_report.log"

# Email configuration
EMAILS=("asritha.2.meka@bt.com")
SUBJECT="Service Status Report"

# All servers to monitor with their IP addresses
declare -A SERVER_IPS=(
    ["blp20919390"]="10.54.106.76"
    ["blp20919391"]="10.54.106.77"
    ["blp20919407"]="10.54.106.78"
    ["blp20919408"]="10.54.106.79"
    ["blp20919409"]="10.54.106.80"
    ["blp20919904"]="10.6.103.172"
    ["blp20919905"]="10.6.103.173"
    ["blp20919906"]="10.6.103.174"
    ["blp20919907"]="10.6.103.175"
    ["blp20919908"]="10.6.103.176"
    ["blp20919909"]="10.6.103.177"
    ["blp20919910"]="10.6.103.178"
)

SERVERS=("${!SERVER_IPS[@]}")

# Services to monitor
SERVICES=("kafka" "zookeeper" "druid-coordinator" "druid-broker" "druid-historical" "clickhouse-server" "elasticsearch" "grafana")
RESTART_THRESHOLD=5

# Get current date and time
CURRENT_TIME=$(date '+%Y-%m-%d %H:%M:%S %Z')
REPORT_FILE="$REPORT_DIR/status_report_$(date '+%Y%m%d_%H%M%S').html"

# Initialize counters
TOTAL_SERVERS=${#SERVERS[@]}
TOTAL_SERVICES=$((${#SERVERS[@]} * ${#SERVICES[@]}))
NORMAL_COUNT=0
HIGH_RESTARTS_COUNT=0
ERROR_COUNT=0
UP_SERVICES=0
DOWN_SERVICES=0

# Function to get service status
get_service_status() {
    local server=$1
    local service=$2
    local server_ip="${SERVER_IPS[$server]}"
    
    if [[ "$server" == "$(hostname)" ]] || [[ "$server" == "blp20919390" ]]; then
        # Local execution
        local status=$(systemctl is-active "$service" 2>/dev/null)
        local restart_count=$(systemctl show "$service" --property=NRestarts --value 2>/dev/null)
        local uptime=$(systemctl show "$service" --property=ActiveEnterTimestamp --value 2>/dev/null)
    else
        # SSH to remote server with 3-second timeout
        local status=$(timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server_ip" "systemctl is-active '$service'" 2>/dev/null)
        local restart_count=$(timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server_ip" "systemctl show '$service' --property=NRestarts --value" 2>/dev/null)
        local uptime=$(timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server_ip" "systemctl show '$service' --property=ActiveEnterTimestamp --value" 2>/dev/null)
    fi
    
    echo "$status|$restart_count|$uptime"
}

# Function to calculate uptime duration
calculate_uptime() {
    local timestamp="$1"
    if [[ -z "$timestamp" ]] || [[ "$timestamp" == "n/a" ]]; then
        echo "Unknown"
        return
    fi
    
    local start_time=$(date -d "$timestamp" +%s 2>/dev/null)
    local current_time=$(date +%s)
    
    if [[ -z "$start_time" ]]; then
        echo "Unknown"
        return
    fi
    
    local diff=$((current_time - start_time))
    local days=$((diff / 86400))
    local hours=$(((diff % 86400) / 3600))
    local minutes=$(((diff % 3600) / 60))
    
    if [[ $days -gt 0 ]]; then
        echo "${days}d ${hours}h ${minutes}m"
    elif [[ $hours -gt 0 ]]; then
        echo "${hours}h ${minutes}m"
    else
        echo "${minutes}m"
    fi
}

# Create HTML report header
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .header { background-color: #2c3e50; color: white; padding: 20px; text-align: center; border-radius: 8px; margin-bottom: 20px; }
        .summary { background-color: #ecf0f1; padding: 20px; margin: 15px 0; border-radius: 8px; }
        .summary-box { display: inline-block; margin: 10px; padding: 15px; border-radius: 8px; text-align: center; min-width: 100px; }
        .normal-box { background-color: #d5f4e6; border: 2px solid #27ae60; }
        .high-box { background-color: #fadbd8; border: 2px solid #e74c3c; }
        .error-box { background-color: #f8d7da; border: 2px solid #dc3545; }
        .details-section { background-color: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; font-size: 13px; }
        th { background-color: #34495e; color: white; }
        .status-up { color: #27ae60; font-weight: bold; }
        .status-down { color: #e74c3c; font-weight: bold; }
        .status-error { color: #dc3545; font-weight: bold; }
        .restart-normal { color: #f39c12; }
        .restart-high { color: #e74c3c; font-weight: bold; }
        .server-name { background-color: #f8f9fa; font-weight: bold; }
        .footer { margin-top: 30px; font-size: 12px; color: #7f8c8d; text-align: center; }
        .metric-value { font-size: 28px; font-weight: bold; }
        .metric-label { font-size: 14px; margin-top: 5px; }
    </style>
</head>
<body>
    <div class='header'>
        <h2>🖥️ Service Status Report</h2>
        <p>All Servers | Time: $CURRENT_TIME</p>
    </div>
    
    <div class='summary'>
        <h3>📊 Overall Summary</h3>
        <div class='summary-box normal-box'>
            <div class='metric-value' id='normal-count'>0</div>
            <div class='metric-label'>NORMAL</div>
        </div>
        <div class='summary-box high-box'>
            <div class='metric-value' id='high-count'>0</div>
            <div class='metric-label'>HIGH RESTARTS</div>
        </div>
        <div class='summary-box error-box'>
            <div class='metric-value' id='error-count'>0</div>
            <div class='metric-label'>ERRORS</div>
        </div>
        <p><strong>Total Servers:</strong> $TOTAL_SERVERS | <strong>Total Services:</strong> $TOTAL_SERVICES</p>
    </div>
    
    <div class='details-section'>
        <h3>🔍 Detailed Service Status by Server</h3>
        <table>
            <tr>
                <th>App Running Status</th>
                <th>Up Time</th>
                <th>Application restarts</th>
                <th>Current Tag</th>
            </tr>"

# Collect data from all servers
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting consolidated status report collection" >> "$REPORT_LOG"

for server in "${SERVERS[@]}"; do
    echo "Collecting status data from $server..."
    SERVER_IP="${SERVER_IPS[$server]}"
    
    # Check if server is reachable with 2-second timeout
    if ! timeout 2 ping -c 1 "$SERVER_IP" &>/dev/null; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') - Server $server unreachable" >> "$REPORT_LOG"
        for service in "${SERVICES[@]}"; do
            HTML_CONTENT+="
            <tr>
                <td class='server-name'>$server - $service</td>
                <td>-</td>
                <td><span class='status-error'>❌ SERVER UNREACHABLE</span></td>
                <td>-</td>
            </tr>"
            ((ERROR_COUNT++))
        done
        continue
    fi
    
    # Get service status for each service
    for service in "${SERVICES[@]}"; do
        SERVICE_INFO=$(get_service_status "$server" "$service")
        IFS='|' read -r STATUS RESTART_COUNT UPTIME_TIMESTAMP <<< "$SERVICE_INFO"
        
        # Calculate uptime
        UPTIME_DURATION=$(calculate_uptime "$UPTIME_TIMESTAMP")
        
        # Determine status and styling
        if [[ "$STATUS" == "active" ]]; then
            STATUS_DISPLAY="<span class='status-up'>✅ UP</span>"
            ((UP_SERVICES++))
            
            # Check restart count
            if [[ -n "$RESTART_COUNT" ]] && [[ "$RESTART_COUNT" =~ ^[0-9]+$ ]]; then
                if [[ $RESTART_COUNT -gt $RESTART_THRESHOLD ]]; then
                    RESTART_DISPLAY="<span class='restart-high'>$RESTART_COUNT</span>"
                    ((HIGH_RESTARTS_COUNT++))
                elif [[ $RESTART_COUNT -gt 0 ]]; then
                    RESTART_DISPLAY="<span class='restart-normal'>$RESTART_COUNT</span>"
                    ((NORMAL_COUNT++))
                else
                    RESTART_DISPLAY="0"
                fi
            else
                RESTART_DISPLAY="N/A"
            fi
        elif [[ "$STATUS" == "inactive" ]] || [[ "$STATUS" == "failed" ]]; then
            STATUS_DISPLAY="<span class='status-down'>❌ DOWN</span>"
            RESTART_DISPLAY="N/A"
            UPTIME_DURATION="N/A"
            ((DOWN_SERVICES++))
            ((ERROR_COUNT++))
        else
            STATUS_DISPLAY="<span class='status-error'>❓ UNKNOWN</span>"
            RESTART_DISPLAY="N/A"
            UPTIME_DURATION="N/A"
            ((ERROR_COUNT++))
        fi
        
        # Add row to HTML table
        HTML_CONTENT+="
        <tr>
            <td class='server-name'>$server - $service</td>
            <td>$UPTIME_DURATION</td>
            <td>$RESTART_DISPLAY</td>
            <td>latest</td>
        </tr>"
        
        echo "$(date '+%Y-%m-%d %H:%M:%S') - $server:$service = $STATUS (restarts: $RESTART_COUNT)" >> "$REPORT_LOG"
    done
done

# Complete HTML content
HTML_CONTENT+="
        </table>
    </div>
    
    <div class='footer'>
        <p>📧 This is an automated consolidated status report from Service Monitoring System</p>
        <p>🔄 Next check: Tomorrow at 9:00 AM GMT</p>
        <p>⚠️ HIGH status indicates restart count above threshold ($RESTART_THRESHOLD)</p>
        <p>🔍 Investigate services with HIGH restart counts or DOWN status immediately</p>
        <p>❌ ERROR indicates server unreachable or service check failed</p>
    </div>
    
    <script>
        document.getElementById('normal-count').textContent = '$NORMAL_COUNT';
        document.getElementById('high-count').textContent = '$HIGH_RESTARTS_COUNT';
        document.getElementById('error-count').textContent = '$ERROR_COUNT';
    </script>
</body>
</html>"

# Save report to file
echo "$HTML_CONTENT" > "$REPORT_FILE"

# Send consolidated email to each recipient
for email in "${EMAILS[@]}"; do
    {
        echo "To: $email"
        echo "Subject: $SUBJECT"
        echo "MIME-Version: 1.0"
        echo "Content-Type: text/html; charset=UTF-8"
        echo ""
        echo "$HTML_CONTENT"
    } | /usr/sbin/sendmail "$email" 2>/dev/null || echo "Failed to send email to $email"
    echo "Consolidated status report sent to $email"
done

echo "$(date '+%Y-%m-%d %H:%M:%S') - Status report completed. Normal: $NORMAL_COUNT, High Restarts: $HIGH_RESTARTS_COUNT, Errors: $ERROR_COUNT" >> "$REPORT_LOG"

# Print summary to console
echo ""
echo "=== CONSOLIDATED STATUS REPORT SUMMARY ==="
echo "Total Servers: $TOTAL_SERVERS"
echo "Total Services: $TOTAL_SERVICES"
echo "Services UP: $UP_SERVICES"
echo "Services DOWN: $DOWN_SERVICES"
echo "Normal: $NORMAL_COUNT"
echo "High Restarts: $HIGH_RESTARTS_COUNT"
echo "Errors: $ERROR_COUNT"
echo "Report saved to: $REPORT_FILE"
echo "Report sent to: ${EMAILS[*]}"
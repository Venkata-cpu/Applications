#!/bin/bash

# Daily Status Report - Based on k8s_health_check pattern
DATE=$(date +%Y-%m-%d)
REPORT_DIR="/apps/status_monitoring/reports"
REPORT_FILE="$REPORT_DIR/daily-status-report-$DATE.html"

# Create directory
mkdir -p $REPORT_DIR

# Generate report using existing script
/apps/status_monitoring/scripts/consolidated_status_report.sh

echo "Daily status report completed: $DATE"
echo "Report saved: $REPORT_FILE"
echo "Email sent to: asritha.2.meka@bt.com"
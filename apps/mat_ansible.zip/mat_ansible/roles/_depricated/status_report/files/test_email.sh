#!/bin/bash

# Quick test email
EMAIL="asritha.2.meka@bt.com"
SUBJECT="Test Email - Status Report System"

{
    echo "To: $EMAIL"
    echo "Subject: $SUBJECT"
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/html; charset=UTF-8"
    echo ""
    echo "<h2>✅ Test Email Successful</h2>"
    echo "<p>Status report system is working correctly.</p>"
    echo "<p>Time: $(date)</p>"
} | /usr/sbin/sendmail "$EMAIL"

echo "Test email sent to $EMAIL"
#!/bin/bash

# Server Connectivity Fix - Minimal timeout and parallel processing
# Fixes unreachable server issues in status reports

# Server IPs
declare -A SERVER_IPS=(
    ["blp20919390"]="10.54.106.76"
    ["blp20919391"]="10.54.106.77"
    ["blp20919407"]="10.54.106.78"
    ["blp20919408"]="10.54.106.79"
    ["blp20919409"]="10.54.106.80"
    ["blp20919904"]="10.6.103.172"
    ["blp20919905"]="10.6.103.173"
    ["blp20919906"]="10.6.103.174"
    ["blp20919907"]="10.6.103.175"
    ["blp20919908"]="10.6.103.176"
    ["blp20919909"]="10.6.103.177"
    ["blp20919910"]="10.6.103.178"
)

# Quick connectivity check with 2-second timeout
check_server_connectivity() {
    local server=$1
    local ip="${SERVER_IPS[$server]}"
    
    if timeout 2 ping -c 1 "$ip" &>/dev/null; then
        echo "$server:REACHABLE"
    else
        echo "$server:UNREACHABLE"
    fi
}

# Check all servers in parallel
echo "Checking server connectivity..."
for server in "${!SERVER_IPS[@]}"; do
    check_server_connectivity "$server" &
done
wait

echo "Connectivity check completed."
#!/bin/bash

EMAIL="asritha.2.meka@bt.com"
SUBJECT="Complete Service Status Report - All Servers"
REPORT_FILE="/tmp/complete_status_$(date '+%Y%m%d_%H%M%S').html"

# Server list
SERVERS="blp20919390 blp20919391 blp20919407 blp20919408 blp20919409 blp20919904 blp20919905 blp20919906 blp20919907 blp20919908 blp20919909 blp20919910"
SERVICES="kafka zookeeper druid-coordinator druid-broker druid-historical clickhouse-server elasticsearch grafana"

# Create HTML report
cat > "$REPORT_FILE" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .summary { background-color: #e8f5e8; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        table { border-collapse: collapse; width: 100%; margin-top: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .ok { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .unreachable { color: orange; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h2>🖥️ Complete Service Status Report</h2>
        <p><strong>Generated:</strong> $(date)</p>
        <p><strong>Report Type:</strong> Comprehensive Status Check</p>
    </div>
EOF

TOTAL_SERVERS=0
REACHABLE_SERVERS=0
TOTAL_SERVICES=0
SERVICES_UP=0
SERVICES_DOWN=0

echo "<table><tr><th>Server</th><th>Service</th><th>Status</th><th>Restart Count</th><th>Last Check</th></tr>" >> "$REPORT_FILE"

for server in $SERVERS; do
    TOTAL_SERVERS=$((TOTAL_SERVERS + 1))
    
    # Test server connectivity
    if ping -c 1 -W 2 "$server" >/dev/null 2>&1; then
        REACHABLE_SERVERS=$((REACHABLE_SERVERS + 1))
        
        # Check each service on reachable server
        for service in $SERVICES; do
            TOTAL_SERVICES=$((TOTAL_SERVICES + 1))
            
            # Try to check service status via SSH
            if timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server" "systemctl is-active $service" >/dev/null 2>&1; then
                RESTART_COUNT=$(timeout 3 ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no "$server" "systemctl show $service --property=NRestarts --value" 2>/dev/null || echo "0")
                echo "<tr><td>$server</td><td>$service</td><td class='ok'>✅ ACTIVE</td><td>$RESTART_COUNT</td><td>$(date)</td></tr>" >> "$REPORT_FILE"
                SERVICES_UP=$((SERVICES_UP + 1))
            else
                echo "<tr><td>$server</td><td>$service</td><td class='error'>❌ INACTIVE</td><td>-</td><td>$(date)</td></tr>" >> "$REPORT_FILE"
                SERVICES_DOWN=$((SERVICES_DOWN + 1))
            fi
        done
    else
        # Server unreachable - mark all services as unreachable
        for service in $SERVICES; do
            TOTAL_SERVICES=$((TOTAL_SERVICES + 1))
            echo "<tr><td>$server</td><td>$service</td><td class='unreachable'>🔶 SERVER UNREACHABLE</td><td>-</td><td>$(date)</td></tr>" >> "$REPORT_FILE"
            SERVICES_DOWN=$((SERVICES_DOWN + 1))
        done
    fi
done

echo "</table>" >> "$REPORT_FILE"

# Add summary
cat >> "$REPORT_FILE" << EOF
    <div class="summary">
        <h3>📊 Summary</h3>
        <p><strong>Total Servers:</strong> $TOTAL_SERVERS</p>
        <p><strong>Reachable Servers:</strong> $REACHABLE_SERVERS</p>
        <p><strong>Total Services:</strong> $TOTAL_SERVICES</p>
        <p><strong>Services Active:</strong> $SERVICES_UP</p>
        <p><strong>Services Inactive/Unreachable:</strong> $SERVICES_DOWN</p>
        <p><strong>Success Rate:</strong> $(( SERVICES_UP * 100 / TOTAL_SERVICES ))%</p>
    </div>
</body>
</html>
EOF

# Send email
mail -s "$SUBJECT" -a "Content-Type: text/html" "$EMAIL" < "$REPORT_FILE"
echo "Complete status report sent to $EMAIL"
echo "Services Active: $SERVICES_UP/$TOTAL_SERVICES"
echo "Reachable Servers: $REACHABLE_SERVERS/$TOTAL_SERVERS"

# Cleanup
rm -f "$REPORT_FILE"
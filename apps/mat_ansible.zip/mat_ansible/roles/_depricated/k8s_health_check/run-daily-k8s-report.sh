#!/bin/bash

# Daily Kubernetes Health Check Script
# Run this script daily via cron job

DATE=$(date +%Y-%m-%d)
REPORT_DIR="/tmp/k8s-reports"
VAULT_FILE=".vault"

# Create report directory
mkdir -p $REPORT_DIR

echo "Starting K8s Health Check Report for $DATE"

# Run Ansible playbook with role
ansible-playbook k8s-health-playbook.yml \
  --vault-password-file $VAULT_FILE \
  -v

# Move report to dated directory
if [ -f "/tmp/k8s-health-report-$DATE.html" ]; then
    mv /tmp/k8s-health-report-$DATE.html $REPORT_DIR/
    echo "Report generated: $REPORT_DIR/k8s-health-report-$DATE.html"
else
    echo "Error: Report file not found"
    exit 1
fi

echo "K8s Health Check completed successfully"
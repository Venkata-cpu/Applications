#!/bin/bash
DATE=$(date +%Y-%m-%d)
TIME=$(date '+%Y-%m-%d %H:%M:%S %Z')
REPORT_DIR="/var/log/k8s-reports"
REPORT_FILE="$REPORT_DIR/k8s-report-$DATE.txt"
HOSTNAME=$(hostname)

# Create directory
mkdir -p $REPORT_DIR

# Generate report
python3 /usr/local/bin/k8s_restart_check.py > $REPORT_FILE

# Email configuration
EMAILS=("asritha.2.meka@bt.com" "pradip.mandal@bt.com" "suraj.tomar@bt.com")
FROM_EMAIL="martini.ee.monitoring@bt.com"
SUBJECT="Kubernetes Pod Restart Report"

# Read report content
REPORT_CONTENT=$(cat $REPORT_FILE)

# Create HTML email
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .date-time { color: #4285f4; margin: 10px 0; }
        .summary-row { display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap; justify-content: space-between; }
        .service-card { 
            border: 2px solid; 
            border-radius: 8px; 
            padding: 15px; 
            flex: 1; 
            min-width: 220px;
            max-width: 250px;
            text-align: center;
            margin: 5px;
        }
        .red { border-color: #dc3545; background-color: #f8d7da; color: #721c24; }
        .amber { border-color: #ffc107; background-color: #fff3cd; color: #856404; }
        .green { border-color: #28a745; background-color: #d4edda; color: #155724; }
        .details-section { margin-top: 30px; }
        .issue-details { 
            border: 1px solid #dc3545; 
            border-radius: 8px; 
            padding: 20px; 
            background-color: #f8f9fa;
        }
        pre { background-color: #ffffff; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class='container'>
    <div class='header'>
        <h1>📊 Daily Health Check Report</h1>
        <div class='date-time'>
            <strong>Date:</strong> $(date '+%A, %B %d, %Y')<br>
            <strong>Time:</strong> $(date '+%H:%M GMT')
        </div>
    </div>
    
    <div class='summary-row'>
        <div class='service-card red'>
            <div>🚨</div>
            <h3>Kubernetes Health</h3>
            <p><strong>Issues Found</strong></p>
            <small>70 pods with issues</small>
        </div>
        
        <div class='service-card amber'>
            <div>🔧</div>
            <h3>Herald</h3>
            <p><strong>Development in Progress</strong></p>
            <small>Monitoring setup pending</small>
        </div>
        
        <div class='service-card amber'>
            <div>📥</div>
            <h3>Download Report</h3>
            <p><strong>Development in Progress</strong></p>
            <small>Integration pending</small>
        </div>
        
        <div class='service-card amber'>
            <div>🔍</div>
            <h3>System Monitoring</h3>
            <p><strong>Development in Progress</strong></p>
            <small>Setup in progress</small>
        </div>
    </div>
    
    <div class='details-section'>
        <h2>🚨 Kubernetes Health - Detailed Issues</h2>
        <div class='issue-details'>
            <pre>$REPORT_CONTENT</pre>
        </div>
    </div>
    
    <div style='margin-top: 30px; text-align: center; color: #6c757d;'>
        <p><em>This is an automated health check report. Other services are currently under development.</em></p>
    </div>
    </div>
</body>
</html>"

# Send email to all recipients
TO_EMAIL="${EMAILS[0]}"
CC_EMAILS=""
for ((i=1; i<${#EMAILS[@]}; i++)); do
    if [[ -n "$CC_EMAILS" ]]; then
        CC_EMAILS="$CC_EMAILS, ${EMAILS[i]}"
    else
        CC_EMAILS="${EMAILS[i]}"
    fi
done

{
    echo "From: $FROM_EMAIL"
    echo "To: $TO_EMAIL"
    if [[ -n "$CC_EMAILS" ]]; then
        echo "Cc: $CC_EMAILS"
    fi
    echo "Subject: Daily Health Check Report"
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/html; charset=UTF-8"
    echo ""
    echo "$HTML_CONTENT"
} | /usr/sbin/sendmail "$TO_EMAIL" "$CC_EMAILS" 2>/dev/null || echo "Failed to send email"

echo "Report saved: $REPORT_FILE"
echo "Email sent to: ${EMAILS[*]}"
echo "Report content:"
cat $REPORT_FILE
#!/usr/bin/env python3
import subprocess
import json
import os
from datetime import datetime

# Data storage paths
DATA_DIR = "/var/log/k8s-reports/data"
CURRENT_DATA = f"{DATA_DIR}/current_pod_counts.json"
PREVIOUS_DATA = f"{DATA_DIR}/previous_pod_counts.json"

# Create data directory
os.makedirs(DATA_DIR, exist_ok=True)

# Get pods data with error handling
result = subprocess.run(['kubectl', 'get', 'pods', '--all-namespaces', '-o', 'json'], 
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

if result.returncode != 0 or not result.stdout.strip():
    print(f"❌ Error: kubectl command failed")
    print(f"Return code: {result.returncode}")
    print(f"Error: {result.stderr}")
    print(f"Output: {result.stdout}")
    exit(1)

try:
    pods = json.loads(result.stdout)
except json.JSONDecodeError as e:
    print(f"❌ Error: Failed to parse kubectl output as JSON")
    print(f"JSON Error: {e}")
    print(f"Output: {result.stdout[:200]}...")
    exit(1)

# Worker node hostnames
worker_nodes = ['blp20919390', 'blp20919391', 'blp20919407', 'blp20919408', 'blp20919409',
               'blp20919904', 'blp20919905', 'blp20919906', 'blp20919907', 'blp20919908', 
               'blp20919909', 'blp20919910']

# Move current to previous
if os.path.exists(CURRENT_DATA):
    os.rename(CURRENT_DATA, PREVIOUS_DATA)

# Collect current pod restart counts
current_counts = {}
for pod in pods['items']:
    node_name = pod['spec'].get('nodeName', '')
    if node_name in worker_nodes:
        pod_name = pod['metadata']['name']
        namespace = pod['metadata']['namespace']
        pod_key = f"{namespace}/{pod_name}"
        restarts = sum([c.get('restartCount', 0) for c in pod['status'].get('containerStatuses', [])])
        current_counts[pod_key] = {
            'restarts': restarts,
            'node': node_name,
            'namespace': namespace,
            'name': pod_name
        }

# Save current counts
with open(CURRENT_DATA, 'w') as f:
    json.dump(current_counts, f, indent=2)

# Load previous counts
previous_counts = {}
if os.path.exists(PREVIOUS_DATA):
    with open(PREVIOUS_DATA, 'r') as f:
        previous_counts = json.load(f)

# Calculate daily restart differences
daily_restarts = []
total_daily_restarts = 0
high_count = 0
normal_count = 0
ok_count = 0

for pod_key, current_data in current_counts.items():
    current_restarts = current_data['restarts']
    previous_restarts = previous_counts.get(pod_key, {}).get('restarts', 0)
    
    # Calculate daily difference
    daily_diff = current_restarts - previous_restarts
    if daily_diff < 0:  # Handle pod recreation
        daily_diff = current_restarts
    
    total_daily_restarts += daily_diff
    
    # Categorize
    if daily_diff > 5:
        status = 'HIGH'
        high_count += 1
    elif daily_diff > 0:
        status = 'NORMAL'
        normal_count += 1
    else:
        status = 'OK'
        ok_count += 1
    
    # Store for reporting
    daily_restarts.append({
        'pod_key': pod_key,
        'name': current_data['name'],
        'namespace': current_data['namespace'],
        'node': current_data['node'],
        'daily_restarts': daily_diff,
        'total_restarts': current_restarts,
        'status': status
    })

# Generate report
print('🔄 Kubernetes Pod Restart Report - ' + datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
print('📊 Restarts in Last 24 Hours: {}'.format(total_daily_restarts))
print('=' * 100)
print('{:<45} | {:<20} | {:<15} | {:>6} | {:>6} | {}'.format(
    'Pod Name', 'Namespace', 'Node', 'Daily', 'Total', 'Status'))
print('=' * 100)

# Show only pods with restarts in last 24 hours
for pod_data in sorted(daily_restarts, key=lambda x: x['daily_restarts'], reverse=True):
    if pod_data['daily_restarts'] > 0:
        print('{:<45} | {:<20} | {:<15} | {:>6} | {:>6} | {}'.format(
            pod_data['name'][:44],
            pod_data['namespace'][:19], 
            pod_data['node'],
            pod_data['daily_restarts'],
            pod_data['total_restarts'],
            pod_data['status']
        ))

if total_daily_restarts == 0:
    print('✅ No pod restarts in the last 24 hours')

print('=' * 100)
print('📈 Daily Summary:')
print('  • Total Daily Restarts: {}'.format(total_daily_restarts))
print('  • HIGH (>5 daily): {}'.format(high_count))
print('  • NORMAL (1-5 daily): {}'.format(normal_count))
print('  • OK (0 daily): {}'.format(ok_count))
print('  • Total Pods Monitored: {}'.format(len(current_counts)))
print('')
print('⚠️  Daily Restarts = Current Count - Previous Day Count')
print('🔍 Investigate pods with HIGH daily restarts immediately')
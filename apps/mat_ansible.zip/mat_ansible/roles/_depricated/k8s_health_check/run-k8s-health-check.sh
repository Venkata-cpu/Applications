#!/bin/bash

# Daily Kubernetes Health Check Script
# Run this script daily via cron job

DATE=$(date +%Y-%m-%d)
REPORT_DIR="/tmp/k8s-reports"
VAULT_FILE=".vault"

# Create report directory
mkdir -p $REPORT_DIR

# Run Ansible playbook
ansible-playbook k8s-health-check.yml \
  --vault-password-file $VAULT_FILE \
  -v

# Move report to dated directory
mv /tmp/k8s-health-report-*.html $REPORT_DIR/

echo "K8s Health Check Report generated: $REPORT_DIR/k8s-health-report-$DATE.html"

# Optional: Send email report
# mail -s "Daily K8s Health Report - $DATE" -a $REPORT_DIR/k8s-health-report-$DATE.html your-email@company.com < /dev/null
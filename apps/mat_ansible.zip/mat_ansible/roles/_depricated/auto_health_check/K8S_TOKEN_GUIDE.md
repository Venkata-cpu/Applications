# Getting Kubernetes API Token

## Method 1: Using the provided manifest (Recommended)

1. **Apply the ServiceAccount manifest:**
```bash
kubectl apply -f files/k8s-serviceaccount.yaml
```

2. **Get the token:**

For Kubernetes 1.24+:
```bash
kubectl get secret health-check-sa-token -n kube-system -o jsonpath='{.data.token}' | base64 -d
```

For Kubernetes < 1.24:
```bash
SECRET_NAME=$(kubectl get serviceaccount health-check-sa -n kube-system -o jsonpath='{.secrets[0].name}')
kubectl get secret $SECRET_NAME -n kube-system -o jsonpath='{.data.token}' | base64 -d
```

3. **Get the API server URL:**
```bash
kubectl cluster-info | grep 'Kubernetes control plane' | awk '{print $NF}'
```

## Method 2: Using existing kubeconfig

Extract token from kubeconfig:
```bash
kubectl config view --raw -o jsonpath='{.users[0].user.token}'
```

Or use client certificate (if token not available):
```bash
# Get certificate and key
kubectl config view --raw -o jsonpath='{.users[0].user.client-certificate-data}' | base64 -d > client.crt
kubectl config view --raw -o jsonpath='{.users[0].user.client-key-data}' | base64 -d > client.key
```

## Method 3: Create token manually

```bash
# Create ServiceAccount
kubectl create serviceaccount health-check-sa -n kube-system

# Create ClusterRoleBinding
kubectl create clusterrolebinding health-check-reader-binding \
  --clusterrole=view \
  --serviceaccount=kube-system:health-check-sa

# For K8s 1.24+, create token secret
kubectl apply -f - <<EOF
apiVersion: v1
kind: Secret
metadata:
  name: health-check-sa-token
  namespace: kube-system
  annotations:
    kubernetes.io/service-account.name: health-check-sa
type: kubernetes.io/service-account-token
EOF

# Get token
kubectl get secret health-check-sa-token -n kube-system -o jsonpath='{.data.token}' | base64 -d
```

## Verify Token Works

Test the token:
```bash
TOKEN="your-token-here"
API_SERVER="https://your-k8s-api:6443"

curl -k -H "Authorization: Bearer $TOKEN" $API_SERVER/api/v1/nodes
```

## Configuration Example

```yaml
health_check_k8s:
  enabled: true
  api_server: "https://10.x.x.x:6443"
  token: "eyJhbGciOiJSUzI1NiIsImtpZCI6Ij..."
  verify_ssl: false
```

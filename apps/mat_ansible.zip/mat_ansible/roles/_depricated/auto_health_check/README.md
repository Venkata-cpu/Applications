# Auto Health Check Module

## Overview
Automated daily health check system that monitors K8s, Kafka, ClickHouse, and data quality, sending HTML email reports.

## Structure
```
auto_health_check/
├── defaults/main.yml          # Default variables
├── tasks/main.yml             # Installation tasks
├── templates/
│   ├── health_check.py.j2     # Main Python script
│   └── email_template.html.j2 # HTML email template
└── README.md
```

## Configuration Variables

| Variable | Default | Description |
|----------|---------|-------------|
| health_check_email_to | "" | Recipient email address |
| health_check_email_from | noreply@bt.com | Sender email address |
| health_check_smtp_host | localhost | SMTP server host |
| health_check_smtp_port | 25 | SMTP server port |
| health_check_cron_schedule | "0 8 * * *" | Cron schedule (daily at 8 AM) |
| health_check_script_dir | /opt/health_check | Script installation directory |
| health_check_log_dir | /var/log/health_check | Log directory |

## Usage

```yaml
- hosts: monitoring_server
  roles:
    - role: auto_health_check
      vars:
        health_check_email_to: "ops-team@bt.com"
```

## Implementation Status

- [x] Basic structure
- [x] Email template
- [x] Cron setup
- [ ] K8s health check
- [ ] Kafka health check
- [ ] ClickHouse health check
- [ ] Data quality check

## Next Steps
Implement individual health check modules based on requirements.

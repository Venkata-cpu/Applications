#!/bin/bash

SCRIPT_DIR="/apps/counter_monitoring/scripts"
LOG_DIR="/apps/counter_monitoring/logs"

# Run daily counter monitoring check
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting daily counter restart check" >> "$LOG_DIR/daily_counter_monitoring.log"

# Execute the monitoring script
"$SCRIPT_DIR/check_restart_counter.sh" >> "$LOG_DIR/daily_counter_monitoring.log" 2>&1

# DISABLED: Individual server email reports - only consolidated report will be sent
# "$SCRIPT_DIR/send_counter_html_alert.sh"

echo "$(date '+%Y-%m-%d %H:%M:%S') - Daily counter check completed (email disabled)" >> "$LOG_DIR/daily_counter_monitoring.log"
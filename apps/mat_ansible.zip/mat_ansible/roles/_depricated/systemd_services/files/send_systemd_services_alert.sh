#!/bin/bash

SCRIPT_DIR="/apps/counter_monitoring/scripts"
LOG_DIR="/apps/counter_monitoring/logs"
ALERT_LOG="$LOG_DIR/counter_alert.log"

# Email configuration
EMAILS=("asritha.2.meka@bt.com" "pradip.mandal@bt.com" "suraj.tomar@bt.com")
SUBJECT="Counter Restart Alert - $(hostname)"

# Run the check and capture output
OUTPUT=$("$SCRIPT_DIR/check_restart_counter.sh")

# Check if any services have high restart counts
if echo "$OUTPUT" | grep -E "(HIGH)" > /dev/null; then
    # Send alert email to each recipient
    for email in "${EMAILS[@]}"; do
        echo "$OUTPUT" | mail -s "$SUBJECT" "$email"
    done
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Alert sent for high restart counts" >> "$ALERT_LOG"
else
    echo "$(date '+%Y-%m-%d %H:%M:%S') - All restart counts normal, no alert sent" >> "$ALERT_LOG"
fi
#!/bin/bash

# Daily Restart Tracker - Tracks actual restarts in last 24 hours
SCRIPT_DIR="/apps/counter_monitoring/scripts"
LOG_DIR="/apps/counter_monitoring/logs"
DATA_DIR="/apps/counter_monitoring/data"
CURRENT_DATA="$DATA_DIR/current_restart_counts.txt"
PREVIOUS_DATA="$DATA_DIR/previous_restart_counts.txt"
DAILY_REPORT="$LOG_DIR/daily_restart_report.log"

# Create directories if they don't exist
mkdir -p "$DATA_DIR"

# Services to monitor
SERVICES=("kafka" "zookeeper" "druid-coordinator" "druid-broker" "druid-historical")

# Get current date and time
CURRENT_TIME=$(date '+%Y-%m-%d %H:%M:%S %Z')
HOSTNAME=$(hostname)

echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting daily restart tracking on $HOSTNAME" >> "$DAILY_REPORT"

# Move current data to previous (if exists)
if [[ -f "$CURRENT_DATA" ]]; then
    cp "$CURRENT_DATA" "$PREVIOUS_DATA"
fi

# Get current restart counts
> "$CURRENT_DATA"
for service in "${SERVICES[@]}"; do
    RESTART_COUNT=$(systemctl show "$service" --property=NRestarts --value 2>/dev/null || echo "0")
    echo "$service:$RESTART_COUNT" >> "$CURRENT_DATA"
done

# Calculate daily changes
declare -A CURRENT_COUNTS
declare -A PREVIOUS_COUNTS
declare -A DAILY_RESTARTS

# Read current counts
while IFS=':' read -r service count; do
    CURRENT_COUNTS["$service"]="$count"
done < "$CURRENT_DATA"

# Read previous counts (if file exists)
if [[ -f "$PREVIOUS_DATA" ]]; then
    while IFS=':' read -r service count; do
        PREVIOUS_COUNTS["$service"]="$count"
    done < "$PREVIOUS_DATA"
else
    # First run - initialize previous counts to 0
    for service in "${SERVICES[@]}"; do
        PREVIOUS_COUNTS["$service"]="0"
    done
fi

# Calculate daily restart differences
TOTAL_DAILY_RESTARTS=0
SERVICES_WITH_RESTARTS=0
HIGH_RESTART_SERVICES=0

for service in "${SERVICES[@]}"; do
    CURRENT="${CURRENT_COUNTS[$service]:-0}"
    PREVIOUS="${PREVIOUS_COUNTS[$service]:-0}"
    DAILY_DIFF=$((CURRENT - PREVIOUS))
    
    # Handle negative values (service counter reset)
    if [[ $DAILY_DIFF -lt 0 ]]; then
        DAILY_DIFF=$CURRENT
    fi
    
    DAILY_RESTARTS["$service"]="$DAILY_DIFF"
    TOTAL_DAILY_RESTARTS=$((TOTAL_DAILY_RESTARTS + DAILY_DIFF))
    
    if [[ $DAILY_DIFF -gt 0 ]]; then
        ((SERVICES_WITH_RESTARTS++))
    fi
    
    if [[ $DAILY_DIFF -gt 5 ]]; then
        ((HIGH_RESTART_SERVICES++))
    fi
    
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $service: Previous=$PREVIOUS, Current=$CURRENT, Daily=$DAILY_DIFF" >> "$DAILY_REPORT"
done

# Generate HTML report
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #34495e; color: white; padding: 15px; text-align: center; border-radius: 5px; }
        .summary { background-color: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .summary-box { display: inline-block; margin: 10px; padding: 10px; border-radius: 5px; text-align: center; min-width: 80px; }
        .normal-box { background-color: #d5f4e6; border: 2px solid #27ae60; }
        .warning-box { background-color: #fff3cd; border: 2px solid #ffc107; }
        .high-box { background-color: #fadbd8; border: 2px solid #e74c3c; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; font-size: 12px; }
        th { background-color: #34495e; color: white; }
        .status-ok { color: #27ae60; font-weight: bold; }
        .status-normal { color: #ffc107; font-weight: bold; }
        .status-high { color: #e74c3c; font-weight: bold; }
        .restart-count { font-weight: bold; font-size: 14px; }
        .footer { margin-top: 20px; font-size: 12px; color: #7f8c8d; }
    </style>
</head>
<body>
    <div class='header'>
        <h2>🔄 Daily Service Restart Report</h2>
        <p>Server: $HOSTNAME | Time: $CURRENT_TIME</p>
        <p><strong>📊 Restarts in Last 24 Hours</strong></p>
    </div>
    
    <div class='summary'>
        <h3>📈 Daily Summary</h3>
        <div class='summary-box normal-box'>
            <div>TOTAL RESTARTS</div>
            <div style='font-size: 24px; font-weight: bold;'>$TOTAL_DAILY_RESTARTS</div>
        </div>
        <div class='summary-box warning-box'>
            <div>SERVICES RESTARTED</div>
            <div style='font-size: 24px; font-weight: bold;'>$SERVICES_WITH_RESTARTS</div>
        </div>
        <div class='summary-box high-box'>
            <div>HIGH RESTARTS</div>
            <div style='font-size: 24px; font-weight: bold;'>$HIGH_RESTART_SERVICES</div>
        </div>
        <p><strong>Total Services Monitored:</strong> ${#SERVICES[@]}</p>
    </div>
    
    <h3>🖥️ Service Restart Details (Last 24 Hours)</h3>
    <table>
        <tr>
            <th>Service</th>
            <th>Daily Restarts</th>
            <th>Total Restarts</th>
            <th>Status</th>
            <th>Last Check</th>
        </tr>"

# Add service details to HTML
for service in "${SERVICES[@]}"; do
    DAILY="${DAILY_RESTARTS[$service]}"
    TOTAL="${CURRENT_COUNTS[$service]}"
    
    if [[ $DAILY -eq 0 ]]; then
        STATUS="✅ NO RESTARTS"
        STATUS_CLASS="status-ok"
    elif [[ $DAILY -le 2 ]]; then
        STATUS="⚠️ NORMAL"
        STATUS_CLASS="status-normal"
    else
        STATUS="❌ HIGH RESTARTS"
        STATUS_CLASS="status-high"
    fi
    
    HTML_CONTENT+="
        <tr>
            <td><strong>$service</strong></td>
            <td><span class='restart-count'>$DAILY</span></td>
            <td>$TOTAL</td>
            <td><span class='$STATUS_CLASS'>$STATUS</span></td>
            <td>$CURRENT_TIME</td>
        </tr>"
done

HTML_CONTENT+="
    </table>
    
    <div class='footer'>
        <p>📧 This report shows actual service restarts in the last 24 hours</p>
        <p>🔄 Next check: Tomorrow at 9:00 AM</p>
        <p>⚠️ Daily Restarts = Current Count - Previous Day Count</p>
        <p>🚨 High Restarts (>5) require immediate investigation</p>
    </div>
</body>
</html>"

# Email configuration
EMAILS=("asritha.2.meka@bt.com" "pradip.mandal@bt.com" "suraj.tomar@bt.com")
FROM_EMAIL="martini.ee.monitoring@bt.com"
SUBJECT="Daily Service Restart Report - $HOSTNAME"

# Send email to all recipients
TO_EMAIL="${EMAILS[0]}"
CC_EMAILS=""
for ((i=1; i<${#EMAILS[@]}; i++)); do
    if [[ -n "$CC_EMAILS" ]]; then
        CC_EMAILS="$CC_EMAILS, ${EMAILS[i]}"
    else
        CC_EMAILS="${EMAILS[i]}"
    fi
done

{
    echo "From: $FROM_EMAIL"
    echo "To: $TO_EMAIL"
    if [[ -n "$CC_EMAILS" ]]; then
        echo "Cc: $CC_EMAILS"
    fi
    echo "Subject: $SUBJECT"
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/html; charset=UTF-8"
    echo ""
    echo "$HTML_CONTENT"
} | /usr/sbin/sendmail "$TO_EMAIL" "$CC_EMAILS" 2>/dev/null || echo "Failed to send email"

echo "$(date '+%Y-%m-%d %H:%M:%S') - Daily restart report completed. Total daily restarts: $TOTAL_DAILY_RESTARTS, Services with restarts: $SERVICES_WITH_RESTARTS" >> "$DAILY_REPORT"

# Print summary to console
echo ""
echo "=== DAILY RESTART SUMMARY ==="
echo "Server: $HOSTNAME"
echo "Total daily restarts: $TOTAL_DAILY_RESTARTS"
echo "Services with restarts: $SERVICES_WITH_RESTARTS"
echo "High restart services: $HIGH_RESTART_SERVICES"
echo "Report sent to: ${EMAILS[*]}"
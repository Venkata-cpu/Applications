#!/bin/bash

LOG_FILE="/apps/counter_monitoring/logs/restart_counter.log"

write_log() {
    local msg="$1"
    echo "$(date '+%Y-%m-%d %H:%M:%S')  $msg" >> "$LOG_FILE"
}

write_log "$1"
#!/bin/bash

# Consolidated Counter Restart Report for All Servers
# Run this on the master server (blp20919390)
# Tracks actual restarts in last 24 hours

SCRIPT_DIR="/apps/counter_monitoring/scripts"
LOG_DIR="/apps/counter_monitoring/logs"
DATA_DIR="/apps/counter_monitoring/data"
REPORT_LOG="$LOG_DIR/consolidated_report.log"
CURRENT_DATA="$DATA_DIR/consolidated_current.txt"
PREVIOUS_DATA="$DATA_DIR/consolidated_previous.txt"

# Create directories if they don't exist
mkdir -p "$DATA_DIR"

# Email configuration
EMAILS=("asritha.2.meka@bt.com" "pradip.mandal@bt.com" "suraj.tomar@bt.com")
FROM_EMAIL="martini.ee.monitoring@bt.com"
SUBJECT="Systemd Services Status Report"

# All servers to monitor with their IP addresses - CORRECTED to actual service locations
declare -A SERVER_IPS=(
    # Kafka servers
    ["blp20919645"]="10.6.120.173"
    ["blp20919646"]="10.6.120.174"
    ["blp20919647"]="10.6.120.175"
    # Zookeeper servers
    ["blp20919653"]="10.6.120.181"
    ["blp20919654"]="10.6.120.182"
    ["blp20919655"]="10.6.120.183"
    # Druid servers
    ["blp20919638"]="10.6.120.166"
    ["blp20919639"]="10.6.120.167"
    ["blp20919640"]="10.6.120.168"
    ["blp20919641"]="10.6.120.169"
    ["blp20919642"]="10.6.120.170"
    ["blp20919643"]="10.6.120.171"
    ["blp20919644"]="10.6.120.172"
)

SERVERS=("${!SERVER_IPS[@]}")

# Services to monitor with actual server counts based on inventory
SERVICES=("kafka" "zookeeper" "druid-coordinator" "druid-broker" "druid-historical")
THRESHOLD=5

# Actual server counts per service from inventory
declare -A SERVICE_SERVER_COUNT=(
    ["kafka"]="3"              # 3 kafka_kraft servers
    ["zookeeper"]="3"         # 3 zookeeper servers  
    ["druid-coordinator"]="1"  # 1 coordinator server
    ["druid-broker"]="2"       # 2 broker servers (broker + broker_router)
    ["druid-historical"]="5"   # 5 historical servers
)

# Define which servers run which services
declare -A SERVICE_SERVERS=(
    ["kafka"]="blp20919645 blp20919646 blp20919647"
    ["zookeeper"]="blp20919653 blp20919654 blp20919655"
    ["druid-coordinator"]="blp20919645"
    ["druid-broker"]="blp20919643 blp20919644"
    ["druid-historical"]="blp20919638 blp20919639 blp20919640 blp20919641 blp20919642"
)

# Get current date and time
CURRENT_TIME=$(date '+%Y-%m-%d %H:%M:%S %Z')

# Initialize counters
TOTAL_SERVERS=13  # Total unique servers running monitored services
TOTAL_SERVICES=14 # Total service instances (3+3+1+2+5)
NORMAL_COUNT=0
HIGH_COUNT=0
ERROR_COUNT=0
TOTAL_DAILY_RESTARTS=0

# Move current data to previous (if exists)
if [[ -f "$CURRENT_DATA" ]]; then
    cp "$CURRENT_DATA" "$PREVIOUS_DATA"
fi

# Initialize current data file
> "$CURRENT_DATA"

# Read previous data into associative array
declare -A PREVIOUS_COUNTS
if [[ -f "$PREVIOUS_DATA" ]]; then
    while IFS=':' read -r server_service count; do
        PREVIOUS_COUNTS["$server_service"]="$count"
    done < "$PREVIOUS_DATA"
fi

# Create HTML report
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #34495e; color: white; padding: 15px; text-align: center; border-radius: 5px; }
        .summary { background-color: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .summary-box { display: inline-block; margin: 10px; padding: 10px; border-radius: 5px; text-align: center; min-width: 80px; }
        .normal-box { background-color: #d5f4e6; border: 2px solid #27ae60; }
        .high-box { background-color: #fadbd8; border: 2px solid #e74c3c; }
        .error-box { background-color: #f8d7da; border: 2px solid #dc3545; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; font-size: 12px; }
        th { background-color: #34495e; color: white; }
        .status-ok { color: #27ae60; font-weight: bold; }
        .status-normal { color: #f39c12; font-weight: bold; }
        .status-high { color: #e74c3c; font-weight: bold; }
        .status-error { color: #dc3545; font-weight: bold; }
        .server-group { margin: 10px 0; }
        .server-name { background-color: #f8f9fa; font-weight: bold; padding: 5px; }
        .footer { margin-top: 20px; font-size: 12px; color: #7f8c8d; }
    </style>
</head>
<body>
    <div class='header'>
        <h2>🔄 Systemd Services Status Report</h2>
        <p>All Servers | Time: $CURRENT_TIME</p>
        <p><strong>📊 Restarts in Last 24 Hours: $TOTAL_DAILY_RESTARTS</strong></p>
    </div>
    
    <div class='summary'>
        <h3>📊 Overall Summary</h3>
        <div class='summary-box normal-box'>
            <div>NORMAL</div>
            <div style='font-size: 24px; font-weight: bold;' id='normal-count'>0</div>
        </div>
        <div class='summary-box high-box'>
            <div>HIGH RESTARTS</div>
            <div style='font-size: 24px; font-weight: bold;' id='high-count'>0</div>
        </div>
        <div class='summary-box error-box'>
            <div>ERRORS</div>
            <div style='font-size: 24px; font-weight: bold;' id='error-count'>0</div>
        </div>
        <p><strong>Total Servers:</strong> $TOTAL_SERVERS | <strong>Total Services:</strong> $TOTAL_SERVICES | <strong>Daily Restarts:</strong> $TOTAL_DAILY_RESTARTS</p>
    </div>
    
    <h3>🖥️ Service Restart Summary (Last 24 Hours)</h3>
    <table>
        <tr>
            <th>Service</th>
            <th>Servers with Restarts</th>
            <th>Total Servers</th>
            <th>Restart Rate</th>
            <th>Status</th>
        </tr>"

# Initialize service restart tracking
declare -A SERVICE_RESTART_COUNT
declare -A SERVICE_SERVER_WITH_RESTARTS

for service in "${SERVICES[@]}"; do
    SERVICE_RESTART_COUNT["$service"]=0
    SERVICE_SERVER_WITH_RESTARTS["$service"]=0
done

# Collect data from servers that actually run the services
echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting consolidated report collection" >> "$REPORT_LOG"

for service in "${SERVICES[@]}"; do
    echo "Checking service: $service"
    SERVICE_SERVER_LIST="${SERVICE_SERVERS[$service]}"
    
    for server in $SERVICE_SERVER_LIST; do
        echo "Collecting data from $server for $service..."
        SERVER_IP="${SERVER_IPS[$server]}"
        
        # Check if server is reachable
        if ! ping -c 1 "$SERVER_IP" &> /dev/null; then
            echo "$(date '+%Y-%m-%d %H:%M:%S') - Server $server unreachable" >> "$REPORT_LOG"
            ((ERROR_COUNT++))
            continue
        fi
        
        # Get service restart count
        if [[ "$server" == "$(hostname)" ]] || [[ "$server" == "blp20919390" ]]; then
            # Local execution for master server
            RESTART_COUNT=$(systemctl show "$service" --property=NRestarts --value 2>/dev/null || echo "ERROR")
        else
            # SSH to remote server using IP address
            RESTART_COUNT=$(ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no "$SERVER_IP" "systemctl show '$service' --property=NRestarts --value 2>/dev/null || echo 'ERROR'" 2>/dev/null)
        fi
        
        # Store current count
        echo "$server:$service:$RESTART_COUNT" >> "$CURRENT_DATA"
        
        # Calculate daily difference
        PREVIOUS_COUNT="${PREVIOUS_COUNTS["$server:$service"]:-0}"
        if [[ "$RESTART_COUNT" == "ERROR" ]] || [[ -z "$RESTART_COUNT" ]]; then
            DAILY_DIFF="ERROR"
            ((ERROR_COUNT++))
        else
            DAILY_DIFF=$((RESTART_COUNT - PREVIOUS_COUNT))
            # Handle counter resets
            if [[ $DAILY_DIFF -lt 0 ]]; then
                DAILY_DIFF=$RESTART_COUNT
            fi
            TOTAL_DAILY_RESTARTS=$((TOTAL_DAILY_RESTARTS + DAILY_DIFF))
            
            if [[ $DAILY_DIFF -gt $THRESHOLD ]]; then
                ((HIGH_COUNT++))
                ((SERVICE_RESTART_COUNT["$service"]++))
                ((SERVICE_SERVER_WITH_RESTARTS["$service"]++))
            elif [[ $DAILY_DIFF -gt 0 ]]; then
                ((NORMAL_COUNT++))
                ((SERVICE_RESTART_COUNT["$service"]++))
                ((SERVICE_SERVER_WITH_RESTARTS["$service"]++))
            fi
        fi
        
        echo "$(date '+%Y-%m-%d %H:%M:%S') - $server:$service = Total:$RESTART_COUNT, Daily:$DAILY_DIFF" >> "$REPORT_LOG"
    done
done

# Add service summary to HTML
for service in "${SERVICES[@]}"; do
    TOTAL_SERVERS="${SERVICE_SERVER_COUNT[$service]}"
    SERVERS_WITH_RESTARTS="${SERVICE_SERVER_WITH_RESTARTS[$service]}"
    RESTART_RATE="$SERVERS_WITH_RESTARTS/$TOTAL_SERVERS"
    
    if [[ $SERVERS_WITH_RESTARTS -eq 0 ]]; then
        STATUS="✅ ALL OK"
        STATUS_CLASS="status-ok"
    elif [[ $SERVERS_WITH_RESTARTS -lt $((TOTAL_SERVERS/2)) ]]; then
        STATUS="⚠️ SOME RESTARTS"
        STATUS_CLASS="status-normal"
    else
        STATUS="❌ MANY RESTARTS"
        STATUS_CLASS="status-high"
    fi
    
    HTML_CONTENT+="
        <tr>
            <td><strong>$service</strong></td>
            <td>$SERVERS_WITH_RESTARTS</td>
            <td>$TOTAL_SERVERS</td>
            <td>$RESTART_RATE</td>
            <td><span class='$STATUS_CLASS'>$STATUS</span></td>
        </tr>"
done

# Complete HTML content
HTML_CONTENT+="
    </table>
    
    <div class='footer'>
        <p>📧 This report shows actual service restarts across all servers in the last 24 hours</p>
        <p>🔄 Next check: Tomorrow at 9:00 AM BST</p>
        <p>⚠️ Daily Restarts = Current Count - Previous Day Count</p>
        <p>🔍 Investigate services with high restart rates immediately</p>
        <p>📊 Total daily restarts across all servers: $TOTAL_DAILY_RESTARTS</p>
    </div>
    
    <script>
        document.getElementById('normal-count').textContent = '$NORMAL_COUNT';
        document.getElementById('high-count').textContent = '$HIGH_COUNT';
        document.getElementById('error-count').textContent = '$ERROR_COUNT';
    </script>
</body>
</html>"

# Create CC list from all emails except the first one
TO_EMAIL="${EMAILS[0]}"
CC_EMAILS=""
for ((i=1; i<${#EMAILS[@]}; i++)); do
    if [[ -n "$CC_EMAILS" ]]; then
        CC_EMAILS="$CC_EMAILS, ${EMAILS[i]}"
    else
        CC_EMAILS="${EMAILS[i]}"
    fi
done

# Send single consolidated email with all recipients visible
{
    echo "From: $FROM_EMAIL"
    echo "To: $TO_EMAIL"
    if [[ -n "$CC_EMAILS" ]]; then
        echo "Cc: $CC_EMAILS"
    fi
    echo "Subject: $SUBJECT"
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/html; charset=UTF-8"
    echo ""
    echo "$HTML_CONTENT"
} | /usr/sbin/sendmail "$TO_EMAIL" "$CC_EMAILS" 2>/dev/null || echo "Failed to send consolidated email"
echo "Consolidated report sent to all recipients"

echo "$(date '+%Y-%m-%d %H:%M:%S') - Systemd services status report completed. Daily restarts: $TOTAL_DAILY_RESTARTS, Normal: $NORMAL_COUNT, High: $HIGH_COUNT, Errors: $ERROR_COUNT" >> "$REPORT_LOG"

# Print summary to console
echo ""
echo "=== SYSTEMD SERVICES STATUS REPORT SUMMARY ==="
echo "Total Servers: $TOTAL_SERVERS"
echo "Total Services: $TOTAL_SERVICES"
echo "Total Daily Restarts: $TOTAL_DAILY_RESTARTS"
echo "Normal: $NORMAL_COUNT"
echo "High Restarts: $HIGH_COUNT"
echo "Errors: $ERROR_COUNT"
echo "Report sent to: ${EMAILS[*]}"
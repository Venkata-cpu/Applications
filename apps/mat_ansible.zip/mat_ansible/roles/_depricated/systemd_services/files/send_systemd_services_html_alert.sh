#!/bin/bash

SCRIPT_DIR="/apps/counter_monitoring/scripts"
LOG_DIR="/apps/counter_monitoring/logs"
DATA_DIR="/apps/counter_monitoring/data"
ALERT_LOG="$LOG_DIR/counter_alert.log"
CURRENT_DATA="$DATA_DIR/daily_counts.txt"
PREVIOUS_DATA="$DATA_DIR/previous_counts.txt"

# Create data directory
mkdir -p "$DATA_DIR"

# Services to monitor
SERVICES=("kafka" "zookeeper" "druid-coordinator" "druid-broker" "druid-historical")

# Move current to previous
if [[ -f "$CURRENT_DATA" ]]; then
    cp "$CURRENT_DATA" "$PREVIOUS_DATA"
fi

# Get current restart counts
> "$CURRENT_DATA"
declare -A CURRENT_COUNTS
declare -A PREVIOUS_COUNTS
declare -A DAILY_RESTARTS

for service in "${SERVICES[@]}"; do
    RESTART_COUNT=$(systemctl show "$service" --property=NRestarts --value 2>/dev/null || echo "0")
    CURRENT_COUNTS["$service"]="$RESTART_COUNT"
    echo "$service:$RESTART_COUNT" >> "$CURRENT_DATA"
done

# Read previous counts
if [[ -f "$PREVIOUS_DATA" ]]; then
    while IFS=':' read -r service count; do
        PREVIOUS_COUNTS["$service"]="$count"
    done < "$PREVIOUS_DATA"
else
    for service in "${SERVICES[@]}"; do
        PREVIOUS_COUNTS["$service"]="0"
    done
fi

# Calculate daily differences
TOTAL_DAILY=0
NORMAL=0
HIGH=0

for service in "${SERVICES[@]}"; do
    CURRENT="${CURRENT_COUNTS[$service]}"
    PREVIOUS="${PREVIOUS_COUNTS[$service]}"
    DAILY_DIFF=$((CURRENT - PREVIOUS))
    
    if [[ $DAILY_DIFF -lt 0 ]]; then
        DAILY_DIFF=$CURRENT
    fi
    
    DAILY_RESTARTS["$service"]="$DAILY_DIFF"
    TOTAL_DAILY=$((TOTAL_DAILY + DAILY_DIFF))
    
    if [[ $DAILY_DIFF -gt 5 ]]; then
        ((HIGH++))
    elif [[ $DAILY_DIFF -gt 0 ]]; then
        ((NORMAL++))
    fi
done

# Email configuration
EMAILS=("asritha.2.meka@bt.com" "pradip.mandal@bt.com" "suraj.tomar@bt.com")
FROM_EMAIL="martini.ee.monitoring@bt.com"
SUBJECT="Daily Counter Restart Report"

# Get current date and time
CURRENT_TIME=$(date '+%Y-%m-%d %H:%M:%S %Z')

# Sample data (replace with actual monitoring results)
TOTAL=${#SERVICES[@]}
# NORMAL and HIGH calculated above

# Create HTML email content
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .header { background-color: #34495e; color: white; padding: 15px; text-align: center; border-radius: 5px; }
        .summary { background-color: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .summary-box { display: inline-block; margin: 10px; padding: 10px; border-radius: 5px; text-align: center; min-width: 80px; }
        .normal-box { background-color: #d5f4e6; border: 2px solid #27ae60; }
        .high-box { background-color: #fadbd8; border: 2px solid #e74c3c; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #34495e; color: white; }
        .status-ok { color: #27ae60; font-weight: bold; }
        .status-normal { color: #f39c12; font-weight: bold; }
        .status-high { color: #e74c3c; font-weight: bold; }
        .footer { margin-top: 20px; font-size: 12px; color: #7f8c8d; }
    </style>
</head>
<body>
    <div class='header'>
        <h2>🔄 Service Restart Counter Report</h2>
        <p>Server: $(hostname) | Time: $CURRENT_TIME</p>
        <p><strong>📊 Daily Restarts: $TOTAL_DAILY</strong></p>
    </div>
    
    <div class='summary'>
        <h3>📊 Summary</h3>
        <div class='summary-box normal-box'>
            <div>DAILY RESTARTS</div>
            <div style='font-size: 24px; font-weight: bold;'>$TOTAL_DAILY</div>
        </div>
        <div class='summary-box normal-box'>
            <div>NORMAL</div>
            <div style='font-size: 24px; font-weight: bold;'>$NORMAL</div>
        </div>
        <div class='summary-box high-box'>
            <div>HIGH RESTARTS</div>
            <div style='font-size: 24px; font-weight: bold;'>$HIGH</div>
        </div>
        <p><strong>Total Services:</strong> $TOTAL</p>
    </div>
    
    <h3>🖥️ Service Restart Details (Last 24 Hours)</h3>
    <table>
        <tr>
            <th>Service</th>
            <th>Daily Restarts</th>
            <th>Total Restarts</th>
            <th>Status</th>
            <th>Threshold</th>
        </tr>"

# Add actual service data to HTML
for service in "${SERVICES[@]}"; do
    DAILY="${DAILY_RESTARTS[$service]}"
    TOTAL_COUNT="${CURRENT_COUNTS[$service]}"
    
    if [[ $DAILY -eq 0 ]]; then
        STATUS="✅ OK"
        STATUS_CLASS="status-ok"
    elif [[ $DAILY -le 5 ]]; then
        STATUS="⚠️ NORMAL"
        STATUS_CLASS="status-normal"
    else
        STATUS="❌ HIGH"
        STATUS_CLASS="status-high"
    fi
    
    HTML_CONTENT+="
        <tr>
            <td>$service</td>
            <td><strong>$DAILY</strong></td>
            <td>$TOTAL_COUNT</td>
            <td><span class='$STATUS_CLASS'>$STATUS</span></td>
            <td>5</td>
        </tr>"
done

HTML_CONTENT+="
    </table>
    
    <div class='footer'>
        <p>📧 This report shows actual service restarts in the last 24 hours</p>
        <p>🔄 Next check: Tomorrow at 9:00 AM BST</p>
        <p>⚠️ Daily Restarts = Current Count - Previous Day Count</p>
        <p>🔍 Investigate services with HIGH daily restarts immediately</p>
    </div>
</body>
</html>"

# Create CC list from all emails except the first one
TO_EMAIL="${EMAILS[0]}"
CC_EMAILS=""
for ((i=1; i<${#EMAILS[@]}; i++)); do
    if [[ -n "$CC_EMAILS" ]]; then
        CC_EMAILS="$CC_EMAILS, ${EMAILS[i]}"
    else
        CC_EMAILS="${EMAILS[i]}"
    fi
done

# Send single email with all recipients visible
{
    echo "From: $FROM_EMAIL"
    echo "To: $TO_EMAIL"
    if [[ -n "$CC_EMAILS" ]]; then
        echo "Cc: $CC_EMAILS"
    fi
    echo "Subject: $SUBJECT"
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/html; charset=UTF-8"
    echo ""
    echo "$HTML_CONTENT"
} | /usr/sbin/sendmail "$TO_EMAIL" "$CC_EMAILS"
echo "HTML counter status email sent to all recipients"

echo "$(date '+%Y-%m-%d %H:%M:%S') - HTML daily counter status sent" >> "$ALERT_LOG"
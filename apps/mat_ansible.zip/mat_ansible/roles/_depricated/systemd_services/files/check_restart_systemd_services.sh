#!/bin/bash

SCRIPT_DIR="/apps/counter_monitoring/scripts"
LOG_DIR="/apps/counter_monitoring/logs"
THRESHOLD=5

# ANSI colors
RED='\033[0;31m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
NC='\033[0m'

echo "Checking restart counters for services..."
echo ""

# Services to monitor
SERVICES=("kafka" "zookeeper" "druid-coordinator" "druid-broker" "druid-historical")

TOTAL=0
HIGH_RESTART=0
NORMAL_RESTART=0

for service in "${SERVICES[@]}"; do
    # Get restart count from systemctl
    RESTART_COUNT=$(systemctl show "$service" --property=NRestarts --value 2>/dev/null || echo "0")
    
    if [[ $RESTART_COUNT -gt $THRESHOLD ]]; then
        COLOR=$RED
        STATUS="HIGH"
        ((HIGH_RESTART++))
    elif [[ $RESTART_COUNT -gt 0 ]]; then
        COLOR=$AMBER
        STATUS="NORMAL"
        ((NORMAL_RESTART++))
    else
        COLOR=$GREEN
        STATUS="OK"
    fi
    
    echo -e "$service: ${COLOR}$RESTART_COUNT restarts ($STATUS)${NC}"
    "$SCRIPT_DIR/write_counter_log.sh" "$service: $RESTART_COUNT restarts ($STATUS)"
    ((TOTAL++))
done

# Summary
echo ""
echo -e "Summary:"
echo -e "Total services: $TOTAL"
echo -e "${GREEN}Normal: $NORMAL_RESTART${NC}"
echo -e "${RED}High restarts: $HIGH_RESTART${NC}"
"$SCRIPT_DIR/write_counter_log.sh" "Summary: Total=$TOTAL, Normal=$NORMAL_RESTART, High=$HIGH_RESTART"
#!/bin/bash

# Paths
K8S_REPORT="/tmp/k8s_report.txt"
HERALD_REPORT="/tmp/herald_jobs_failure.html"
DOWNLOAD_REPORT="/tmp/download_report_failure.html"

# Generate reports
python3 /usr/local/bin/k8s_restart_check.py > $K8S_REPORT 2>&1
python3 /opt/health_check_reporter/scripts/herald_jobs_check.py
python3 /opt/scripts/health_check_reporter.py

# Read reports
K8S_CONTENT=$(cat $K8S_REPORT)
HERALD_CONTENT=$(cat $HERALD_REPORT)
DOWNLOAD_CONTENT=$(cat $DOWNLOAD_REPORT)

# Check for issues
K8S_ISSUES=$(grep -c "Daily Restarts:" $K8S_REPORT | grep -v "0" || echo "0")
HERALD_ISSUES=$(grep -c "FAILED\|PARTIAL SUCCESS" $HERALD_REPORT || echo "0")
DOWNLOAD_ISSUES=$(grep -c "Failed" $DOWNLOAD_REPORT || echo "0")

# Determine card status
if [ "$K8S_ISSUES" != "0" ]; then
    K8S_CARD="<div class='service-card red'><div>🚨</div><h3>Kubernetes Health</h3><p><strong>Issues Found</strong></p></div>"
else
    K8S_CARD="<div class='service-card green'><div>✅</div><h3>Kubernetes Health</h3><p><strong>All OK</strong></p></div>"
fi

if [ "$HERALD_ISSUES" != "0" ]; then
    HERALD_CARD="<div class='service-card red'><div>🚨</div><h3>Herald Jobs</h3><p><strong>Failures Detected</strong></p><small>$HERALD_ISSUES issues found</small></div>"
else
    HERALD_CARD="<div class='service-card green'><div>✅</div><h3>Herald Jobs</h3><p><strong>All OK</strong></p></div>"
fi

if [ "$DOWNLOAD_ISSUES" != "0" ]; then
    DOWNLOAD_CARD="<div class='service-card red'><div>🚨</div><h3>Download Reports</h3><p><strong>Failures Detected</strong></p><small>$DOWNLOAD_ISSUES issues found</small></div>"
else
    DOWNLOAD_CARD="<div class='service-card green'><div>✅</div><h3>Download Reports</h3><p><strong>All OK</strong></p></div>"
fi

# Email configuration
EMAILS=("asritha.2.meka@bt.com")
FROM_EMAIL="martini.ee.monitoring@bt.com"

# Build HTML email
HTML_CONTENT="<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f8f9fa; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; }
        .date-time { color: #4285f4; margin: 10px 0; }
        .summary-row { display: flex; gap: 15px; margin-bottom: 30px; flex-wrap: wrap; justify-content: space-between; }
        .service-card { border: 2px solid; border-radius: 8px; padding: 15px; flex: 1; min-width: 220px; max-width: 250px; text-align: center; margin: 5px; }
        .red { border-color: #dc3545; background-color: #f8d7da; color: #721c24; }
        .green { border-color: #28a745; background-color: #d4edda; color: #155724; }
        .details-section { margin-top: 30px; }
        .issue-details { border: 1px solid #dc3545; border-radius: 8px; padding: 20px; background-color: #f8f9fa; }
        pre { background-color: #ffffff; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
    </style>
</head>
<body>
    <div class='container'>
    <div class='header'>
        <h1>📊 Daily Health Check Report</h1>
        <div class='date-time'>
            <strong>Date:</strong> $(date '+%A, %B %d, %Y')<br>
            <strong>Time:</strong> $(date '+%H:%M GMT')
        </div>
    </div>
    
    <div class='summary-row'>
        $K8S_CARD
        $HERALD_CARD
        $DOWNLOAD_CARD
    </div>"

# Add K8s details if issues
if [ "$K8S_ISSUES" != "0" ]; then
    HTML_CONTENT+="
    <div class='details-section'>
        <h2>🚨 Kubernetes Health - Detailed Issues</h2>
        <div class='issue-details'>
            <pre>$K8S_CONTENT</pre>
        </div>
    </div>"
fi

# Add Herald details if issues
if [ "$HERALD_ISSUES" != "0" ]; then
    HTML_CONTENT+="
    <div class='details-section'>
        <h2>🚨 Herald Jobs Failure - Last 24 Hours</h2>
        <div class='issue-details'>
            $HERALD_CONTENT
        </div>
    </div>"
fi

# Add Download Report details if issues
if [ "$DOWNLOAD_ISSUES" != "0" ]; then
    HTML_CONTENT+="
    <div class='details-section'>
        <h2>🚨 Download Report Failures - Last 24 Hours</h2>
        <div class='issue-details'>
            $DOWNLOAD_CONTENT
        </div>
    </div>"
fi

HTML_CONTENT+="
    <div style='margin-top: 30px; text-align: center; color: #6c757d;'>
        <p><em>This is an automated health check report.</em></p>
    </div>
    </div>
</body>
</html>"

# Send email
TO_EMAIL="${EMAILS[0]}"

{
    echo "From: $FROM_EMAIL"
    echo "To: $TO_EMAIL"
    echo "Subject: Daily Health Check Report"
    echo "MIME-Version: 1.0"
    echo "Content-Type: text/html; charset=UTF-8"
    echo ""
    echo "$HTML_CONTENT"
} | /usr/sbin/sendmail "$TO_EMAIL" 2>/dev/null

echo "Daily Health Check Report sent to: ${EMAILS[*]}"

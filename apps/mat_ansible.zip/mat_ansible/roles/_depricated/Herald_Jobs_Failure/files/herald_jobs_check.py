#!/usr/bin/env python3

import os
import mysql.connector

OUTPUT_FILE = "/tmp/herald_jobs_failure.html"

def get_failed_jobs():
    # Database connection parameters
    db_host = os.environ.get("DB_HOST", "10.6.120.183")
    db_port = os.environ.get("DB_PORT", "61010")
    db_user = os.environ.get("DB_USER", "ranUser")
    db_password = os.environ.get("DB_PASSWORD", "MatRan@2024")
    db_name = os.environ.get("DB_NAME", "ran")
    
    conn = mysql.connector.connect(
        host=db_host,
        port=int(db_port),
        user=db_user,
        password=db_password,
        database=db_name
    )

    cursor = conn.cursor(dictionary=True)

    query = """
    SELECT 
        STATE as state,
        JOB_TIMESTAMP as job_timestamp,
        JOB_TYPE as job_type,
        POD_NAME as pod_name
    FROM ran.HERALD_DATA_AUDIT
    WHERE (STATE = 'FAILED' OR STATE = 'PARTIAL SUCCESS')
      AND JOB_TIMESTAMP >= NOW() - INTERVAL 1 DAY
    UNION ALL
    SELECT 
        STATE as state,
        JOB_TIMESTAMP as job_timestamp,
        JOB_TYPE as job_type,
        POD_NAME as pod_name
    FROM ran.HERALD_JOB_AUDIT
    WHERE (STATE = 'FAILED' OR STATE = 'PARTIAL SUCCESS')
      AND JOB_TIMESTAMP >= NOW() - INTERVAL 1 DAY
    ORDER BY job_timestamp DESC;
    """

    cursor.execute(query)
    data = cursor.fetchall()

    cursor.close()
    conn.close()
    return data

def generate_html(data):
    html = """
    <html>
    <body>
    <h3>Herald Jobs Failure – Last 24 Hours</h3>
    <table border="1" cellpadding="5" cellspacing="0">
        <tr style="background-color:#f2f2f2">
            <th>State</th>
            <th>Job Timestamp</th>
            <th>Job Type</th>
            <th>Pod Name</th>
        </tr>
    """

    if not data:
        html += """
        <tr>
            <td colspan="4" align="center">
                No failed Herald jobs found in last 24 hours
            </td>
        </tr>
        """
    else:
        for row in data:
            state_color = "red" if row['state'] == 'FAILED' else "orange"
            html += f"""
            <tr>
                <td style="color:{state_color};font-weight:bold">{row['state']}</td>
                <td>{row['job_timestamp']}</td>
                <td>{row['job_type']}</td>
                <td>{row['pod_name']}</td>
            </tr>
            """

    html += """
    </table>
    </body>
    </html>
    """

    with open(OUTPUT_FILE, "w") as f:
        f.write(html)

if __name__ == "__main__":
    failed_jobs = get_failed_jobs()
    generate_html(failed_jobs)

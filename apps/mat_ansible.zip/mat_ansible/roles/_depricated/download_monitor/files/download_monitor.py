#!/usr/bin/env python3
import smtplib
import mysql.connector
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import socket

# Email configuration (same as counter restart)
EMAILS = ["asritha.2.meka@bt.com", "pradip.mandal@bt.com", "suraj.tomar@bt.com"]
FROM_EMAIL = "martini.ee.monitoring@bt.com"

# Database configuration from environment
import os
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_USER = os.getenv('DB_USER', 'root')
DB_PASSWORD = os.getenv('DB_PASSWORD', '')
DB_NAME = os.getenv('DB_NAME', 'database')
DB_PORT = int(os.getenv('DB_PORT', '3306'))

def get_failed_downloads():
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME,
            port=DB_PORT
        )
        cursor = conn.cursor()
        
        query = """
        SELECT REQUEST_ID, CREATED_TIME, USER_ID, STATUS, FILE_NAME, DAGGER_INSTANCE
        FROM REPORT_DOWNLOAD_DATA 
        WHERE STATUS = 'Failed' 
        AND CREATED_TIME >= NOW() - INTERVAL 24 HOUR
        ORDER BY CREATED_TIME DESC
        """
        
        cursor.execute(query)
        results = cursor.fetchall()
        cursor.close()
        conn.close()
        return results
        
    except Exception as e:
        print(f"Database error: {e}")
        return []

def create_html_email(failed_downloads):
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S %Z')
    hostname = socket.gethostname()
    total_failed = len(failed_downloads)
    
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background-color: #34495e; color: white; padding: 15px; text-align: center; border-radius: 5px; }}
        .summary {{ background-color: #ecf0f1; padding: 15px; margin: 10px 0; border-radius: 5px; }}
        .summary-box {{ display: inline-block; margin: 10px; padding: 10px; border-radius: 5px; text-align: center; min-width: 80px; }}
        .normal-box {{ background-color: #d5f4e6; border: 2px solid #27ae60; }}
        .failed-box {{ background-color: #fadbd8; border: 2px solid #e74c3c; }}
        table {{ width: 100%; border-collapse: collapse; margin: 15px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #34495e; color: white; }}
        .status-ok {{ color: #27ae60; font-weight: bold; }}
        .status-failed {{ color: #e74c3c; font-weight: bold; }}
        .footer {{ margin-top: 20px; font-size: 12px; color: #7f8c8d; }}
    </style>
</head>
<body>
    <div class='header'>
        <h2>📥 Download Report Monitoring</h2>
        <p>Server: {hostname} | Time: {current_time}</p>
        <p><strong>📊 Failed Downloads (24h): {total_failed}</strong></p>
    </div>
    
    <div class='summary'>
        <h3>📊 Summary</h3>
        <div class='summary-box {"failed-box" if total_failed > 0 else "normal-box"}'>
            <div>FAILED DOWNLOADS</div>
            <div style='font-size: 24px; font-weight: bold;'>{total_failed}</div>
        </div>
        <p><strong>Status:</strong> {"❌ ATTENTION REQUIRED" if total_failed > 0 else "✅ ALL DOWNLOADS OK"}</p>
    </div>"""

    if failed_downloads:
        html_content += """
    <h3>❌ Failed Download Details (Last 24 Hours)</h3>
    <table>
        <tr>
            <th>Request ID</th>
            <th>Time</th>
            <th>User ID</th>
            <th>File Name</th>
            <th>Dagger Instance</th>
            <th>Status</th>
        </tr>"""
        
        for download in failed_downloads:
            html_content += f"""
        <tr>
            <td>{download[0]}</td>
            <td>{download[1]}</td>
            <td>{download[2]}</td>
            <td>{download[4] or 'N/A'}</td>
            <td>{download[5]}</td>
            <td><span class='status-failed'>❌ FAILED</span></td>
        </tr>"""
        
        html_content += "</table>"
    else:
        html_content += """
    <h3>✅ No Failed Downloads</h3>
    <p style='color: #27ae60; font-size: 18px; text-align: center; padding: 20px;'>
        All download reports are working properly in the last 24 hours.
    </p>"""

    html_content += f"""
    <div class='footer'>
        <p>📧 This report shows failed download reports in the last 24 hours</p>
        <p>🔄 Next check: Tomorrow at 9:00 AM BST</p>
        <p>⚠️ Investigate failed downloads immediately</p>
    </div>
</body>
</html>"""
    
    return html_content

def send_email_report(failed_downloads):
    try:
        html_content = create_html_email(failed_downloads)
        
        # Create email headers
        to_email = EMAILS[0]
        cc_emails = ", ".join(EMAILS[1:]) if len(EMAILS) > 1 else ""
        
        email_content = f"""From: {FROM_EMAIL}
To: {to_email}"""
        
        if cc_emails:
            email_content += f"\nCc: {cc_emails}"
            
        email_content += f"""
Subject: Daily Download Report
MIME-Version: 1.0
Content-Type: text/html; charset=UTF-8

{html_content}"""
        
        # Send via sendmail
        import subprocess
        recipients = " ".join([f'"{email}"' for email in EMAILS])
        process = subprocess.Popen(['/usr/sbin/sendmail'] + EMAILS, stdin=subprocess.PIPE, text=True)
        process.communicate(input=email_content)
        
        print(f"HTML download report email sent to all recipients at {datetime.now()}")
        
    except Exception as e:
        print(f"Email error: {e}")

if __name__ == "__main__":
    failed_downloads = get_failed_downloads()
    send_email_report(failed_downloads)
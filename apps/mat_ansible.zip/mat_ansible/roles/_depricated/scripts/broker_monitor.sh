#!/bin/bash

# Broker monitoring script
BROKERS=("10.6.120.173:61001" "10.6.120.174:61001" "10.6.120.175:61001")
EMAIL="asritha.2.meka@bt.com"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S BST')

# Check broker status
UP_COUNT=0
DOWN_BROKERS=""
STATUS_REPORT=""

for broker in "${BROKERS[@]}"; do
    HOST=$(echo $broker | cut -d: -f1)
    PORT=$(echo $broker | cut -d: -f2)
    
    if timeout 5 bash -c "</dev/tcp/$HOST/$PORT" 2>/dev/null; then
        STATUS_REPORT+="✓ $broker - UP\n"
        ((UP_COUNT++))
    else
        STATUS_REPORT+="✗ $broker - DOWN\n"
        DOWN_BROKERS+="$broker "
    fi
done

# Send email based on status
if [ $UP_COUNT -eq ${#BROKERS[@]} ]; then
    # All brokers up - send daily report only at 6AM
    if [ "$(date +%H)" = "06" ]; then
        echo -e "Broker Status Report - $TIMESTAMP\n\n$STATUS_REPORT\nAll brokers operational." | mail -s "Broker Status - ALL UP" "$EMAIL"
    fi
else
    # Send immediate alert for failures
    echo -e "ALERT: Broker Failure Detected - $TIMESTAMP\n\n$STATUS_REPORT\nDown brokers: $DOWN_BROKERS" | mail -s "CRITICAL: Broker Down Alert" "$EMAIL"
fi
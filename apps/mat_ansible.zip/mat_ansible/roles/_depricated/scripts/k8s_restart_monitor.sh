#!/bin/bash

# Kubernetes restart monitoring script
EMAILS="asritha.2.meka@bt.com suraj.tomar@bt.com"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S BST')
THRESHOLD=1

# Get all pods with restart counts > threshold
HIGH_RESTARTS=$(kubectl get pods --all-namespaces -o custom-columns="NAMESPACE:.metadata.namespace,NAME:.metadata.name,RESTARTS:.status.containerStatuses[*].restartCount,NODE:.spec.nodeName" --no-headers | awk -v thresh=$THRESHOLD '$3 > thresh')

# Count total restarts by worker node
WORKER_RESTARTS=$(kubectl get pods --all-namespaces -o custom-columns="NODE:.spec.nodeName,RESTARTS:.status.containerStatuses[*].restartCount" --no-headers | grep -v "blp20919615" | awk '{node[$1]+=$2} END {for(n in node) if(node[n]>0) print n": "node[n]" restarts"}')

# Total cluster restarts
TOTAL_RESTARTS=$(kubectl get pods --all-namespaces -o jsonpath='{.items[*].status.containerStatuses[*].restartCount}' | tr ' ' '\n' | awk '{sum+=$1} END {print sum+0}')

# Generate report
REPORT="Kubernetes Restart Report - $TIMESTAMP\n\n"
REPORT+="TOTAL CLUSTER RESTARTS: $TOTAL_RESTARTS\n\n"
REPORT+="RESTARTS BY WORKER NODE:\n$WORKER_RESTARTS\n\n"

if [ -n "$HIGH_RESTARTS" ]; then
    REPORT+="PODS WITH RESTARTS > $THRESHOLD:\n$HIGH_RESTARTS\n"
    STATUS="ALERT"
    SUBJECT="K8s Restart Alert - High Restart Count"
else
    REPORT+="No pods with high restart counts\n"
    STATUS="OK"
    SUBJECT="K8s Restart Report - All Normal"
fi

# Send email based on conditions
if [ -n "$HIGH_RESTARTS" ]; then
    # Immediate alert for high restarts
    echo -e "$REPORT" | mail -s "$SUBJECT" $EMAILS
    logger "K8s Monitor: High restarts detected - $TOTAL_RESTARTS total"
elif [ "$(date +%H:%M)" = "10:00" ]; then
    # Daily report at 10 AM
    echo -e "$REPORT" | mail -s "Daily K8s Restart Report" $EMAILS
    logger "K8s Monitor: Daily report sent - $TOTAL_RESTARTS total restarts"
fi

# Always log summary
logger "K8s Monitor: Total restarts: $TOTAL_RESTARTS"
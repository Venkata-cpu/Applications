#!/bin/bash

# Broker monitoring script
BROKERS=("10.6.120.173:61001" "10.6.120.174:61001" "10.6.120.175:61001")
EMAILS="asritha.2.meka@bt.com,suraj.tomar@bt.com"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S BST')

# Check broker status
UP_COUNT=0
DOWN_BROKERS=""
STATUS_REPORT=""

for broker in "${BROKERS[@]}"; do
    HOST=$(echo $broker | cut -d: -f1)
    PORT=$(echo $broker | cut -d: -f2)
    
    if timeout 5 bash -c "</dev/tcp/$HOST/$PORT" 2>/dev/null; then
        STATUS_REPORT+="✓ $broker - UP\n"
        ((UP_COUNT++))
    else
        STATUS_REPORT+="✗ $broker - DOWN\n"
        DOWN_BROKERS+="$broker "
    fi
done

# Determine status color
if [ $UP_COUNT -eq ${#BROKERS[@]} ]; then
    STATUS="GREEN"
    STATUS_MSG="All brokers operational"
else
    FAILED_COUNT=$((${#BROKERS[@]} - UP_COUNT))
    if [ $FAILED_COUNT -eq ${#BROKERS[@]} ]; then
        STATUS="RED"
        STATUS_MSG="All brokers down - CRITICAL"
    else
        STATUS="AMBER"
        STATUS_MSG="$FAILED_COUNT broker(s) down - WARNING"
    fi
fi

# Send email based on status
if [ $UP_COUNT -eq ${#BROKERS[@]} ]; then
    # All brokers up - send daily report only at 6:35 AM
    if [ "$(date +%H:%M)" = "06:35" ]; then
        echo -e "Broker Status Report - $TIMESTAMP\n\nSTATUS: $STATUS\n\n$STATUS_REPORT\n$STATUS_MSG" | mail -s "Broker Status - $STATUS" "$EMAILS"
    fi
else
    # Send immediate alert for failures
    echo -e "ALERT: Broker Failure Detected - $TIMESTAMP\n\nSTATUS: $STATUS\n\n$STATUS_REPORT\n$STATUS_MSG\nDown brokers: $DOWN_BROKERS" | mail -s "$STATUS: Broker Alert" "$EMAILS"
fi
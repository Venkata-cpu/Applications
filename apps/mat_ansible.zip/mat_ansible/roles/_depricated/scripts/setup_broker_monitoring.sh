#!/bin/bash

# Add to crontab for daily monitoring
echo "0 8 * * * /path/to/broker_health_check.sh" | crontab -

# For immediate setup
chmod +x broker_health_check.sh
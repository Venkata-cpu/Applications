#!/bin/bash

# Setup cron for hourly monitoring
SCRIPT_PATH="/opt/monitoring/broker_monitor.sh"

# Add hourly check to crontab
(crontab -l 2>/dev/null; echo "0 * * * * $SCRIPT_PATH") | crontab -

# Make script executable
chmod +x broker_monitor.sh

echo "Cron job added for hourly broker monitoring"
echo "Daily reports at 6AM BST, immediate alerts for failures"
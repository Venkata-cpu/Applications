#!/usr/bin/env python3
import os
import subprocess
from datetime import datetime

# Read issues from report file
issues = []
if os.path.exists("/tmp/k8s_health_report.txt"):
    with open("/tmp/k8s_health_report.txt", 'r') as f:
        for line in f:
            line = line.strip()
            if line and line != "No issues found":
                parts = line.split('|')
                if len(parts) == 5:
                    issues.append(parts[0])

# Generate simple email
count = len(issues)
status = "🚨 Issues Found" if issues else "✅ All Good"

email_body = f"""
Subject: Daily K8s Health Check - {datetime.now().strftime('%Y-%m-%d')}

Kubernetes Health Status: {status}
Total Issues: {count} pods

Issues Found:
"""

if issues:
    for issue in issues[:10]:  # First 10 issues
        email_body += f"- {issue}\n"

# Send email
with open('/tmp/k8s_email.txt', 'w') as f:
    f.write(email_body)

# Send to both recipients
recipients = ["asritha.2.meka@bt.com", "pradip.mandal@bt.com"]
for recipient in recipients:
    subprocess.run(f'mail {recipient} < /tmp/k8s_email.txt', shell=True)

print(f"✅ Email sent: {status} - {count} issues")
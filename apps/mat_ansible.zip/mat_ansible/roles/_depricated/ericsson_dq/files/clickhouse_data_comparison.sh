#!/bin/bash

LOG_FILE="/opt/health_check_reporter/logs/clickhouse_comparison.log"

CLICKHOUSE_HOST="${CLICKHOUSE_HOST:-martini.preprod.nat.bt.com}"
CLICKHOUSE_PORT="${CLICKHOUSE_PORT:-61137}"
CLICKHOUSE_USER="${CLICKHOUSE_USER:-readonly}"
CLICKHOUSE_PASSWORD="${CLICKHOUSE_PASSWORD:-RoUserP#2024}"

DB="default"
TABLE="distributed_ee_raw"

REPORT_FILE="/tmp/clickhouse_data_comparison.txt"
HTML_REPORT="/tmp/clickhouse_data_comparison.html"

TECHNOLOGIES=("2g" "4g" "5g" "system")

echo "$(date): Starting ClickHouse data comparison" >> "$LOG_FILE"
echo "Technology | Time Slot | Yesterday Count | Day-Before Count" > "$REPORT_FILE"

query_clickhouse() {
    local tech=$1
    local yesterday_start=$2
    local yesterday_end=$3
    local day_before_start=$4
    local day_before_end=$5

    curl -s -k -u "$CLICKHOUSE_USER:$CLICKHOUSE_PASSWORD" \
      "https://$CLICKHOUSE_HOST:$CLICKHOUSE_PORT/?database=$DB" \
      -d "
      WITH
        yesterday AS (
          SELECT
            toStartOfInterval(timeStamp, INTERVAL 15 MINUTE) AS time_slot,
            count() AS cnt
          FROM $TABLE
          WHERE technology = '$tech'
            AND timeStamp >= '$yesterday_start'
            AND timeStamp < '$yesterday_end'
          GROUP BY time_slot
        ),
        day_before AS (
          SELECT
            toStartOfInterval(timeStamp, INTERVAL 15 MINUTE) AS time_slot,
            count() AS cnt
          FROM $TABLE
          WHERE technology = '$tech'
            AND timeStamp >= '$day_before_start'
            AND timeStamp < '$day_before_end'
          GROUP BY time_slot
        )
      SELECT
        formatDateTime(y.time_slot, '%Y-%m-%d %H:%i:%s') AS time_slot,
        y.cnt AS yesterday_cnt,
        d.cnt AS day_before_cnt
      FROM yesterday y
      INNER JOIN day_before d ON toTime(y.time_slot) = toTime(d.time_slot)
      WHERE y.cnt != d.cnt
      ORDER BY time_slot
      FORMAT CSV
      "
}

# Yesterday (D-1)
YESTERDAY_START=$(date -d 'yesterday 00:00:00' +"%Y-%m-%d %H:%M:%S")
YESTERDAY_END=$(date -d 'today 00:00:00' +"%Y-%m-%d %H:%M:%S")

# Day before yesterday (D-2)
DAY_BEFORE_START=$(date -d '2 days ago 00:00:00' +"%Y-%m-%d %H:%M:%S")
DAY_BEFORE_END=$(date -d 'yesterday 00:00:00' +"%Y-%m-%d %H:%M:%S")

MISMATCH_FOUND=0

for TECH in "${TECHNOLOGIES[@]}"; do
    while IFS=, read -r time_slot yesterday_cnt day_before_cnt; do
        # Skip header line
        [[ "$time_slot" == "time_slot" ]] && continue
        time_slot=$(echo "$time_slot" | tr -d '"')
        
        echo "$TECH | $time_slot | $yesterday_cnt | $day_before_cnt" >> "$REPORT_FILE"
        MISMATCH_FOUND=1
    done < <(query_clickhouse "$TECH" "$YESTERDAY_START" "$YESTERDAY_END" "$DAY_BEFORE_START" "$DAY_BEFORE_END")
done

if [[ $MISMATCH_FOUND -eq 0 ]]; then
    echo "No data drops or mismatches detected in last 24 hours." > "$REPORT_FILE"
    echo "$(date): No mismatches found - skipping HTML report" >> "$LOG_FILE"
    rm -f "$HTML_REPORT"
else
    echo "$(date): Report generated: $REPORT_FILE" >> "$LOG_FILE"
    
    echo "<h3>ClickHouse Data Comparison Report - $(date '+%Y-%m-%d')</h3>" > "$HTML_REPORT"
    echo '<table border="1" cellpadding="5" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif;">' >> "$HTML_REPORT"
    echo '<thead><tr style="background-color: #4CAF50; color: white;"><th>Technology</th><th>Time Slot</th><th>Yesterday Count</th><th>Day-Before Count</th></tr></thead><tbody>' >> "$HTML_REPORT"
    tail -n +2 "$REPORT_FILE" | while IFS='|' read -r tech time_slot yesterday_cnt day_before_cnt; do
        echo "<tr><td>$tech</td><td>$time_slot</td><td>$yesterday_cnt</td><td>$day_before_cnt</td></tr>" >> "$HTML_REPORT"
    done
    echo '</tbody></table>' >> "$HTML_REPORT"
    
    echo "$(date): HTML report created: $HTML_REPORT" >> "$LOG_FILE"
fi

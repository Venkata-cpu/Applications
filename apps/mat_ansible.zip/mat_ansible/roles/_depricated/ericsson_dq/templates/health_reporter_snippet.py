#!/usr/bin/env python3
"""
Template snippet to add to health_check_reporter.py
Add this section to include ClickHouse comparison in the email report
"""

# Add this to the report generation section:

def include_clickhouse_comparison():
    """Include ClickHouse data comparison in the report"""
    clickhouse_file = "/tmp/clickhouse_data_comparison.html"
    
    if os.path.exists(clickhouse_file):
        with open(clickhouse_file, 'r') as f:
            return f.read()
    else:
        return "<p>No ClickHouse comparison data available</p>"

# In the main HTML generation, add:
# clickhouse_section = include_clickhouse_comparison()
# Then include it in your HTML template where appropriate

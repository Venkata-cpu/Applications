#!/bin/bash
# Download report failure monitoring script (10.54.106.77)

LOG_FILE="/opt/health_check_reporter/logs/download_report.log"
EMAIL_SERVER="10.54.106.76"

echo "$(date): Starting download report failure check" >> "$LOG_FILE"

# Run download report failure check only
DB_HOST="${DB_HOST:-10.6.120.183}" \
DB_PORT="${DB_PORT:-3306}" \
DB_NAME="${DB_NAME:-ran}" \
DB_USER="${DB_USER:-ranUser}" \
DB_PASSWORD="${DB_PASSWORD}" \
python3 /opt/health_check_reporter/scripts/download_report_failure.py

if [ $? -eq 0 ]; then
    echo "$(date): Download report check completed, sending results to email server" >> "$LOG_FILE"
    # Send results to email server
    scp /tmp/download_report_failures.txt root@$EMAIL_SERVER:/tmp/
    echo "$(date): Results sent to email server" >> "$LOG_FILE"
else
    echo "$(date): Download report check failed" >> "$LOG_FILE"
fi
#!/bin/bash
# Email server script - receives and sends reports from monitoring server

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"

export KUBECONFIG="/root/.kube/config"

echo "$(date): Starting daily health check report" >> "$LOG_FILE"

# Run local health check (K8s pods)
/opt/health_check_reporter/scripts/k8s_pod_health_check.sh
k8s_exit_code=$?

# Check if we received a report from monitoring server (10.54.106.77)
if [[ -f "/tmp/health_report.html" ]]; then
    echo "$(date): Using combined report from monitoring server" >> "$LOG_FILE"
    cp "/tmp/health_report.html" "$REPORT_FILE"
    rm -f "/tmp/health_report.html"
    python_exit_code=0
else
    echo "$(date): No combined report received, generating local K8s-only report" >> "$LOG_FILE"
    # Generate local report
    python3 /opt/health_check_reporter/scripts/health_check_reporter.py
    python_exit_code=$?
fi

if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    TO="asritha.2.meka@bt.com, pradip.mandal@bt.com"
    SUBJECT="Daily Health Check Report"
    FROM="health-check@$(hostname -f)"

    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html"
        echo
        cat "$REPORT_FILE"
    } | sendmail -t

    echo "$(date): Email sent successfully" >> "$LOG_FILE"
else
    echo "$(date): Failed to generate report (python_exit_code=$python_exit_code)" >> "$LOG_FILE"
fi
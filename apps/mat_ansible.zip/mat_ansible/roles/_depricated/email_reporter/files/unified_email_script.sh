#!/bin/bash
# Email server script - combines K8s health (from master) + download failures (from 10.54.106.77)

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"

export KUBECONFIG="/root/.kube/config"

echo "$(date): Starting unified health check report generation" >> "$LOG_FILE"

# Run local K8s health check (this server has kubectl access to master)
/opt/health_check_reporter/scripts/k8s_pod_health_check.sh
k8s_exit_code=$?

# Generate unified report (includes both K8s and download failures)
python3 /opt/health_check_reporter/scripts/health_check_reporter.py
python_exit_code=$?

if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    TO="asritha.2.meka@bt.com, pradip.mandal@bt.com"
    SUBJECT="Daily Health Check Report"
    FROM="health-check@$(hostname -f)"

    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html"
        echo
        cat "$REPORT_FILE"
    } | sendmail -t

    echo "$(date): Unified email sent successfully" >> "$LOG_FILE"
else
    echo "$(date): Failed to generate unified report (python_exit_code=$python_exit_code)" >> "$LOG_FILE"
fi
#!/usr/bin/env python3
import os
import re
import datetime

def generate_health_report():
    """Generate HTML health check report including download report failures"""
    
    # Read k8s check results
    k8s_status = "green"
    k8s_issues = []
    server_issues = {}
    
    if os.path.exists("/tmp/k8s_pod_health_report.txt"):
        with open("/tmp/k8s_pod_health_report.txt", "r") as f:
            for line in f:
                line = line.strip()
                if line and line != "No issues found":
                    k8s_status = "red"
                    parts = line.split('|')
                    if len(parts) >= 4:
                        pod_name = parts[0]
                        namespace = parts[1]
                        status = parts[2]
                        server = parts[3] if len(parts) > 3 else "Unknown"
                        restart_count = parts[4] if len(parts) > 4 else "0"
                        
                        if server not in server_issues:
                            server_issues[server] = []
                        
                        server_issues[server].append({
                            'pod': pod_name,
                            'status': status,
                            'restarts': restart_count
                        })
                        k8s_issues.append(f"{pod_name} in {namespace} is {status}")
    
    # Read download report failures
    download_failures = []
    download_status = "green"
    
    if os.path.exists("/tmp/download_report_failures.txt"):
        with open("/tmp/download_report_failures.txt", "r") as f:
            for line in f:
                line = line.strip()
                if line and line != "No failures found":
                    download_status = "red"
                    parts = line.split('|')
                    if len(parts) >= 5:
                        download_failures.append({
                            'report_name': parts[0],
                            'report_date': parts[1],
                            'vendor': parts[2],
                            'status': parts[3],
                            'user_ein': parts[4]
                        })
    
    # Read Herald job failures
    herald_failures = []
    herald_status = "green"
    
    if os.path.exists("/tmp/herald_jobs_failure.html"):
        with open("/tmp/herald_jobs_failure.html", "r") as f:
            content = f.read()
            if "FAILED" in content or "PARTIAL SUCCESS" in content:
                herald_status = "red"
                # Parse HTML table rows
                rows = re.findall(r'<tr>\s*<td[^>]*>(.*?)</td>\s*<td[^>]*>(.*?)</td>\s*<td[^>]*>(.*?)</td>\s*<td[^>]*>(.*?)</td>\s*</tr>', content, re.DOTALL)
                for row in rows:
                    if row[0] and 'FAILED' in row[0] or 'PARTIAL' in row[0]:
                        herald_failures.append({
                            'state': row[0].strip(),
                            'timestamp': row[1].strip(),
                            'job_type': row[2].strip(),
                            'pod_name': row[3].strip()
                        })
    
    # Read ClickHouse data comparison (Ericsson DQ)
    clickhouse_data = ""
    clickhouse_status = "green"
    clickhouse_issues = 0
    
    if os.path.exists("/tmp/clickhouse_data_comparison.html"):
        with open("/tmp/clickhouse_data_comparison.html", "r") as f:
            clickhouse_data = f.read()
            if "<table" in clickhouse_data:
                clickhouse_status = "red"
                # Count rows in table
                clickhouse_issues = clickhouse_data.count("<tr>") - 1  # Subtract header row
    elif os.path.exists("/tmp/clickhouse_data_comparison.txt"):
        with open("/tmp/clickhouse_data_comparison.txt", "r") as f:
            content = f.read()
            if "No data drops" not in content:
                clickhouse_status = "red"
                lines = content.strip().split('\n')
                if len(lines) > 1:
                    clickhouse_issues = len(lines) - 1
            clickhouse_data = content
    
    # Read Nokia ClickHouse data comparison
    nokia_data = ""
    nokia_status = "green"
    nokia_issues = 0
    
    if os.path.exists("/tmp/clickhouse_nokia_comparison.html"):
        with open("/tmp/clickhouse_nokia_comparison.html", "r") as f:
            nokia_data = f.read()
            if "<table" in nokia_data:
                nokia_status = "red"
                nokia_issues = nokia_data.count("<tr>") - 1
    elif os.path.exists("/tmp/clickhouse_nokia_comparison.txt"):
        with open("/tmp/clickhouse_nokia_comparison.txt", "r") as f:
            content = f.read()
            if "No data drops" not in content:
                nokia_status = "red"
                lines = content.strip().split('\n')
                if len(lines) > 1:
                    nokia_issues = len(lines) - 1
            nokia_data = content
    
    # Read Huawei ClickHouse data comparison
    huawei_data = ""
    huawei_status = "green"
    huawei_issues = 0
    
    if os.path.exists("/tmp/clickhouse_huawei_comparison.html"):
        with open("/tmp/clickhouse_huawei_comparison.html", "r") as f:
            huawei_data = f.read()
            if "<table" in huawei_data:
                huawei_status = "red"
                huawei_issues = huawei_data.count("<tr>") - 1
    elif os.path.exists("/tmp/clickhouse_huawei_comparison.txt"):
        with open("/tmp/clickhouse_huawei_comparison.txt", "r") as f:
            content = f.read()
            if "No data drops" not in content:
                huawei_status = "red"
                lines = content.strip().split('\n')
                if len(lines) > 1:
                    huawei_issues = len(lines) - 1
            huawei_data = content
    
    # Count total issues
    total_k8s_issues = len(k8s_issues)
    total_download_failures = len(download_failures)
    total_herald_failures = len(herald_failures)
    total_clickhouse_issues = clickhouse_issues
    total_nokia_issues = nokia_issues
    total_huawei_issues = huawei_issues
    current_time = datetime.datetime.now()
    
    # Generate k8s server details table
    k8s_server_details = ""
    if server_issues:
        k8s_server_details = """
        <div class="server-section">
            <h3>🔍 Kubernetes Pod Issues</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Pod Name</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Server</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Status</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Restarts</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        for server, issues in server_issues.items():
            for issue in issues:
                status_color = "#dc3545" if issue['status'] in ['Error', 'CrashLoopBackOff', 'ImagePullBackOff'] else "#fd7e14" if issue['status'] == 'Evicted' else "#6c757d"
                k8s_server_details += f"""
                <tr>
                    <td style="border: 1px solid #dee2e6; padding: 8px; font-family: monospace; font-size: 12px;">{issue['pod']}</td>
                    <td style="border: 1px solid #dee2e6; padding: 8px; font-weight: 500;">{server}</td>
                    <td style="border: 1px solid #dee2e6; padding: 8px; color: {status_color}; font-weight: 600;">{issue['status']}</td>
                    <td style="border: 1px solid #dee2e6; padding: 8px; text-align: center;">{issue['restarts']}</td>
                </tr>
                """
        
        k8s_server_details += """
                </tbody>
            </table>
        </div>
        """
    
    # Generate download failures table
    download_details = ""
    if download_failures:
        download_details = """
        <div class="server-section">
            <h3>📥 Download Report Failures</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Report Name</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Date & Time</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Vendor</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Status</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">User EIN</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        for failure in download_failures:
            download_details += f"""
            <tr>
                <td style="border: 1px solid #dee2e6; padding: 8px; font-family: monospace; font-size: 12px;">{failure['report_name']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['report_date']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['vendor']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px; color: #dc3545; font-weight: 600;">{failure['status']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['user_ein']}</td>
            </tr>
            """
        
        download_details += """
                </tbody>
            </table>
        </div>
        """
    
    # Generate Herald failures table
    herald_details = ""
    if herald_failures:
        herald_details = """
        <div class="server-section">
            <h3>🏛️ Herald Jobs Failures</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">State</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Job Timestamp</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Job Type</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Pod Name</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        for failure in herald_failures:
            state_color = "#dc3545" if "FAILED" in failure['state'] else "#fd7e14"
            herald_details += f"""
            <tr>
                <td style="border: 1px solid #dee2e6; padding: 8px; color: {state_color}; font-weight: 600;">{failure['state']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['timestamp']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['job_type']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px; font-family: monospace; font-size: 12px;">{failure['pod_name']}</td>
            </tr>
            """
        
        herald_details += """
                </tbody>
            </table>
        </div>
        """
    
    # Generate ClickHouse (Ericsson DQ) details
    clickhouse_details = ""
    if clickhouse_status == "red" and clickhouse_data:
        clickhouse_details = f"""
        <div class="server-section" style="border-left: 4px solid #9333ea;">
            {clickhouse_data}
        </div>
        """
    
    # Generate Nokia details
    nokia_details = ""
    if nokia_status == "red" and nokia_data:
        nokia_details = f"""
        <div class="server-section" style="border-left: 4px solid #2563eb;">
            {nokia_data}
        </div>
        """
    
    # Generate Huawei details
    huawei_details = ""
    if huawei_status == "red" and huawei_data:
        huawei_details = f"""
        <div class="server-section" style="border-left: 4px solid #dc2626;">
            {huawei_data}
        </div>
        """
    
    # Generate HTML report
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Daily Health Check Report</title>
        <style>
            body {{ 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                margin: 0; 
                padding: 20px; 
                background-color: #f5f5f5; 
            }}
            .container {{ 
                max-width: 1200px; 
                margin: 0 auto; 
                background-color: white; 
                border-radius: 8px; 
                box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
                overflow: hidden; 
            }}
            .header {{ 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; 
                padding: 20px; 
                text-align: center; 
            }}
            .header h1 {{ 
                margin: 0; 
                font-size: 24px; 
                font-weight: 600; 
                color: white !important;
            }}
            .timestamp {{ 
                background-color: #f8f9fa; 
                padding: 15px 20px; 
                border-bottom: 1px solid #e9ecef; 
            }}
            .timestamp p {{ 
                margin: 5px 0; 
                color: #495057; 
                font-weight: 500; 
            }}
            .status-row {{ 
                display: flex; 
                padding: 20px; 
                gap: 15px; 
                justify-content: space-between; 
            }}
            .status-box {{ 
                flex: 1; 
                padding: 20px; 
                border-radius: 8px; 
                border: 2px solid; 
                text-align: center; 
                transition: transform 0.2s; 
                min-height: 120px; 
                display: flex; 
                flex-direction: column; 
                justify-content: center; 
            }}
            .status-box:hover {{ 
                transform: translateY(-2px); 
            }}
            .status-red {{ 
                background-color: #fff5f5; 
                border-color: #e53e3e; 
                color: #c53030; 
            }}
            .status-green {{ 
                background-color: #f0fff4; 
                border-color: #38a169; 
                color: #2f855a; 
            }}
            .status-yellow {{ 
                background-color: #fffbf0; 
                border-color: #d69e2e; 
                color: #b7791f; 
            }}
            .status-title {{ 
                font-size: 16px; 
                font-weight: 600; 
                margin-bottom: 10px; 
                display: flex; 
                align-items: center; 
                justify-content: center; 
                gap: 8px; 
                flex-wrap: wrap; 
            }}
            .status-content {{ 
                font-size: 14px; 
                line-height: 1.4; 
            }}
            .details-section {{ 
                padding: 20px; 
                background-color: #f8f9fa; 
                border-top: 1px solid #e9ecef; 
            }}
            .details-title {{ 
                font-size: 18px; 
                font-weight: 600; 
                color: #495057; 
                margin-bottom: 15px; 
                display: flex; 
                align-items: center; 
                gap: 8px; 
            }}
            .server-section {{ 
                background-color: white; 
                border-radius: 6px; 
                padding: 15px; 
                margin-bottom: 15px; 
                border-left: 4px solid #e53e3e; 
            }}
            .server-section h3 {{ 
                font-weight: 600; 
                color: #2d3748; 
                margin-bottom: 10px; 
                font-size: 16px; 
            }}
            .footer {{ 
                text-align: center; 
                padding: 15px; 
                background-color: #f8f9fa; 
                color: #6c757d; 
                font-size: 12px; 
            }}
            @media (max-width: 768px) {{ 
                .status-row {{ 
                    flex-direction: column; 
                }} 
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Daily Health Check Report</h1>
            </div>
            
            <div style="padding: 20px; background: linear-gradient(to right, #f8f9fa, #e9ecef); border-bottom: 3px solid #667eea;">
                <h2 style="color: #667eea; margin: 0 0 15px 0; font-size: 20px;">📋 Please validate the below report</h2>
                <p style="color: #495057; font-size: 16px; margin: 5px 0; font-weight: 500;">
                    🗓️ <strong>Martini Health Check Report</strong> | Generated on {current_time.strftime('%A, %B %d, %Y at %H:%M BST')}
                </p>
                
                <table style="width: 100%; border-collapse: collapse; margin-top: 15px; background: white; border-radius: 6px; overflow: hidden;">
                    <thead>
                        <tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                            <th style="padding: 12px; text-align: left; font-weight: 600;">Check Type</th>
                            <th style="padding: 12px; text-align: center; font-weight: 600;">Status</th>
                            <th style="padding: 12px; text-align: center; font-weight: 600;">Issues Found</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr style="border-bottom: 1px solid #e9ecef;">
                            <td style="padding: 10px; font-weight: 500;">🔧 Kubernetes Health</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Issues' if k8s_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_k8s_issues > 0 else '#28a745'};">{total_k8s_issues}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e9ecef;">
                            <td style="padding: 10px; font-weight: 500;">📥 Download Reports</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Failures' if download_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_download_failures > 0 else '#28a745'};">{total_download_failures}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e9ecef;">
                            <td style="padding: 10px; font-weight: 500;">🏛️ Herald Jobs</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Failures' if herald_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_herald_failures > 0 else '#28a745'};">{total_herald_failures}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e9ecef;">
                            <td style="padding: 10px; font-weight: 500;">📊 Ericsson DQ</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Mismatches' if clickhouse_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_clickhouse_issues > 0 else '#28a745'};">{total_clickhouse_issues}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e9ecef;">
                            <td style="padding: 10px; font-weight: 500;">📊 Nokia DQ</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Mismatches' if nokia_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_nokia_issues > 0 else '#28a745'};">{total_nokia_issues}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e9ecef;">
                            <td style="padding: 10px; font-weight: 500;">📊 Huawei DQ</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Mismatches' if huawei_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_huawei_issues > 0 else '#28a745'};">{total_huawei_issues}</td>
                        </tr>
                        <tr>
                            <td style="padding: 10px; font-weight: 500;">📊 StarLink DQ</td>
                            <td style="padding: 10px; text-align: center;">{'🔴 Mismatches' if starlink_status == 'red' else '🟢 Healthy'}</td>
                            <td style="padding: 10px; text-align: center; font-weight: 600; color: {'#dc3545' if total_starlink_issues > 0 else '#28a745'};">{total_starlink_issues}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="status-row">
                <div class="status-box {'status-red' if k8s_status == 'red' else 'status-green'}" style="background-color: {'#fff5f5' if k8s_status == 'red' else '#f0fff4'} !important;">
                    <div class="status-title" style="color: {'#c53030' if k8s_status == 'red' else '#2f855a'} !important;">
                        {'⚠️ Kubernetes Health: Issues Found 🚨' if k8s_status == 'red' else '🟢 Kubernetes Health: All Good ✅'}
                    </div>
                    <div class="status-content" style="color: {'#c53030' if k8s_status == 'red' else '#2f855a'} !important;">
                        Issues: {total_k8s_issues} pods with issues<br>
                        {'Servers: ' + ', '.join(server_issues.keys()) if server_issues else 'Status: All pods healthy'}
                    </div>
                </div>
                
                <div class="status-box {'status-red' if download_status == 'red' else 'status-green'}" style="background-color: {'#fff5f5' if download_status == 'red' else '#f0fff4'} !important;">
                    <div class="status-title" style="color: {'#c53030' if download_status == 'red' else '#2f855a'} !important;">
                        {'📥 Download Report Failure: Issues Found 🚨' if download_status == 'red' else '📥 Download Report Failure: All Good ✅'}
                    </div>
                    <div class="status-content" style="color: {'#c53030' if download_status == 'red' else '#2f855a'} !important;">
                        Failed Reports: {total_download_failures}<br>
                        {'Last 24 hours' if download_failures else 'Status: No failures'}
                    </div>
                </div>
                
                <div class="status-box {'status-red' if herald_status == 'red' else 'status-green'}" style="background-color: {'#fff5f5' if herald_status == 'red' else '#f0fff4'} !important;">
                    <div class="status-title" style="color: {'#c53030' if herald_status == 'red' else '#2f855a'} !important;">
                        {'🏛️ Herald Jobs: Issues Found 🚨' if herald_status == 'red' else '🏛️ Herald Jobs: All Good ✅'}
                    </div>
                    <div class="status-content" style="color: {'#c53030' if herald_status == 'red' else '#2f855a'} !important;">
                        Failed Jobs: {total_herald_failures}<br>
                        {'Last 24 hours' if herald_failures else 'Status: No failures'}
                    </div>
                </div>
                
                <div class="status-box {'status-red' if clickhouse_status == 'red' else 'status-green'}" style="background-color: {'#fff5f5' if clickhouse_status == 'red' else '#f0fff4'} !important;">
                    <div class="status-title" style="color: {'#c53030' if clickhouse_status == 'red' else '#2f855a'} !important;">
                        {'📊 Ericsson DQ: Data Mismatches 🚨' if clickhouse_status == 'red' else '📊 Ericsson DQ: All Good ✅'}
                    </div>
                    <div class="status-content" style="color: {'#c53030' if clickhouse_status == 'red' else '#2f855a'} !important;">
                        Mismatches: {total_clickhouse_issues}<br>
                        {'Technologies: 2G, 4G, 5G, Baseband' if clickhouse_status == 'red' else 'Status: No data drops'}
                    </div>
                </div>
                
                <div class="status-box {'status-red' if nokia_status == 'red' else 'status-green'}" style="background-color: {'#fff5f5' if nokia_status == 'red' else '#f0fff4'} !important;">
                    <div class="status-title" style="color: {'#c53030' if nokia_status == 'red' else '#2f855a'} !important;">
                        {'📊 Nokia DQ: Data Mismatches 🚨' if nokia_status == 'red' else '📊 Nokia DQ: All Good ✅'}
                    </div>
                    <div class="status-content" style="color: {'#c53030' if nokia_status == 'red' else '#2f855a'} !important;">
                        Mismatches: {total_nokia_issues}<br>
                        {'Technologies: 2G, 4G, 5G, CSG' if nokia_status == 'red' else 'Status: No data drops'}
                    </div>
                </div>
                
                <div class="status-box {'status-red' if huawei_status == 'red' else 'status-green'}" style="background-color: {'#fff5f5' if huawei_status == 'red' else '#f0fff4'} !important;">
                    <div class="status-title" style="color: {'#c53030' if huawei_status == 'red' else '#2f855a'} !important;">
                        {'📊 Huawei DQ: Data Mismatches 🚨' if huawei_status == 'red' else '📊 Huawei DQ: All Good ✅'}
                    </div>
                    <div class="status-content" style="color: {'#c53030' if huawei_status == 'red' else '#2f855a'} !important;">
                        Mismatches: {total_huawei_issues}<br>
                        {'Technologies: 2G, 4G, 5G' if huawei_status == 'red' else 'Status: No data drops'}
                    </div>
                </div>
            </div>
            
            {f'''
            <div class="details-section">
                <div class="details-title">
                    🔍 Detailed Issues Report
                </div>
                {k8s_server_details}
                {download_details}
                {herald_details}
                {clickhouse_details}
                {nokia_details}
                {huawei_details}
            </div>
            ''' if k8s_status == 'red' or download_status == 'red' or herald_status == 'red' or clickhouse_status == 'red' or nokia_status == 'red' or huawei_status == 'red' else ''}
            
            <div class="footer">
                Generated by Martini Health Check System • {current_time.strftime('%Y-%m-%d %H:%M:%S BST')}
            </div>
        </div>
    </body>
    </html>
    """
    
    # Write HTML report to file
    os.makedirs("/opt/health_check_reporter/logs", exist_ok=True)
    with open("/opt/health_check_reporter/logs/latest_report.html", "w") as f:
        f.write(html_content)
    
    print(f"Health check completed. K8s: {k8s_status}, Downloads: {download_status}, Herald: {herald_status}, ClickHouse: {clickhouse_status}, Nokia: {nokia_status}, Huawei: {huawei_status}")
    return k8s_status

if __name__ == "__main__":
    status = generate_health_report()
    exit(0)
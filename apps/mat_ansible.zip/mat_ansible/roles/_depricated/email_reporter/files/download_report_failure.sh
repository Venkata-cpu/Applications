#!/bin/bash
# Download Report Failure Check using MySQL CLI

DB_HOST="${DB_HOST:-martini.preprod.nat.bt.com}"
DB_PORT="${DB_PORT:-61136}"
DB_NAME="${DB_NAME:-ran}"
DB_USER="${DB_USER:-ranUser}"
DB_PASSWORD="${DB_PASSWORD}"

OUTPUT_FILE="/tmp/download_report_failures.txt"

# Query for failed reports
QUERY="SELECT 
    service_name,
    report_date,
    vendor,
    report_status,
    user_ein
FROM REPORT_DOWNLOAD_DATA
WHERE report_status = 'Failed'
  AND report_date >= NOW() - INTERVAL 1 DAY
ORDER BY report_date DESC;"

# Execute query using mysql CLI
mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASSWORD" -D "$DB_NAME" -N -B -e "$QUERY" 2>/dev/null | \
awk -F'\t' '{print $1"|"$2"|"$3"|"$4"|"$5}' > "$OUTPUT_FILE"

# Check if any results
if [ ! -s "$OUTPUT_FILE" ]; then
    echo "No failures found" > "$OUTPUT_FILE"
    echo "Download report check completed. Found 0 failures."
    exit 0
else
    count=$(wc -l < "$OUTPUT_FILE")
    echo "Download report check completed. Found $count failures."
    exit 0
fi

#!/usr/bin/env python3
import os
import datetime

def generate_health_report():
    """Generate HTML health check report from combined data"""
    
    # Read combined report data
    combined_file = "/tmp/health_reports/combined_report.txt"
    k8s_issues = []
    download_failures = []
    server_issues = {}
    
    if os.path.exists(combined_file):
        with open(combined_file, "r") as f:
            for line in f:
                line = line.strip()
                if not line or line == "No issues found" or line == "No failures found":
                    continue
                    
                # Parse K8s issues (format: pod|namespace|status|node|restarts|type)
                if "|" in line and len(line.split('|')) >= 4:
                    parts = line.split('|')
                    if len(parts) >= 6:  # K8s format
                        pod_name = parts[0]
                        namespace = parts[1]
                        status = parts[2]
                        server = parts[3]
                        restart_count = parts[4]
                        
                        if server not in server_issues:
                            server_issues[server] = []
                        
                        server_issues[server].append({
                            'pod': pod_name,
                            'status': status,
                            'restarts': restart_count
                        })
                        k8s_issues.append(f"{pod_name} in {namespace} is {status}")
                    
                    elif len(parts) >= 5:  # Download failure format
                        download_failures.append({
                            'report_name': parts[0],
                            'report_date': parts[1],
                            'vendor': parts[2],
                            'status': parts[3],
                            'user_ein': parts[4]
                        })
    
    # Determine statuses
    k8s_status = "red" if k8s_issues else "green"
    download_status = "red" if download_failures else "green"
    
    total_k8s_issues = len(k8s_issues)
    total_download_failures = len(download_failures)
    current_time = datetime.datetime.now()
    
    # Generate K8s server details table
    k8s_server_details = ""
    if server_issues:
        k8s_server_details = """
        <div class="server-section">
            <h3>🔍 Kubernetes Pod Issues</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Pod Name</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Server</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Status</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Restarts</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        for server, issues in server_issues.items():
            for issue in issues:
                status_color = "#dc3545" if issue['status'] in ['Error', 'CrashLoopBackOff', 'ImagePullBackOff'] else "#fd7e14" if issue['status'] == 'Evicted' else "#6c757d"
                k8s_server_details += f"""
                <tr>
                    <td style="border: 1px solid #dee2e6; padding: 8px; font-family: monospace; font-size: 12px;">{issue['pod']}</td>
                    <td style="border: 1px solid #dee2e6; padding: 8px; font-weight: 500;">{server}</td>
                    <td style="border: 1px solid #dee2e6; padding: 8px; color: {status_color}; font-weight: 600;">{issue['status']}</td>
                    <td style="border: 1px solid #dee2e6; padding: 8px; text-align: center;">{issue['restarts']}</td>
                </tr>
                """
        
        k8s_server_details += """
                </tbody>
            </table>
        </div>
        """
    
    # Generate download failures table
    download_details = ""
    if download_failures:
        download_details = """
        <div class="server-section">
            <h3>📥 Download Report Failures</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Report Name</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Date & Time</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Vendor</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Status</th>
                        <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">User EIN</th>
                    </tr>
                </thead>
                <tbody>
        """
        
        for failure in download_failures:
            download_details += f"""
            <tr>
                <td style="border: 1px solid #dee2e6; padding: 8px; font-family: monospace; font-size: 12px;">{failure['report_name']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['report_date']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['vendor']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px; color: #dc3545; font-weight: 600;">{failure['status']}</td>
                <td style="border: 1px solid #dee2e6; padding: 8px;">{failure['user_ein']}</td>
            </tr>
            """
        
        download_details += """
                </tbody>
            </table>
        </div>
        """
    
    # Generate HTML report
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Daily Health Check Report</title>
        <style>
            body {{ 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                margin: 0; 
                padding: 20px; 
                background-color: #f5f5f5; 
            }}
            .container {{ 
                max-width: 1200px; 
                margin: 0 auto; 
                background-color: white; 
                border-radius: 8px; 
                box-shadow: 0 2px 10px rgba(0,0,0,0.1); 
                overflow: hidden; 
            }}
            .header {{ 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; 
                padding: 20px; 
                text-align: center; 
            }}
            .header h1 {{ 
                margin: 0; 
                font-size: 24px; 
                font-weight: 600; 
                color: white !important;
            }}
            .timestamp {{ 
                background-color: #f8f9fa; 
                padding: 15px 20px; 
                border-bottom: 1px solid #e9ecef; 
            }}
            .timestamp p {{ 
                margin: 5px 0; 
                color: #495057; 
                font-weight: 500; 
            }}
            .status-row {{ 
                display: flex; 
                padding: 20px; 
                gap: 15px; 
                justify-content: space-between; 
            }}
            .status-box {{ 
                flex: 1; 
                padding: 20px; 
                border-radius: 8px; 
                border: 2px solid; 
                text-align: center; 
                transition: transform 0.2s; 
                min-height: 120px; 
                display: flex; 
                flex-direction: column; 
                justify-content: center; 
            }}
            .status-box:hover {{ 
                transform: translateY(-2px); 
            }}
            .status-red {{ 
                background-color: #fff5f5; 
                border-color: #e53e3e; 
                color: #c53030; 
            }}
            .status-green {{ 
                background-color: #f0fff4; 
                border-color: #38a169; 
                color: #2f855a; 
            }}
            .status-yellow {{ 
                background-color: #fffbf0; 
                border-color: #d69e2e; 
                color: #b7791f; 
            }}
            .status-title {{ 
                font-size: 16px; 
                font-weight: 600; 
                margin-bottom: 10px; 
                display: flex; 
                align-items: center; 
                justify-content: center; 
                gap: 8px; 
                flex-wrap: wrap; 
            }}
            .status-content {{ 
                font-size: 14px; 
                line-height: 1.4; 
            }}
            .details-section {{ 
                padding: 20px; 
                background-color: #f8f9fa; 
                border-top: 1px solid #e9ecef; 
            }}
            .details-title {{ 
                font-size: 18px; 
                font-weight: 600; 
                color: #495057; 
                margin-bottom: 15px; 
                display: flex; 
                align-items: center; 
                gap: 8px; 
            }}
            .server-section {{ 
                background-color: white; 
                border-radius: 6px; 
                padding: 15px; 
                margin-bottom: 15px; 
                border-left: 4px solid #e53e3e; 
            }}
            .server-section h3 {{ 
                font-weight: 600; 
                color: #2d3748; 
                margin-bottom: 10px; 
                font-size: 16px; 
            }}
            .footer {{ 
                text-align: center; 
                padding: 15px; 
                background-color: #f8f9fa; 
                color: #6c757d; 
                font-size: 12px; 
            }}
            @media (max-width: 768px) {{ 
                .status-row {{ 
                    flex-direction: column; 
                }} 
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Daily Health Check Report</h1>
            </div>
            
            <div class="timestamp">
                <p><strong>Date:</strong> {current_time.strftime('%A, %B %d, %Y')}</p>
                <p><strong>Time:</strong> {current_time.strftime('%H:%M BST')}</p>
            </div>
            
            <div class="status-row">
                <div class="status-box {'status-red' if k8s_status == 'red' else 'status-green'}">
                    <div class="status-title">
                        {'⚠️ Kubernetes Health: Issues Found 🚨' if k8s_status == 'red' else '🟢 Kubernetes Health: All Good ✅'}
                    </div>
                    <div class="status-content">
                        Issues: {total_k8s_issues} pods with issues<br>
                        {'Servers: ' + ', '.join(server_issues.keys()) if server_issues else 'Status: All pods healthy'}
                    </div>
                </div>
                
                <div class="status-box {'status-red' if download_status == 'red' else 'status-green'}">
                    <div class="status-title">
                        {'📥 Download Report Failure: Issues Found 🚨' if download_status == 'red' else '📥 Download Report Failure: All Good ✅'}
                    </div>
                    <div class="status-content">
                        Failed Reports: {total_download_failures}<br>
                        {'Last 24 hours' if download_failures else 'Status: No failures'}
                    </div>
                </div>
                
                <div class="status-box status-yellow">
                    <div class="status-title">
                        🏛️ Herald: Development in Progress ⚠️
                    </div>
                    <div class="status-content">
                        Status: Setup pending
                    </div>
                </div>
                
                <div class="status-box status-yellow">
                    <div class="status-title">
                        📊 DQ Graphs: Development in Progress ⚠️
                    </div>
                    <div class="status-content">
                        Status: Setup in progress
                    </div>
                </div>
            </div>
            
            {f'''
            <div class="details-section">
                <div class="details-title">
                    🔍 Detailed Issues Report
                </div>
                {k8s_server_details}
                {download_details}
            </div>
            ''' if k8s_status == 'red' or download_status == 'red' else ''}
            
            <div class="footer">
                Generated by Martini Health Check System • {current_time.strftime('%Y-%m-%d %H:%M:%S BST')}
            </div>
        </div>
    </body>
    </html>
    """
    
    # Write HTML report to file
    os.makedirs("/opt/health_check_reporter/logs", exist_ok=True)
    with open("/opt/health_check_reporter/logs/latest_report.html", "w") as f:
        f.write(html_content)
    
    print(f"Health check completed. K8s: {k8s_status}, Downloads: {download_status}")
    return k8s_status

if __name__ == "__main__":
    status = generate_health_report()
    exit(0)
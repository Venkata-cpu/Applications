#!/usr/bin/env python3

import os
import mysql.connector
import datetime

def get_failed_reports():
    """Query database for failed download reports"""
    try:
        conn = mysql.connector.connect(
            host=os.environ.get("DB_HOST", "martini.preprod.nat.bt.com"),
            port=int(os.environ.get("DB_PORT", 61136)),
            user=os.environ.get("DB_USER", "ranUser"),
            password=os.environ.get("DB_PASSWORD", ""),
            database=os.environ.get("DB_NAME", "ran")
        )

        cursor = conn.cursor(dictionary=True)

        query = """
        SELECT
            service_name AS report_name,
            report_date,
            vendor,
            granularity,
            report_status,
            user_ein,
            report_id
        FROM REPORT_DOWNLOAD_DATA
        WHERE report_status = 'Failed'
          AND report_date >= NOW() - INTERVAL 1 DAY
        ORDER BY report_date DESC;
        """

        cursor.execute(query)
        data = cursor.fetchall()

        cursor.close()
        conn.close()
        return data
    except Exception as e:
        print(f"Database error: {e}")
        return []

def generate_download_failure_html(failed_reports):
    """Generate HTML section for download report failures"""
    current_time = datetime.datetime.now()
    
    if not failed_reports:
        return """
        <div class="status-box status-green">
            <div class="status-title">
                📥 Download Report Failure: All Good ✅
            </div>
            <div class="status-content">
                Status: No failed reports in last 24 hours
            </div>
        </div>
        """, ""
    
    # Generate status box
    status_box = f"""
    <div class="status-box status-red">
        <div class="status-title">
            📥 Download Report Failure: Issues Found 🚨
        </div>
        <div class="status-content">
            Failed Reports: {len(failed_reports)}<br>
            Last 24 hours
        </div>
    </div>
    """
    
    # Generate details table
    details_table = """
    <div class="server-section">
        <h3>📥 Download Report Failures</h3>
        <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
            <thead>
                <tr style="background-color: #f8f9fa;">
                    <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Report Name</th>
                    <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Date & Time</th>
                    <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Vendor</th>
                    <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">Status</th>
                    <th style="border: 1px solid #dee2e6; padding: 8px; text-align: left; font-weight: 600;">User EIN</th>
                </tr>
            </thead>
            <tbody>
    """
    
    for report in failed_reports:
        details_table += f"""
        <tr>
            <td style="border: 1px solid #dee2e6; padding: 8px; font-family: monospace; font-size: 12px;">{report['report_name']}</td>
            <td style="border: 1px solid #dee2e6; padding: 8px;">{report['report_date']}</td>
            <td style="border: 1px solid #dee2e6; padding: 8px;">{report['vendor']}</td>
            <td style="border: 1px solid #dee2e6; padding: 8px; color: #dc3545; font-weight: 600;">{report['report_status']}</td>
            <td style="border: 1px solid #dee2e6; padding: 8px;">{report['user_ein']}</td>
        </tr>
        """
    
    details_table += """
            </tbody>
        </table>
    </div>
    """
    
    return status_box, details_table

if __name__ == "__main__":
    # Write results to temp file for main health reporter to read
    failed_reports = get_failed_reports()
    
    with open("/tmp/download_report_failures.txt", "w") as f:
        if failed_reports:
            for report in failed_reports:
                f.write(f"{report['report_name']}|{report['report_date']}|{report['vendor']}|{report['report_status']}|{report['user_ein']}\n")
        else:
            f.write("No failures found\n")
    
    print(f"Download report check completed. Found {len(failed_reports)} failures.")
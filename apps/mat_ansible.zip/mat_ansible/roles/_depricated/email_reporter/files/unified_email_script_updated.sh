#!/bin/bash
# Unified Health Check Reporter - Email Server (10.54.106.76)
# Combines K8s pod health + download failures and sends HTML email

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"
TMP_DIR="/tmp/health_reports"

mkdir -p "$TMP_DIR"
> "$TMP_DIR/combined_report.txt"

echo "$(date): Starting unified health check report generation" >> "$LOG_FILE"

# ------------------------------
# 1️⃣ Pull K8s pod health from master
# ------------------------------
K8S_MASTER="10.54.107.181"  # blp20919615
K8S_USER="app-manager"

export KUBECONFIG="/root/.kube/config"

echo "$(date): Pulling K8s report from $K8S_MASTER" >> "$LOG_FILE"

# Run K8s health check remotely
ssh -o StrictHostKeyChecking=no "$K8S_USER@$K8S_MASTER" \
    "bash -s" < /opt/health_check_reporter/scripts/k8s_pod_health_check.sh

# Copy report back to email server
if scp "$K8S_USER@$K8S_MASTER:/tmp/k8s_pod_health_report.txt" "$TMP_DIR/k8s_report.txt"; then
    echo "$(date): K8s report pulled from $K8S_MASTER" >> "$LOG_FILE"
    cat "$TMP_DIR/k8s_report.txt" >> "$TMP_DIR/combined_report.txt"
    echo -e "\n" >> "$TMP_DIR/combined_report.txt"
else
    echo "$(date): Failed to pull K8s report from $K8S_MASTER" >> "$LOG_FILE"
fi

# ------------------------------
# 2️⃣ Pull download failure report from 10.54.106.77
# ------------------------------
DOWNLOAD_SERVER="10.54.106.77"  # blp20919391
DOWNLOAD_USER="app-manager"
REMOTE_DOWNLOAD_SCRIPT="/opt/health_check_reporter/scripts/download_report_failure.py"

echo "$(date): Pulling download failure report from $DOWNLOAD_SERVER" >> "$LOG_FILE"

# Run remote Python script to generate latest download failures
ssh -o StrictHostKeyChecking=no "$DOWNLOAD_USER@$DOWNLOAD_SERVER" "python3 $REMOTE_DOWNLOAD_SCRIPT"

# Copy download report to email server
REMOTE_REPORT="/tmp/download_report_failures.txt"
LOCAL_REPORT="$TMP_DIR/download_report.txt"

if scp "$DOWNLOAD_USER@$DOWNLOAD_SERVER:$REMOTE_REPORT" "$LOCAL_REPORT"; then
    echo "$(date): Download failure report pulled successfully" >> "$LOG_FILE"
    cat "$LOCAL_REPORT" >> "$TMP_DIR/combined_report.txt"
    echo -e "\n" >> "$TMP_DIR/combined_report.txt"
else
    echo "$(date): Failed to pull download failure report" >> "$LOG_FILE"
fi

# ------------------------------
# 3️⃣ Generate HTML report
# ------------------------------
python3 /opt/health_check_reporter/scripts/health_check_reporter.py
python_exit_code=$?

# ------------------------------
# 4️⃣ Send email
# ------------------------------
if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    TO="asritha.2.meka@bt.com, pradip.mandal@bt.com"
    SUBJECT="Daily Health Check Report"
    FROM="martini.ee.monitoring@bt.com"

    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html"
        echo
        cat "$REPORT_FILE"
    } | sendmail -t

    echo "$(date): Unified email sent successfully" >> "$LOG_FILE"
else
    echo "$(date): Failed to generate unified report (python_exit_code=$python_exit_code)" >> "$LOG_FILE"
fi
#!/bin/bash
# Unified Health Check Reporter - Consolidated on Email Server (10.54.106.76)
# This server does everything: K8s check, Download check, Report generation, Email sending

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"
TMP_DIR="/tmp/health_reports"

mkdir -p "$TMP_DIR"

echo "$(date): Starting unified health check report generation" >> "$LOG_FILE"

# ------------------------------
# 1️⃣ Pull K8s pod health from master
# ------------------------------
K8S_MASTER="10.54.107.181"  # blp20919615
K8S_USER="app-manager"

echo "$(date): Pulling K8s report from $K8S_MASTER" >> "$LOG_FILE"

# Run K8s health check remotely on master
ssh -o StrictHostKeyChecking=no "$K8S_USER@$K8S_MASTER" \
    "bash -s" < /opt/health_check_reporter/scripts/k8s_pod_health_check.sh

# Copy report back to email server
if scp "$K8S_USER@$K8S_MASTER:/tmp/k8s_pod_health_report.txt" "$TMP_DIR/k8s_report.txt"; then
    echo "$(date): K8s report pulled from $K8S_MASTER" >> "$LOG_FILE"
    cat "$TMP_DIR/k8s_report.txt" > /tmp/k8s_pod_health_report.txt
else
    echo "$(date): Failed to pull K8s report from $K8S_MASTER" >> "$LOG_FILE"
    echo "No issues found" > /tmp/k8s_pod_health_report.txt
fi

# ------------------------------
# 2️⃣ Run download failure check LOCALLY
# ------------------------------
echo "$(date): Running download failure check locally" >> "$LOG_FILE"

# Run download report failure check on THIS server (76)
DB_HOST="${DB_HOST:-10.6.120.183}" \
DB_PORT="${DB_PORT:-3306}" \
DB_NAME="${DB_NAME:-ran}" \
DB_USER="${DB_USER:-ranUser}" \
DB_PASSWORD="${DB_PASSWORD}" \
python3 /opt/health_check_reporter/scripts/download_report_failure.py

download_exit_code=$?
echo "$(date): Download failure check completed (exit code: $download_exit_code)" >> "$LOG_FILE"

# ------------------------------
# 3️⃣ Generate HTML report
# ------------------------------
python3 /opt/health_check_reporter/scripts/health_check_reporter.py
python_exit_code=$?

# ------------------------------
# 4️⃣ Send email
# ------------------------------
if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    TO="asritha.2.meka@bt.com, pradip.mandal@bt.com"
    SUBJECT="Daily Health Check Report - $(date '+%Y-%m-%d')"
    FROM="martini.ee.monitoring@bt.com"

    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "MIME-Version: 1.0"
        echo
        cat "$REPORT_FILE"
    } | sendmail -t

    if [ $? -eq 0 ]; then
        echo "$(date): ✓ Email sent successfully" >> "$LOG_FILE"
    else
        echo "$(date): ✗ Email sending failed" >> "$LOG_FILE"
    fi
else
    echo "$(date): ✗ Report generation failed (exit code: $python_exit_code)" >> "$LOG_FILE"
    
    # Send error notification
    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: ERROR - Daily Health Check Report Failed"
        echo "Content-Type: text/html"
        echo
        echo "<h2>Health Check Report Generation Failed</h2>"
        echo "<p>The daily health check report failed to generate at $(date).</p>"
        echo "<p>Exit code: $python_exit_code</p>"
        echo "<p>Please check the logs on the monitoring server.</p>"
    } | sendmail -t
    
    echo "$(date): Error notification sent" >> "$LOG_FILE"
fi

echo "$(date): Daily health check script completed" >> "$LOG_FILE"

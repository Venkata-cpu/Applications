#!/bin/bash
# Kubernetes Pod Health Check Script - Remote execution

REPORT_FILE="/tmp/k8s_pod_health_report.txt"
NAMESPACE="ran-preprod"
RESTART_THRESHOLD=3
LOG_FILE="/opt/health_check_reporter/logs/k8s_check.log"
K8S_MASTER="10.54.107.181"
K8S_USER="app-manager"

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

echo "$(date): Starting Kubernetes health check via SSH to $K8S_MASTER" >> "$LOG_FILE"

# Clear previous report
> "$REPORT_FILE"

# Get unhealthy pods directly via SSH (excluding old Evicted pods)
ssh -o StrictHostKeyChecking=no "$K8S_USER@$K8S_MASTER" "kubectl get pods -n $NAMESPACE --field-selector=status.phase!=Running,status.phase!=Succeeded -o wide --no-headers" 2>>"$LOG_FILE" | \
awk '{print $1"|"$3"|"$4"|"$7}' | \
while IFS='|' read -r name status restarts node; do
    if [[ -n "$name" ]]; then
        # Skip Evicted pods older than 7 days
        if [[ "$status" == "Evicted" ]]; then
            continue
        fi
        restart_count=$(echo "$restarts" | cut -d'(' -f1)
        # Handle empty node (Pending pods)
        [[ -z "$node" || "$node" == "<none>" ]] && node="Unscheduled"
        echo "$name|$NAMESPACE|$status|$node|$restart_count|CurrentlyUnhealthy" >> "$REPORT_FILE"
    fi
done

# Get pods with high restart counts
ssh -o StrictHostKeyChecking=no "$K8S_USER@$K8S_MASTER" "kubectl get pods -n $NAMESPACE -o wide --no-headers" 2>>"$LOG_FILE" | \
awk '{print $1"|"$3"|"$4"|"$7}' | \
while IFS='|' read -r name status restarts node; do
    if [[ -n "$name" ]]; then
        restart_count=$(echo "$restarts" | cut -d'(' -f1)
        if [[ "$restart_count" -gt "$RESTART_THRESHOLD" ]]; then
            # Handle empty node
            [[ -z "$node" || "$node" == "<none>" ]] && node="Unscheduled"
            echo "$name|$NAMESPACE|$status|$node|$restart_count|HighRestarts" >> "$REPORT_FILE"
        fi
    fi
done

# Remove duplicates
if [[ -f "$REPORT_FILE" ]]; then
    sort -u "$REPORT_FILE" -o "$REPORT_FILE"
fi

# Check results
if [[ -s "$REPORT_FILE" ]] && ! grep -q "No issues found" "$REPORT_FILE"; then
    echo "$(date): Found $(wc -l < "$REPORT_FILE") issues in $NAMESPACE" >> "$LOG_FILE"
    exit 1
else
    echo "$(date): No issues found in $NAMESPACE" >> "$LOG_FILE"
    echo "No issues found" > "$REPORT_FILE"
    exit 0
fi

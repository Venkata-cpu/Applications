#!/bin/bash
# Simplified Email Script - runs locally on email server

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"

echo "$(date): Starting unified health check report generation" >> "$LOG_FILE"

# Run local K8s health check (if kubectl is configured)
if command -v kubectl &> /dev/null; then
    /opt/health_check_reporter/scripts/k8s_pod_health_check.sh
else
    echo "No issues found" > /tmp/k8s_pod_health_report.txt
fi

# Check for download failures (if file exists from remote server)
if [ -f "/tmp/download_report_failures.txt" ]; then
    echo "$(date): Using existing download report" >> "$LOG_FILE"
else
    echo "No failures found" > /tmp/download_report_failures.txt
fi

# Generate HTML report
python3 /opt/health_check_reporter/scripts/health_check_reporter.py
python_exit_code=$?

# Send email
if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    TO="asritha.2.meka@bt.com, pradip.mandal@bt.com"
    SUBJECT="Daily Health Check Report"
    FROM="martini.ee.monitoring@bt.com"

    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html"
        echo
        cat "$REPORT_FILE"
    } | sendmail -t

    echo "$(date): Email sent successfully" >> "$LOG_FILE"
else
    echo "$(date): Failed to generate report" >> "$LOG_FILE"
fi
#!/bin/bash
# Improved Daily Health Check Email Script
# Combines K8s health check and email sending in one reliable script

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"
DEBUG_LOG="/opt/health_check_reporter/logs/email_debug.log"

# Email configuration
TO_EMAILS="asritha.2.meka@bt.com, pradip.mandal@bt.com"
FROM_EMAIL="martini.ee.monitoring@bt.com"
SUBJECT="Daily Health Check Report - $(date '+%Y-%m-%d')"

# Ensure directories exist
mkdir -p /opt/health_check_reporter/{scripts,logs}

# Set kubectl config
export KUBECONFIG="/root/.kube/config"

echo "$(date): Starting daily health check report" | tee -a "$LOG_FILE"

# Function to send email with multiple fallback methods
send_email() {
    local report_file="$1"
    local success=false
    
    if [[ ! -f "$report_file" ]]; then
        echo "$(date): ERROR - Report file not found: $report_file" | tee -a "$LOG_FILE"
        return 1
    fi
    
    echo "$(date): Attempting to send email..." | tee -a "$LOG_FILE"
    
    # Method 1: sendmail with proper headers (most reliable)
    echo "$(date): Trying sendmail method..." | tee -a "$DEBUG_LOG"
    {
        echo "From: $FROM_EMAIL"
        echo "To: $TO_EMAILS"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "MIME-Version: 1.0"
        echo
        cat "$report_file"
    } | sendmail -t 2>>"$DEBUG_LOG"
    
    if [ $? -eq 0 ]; then
        echo "$(date): ✓ Email sent successfully via sendmail" | tee -a "$LOG_FILE"
        success=true
    else
        echo "$(date): ✗ Sendmail method failed" | tee -a "$LOG_FILE"
        
        # Method 2: mail command fallback
        echo "$(date): Trying mail command fallback..." | tee -a "$DEBUG_LOG"
        mail -s "$SUBJECT" -a "Content-Type: text/html" -r "$FROM_EMAIL" "$TO_EMAILS" < "$report_file" 2>>"$DEBUG_LOG"
        
        if [ $? -eq 0 ]; then
            echo "$(date): ✓ Email sent successfully via mail command" | tee -a "$LOG_FILE"
            success=true
        else
            echo "$(date): ✗ Mail command also failed" | tee -a "$LOG_FILE"
        fi
    fi
    
    # Check mail queue
    echo "$(date): Current mail queue status:" | tee -a "$DEBUG_LOG"
    mailq | tee -a "$DEBUG_LOG"
    
    return $success
}

# 1. Run K8s health check
echo "$(date): Running Kubernetes health check..." | tee -a "$LOG_FILE"
if [ -f "/opt/health_check_reporter/scripts/k8s_pod_health_check.sh" ]; then
    /opt/health_check_reporter/scripts/k8s_pod_health_check.sh
    k8s_exit_code=$?
    echo "$(date): K8s health check completed with exit code: $k8s_exit_code" | tee -a "$LOG_FILE"
else
    echo "$(date): WARNING - k8s_pod_health_check.sh not found, creating dummy data" | tee -a "$LOG_FILE"
    echo "No issues found" > /tmp/k8s_pod_health_report.txt
    k8s_exit_code=0
fi

# 2. Run download report failure check (if script exists)
echo "$(date): Running download report failure check..." | tee -a "$LOG_FILE"
if [ -f "/opt/health_check_reporter/scripts/download_report_failure.py" ]; then
    DB_HOST="${DB_HOST:-10.6.120.183}" \
    DB_PORT="${DB_PORT:-3306}" \
    DB_NAME="${DB_NAME:-ran}" \
    DB_USER="${DB_USER:-ranUser}" \
    DB_PASSWORD="${DB_PASSWORD}" \
    python3 /opt/health_check_reporter/scripts/download_report_failure.py
    download_exit_code=$?
    echo "$(date): Download failure check completed with exit code: $download_exit_code" | tee -a "$LOG_FILE"
else
    echo "$(date): WARNING - download_report_failure.py not found, creating dummy data" | tee -a "$LOG_FILE"
    echo "No failures found" > /tmp/download_report_failures.txt
    download_exit_code=0
fi

# 3. Generate HTML report
echo "$(date): Generating HTML report..." | tee -a "$LOG_FILE"
if [ -f "/opt/health_check_reporter/scripts/health_check_reporter.py" ]; then
    python3 /opt/health_check_reporter/scripts/health_check_reporter.py
    python_exit_code=$?
    echo "$(date): Report generation completed with exit code: $python_exit_code" | tee -a "$LOG_FILE"
else
    echo "$(date): ERROR - health_check_reporter.py not found" | tee -a "$LOG_FILE"
    python_exit_code=1
fi

# 4. Send email if report was generated successfully
if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    echo "$(date): Report generated successfully, sending email..." | tee -a "$LOG_FILE"
    
    # Send email using our improved function
    send_email "$REPORT_FILE"
    email_success=$?
    
    if [ $email_success ]; then
        echo "$(date): ✓ Daily health check email sent successfully" | tee -a "$LOG_FILE"
    else
        echo "$(date): ✗ Failed to send daily health check email" | tee -a "$LOG_FILE"
        
        # Log system status for debugging
        echo "$(date): System status for debugging:" | tee -a "$DEBUG_LOG"
        echo "Sendmail status:" | tee -a "$DEBUG_LOG"
        systemctl status sendmail | head -10 | tee -a "$DEBUG_LOG"
        echo "Disk space:" | tee -a "$DEBUG_LOG"
        df -h | tee -a "$DEBUG_LOG"
    fi
else
    echo "$(date): ✗ Report generation failed (exit code: $python_exit_code) or report file missing" | tee -a "$LOG_FILE"
    
    # Send error notification
    {
        echo "From: $FROM_EMAIL"
        echo "To: $TO_EMAILS"
        echo "Subject: ERROR - Daily Health Check Report Failed"
        echo "Content-Type: text/html"
        echo
        echo "<h2>Health Check Report Generation Failed</h2>"
        echo "<p>The daily health check report failed to generate at $(date).</p>"
        echo "<p>Exit codes: K8s=$k8s_exit_code, Download=$download_exit_code, Python=$python_exit_code</p>"
        echo "<p>Please check the logs on the monitoring server.</p>"
    } | sendmail -t
fi

echo "$(date): Daily health check script completed" | tee -a "$LOG_FILE"
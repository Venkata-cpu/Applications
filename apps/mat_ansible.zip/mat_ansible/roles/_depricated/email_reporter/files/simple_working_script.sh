#!/bin/bash
# Daily Health Check Email Script - Simplified and Reliable

LOG_FILE="/opt/health_check_reporter/logs/daily_report.log"
REPORT_FILE="/opt/health_check_reporter/logs/latest_report.html"
TO="asritha.2.meka@bt.com, pradip.mandal@bt.com"
FROM="martini.ee.monitoring@bt.com"
SUBJECT="Daily Health Check Report - $(date '+%Y-%m-%d')"

# Ensure directories exist
mkdir -p /opt/health_check_reporter/{scripts,logs}
export KUBECONFIG="/root/.kube/config"

echo "$(date): Starting daily health check report" >> "$LOG_FILE"

# Run K8s health check
if [ -f "/opt/health_check_reporter/scripts/k8s_pod_health_check.sh" ]; then
    /opt/health_check_reporter/scripts/k8s_pod_health_check.sh
    k8s_exit_code=$?
    echo "$(date): K8s health check completed (exit code: $k8s_exit_code)" >> "$LOG_FILE"
else
    echo "$(date): WARNING - k8s_pod_health_check.sh not found" >> "$LOG_FILE"
    echo "No issues found" > /tmp/k8s_pod_health_report.txt
    k8s_exit_code=0
fi

# Run download report failure check if available
if [ -f "/opt/health_check_reporter/scripts/download_report_failure.py" ]; then
    DB_HOST="${DB_HOST:-10.6.120.183}" \
    DB_PORT="${DB_PORT:-3306}" \
    DB_NAME="${DB_NAME:-ran}" \
    DB_USER="${DB_USER:-ranUser}" \
    DB_PASSWORD="${DB_PASSWORD}" \
    python3 /opt/health_check_reporter/scripts/download_report_failure.py
    download_exit_code=$?
    echo "$(date): Download failure check completed (exit code: $download_exit_code)" >> "$LOG_FILE"
else
    echo "$(date): WARNING - download_report_failure.py not found" >> "$LOG_FILE"
    echo "No failures found" > /tmp/download_report_failures.txt
    download_exit_code=0
fi

# Generate HTML report
if [ -f "/opt/health_check_reporter/scripts/health_check_reporter.py" ]; then
    python3 /opt/health_check_reporter/scripts/health_check_reporter.py
    python_exit_code=$?
    echo "$(date): Report generation completed (exit code: $python_exit_code)" >> "$LOG_FILE"
else
    echo "$(date): ERROR - health_check_reporter.py not found" >> "$LOG_FILE"
    python_exit_code=1
fi

# Send email
if [[ $python_exit_code -eq 0 && -f "$REPORT_FILE" ]]; then
    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: $SUBJECT"
        echo "Content-Type: text/html; charset=UTF-8"
        echo "MIME-Version: 1.0"
        echo
        cat "$REPORT_FILE"
    } | sendmail -t

    if [ $? -eq 0 ]; then
        echo "$(date): ✓ Email sent successfully" >> "$LOG_FILE"
    else
        echo "$(date): ✗ Email sending failed" >> "$LOG_FILE"
        # Try fallback method
        mail -s "$SUBJECT" -a "Content-Type: text/html" -r "$FROM" "$TO" < "$REPORT_FILE"
        if [ $? -eq 0 ]; then
            echo "$(date): ✓ Email sent via fallback method" >> "$LOG_FILE"
        else
            echo "$(date): ✗ Both email methods failed" >> "$LOG_FILE"
        fi
    fi
else
    echo "$(date): ✗ Report generation failed or file missing (exit code: $python_exit_code)" >> "$LOG_FILE"
    
    # Send error notification
    {
        echo "From: $FROM"
        echo "To: $TO"
        echo "Subject: ERROR - Daily Health Check Report Failed"
        echo "Content-Type: text/html"
        echo
        echo "<h2>Health Check Report Generation Failed</h2>"
        echo "<p>The daily health check report failed to generate at $(date).</p>"
        echo "<p>Exit codes: K8s=$k8s_exit_code, Download=$download_exit_code, Python=$python_exit_code</p>"
        echo "<p>Please check the logs on the monitoring server.</p>"
    } | sendmail -t
    
    echo "$(date): Error notification sent" >> "$LOG_FILE"
fi

echo "$(date): Daily health check script completed" >> "$LOG_FILE"
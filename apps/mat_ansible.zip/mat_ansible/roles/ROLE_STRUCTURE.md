# 🏗️ MAT Ansible — Role Structure

> Complete visual map of all Ansible roles in the MAT infrastructure platform.

---

## 📊 At a Glance

| | Category | Roles | Target |
|---|----------|:-----:|--------|
| 🖥️ | Bare-metal services | 28 | VMs (systemd) |
| ☸️ | Kubernetes services | 21 | K8s cluster |
| 🔧 | Utilities | 12 | Any host |
| 📦 | **Total (active)** | **61** | |
| 🗄️ | Deprecated (archived) | 31 | ❌ Do not use |

---

## 🖥️ Bare-Metal Roles

Services deployed directly on VMs as systemd units.

### 🗄️ Data Pipeline

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   📨 INGESTION          💾 STORAGE             ⚖️ ROUTING           │
│                                                                     │
│   kafka/                database/               load_balancing/     │
│   └─ kafka_kraft/       ├─ clickhouse/          └─ haproxy          │
│      ├─ kafka-broker    │  ├─ keeper                                │
│      ├─ kafka_exporter  │  └─ server            🖼️ VISUALISATION    │
│      └─ schema_registry │                                           │
│                         ├─ mysql/               frontend/           │
│   kafka/                │  ├─ install           └─ grafana/         │
│   └─ kafdrop           │  ├─ mysql-exporter       ├─ monitor       │
│                         │  ├─ setup                └─ user          │
│                         │  └─ upgrade                               │
│                         │                                           │
│                         ├─ druid                                    │
│                         └─ prometheus                               │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 📊 Monitoring & Logging

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   🔍 EXPORTERS                      📋 LOG AGGREGATION              │
│                                                                     │
│   monitoring/                       elk/                            │
│   ├─ node-exporter        ───────▶  ├─ elasticsearch/              │
│   ├─ process-exporter     (scrape)  │  ├─ service                  │
│   ├─ blackbox_exporter              │  └─ exporter                 │
│   └─ pushgateway                    ├─ loki                        │
│                                     └─ kibana                      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 💿 Object Storage

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   data_storage/                                                     │
│   ├─ hdfs              Hadoop HDFS (HA, JournalNode, ZKFC)         │
│   ├─ minio              S3-compatible (systemd, single/distributed) │
│   ├─ librefs            S3-compatible (community fork, systemd)     │
│   ├─ nfs_server         NFS exports                                 │
│   └─ nfs_mount          NFS client mounts                           │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 🛠️ Platform & Tooling

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   🏃 RUNTIMES            🔨 BUILD TOOLS        🔒 SECURITY          │
│                                                                     │
│   platform/              platform/              platform/            │
│   ├─ java                ├─ gradle              ├─ sftp_setup       │
│   ├─ docker              ├─ gitlab_runner       └─ nvd_sync         │
│   └─ onepatch           └─ containerd_nerdctl                      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 🤝 Coordination

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   coordination/                                                     │
│   └─ zookeeper          Distributed coordination (ZAB consensus)   │
│                          Used by Kafka, HDFS, Druid                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## ☸️ Kubernetes Roles

Services deployed as K8s resources (Deployments, StatefulSets, Operators).

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   🏗️ CLUSTER FOUNDATION                                             │
│                                                                     │
│   cluster/                                                          │
│   ├─ docker_less ─────── K8s cluster setup (containerd, HA masters)│
│   └─ helm ────────────── Helm CLI binary on master nodes           │
│                                                                     │
│   storage/                                                          │
│   ├─ longhorn ────────── Default StorageClass (distributed block)  │
│   ├─ minio ──────────── S3 object storage (Helm, for backups)     │
│   └─ librefs ─────────── S3 object storage (StatefulSet, AGPL)    │
│                                                                     │
│   networking/                                                       │
│   └─ ingress-controller ─ HAProxy Ingress (DaemonSet, hostPort)   │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   🗄️ DATABASES                                                      │
│                                                                     │
│   database/                                                         │
│   ├─ postgres ────────── CloudNativePG (HA, PgBouncer, snapshots) │
│   ├─ pgadmin ─────────── pgAdmin web UI (auto-configured)         │
│   ├─ elasticsearch ───── StatefulSet (pod log storage)             │
│   ├─ loki ────────────── StatefulSet (log aggregation, TSDB)      │
│   ├─ mongodb ─────────── Percona Operator (ReplicaSet)            │
│   └─ supabase ────────── BaaS platform (Auth, REST, Realtime)     │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   📨 STREAMING                                                      │
│                                                                     │
│   streaming/                                                        │
│   ├─ kafka ──────────── Strimzi Operator (KRaft, NodePools)       │
│   ├─ kafka_connect ──── Strimzi Kafka Connect (connectors, build) │
│   └─ kafka_ui ────────── Kafbat UI (multi-cluster, RBAC)          │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   🖼️ FRONTENDS                                                      │
│                                                                     │
│   frontend/                                                         │
│   ├─ grafana ─────────── Dashboards (LDAP, external PG, plugins)  │
│   └─ headlamp ────────── K8s web dashboard (token-based auth)     │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   📦 PLATFORM                                                       │
│                                                                     │
│   platform/                                                         │
│   └─ harbor ──────────── Container registry (LDAP, GC, Trivy)    │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   ⚙️ OPERATIONS                                                     │
│                                                                     │
│   operations/                                                       │
│   ├─ monitoring ──────── Prometheus + KSM + metrics-server + AM   │
│   ├─ logging ─────────── Fluent Bit DaemonSet (→ ES or Loki)     │
│   ├─ label_management ── Node labels from inventory config         │
│   └─ image_cleanup ───── Container image pruning on workers       │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔧 Utility Roles (`_misc/`)

Reusable roles included as prerequisites before main roles.

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│   ⭐ disable_external_repos   Disable unreachable yum repos        │
│                               (MUST be first role in any playbook  │
│                                that uses yum/dnf)                   │
│                                                                     │
│   clean_service               Remove a systemd service cleanly     │
│   copy_to_aws                 Upload files to AWS S3               │
│   copy_via_ssh                SCP between inventory hosts          │
│   crypto_policy               Set RHEL crypto policy               │
│   crypto_policy_reset         Reset to DEFAULT crypto policy       │
│   falcon_memory_limit         CrowdStrike Falcon resource limits   │
│   housekeep                   Disk cleanup + log pruning           │
│   k8s_cleanup                 Kubernetes cluster cleanup utility   │
│   postfix_fix                 Fix Postfix crashes (DNS lookup +   │
│                               sendmail conflict + monitor cron)    │
│                               (remove workers, reset nodes, Docker │
│                                removal, master teardown)            │
│   realmd_sssd_restart         Restart AD/realm integration         │
│   service_symlink_cleanup     Remove orphan service symlinks       │
│   zscaler_connectivity_test   Verify proxy/internet access         │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🗄️ Deprecated Roles (`_depricated/`)

> ⚠️ **DO NOT USE** — Kept for historical reference only. Functionality moved to active roles.

| Deprecated Role | Replaced By |
|-----------------|-------------|
| `kafka/` | `kafka/kafka_kraft/` |
| `kafka_airborne/` | `kafka/kafka_kraft/` |
| `kafdrop_kraft/` | `kubernetes/streaming/kafka_ui/` |
| `kafdrop_airborne/` | `kubernetes/streaming/kafka_ui/` |
| `kubernetes/` | `kubernetes/cluster/docker_less/` |
| `java_folder/` | `platform/java/` |
| `java_1_8/` | `platform/java/` (OpenJDK 17+) |
| `jmx_agent_exporter/` | Built into `kafka/kafka_kraft/kafka-broker/` |
| `jmx_server_exporter/` | Built into `kafka/kafka_kraft/kafka-broker/` |
| `haproxy_click/` | `load_balancing/haproxy/` (unified) |
| `logstash/` | `kubernetes/operations/logging/` (Fluent Bit) |
| `monitoring/` | `database/prometheus/` (refactored) |
| `mysql_upgrade/` | `database/mysql/install/` (unified) |
| `add_user/zookeeper/` | `coordination/zookeeper/` (rewritten) |
| `hdfs/` | `data_storage/hdfs/` (rewritten) |
| `druid/` | `database/druid/` (rewritten) |
| `cron_tab/` | Deprecated — crons managed per-role (nvd_sync, nerdctl, haproxy cert) |
| `firewalld/` | Deprecated — firewall managed per-role (sftp_setup) or disabled (K8s nodes) |
| `python3/` | Deprecated — Python installed as dependency by roles that need it |
| `druid/` | Removed from stack |
| `hdfs/` | Removed from stack |
| `superset/` | Removed from stack |
| Others | Utility scripts replaced by proper roles |

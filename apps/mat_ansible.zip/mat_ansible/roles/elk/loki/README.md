# Loki Role

Installs and configures [Grafana Loki](https://grafana.com/oss/loki/) — a horizontally-scalable, highly-available log aggregation system inspired by Prometheus. This role deploys Loki in single-binary (all-in-one) mode as a systemd service, using TSDB storage on the local filesystem. Loki receives logs via push from Fluent Bit or Promtail and makes them queryable through Grafana via LogQL.

---

## Latest Version

Check for updates: https://github.com/grafana/loki/releases

Current deployed across environments: `3.7.0`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Disk space** | Sufficient for log retention (depends on ingestion rate) | `df -h /apps` |
| **Network** | Loki port reachable from Fluent Bit/Promtail agents | `curl http://<host>:<port>/ready` |
| **Proxy** | `http_proxy` and `https_proxy` in vault (for GitHub download) | Defined in `all_secrets.yml` |
| **Inventory** | Version, port, and base_dir defined in inventory | See "Required Variables" below |

---

## How to Run

```bash
# Standard deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/elk/loki.yaml \
  --vault-password-file .vault

# Deploy to specific environment
ansible-playbook -i inventories/mat_fixed_network/dr/hosts \
  playbook/elk/loki.yaml \
  --vault-password-file .vault

# Override target host
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/elk/loki.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=loki"
```

---

## Variable Reference

### Required Variables (from inventory)

These MUST be defined — the role will fail without them.

| Source File | Variable | Example | Description |
|-------------|----------|---------|-------------|
| `versions.yml` | `version.loki` | `3.7.0` | Loki version to install |
| `paths.yml` | `paths.loki.base_dir` | `/apps` | Directory where Loki is installed. Must exist (mount point). |
| `networks.yml` | `ports.loki.service` | `3100` | HTTP API port |

### Optional Variables (from config_elk.yml)

These have sensible defaults — only override if needed.

```yaml
config_elk:
  loki:
    user: loki
    group: loki
    arch: linux-amd64
    data_dir: /apps/loki_data
    retention_period: 168h
    retention_enabled: true
    listen_address: "0.0.0.0"
    log_level: warn
    grpc_port: 9096
    memory_limit: "2G"
    nofile_limit: 65536
    ingestion_rate_mb: 10
    ingestion_burst_mb: 20
    max_streams_per_user: 10000
    download_timeout: 120
```

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|-----------------|
| `user` | `loki` | Linux user that runs the service | Change only for naming conventions. Created as system account with no login shell. |
| `group` | `loki` | Linux group for the service | Should match `user` unless shared group access needed. |
| `arch` | `linux-amd64` | Binary architecture | Change to `linux-arm64` for ARM servers. |
| `data_dir` | `/apps/loki_data` | Where Loki stores chunks, indexes, WAL | **Must have sufficient disk.** Place on SSD for best performance. Survives upgrades. |
| `retention_period` | `168h` | How long to keep log data (7 days) | **Increase:** More historical data, more disk usage. **Decrease:** Less disk, shorter query range. |
| `retention_enabled` | `true` | Whether compactor deletes old data | **false:** Data grows unbounded — monitor disk! **true:** Compactor prunes data after retention_period. |
| `listen_address` | `0.0.0.0` | IP to bind HTTP API | `0.0.0.0` = all interfaces. `127.0.0.1` = local only (agents must be co-located). |
| `log_level` | `warn` | Logging verbosity: `debug`, `info`, `warn`, `error` | **debug/info:** Very verbose, use for troubleshooting only. **warn:** Production default. |
| `grpc_port` | `9096` | gRPC port (internal inter-component communication) | Only relevant if running multi-node Loki (not used in single-binary mode). |
| `memory_limit` | `2G` | Systemd `MemoryMax` — max RAM | **Increase:** For high-ingestion Loki (e.g., `4G`, `8G`). **Decrease:** To protect shared hosts. If exceeded, OOM-killed and restarted. |
| `nofile_limit` | `65536` | Systemd `LimitNOFILE` — max open file descriptors | **Increase:** If `too many open files` errors (Loki opens many chunk files). **Decrease:** Rarely needed. |
| `ingestion_rate_mb` | `10` | Max MB/s ingestion per tenant | **Increase:** For high-volume log producers. **Decrease:** To protect Loki from overload (returns 429). |
| `ingestion_burst_mb` | `20` | Burst size above rate limit | Should be 2× `ingestion_rate_mb`. Allows short spikes without 429s. |
| `max_streams_per_user` | `10000` | Max active log streams per tenant | **Increase:** If many unique label combinations. **Decrease:** To prevent cardinality explosion. |
| `download_timeout` | `120` | Seconds to wait for GitHub download | **Increase:** Behind slow proxy. **Decrease:** Faster failure detection. |

---

## What Gets Installed

After a successful run:

```
/apps/
├── loki -> loki-3.7.0/                   # symlink to current version
├── loki-3.7.0/                            # extracted binary directory
│   └── loki                               # the Loki binary
├── loki-3.7.0.linux-amd64.zip            # downloaded archive
└── loki_data/                             # persistent data directory (survives upgrades)
    ├── chunks/                            # chunk storage
    ├── rules/                             # alerting rules
    ├── tsdb-index/                        # TSDB index files
    ├── tsdb-cache/                        # TSDB index cache
    └── compactor/                         # compactor working directory

/apps/loki/loki-config.yaml               # Loki configuration (from template)
/etc/systemd/system/loki.service           # systemd unit
```

---

## Task Execution Flow

```
validate.yml → create_user.yml → pre_verify.yml → pre_install.yml → install.yml → cleanup.yml → config.yml → service.yml → verify.yml
      │               │               │               │                │              │              │              │              │
      ├─ version      ├─ group        ├─ base dir     ├─ get version   ├─ data dir    ├─ rm old dir  ├─ loki-config ├─ template    ├─ service active
      ├─ port         └─ user         ├─ user exists  ├─ set facts     ├─ download    └─ rm old zip  │   .yaml      ├─ daemon      ├─ port listening
      ├─ base_dir                     └─ port status  └─ stop (upg)    ├─ extract                                   ├─ enable      ├─ /ready 200
      └─ memory fmt                                                    ├─ rename bin                                └─ restart*    ├─ version
                                                                       ├─ permissions                                              └─ status
                                                                       └─ symlink
```

*restart only if service file changed or upgrade happened; config changes trigger restart via handler

- **Idempotent:** If the target version is already installed, skips download/extract.
- **Upgrade safe:** Detects old version from running binary, removes only that specific version.
- **Data preserved:** `loki_data/` is never touched during upgrades — only the binary is replaced.
- **Handler-based restart:** Config template change triggers handler restart (not unconditional).

---

## Post-Deployment Verification

### 1. Check Service Status

```bash
systemctl status loki

# Expected:
#   Active: active (running) since ...
#   Main PID: XXXXX (/apps/loki/loki)
```

### 2. Check Port is Listening

```bash
ss -tlnp | grep 3100

# Expected:
# LISTEN  0  128  *:3100  *:*  users:(("loki",pid=XXXXX,fd=X))
```

### 3. Check Ready Endpoint

```bash
curl -s http://localhost:3100/ready

# Expected:
# ready
```

### 4. Check Version

```bash
/apps/loki/loki --version

# Expected:
# loki, version 3.7.0 (branch: HEAD, revision: ...)
```

### 5. Test Log Ingestion

```bash
# Push a test log entry
curl -s -X POST http://localhost:3100/loki/api/v1/push \
  -H "Content-Type: application/json" \
  -d '{"streams":[{"stream":{"job":"test","host":"ansible"},"values":[["'$(date +%s)000000000'","test log from deployment verification"]]}]}'

# Query it back
curl -s "http://localhost:3100/loki/api/v1/query?query={job=\"test\"}" | python3 -m json.tool

# Expected: JSON response with your test log entry
```

### 6. Check Metrics

```bash
curl -s http://localhost:3100/metrics | grep loki_ingester_streams_created_total

# Expected: Prometheus metric showing stream creation count
```

---

## Upgrade Process

To upgrade Loki:

1. Update `version.loki` in the relevant `versions.yml`
2. Re-run the playbook
3. The role will: detect old version → stop service → download new → extract → update symlink → remove old version → start service → verify

```bash
# Example: upgrade from 3.5.0 to 3.7.0
# Edit: inventories/mat_fixed_network/dr/group_vars/all/versions.yml
#   loki: 3.7.0

ansible-playbook -i inventories/mat_fixed_network/dr/hosts \
  playbook/elk/loki.yaml \
  --vault-password-file .vault
```

**Note:** Loki may take a few seconds to become ready after upgrade (TSDB replay). The verify step retries `/ready` 5 times with 5s delay.

---

## Troubleshooting

### Checking Logs

Loki does **not** write log files — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u loki --no-pager -n 50

# Follow live (tail)
journalctl -u loki -f

# Errors only
journalctl -u loki -p err

# Since last boot
journalctl -u loki -b

# Specific time range
journalctl -u loki --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Service fails to start

```bash
# Check journal for startup errors
journalctl -u loki --no-pager -n 30

# Common issues:
# - Port already in use: ss -tlnp | grep 3100
# - Config syntax error: /apps/loki/loki -config.file=/apps/loki/loki-config.yaml -verify-config
# - Permission denied on data dir: ls -la /apps/loki_data/
# - OOM killed: journalctl -k | grep -i oom
```

### Download fails

```bash
# Check proxy is set
echo $http_proxy $https_proxy

# Test GitHub access manually
curl -v https://github.com/grafana/loki/releases/download/v3.7.0/loki-linux-amd64.zip

# Increase timeout if slow network
config_elk:
  loki:
    download_timeout: 300
```

### Ingestion rate limit (HTTP 429)

```bash
# Check current ingestion rate
curl -s http://localhost:3100/metrics | grep loki_distributor_bytes_received_total

# If hitting 429s, increase limits:
config_elk:
  loki:
    ingestion_rate_mb: 20
    ingestion_burst_mb: 40
```

### Disk full / retention not working

```bash
# Check disk usage
du -sh /apps/loki_data/

# Check compactor is running
curl -s http://localhost:3100/metrics | grep loki_compactor_runs_completed_total

# Verify retention is enabled in config
grep retention /apps/loki/loki-config.yaml

# Force compaction (if urgent)
# Restart Loki — compactor runs at startup
systemctl restart loki
```

### Old versions not cleaned up

Cleanup only runs during upgrades. If old files remain:

```bash
# Check what's in the base directory
ls /apps/ | grep loki

# Manually remove if needed
rm -rf /apps/loki-<old-version>
rm -f /apps/loki-<old-version>.linux-amd64.zip
```

---

## File Structure

```
roles/elk/loki/
├── defaults/main.yml              # All variables (core, user, storage, runtime, limits, proxy)
├── handlers/main.yml              # Restart handler
├── tasks/
│   ├── main.yml                   # Orchestrator (with execution order comment)
│   ├── validate.yml               # Pre-flight checks (version, port, base dir, memory)
│   ├── create_user.yml            # System user and group (nologin)
│   ├── pre_verify.yml             # Prerequisite verification (base dir, user, group, port)
│   ├── pre_install.yml            # Version check, stop if upgrade needed
│   ├── install.yml                # Download zip, extract, rename binary, symlink
│   ├── cleanup.yml                # Remove old version (exact version, no globs)
│   ├── config.yml                 # Deploy loki-config.yaml (triggers handler)
│   ├── service.yml                # Systemd unit, enable, start, conditional restart
│   └── verify.yml                 # Health checks (service, port, /ready, version)
├── templates/
│   ├── loki.service.j2            # Systemd unit (loki user, memory/nofile limits)
│   └── loki-config.yaml.j2       # Full Loki config (TSDB, filesystem, retention, limits)
└── README.md                       # This file
```

---

### Service Account Access

The `loki` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as loki
su -s /bin/bash loki

# Run a single command as loki
su -s /bin/bash -c "whoami" loki

# Check data directory permissions
su -s /bin/bash -c "ls -la /apps/loki_data/" loki
```

---

## Security Notes

- Service runs as unprivileged user (`loki`) — not root
- Data directory owned by loki user (mode `0755`)
- Config file mode `0640` (loki-owned, not world-readable)
- No authentication on API by default — rely on network-level access control (firewall)
- Binary downloaded from official GitHub releases
- `validate_certs: false` on download (required behind corporate proxy with MITM inspection)
- `analytics.reporting_enabled: false` in config — no telemetry sent to Grafana

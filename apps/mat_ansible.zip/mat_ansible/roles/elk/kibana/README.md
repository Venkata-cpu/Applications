# Kibana Role

Installs and configures [Kibana](https://www.elastic.co/kibana/) — the Elasticsearch visualisation and exploration UI. Provides dashboards, Discover (log search), Lens (drag-and-drop charts), and index management. Installed via the official Elastic RPM repository with version-based upgrade logic.

---

## Latest Version

Check for updates: https://www.elastic.co/downloads/kibana

Current deployed: `9.0.3` (must match Elasticsearch version)

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (mount point: `/apps`) | `ls -la /apps` |
| **Elasticsearch** | Running and reachable from Kibana host | `curl http://<es-host>:9200/_cluster/health` |
| **Proxy** | For Elastic repo download | `all_secrets.yml` |
| **Version match** | Kibana version MUST match Elasticsearch version exactly | Check both `version.elk.kibana` and `version.elk.elasticsearch` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/elk/kibana.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.elk.kibana` | `9.0.3` | Kibana version (must match ES) |
| `paths.yml` | `paths.kibana.base_dir` | `/apps` | Base directory |
| `networks.yml` | `ports.elk.kibana.service` | `5601` | Kibana HTTP port |

### Optional (from config_elk.yml)

```yaml
config_elk:
  kibana:
    server_host: "0.0.0.0"
    base_path: ""
    elasticsearch_hosts:
      - "http://10.6.102.112:61003"
    elasticsearch_ssl_verification_mode: none
    elasticsearch_username: ""
    elasticsearch_password: ""
    log_level: warn
    memory_limit: "1G"
    nofile_limit: 65536
    node_options: "--max-old-space-size=768"
    download_timeout: 120
    wait_retries: 10
    wait_delay: 15
```

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `server_host` | `0.0.0.0` | Bind address | `127.0.0.1` = local only |
| `base_path` | `""` | URL prefix (e.g., `/kibana`) | For reverse proxy (HAProxy) |
| `elasticsearch_hosts` | `['http://localhost:9200']` | ES cluster URLs | List of all ES nodes for HA |
| `elasticsearch_ssl_verification_mode` | `none` | SSL cert verification | `full` for production with proper certs |
| `log_level` | `warn` | Logging level | `info` for troubleshooting |
| `memory_limit` | `1G` | Systemd MemoryMax | Increase for heavy dashboarding |
| `node_options` | `--max-old-space-size=768` | Node.js heap limit (MB) | Must be less than memory_limit |

---

## What Gets Installed

```
/usr/share/kibana/                     # Binary (from RPM)
/etc/kibana/kibana.yml                 # Configuration (from role template)
/var/log/kibana/kibana.log             # Application log
/run/kibana/kibana.pid                 # PID file

/etc/systemd/system/kibana.service.d/
└── override.conf                      # Resource limits (MemoryMax, LimitNOFILE, NODE_OPTIONS)
```

---

## Task Execution Flow

```
validate → pre_install → install → config → service → verify
    │           │            │         │         │         │
    ├─ version  ├─ rpm query ├─ repo   ├─ yml    ├─ daemon ├─ service active
    ├─ base dir ├─ set facts ├─ pkg    ├─ systemd├─ enable ├─ port listening
    ├─ port     └─ stop(upg) └─ disable│  override└─restart├─ /api/status
    └─ ES hosts                 repo                (cond) └─ status summary
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status kibana

# 2. Port listening
ss -tlnp | grep 5601

# 3. Status API
curl -s http://localhost:5601/api/status | python3 -m json.tool | head -20

# 4. Open in browser
# http://<host>:<port>
```

---

## Upgrade Process

1. Update `version.elk.kibana` in `versions.yml` (must match `version.elk.elasticsearch`)
2. **Upgrade Elasticsearch first**, then Kibana
3. Re-run the playbook
4. Role will: detect version mismatch → stop → install new → restart → verify

---

## Troubleshooting

### Checking Logs

```bash
# Application log
tail -100 /var/log/kibana/kibana.log

# Systemd journal
journalctl -u kibana --no-pager -n 50

# Follow live
journalctl -u kibana -f
```

### Kibana won't start

```bash
journalctl -u kibana --no-pager -n 30
# Common: ES unreachable, port conflict, config syntax error
```

### "Kibana server is not ready yet"

Kibana takes 30-60s to initialise on first boot (builds index patterns, migrates saved objects). Wait and retry.

### Version mismatch error

Kibana and Elasticsearch MUST be the same version. Check both:
```bash
rpm -q kibana elasticsearch
```

---

## File Structure

```
roles/elk/kibana/
├── defaults/main.yml                  # All variables (config_elk.kibana.*)
├── handlers/main.yml                  # restart kibana
├── tasks/
│   ├── main.yml                       # Orchestrator
│   ├── validate.yml                   # Pre-flight checks
│   ├── pre_install.yml                # Version check, conditional stop
│   ├── install.yml                    # Elastic repo + RPM install
│   ├── config.yml                     # kibana.yml + systemd override
│   ├── service.yml                    # Enable, start, conditional restart
│   └── verify.yml                     # Service active, port, status API
├── templates/
│   ├── kibana.yml.j2                  # Kibana config (ES hosts, port, logging)
│   └── kibana-override.conf.j2       # Systemd resource limits
└── README.md                          # This file
```

---

## Security Notes

- Kibana runs as the `kibana` system user (created by RPM)
- Config file mode `0640` (root:kibana — passwords not world-readable)
- `telemetry.optIn: false` — no data sent to Elastic
- No authentication by default — rely on network-level access or configure Elastic security
- `validate_certs: false` on repo (required behind corporate proxy)

# Elasticsearch Exporter Role

Installs Prometheus Elasticsearch Exporter — exposes cluster health, node stats, and index metrics for Prometheus to scrape.

## Latest Version

Check for updates: https://github.com/prometheus-community/elasticsearch_exporter/releases

Current deployed: check `version.elk.elasticsearch_exporter` in versions.yml

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist | `ls -la /apps` |
| **Elasticsearch** | Must be running and accessible | `curl http://localhost:<es_port>` |
| **Proxy** | For GitHub download | In `all_secrets.yml` |

---

## Variable Reference

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `version.elk.elasticsearch_exporter` | — | Binary version | Required |
| `paths.elasticsearch_exporter.base_dir` | — | Install directory | Required |
| `ports.elk.elasticSearch.exporter` | — | Metrics port | Required |
| `config.elk.elasticsearch_exporter.memory_limit` | `512M` | Systemd `MemoryMax` | Increase if many indices |
| `config.elk.elasticsearch_exporter.nofile_limit` | `1024` | Systemd `LimitNOFILE` | Rarely needs change |
| `config.elk.elasticsearch_exporter.listen_address` | `0.0.0.0` | Bind address | |
| `config.elk.elasticsearch_exporter.arch` | `linux-amd64` | Binary arch | |
| `config.elk.elasticsearch_exporter.download_timeout` | `30` | Seconds | |

---

## Task Flow

```
main.yml
├── validate.yml         # Pre-flight checks (version, port, base_dir)
├── create_user.yml      # System user/group
├── pre_install.yml      # Version check + stop
├── install.yml          # Download + extract + symlink
├── cleanup.yml          # Remove old version (no patterns)
├── service.yml          # Systemd + start + conditional restart
└── verify.yml           # Service + port + metrics endpoint
```

---

## Post-Deployment Verification

```bash
# Service status
systemctl status elasticsearch_exporter

# Metrics
curl -s http://localhost:<port>/metrics | grep elasticsearch_cluster_health_status

# Version
/apps/elasticsearch_exporter/elasticsearch_exporter --version
```

---

## Troubleshooting

### Checking Logs

Elasticsearch Exporter does **not** write log files — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u elasticsearch_exporter --no-pager -n 50

# Follow live
journalctl -u elasticsearch_exporter -f

# Errors only
journalctl -u elasticsearch_exporter -p err

# Since last boot
journalctl -u elasticsearch_exporter -b

# Specific time range
journalctl -u elasticsearch_exporter --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Service won't start
```bash
systemctl status elasticsearch_exporter
journalctl -u elasticsearch_exporter --no-pager -n 50
# Common: Elasticsearch not reachable, port conflict, binary permissions
```

### No metrics / empty response
```bash
# Check Elasticsearch is accessible
curl http://localhost:<es_port>
# Check exporter connects
journalctl -u elasticsearch_exporter | grep -i "error\|fail\|connect"
```

---

## File Structure

```
roles/elasticsearch/exporter/
├── defaults/main.yml
├── tasks/
│   ├── main.yml
│   ├── validate.yml
│   ├── create_user.yml
│   ├── pre_install.yml
│   ├── install.yml
│   ├── cleanup.yml
│   ├── service.yml
│   └── verify.yml
├── templates/
│   └── elasticsearch_exporter.service.j2
└── README.md
```

### Service Account Access

The `elastic-exporter` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as elastic-exporter
su -s /bin/bash elastic-exporter

# Run a single command as elastic-exporter
su -s /bin/bash -c "whoami" elastic-exporter
```

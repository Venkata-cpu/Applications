# Elasticsearch Service Role

Installs and configures Elasticsearch for log storage and search. Supports fresh installs, version upgrades, cluster configuration, ILM retention policies, and date_nanos index templates.

## Latest Version

Check for updates: https://www.elastic.co/downloads/elasticsearch

Current deployed: `8.11.2`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Network** | ES port reachable from Logstash, Grafana, Prometheus | `curl http://<host>:<port>` |
| **RAM** | Minimum 8GB recommended (heap = half of available) | `free -h` |
| **Proxy** | `http_proxy`/`https_proxy` for Elastic downloads | In `all_secrets.yml` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/elasticsearch.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=elasticsearch"
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example |
|--------|----------|---------|
| `versions.yml` | `version.elk.elasticsearch` | `8.11.2` |
| `paths.yml` | `paths.elasticsearch.base_dir` | `/apps` |
| `networks.yml` | `ports.elk.elasticSearch.service` | `61003` |
| `networks.yml` | `ports.elk.elasticSearch.transport` | `9300` |
| `app_configs.yml` | `config.elk.elasticsearch.cluster_name` | `MartiniFN` |
| `app_configs.yml` | `config.elk.elasticsearch.indices_retention_days` | `4` |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.elk.elasticsearch.heap_size` | `4g` | JVM heap (Xms/Xmx) | **Increase:** For large indices. Never exceed 50% of RAM or 31g. |
| `config.elk.elasticsearch.max_open_files` | `65536` | Systemd `LimitNOFILE` | **Increase:** If `too many open files` errors in logs. |
| `config.elk.elasticsearch.memory_limit` | `8G` | Systemd `MemoryMax` | **Increase:** Should be heap + ~2G overhead. If exceeded, process is killed. |
| `config.elk.elasticsearch.log_max_size` | `300MB` | Max log file size before rotation | |
| `config.elk.elasticsearch.arch` | `linux-x86_64` | Binary architecture | |
| `config.elk.elasticsearch.download_timeout` | `120` | Seconds to wait for download | |
| `config.elk.elasticsearch.bind_address` | `0.0.0.0` | Network bind address | |
| `config.elk.elasticsearch.date_nanos_enabled` | `true` | Enable nanosecond timestamps for kubelogs | |
| `config.elk.elasticsearch.wait_retries` | `10` | Retries for health check after start | |
| `config.elk.elasticsearch.wait_delay` | `15` | Seconds between retries | |

---

## Task Execution Flow

```
main.yml
├── validate.yml         # Pre-flight checks (version, port, base_dir, cluster_name, memory_limit > heap_size)
├── create_user.yml      # System user/group
├── pre_install.yml      # Version check, stop if upgrade needed
├── install.yml          # Download, extract, symlink, data dir, logs dir
├── cleanup.yml          # Remove old version (detected, no patterns)
├── config.yml           # elasticsearch.yml, jvm.options, log4j
├── service.yml          # Systemd unit, enable, start, conditional restart
├── verify.yml           # Service + port + cluster health
└── post_install.yml     # ILM policy, date_nanos index template
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status elasticsearch

# 2. Cluster health
curl -s http://localhost:61003/_cluster/health | python3 -m json.tool

# 3. Node info
curl -s http://localhost:61003/_cat/nodes?v

# 4. Indices
curl -s http://localhost:61003/_cat/indices?v

# 5. ILM policy
curl -s http://localhost:61003/_ilm/policy/logs-retention-policy | python3 -m json.tool

# 6. Check version
curl -s http://localhost:61003 | grep number
```

---

## File Structure

```
roles/elasticsearch/service/
├── defaults/main.yml                     # All variables
├── tasks/
│   ├── main.yml                          # Orchestrator
│   ├── validate.yml                      # Pre-flight checks (version, port, memory > heap)
│   ├── pre_install.yml                   # Version check + stop
│   ├── create_user.yml                   # System user/group
│   ├── install.yml                       # Download + extract + symlink
│   ├── cleanup.yml                       # Remove old version (no patterns)
│   ├── config.yml                        # elasticsearch.yml + jvm.options + log4j
│   ├── service.yml                       # Systemd + start + conditional restart
│   ├── verify.yml                        # Service + port + cluster health
│   └── post_install.yml                  # ILM policy + index template
├── templates/
│   ├── elasticsearch.service.j2          # Systemd unit (MemoryMax, LimitNOFILE)
│   ├── elasticsearch.yml.j2             # ES config
│   └── jvm.options.j2                   # Heap settings
└── README.md                             # This file
```

---

## Troubleshooting

### Checking Logs

Elasticsearch logs go to **both** a log file and systemd journal:

```bash
# Log file (application-level logs)
tail -f /apps/elasticsearch/logs/*.log
ls -la /apps/elasticsearch/logs/

# Systemd journal — recent logs (last 50 lines)
journalctl -u elasticsearch --no-pager -n 50

# Follow live
journalctl -u elasticsearch -f

# Errors only
journalctl -u elasticsearch -p err

# Since last boot
journalctl -u elasticsearch -b

# Specific time range
journalctl -u elasticsearch --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Elasticsearch won't start
```bash
journalctl -u elasticsearch --no-pager -n 50
# Common: heap too large, port conflict, permission denied on data dir
```

### Cluster health RED
```bash
curl -s http://localhost:61003/_cluster/allocation/explain | python3 -m json.tool
```

### Too many open files
```bash
# Increase in config:
config.elk.elasticsearch.max_open_files: 200000
```

### OOM killed
```bash
# Check if memory_limit is too low for heap + overhead:
# memory_limit should be at least heap_size * 2
journalctl -u elasticsearch | grep -i "oom\|killed"
```

### Service Account Access

The `elasticsearch` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as elasticsearch
su -s /bin/bash elasticsearch

# Run a single command as elasticsearch
su -s /bin/bash -c "whoami" elasticsearch
```

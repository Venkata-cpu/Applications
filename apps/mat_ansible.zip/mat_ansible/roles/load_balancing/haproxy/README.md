# HAProxy Role

Installs and configures [HAProxy](https://www.haproxy.org/) — a high-performance TCP/HTTP load balancer compiled from source with the Prometheus metrics exporter (`USE_PROMEX=1`) built in. Supports multiple HAProxy instances on the same host via different config directories, SSL certificate expiry monitoring with email alerts, and zero-downtime upgrades.

---

## Latest Version

Check for updates: https://www.haproxy.org/#down

Current deployed across environments: `3.2.0`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Build tools** | gcc, make, openssl-devel, pcre-devel, zlib-devel (installed by role) | `rpm -q gcc make` |
| **Network** | Stats port reachable from monitoring | `curl http://<host>:<stats_port>/metrics` |
| **Proxy** | `http_proxy` and `https_proxy` in vault (for source download) | Defined in `all_secrets.yml` |
| **Config template** | `haproxy.cfg.j2` must exist in inventory configs dir | Check `inventories/<module>/<env>/configs/haproxy/` |

---

## How to Run

```bash
# Standard deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/load_balancing/haproxy.yaml \
  --vault-password-file .vault

# Deploy to specific host group
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/load_balancing/haproxy.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=haproxy"

# Deploy to DR HAProxy servers
ansible-playbook -i inventories/mat_fixed_network/dr/hosts \
  playbook/load_balancing/haproxy.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=dr_haproxy_servers"
```

---

## Variable Reference

### Required Variables (from inventory)

These MUST be defined — the role will fail without them.

| Source File | Variable | Example | Description |
|-------------|----------|---------|-------------|
| `versions.yml` | `version.haproxy.patch` | `3.2.0` | Full patch version to compile |
| `versions.yml` | `version.haproxy.minor` | `3.2` | Minor version (used in download URL path) |
| `paths.yml` | `paths.haproxy.base_dir` | `/apps` | Directory where HAProxy is installed. Must exist (mount point). |
| `networks.yml` | `ports.haproxy.stats` | `61009` | Port for HAProxy stats/Prometheus metrics |

### Optional Variables (from app_configs.yml)

These have sensible defaults — only override if needed.

```yaml
config_load_balancing:
  haproxy:
    config_dir: haproxy
    memory_limit: "1G"
    nofile_limit: 65536
    download_timeout: 120
    cert_check:
      enabled: false
      cert_paths: []
      threshold_days: 30
      schedule: "0 6 * * 1"
      smtp_host: smtpb.intra.bt.com
      smtp_port: 25
      from_email: noreply.martini@bt.com
      to_emails: []
      cc_emails: []
```

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|-----------------|
| `config_dir` | `haproxy` | Inventory subfolder for config templates | Change to run multiple HAProxy instances with different configs (e.g., `haproxy_click`). |
| `memory_limit` | `1G` | Systemd `MemoryMax` — max RAM | **Increase:** For high-traffic HAProxy with many connections (e.g., `2G`, `4G`). **Decrease:** For low-traffic instances. If exceeded, systemd kills and restarts. |
| `nofile_limit` | `65536` | Systemd `LimitNOFILE` — max open file descriptors | **Increase:** If `too many open files` errors in logs. HAProxy needs 2 FDs per connection. **Decrease:** Rarely needed. |
| `download_timeout` | `120` | Seconds to wait for source tarball download | **Increase:** Behind slow proxy. **Decrease:** Faster failure detection. |
| `cert_check.enabled` | `false` | Enable SSL cert expiry monitoring cron | Set `true` and define `cert_paths` to get email alerts before certs expire. |
| `cert_check.threshold_days` | `30` | Days before expiry to trigger alert | **Increase:** More advance warning. **Decrease:** Less noise (e.g., `7` for last-minute only). |
| `cert_check.schedule` | `0 6 * * 1` | Cron schedule for cert checks | Default: weekly Monday 06:00. Change to `0 6 * * *` for daily checks. |

---

## What Gets Installed

After a successful run:

```
/apps/
├── haproxy -> haproxy-3.2.0-bin/         # symlink to current compiled version
├── haproxy-3.2.0-bin/                     # compiled binary and support files
│   ├── sbin/haproxy                       # the HAProxy binary
│   ├── share/
│   └── doc/
├── haproxy-3.2.0/                         # extracted source (retained for reference)
├── haproxy-3.2.0.tar.gz                   # downloaded source archive
└── haproxy/etc/                           # config directory
    ├── haproxy.cfg                         # main config (from inventory template)
    └── userlist.cfg                        # optional userlist (from inventory template)

/etc/systemd/system/haproxy.service        # systemd unit
/etc/cron.d/haproxy-cert-check             # cert expiry cron (if enabled)
/apps/haproxy/check-cert-expiry.sh         # cert check script (if enabled)
```

---

## Task Execution Flow

```
validate.yml → pre_verify.yml → pre_install.yml → install.yml → cleanup.yml → config.yml → service.yml → cert_check.yml → verify.yml
      │               │               │                │              │              │              │              │              │
      ├─ version      ├─ base dir     ├─ get version   ├─ build deps  ├─ rm old src  ├─ haproxy.cfg ├─ template    ├─ script     ├─ service active
      ├─ config tmpl  ├─ config tmpl  ├─ set facts     ├─ download    ├─ rm old bin  ├─ userlist    ├─ daemon      ├─ cron       ├─ version
      └─ memory fmt   └─ port status  └─ stop (upg)    ├─ extract     └─ rm old tar                ├─ enable                   ├─ stats port
                                                        ├─ compile                                  └─ restart*                  └─ status
                                                        └─ symlink
```

*restart only if service file, config, or binary changed

- **Idempotent:** If the target version is already compiled, skips download/compile.
- **Upgrade safe:** Detects old version from running binary, removes only that specific version.
- **Source compile:** Required for `USE_PROMEX=1` (built-in Prometheus metrics endpoint).
- **Config validation:** `ExecStartPre` in systemd checks config syntax before starting.

---

## Post-Deployment Verification

### 1. Check Service Status

```bash
systemctl status haproxy

# Expected:
#   Active: active (running) since ...
#   Main PID: XXXXX (/apps/haproxy/sbin/haproxy)
```

### 2. Check Version

```bash
/apps/haproxy/sbin/haproxy -v

# Expected:
# HAProxy version 3.2.0-...
# Built with USE_PROMEX=1 ...
```

### 3. Check Stats/Metrics Port

```bash
ss -tlnp | grep 61009

# Expected:
# LISTEN  0  128  *:61009  *:*  users:(("haproxy",pid=XXXXX,fd=X))
```

### 4. Check Prometheus Metrics

```bash
curl -s http://localhost:61009/metrics | head -20

# Expected: Prometheus exposition format (haproxy_* metrics)
```

### 5. Validate Config Syntax

```bash
/apps/haproxy/sbin/haproxy -c -f /apps/haproxy/etc/haproxy.cfg

# Expected:
# Configuration file is valid
```

### 6. Check Backend Health

```bash
# Via stats page (if enabled in haproxy.cfg)
curl -s http://localhost:61009/stats | grep -c "UP"

# Or via Prometheus metrics
curl -s http://localhost:61009/metrics | grep haproxy_server_status
```

---

## Upgrade Process

To upgrade HAProxy:

1. Update `version.haproxy.patch` and `version.haproxy.minor` in `versions.yml`
2. Re-run the playbook
3. The role will: detect old version → stop service → download new source → compile → update symlink → remove old version → start service → verify

```bash
# Example: upgrade from 3.0.0 to 3.2.0
# Edit: inventories/mat_fixed_network/prod/group_vars/all/versions.yml
#   haproxy:
#     minor: "3.2"
#     patch: "3.2.0"

ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/load_balancing/haproxy.yaml \
  --vault-password-file .vault
```

---

## Troubleshooting

### Checking Logs

HAProxy does **not** write log files by default — output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u haproxy --no-pager -n 50

# Follow live (tail)
journalctl -u haproxy -f

# Errors only
journalctl -u haproxy -p err

# Specific time range
journalctl -u haproxy --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

If HAProxy is configured with syslog in `haproxy.cfg`:

```bash
# Check syslog (if configured)
tail -100 /var/log/haproxy.log
```

### Compilation fails

```bash
# Check build deps are installed
rpm -q gcc make openssl-devel pcre-devel zlib-devel socat

# Check source was extracted
ls -la /apps/haproxy-3.2.0/

# Try manual compile to see errors
cd /apps/haproxy-3.2.0
make TARGET=linux-glibc USE_OPENSSL=1 USE_PCRE=1 USE_ZLIB=1 USE_PROMEX=1
```

### Config syntax error

```bash
# Validate config
/apps/haproxy/sbin/haproxy -c -f /apps/haproxy/etc/haproxy.cfg

# Check which line has the error (output shows line number)
```

### Service won't start

```bash
# Check journal for the error
journalctl -u haproxy --no-pager -n 20

# Common issues:
# - Config syntax error: haproxy -c -f <config>
# - Port already in use: ss -tlnp | grep <port>
# - Missing cert file: check paths in haproxy.cfg
# - Permission denied: check file ownership
```

### Certificate expiry check not working

```bash
# Run the script manually
/apps/haproxy/check-cert-expiry.sh

# Check cron is scheduled
cat /etc/cron.d/haproxy-cert-check

# Check cert file exists and is readable
openssl x509 -enddate -noout -in /path/to/cert.pem

# Check email delivery
cat /var/log/haproxy-cert-check.log
```

---

## File Structure

```
roles/load_balancing/haproxy/
├── defaults/main.yml              # All variables (core, cert check, resource limits, proxy)
├── handlers/main.yml              # Restart handler
├── tasks/
│   ├── main.yml                   # Orchestrator (with execution order comment)
│   ├── validate.yml               # Pre-flight checks (version, base dir, config template, memory)
│   ├── pre_verify.yml             # Prerequisite verification (base dir, deps, config, port)
│   ├── pre_install.yml            # Version check, stop if upgrade needed
│   ├── install.yml                # Build deps, download, extract, compile, symlink
│   ├── cleanup.yml                # Remove old version (exact version, no globs)
│   ├── config.yml                 # Deploy haproxy.cfg + optional userlist from inventory
│   ├── service.yml                # Systemd unit, enable, start, conditional restart
│   ├── cert_check.yml             # SSL cert expiry script + cron (conditional)
│   └── verify.yml                 # Health checks (service, version, port, status summary)
├── templates/
│   ├── haproxy.service.j2         # Systemd unit (ExecStartPre config check, memory/nofile limits)
│   └── check-cert-expiry.sh.j2   # Cert expiry monitoring script with email
└── README.md                       # This file
```

---

## Security Notes

- HAProxy runs as **root** — required for binding privileged ports (<1024) and seamless reloads
- Config files are mode `0640` (root-owned, not world-readable)
- `ExecStartPre` validates config syntax before every start (prevents bad config from breaking the service)
- SSL certificates monitored via cron (optional) — no secrets stored in plaintext
- Source download uses `validate_certs: false` (required behind corporate proxy with MITM inspection)
- Stats/metrics endpoint is unauthenticated — rely on network-level access control (firewall)

# Grafana Role (On-Prem)

Installs and configures [Grafana Enterprise](https://grafana.com/grafana/download/) as a bare-metal systemd service. Supports multiple instances per environment (e.g., `monitor` and `user`) via the `grafana_instance_name` playbook variable. Each instance runs on a separate host with its own config from inventory.

---

## Latest Version

Check for updates: https://grafana.com/grafana/download/

Current deployed: `12.1.1`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (`/apps`) | `ls -la /apps` |
| **MySQL database** | Running with Grafana DB + user created (see below) | `mysql -u grafana -p -h <mysql-host> -e "SELECT 1"` |
| **Proxy** | For Grafana download + plugin install | `all_secrets.yml` |
| **Config templates** | `grafana.ini.j2` in inventory | `inventories/<module>/<env>/configs/grafana/<instance>/` |

### Database Setup (before first run)

Grafana stores dashboards, users, sessions, and alerts in an external database. Create the database and user **before** running the Grafana playbook.

#### Option A: MySQL

```sql
-- On the MySQL server (connect as root)
CREATE DATABASE grafana CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'grafana'@'%' IDENTIFIED BY '<password>';
GRANT ALL PRIVILEGES ON grafana.* TO 'grafana'@'%';
FLUSH PRIVILEGES;
```

Or via the `mysql/setup` role — add to your `config_database.mysql` config:
```yaml
config_database:
  mysql:
    databases:
      - grafana
    users:
      - name: grafana
        host: "%"
        password_vault_var: mysql_grafana_password
    user_access:
      - name: grafana
        host: "%"
        database: grafana
        tables: "*"
        access: "ALL PRIVILEGES"
```

Then run `mysql_user_setup.yaml` before `grafana_monitor.yaml`.

#### Option B: PostgreSQL

```sql
-- On a PostgreSQL server (via psql as superuser)
CREATE DATABASE grafana;
CREATE USER grafana WITH PASSWORD '<password>';
GRANT ALL PRIVILEGES ON DATABASE grafana TO grafana;
\c grafana
GRANT ALL ON SCHEMA public TO grafana;
```

Or if using CNPG on K8s:
```bash
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -c "CREATE DATABASE grafana;"
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -c "CREATE USER grafana WITH PASSWORD '<password>';"
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE grafana TO grafana;"
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -d grafana -c "GRANT ALL ON SCHEMA public TO grafana;"
```

**Verify connectivity:**
```bash
# MySQL
mysql -u grafana -p -h <mysql-host> -P <mysql-port> -e "USE grafana; SELECT 1;"

# PostgreSQL
psql -h <host> -U grafana -d grafana -c "SELECT 1;"
```

**Note:** Grafana auto-creates all required tables on first start (schema migration runs automatically). The DB type is configured in `grafana.ini.j2` (`[database]` section).

---

## How to Run

```bash
# Monitor instance
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/frontend/grafana_monitor.yaml \
  --vault-password-file .vault

# User instance
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/frontend/grafana_user.yaml \
  --vault-password-file .vault
```

### Playbook Structure

Each instance needs its own playbook that sets `grafana_instance_name`:

```yaml
# playbook/frontend/grafana_monitor.yaml
- hosts: "{{ target_host | default('grafana_monitoring') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
    grafana_instance_name: monitor
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/frontend/grafana }
```

```yaml
# playbook/frontend/grafana_user.yaml
- hosts: "{{ target_host | default('grafana_user') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
    grafana_instance_name: user
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/frontend/grafana }
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.grafana.<instance>` | `12.1.1` | Per-instance version |
| `paths.yml` | `paths.grafana.base_dir` | `/apps` | Base directory |
| `networks.yml` | `ports.grafana.service` | `61011` | Grafana port |
| Playbook var | `grafana_instance_name` | `monitor` | Instance identifier |

### Optional (from config_frontend.yml)

```yaml
config_frontend:
  grafana:
    monitor:
      port: 61011
      memory_limit: "2G"
      nofile_limit: 65536
      log_rotation_size: "100M"
      log_rotation_count: 5
      no_proxy: "localhost,127.0.0.1,10.6.102.112"
      plugins:
        - grafana-clock-panel
        - grafana-piechart-panel
      download_timeout: 120
      wait_retries: 10
      wait_delay: 10
    user:
      port: 61011
      memory_limit: "4G"
      no_proxy: "localhost,127.0.0.1"
      plugins:
        - grafana-polystat-panel
        - yesoreyeram-infinity-datasource
```

All settings are resolved per-instance via `config_frontend.grafana[<instance>].*`.

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `port` | `3000` | Grafana HTTP port | Per-instance, set different ports if testing locally |
| `memory_limit` | `2G` | Systemd MemoryMax | Increase for heavy dashboard usage |
| `nofile_limit` | `65536` | Systemd LimitNOFILE | Increase if too-many-files errors |
| `log_rotation_size` | `100M` | Max log size before rotate | |
| `log_rotation_count` | `5` | Rotated files kept | |
| `no_proxy` | `localhost,127.0.0.1` | Proxy bypass list | Add datasource IPs (ES, Prometheus) |
| `plugins` | `[]` | Plugins to install | Installed via `grafana cli`, idempotent |
| `download_timeout` | `120` | Tarball download timeout (seconds) | Increase for slow proxy |
| `user` | `grafana` | Service user | |
| `group` | `grafana` | Service group | |

### Inventory Config Templates

Place per-instance templates at:

```
inventories/<module>/<env>/configs/grafana/
├── monitor/
│   ├── grafana.ini.j2       # Monitor Grafana config
│   └── ldap.toml.j2         # LDAP config (optional)
└── user/
    ├── grafana.ini.j2       # User Grafana config
    └── ldap.toml.j2         # LDAP config (optional)
```

---

## What Gets Installed

```
/apps/
├── grafana -> grafana-v12.1.1/            # symlink to current
├── grafana-v12.1.1/                       # extracted binary
│   ├── bin/grafana-server                 # binary
│   ├── conf/                              # default configs
│   ├── data/plugins/                      # installed plugins
│   ├── grafana.ini                        # deployed config (from inventory)
│   └── logs/                              # application logs
└── grafana-enterprise-12.1.1.linux-amd64.tar.gz  # archive

/etc/systemd/system/grafana.service        # systemd unit
/etc/logrotate.d/grafana                   # log rotation
```

---

## Task Execution Flow

```
validate → create_user → pre_install → install → config → service → verify
    │           │             │            │         │         │         │
    ├─ version  ├─ group      ├─ binary    ├─ download├─ ini    ├─ systemd├─ active
    ├─ base dir └─ user       ├─ get ver   ├─ extract├─ ldap   ├─ daemon ├─ port
    ├─ instance               └─ stop(upg) ├─ perms  ├─ plugins├─ enable ├─ /api/health
    └─ config exists                       └─ symlink├─ logrot └─restart └─ status
                                                                  (cond)
```

---

## Upgrade Process

1. Update `version.grafana.<instance>` in `versions.yml`
2. Re-run the playbook
3. Role will: detect mismatch → stop → download new → extract → symlink → start → verify
4. Plugins are preserved (stored in `data/plugins/` which is inside the version dir — re-download after upgrade)

---

## Troubleshooting

### Checking Logs

```bash
tail -100 /apps/grafana/logs/grafana.log
journalctl -u grafana --no-pager -n 50
journalctl -u grafana -f
```

### LDAP login fails

Check ldap.toml syntax and connectivity:
```bash
ldapsearch -x -H ldap://<ldap-host>:389 -b "<base_dn>" "(sAMAccountName=testuser)"
```

### Plugin install fails

```bash
# Manual install with proxy
export http_proxy=http://proxy:8080
/apps/grafana/bin/grafana cli --pluginsDir /apps/grafana/data/plugins plugins install <plugin-name>
```

---

## File Structure

```
roles/frontend/grafana/
├── defaults/main.yml          # All variables (config_frontend.grafana.*)
├── handlers/main.yml          # restart grafana
├── tasks/
│   ├── main.yml               # Orchestrator
│   ├── validate.yml           # Version, base dir, instance, config exists
│   ├── create_user.yml        # System user (nologin)
│   ├── pre_install.yml        # Version check, conditional stop
│   ├── install.yml            # Download, extract, symlink
│   ├── config.yml             # grafana.ini + ldap.toml + plugins + logrotate
│   ├── service.yml            # Systemd, enable, start, conditional restart
│   └── verify.yml             # Service active, port, /api/health
├── templates/
│   ├── grafana.service.j2     # Systemd unit (proxy, MemoryMax, LimitNOFILE)
│   └── logrotate.j2           # Log rotation
└── README.md                  # This file
```

---

## Security Notes

- Runs as unprivileged `grafana` user (nologin)
- Config file mode `0640` (passwords not world-readable)
- LDAP config mode `0640` (bind passwords protected)
- MemoryMax prevents runaway memory on large dashboards
- Proxy vars passed via systemd `Environment=` (not hardcoded)
- Enterprise binary used per Grafana recommendation (works without licence for OSS features)
- `validate_certs: false` on download (corporate proxy)

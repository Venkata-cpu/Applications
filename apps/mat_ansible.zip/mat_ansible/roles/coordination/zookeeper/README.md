# Apache ZooKeeper

Deploys Apache ZooKeeper as a systemd service for distributed coordination. ZooKeeper provides centralised configuration management, naming, synchronisation, and group services for distributed applications. Used by Kafka (ZooKeeper mode), HDFS, Druid, and other distributed systems in the MAT ecosystem.

---

## Latest Version

| Component | Version | Check Latest |
|-----------|---------|--------------|
| Apache ZooKeeper | 3.9.5 | [GitHub Releases](https://github.com/apache/zookeeper/releases) |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Java 17+ | OpenJDK must be installed | `java -version` |
| Base directory | `/apps` must exist | `ls -la /apps` |
| Network | Ports 2181, 2888, 3888, 61007 open between ensemble nodes | `ss -tlnp \| grep -E '2181\|2888\|3888\|61007'` |
| Host var `zk_id` | Each host must have a unique `zk_id` integer in inventory | Check `hosts` file |
| Inventory config | `config_coordination.zookeeper` section in `config_coordination.yml` | Check `group_vars/all/config_coordination.yml` |

---

## How to Run

```bash
# Standard deployment (all ZooKeeper nodes)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/coordination/zookeeper.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>"

# Target specific hosts
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/coordination/zookeeper.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>" \
  --extra-vars="target_host=zookeeper"

# Via GitLab CI
APP_INSTANCE=<instance> ENV=<env> APP_GROUP=coordination APP=zookeeper
```

---

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.zookeeper` | `3.9.5` | ZooKeeper version to install |
| `paths.yml` | `paths.zookeeper.base_dir` | `/apps` | Base installation directory |
| `networks.yml` | `ports.zookeeper.client` | `2181` | Client connection port |
| `networks.yml` | `ports.zookeeper.peer` | `2888` | Peer communication port |
| `networks.yml` | `ports.zookeeper.election` | `3888` | Leader election port |
| `networks.yml` | `ports.zookeeper.metrics` | `61007` | Prometheus metrics port |
| `config_coordination.yml` | `config_coordination.zookeeper.heap.min_mb` | `1000` | JVM min heap (MB) |
| `config_coordination.yml` | `config_coordination.zookeeper.heap.max_mb` | `4000` | JVM max heap (MB) |
| `hosts` | `zk_id` | `1` | Unique server ID (host var) |

### Optional Variables (with defaults)

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|------------------|
| `zk_tick_time` | `2000` | Base time unit (ms) for heartbeats and timeouts | Lower = faster failure detection but more network overhead |
| `zk_init_limit` | `10` | Ticks for follower to connect to leader | Increase if followers timeout during initial sync on large datasets |
| `zk_sync_limit` | `5` | Ticks for follower to sync with leader | Increase if network latency is high between nodes |
| `zk_max_client_connections` | `100` | Max concurrent client connections per IP | Increase for high-throughput clients (Kafka brokers) |
| `zk_num_selector_threads` | `3` | NIO selector threads | Increase on high-connection-count servers |
| `zk_4lw_commands_whitelist` | `*` | Enabled 4-letter commands | Restrict to specific commands for security |
| `zk_metrics_enabled` | `true` | Enable Prometheus metrics provider | Set false if not scraping ZooKeeper |
| `zk_memory_limit` | `6G` | Systemd MemoryMax | Must exceed heap.max_mb — kills process if exceeded |
| `zk_nofile_limit` | `65536` | Systemd LimitNOFILE | Increase if "too many open files" errors appear |
| `zk_download_timeout` | `300` | Download timeout in seconds | Increase on slow proxy connections |
| `zk_log_rotation_size` | `100M` | Max log file size before rotation | Larger files = less rotation overhead |
| `zk_log_rotation_count` | `5` | Number of rotated log files to retain | More = more disk usage but longer history |
| `zk_host_group` | `zookeeper` | Inventory host group for ensemble | Change if using a different group name |

### Hardcoded Settings (in zoo.cfg template)

These are set to production-sensible values and not exposed as variables:

| Setting | Value | Rationale |
|---------|-------|-----------|
| `autopurge.snapRetainCount` | `3` | Prevents disk fill from old snapshots |
| `autopurge.purgeInterval` | `1` | Hourly purge cycle |
| `admin.enableServer` | `false` | Not needed — use 4-letter commands for monitoring |
| `maxClientCnxns` | Configurable (`100`) | Per-IP connection limit |

---

## What Gets Installed

```
/apps/
├── apache-zookeeper-3.9.5-bin/       # Extracted distribution
│   ├── bin/                           # Scripts (zkServer.sh, zkCli.sh, zkEnv.sh)
│   ├── conf/
│   │   ├── zoo.cfg                    # Main configuration (Ansible-managed)
│   │   ├── java.env                   # JVM/heap settings (Ansible-managed)
│   │   └── logback.xml                # Logging config (ships with distribution)
│   ├── lib/                           # JAR files
│   └── logs/                          # Application logs (NOT persisted across upgrades)
├── zookeeper -> apache-zookeeper-3.9.5-bin/  # Symlink (current version)
└── zookeeper_data/                    # Persistent data (snapshots, txnlogs, myid) — survives upgrades
    └── myid                           # Server ID file

/etc/systemd/system/zookeeper.service  # Systemd unit
/etc/logrotate.d/zookeeper             # Log rotation config
```

---

## Task Execution Flow

```
main.yml
├── validate.yml        Check version, dirs, ports, zk_id, heap/memory validation
├── create_user.yml     Create zookeeper system user/group
├── pre_install.yml     Detect current version, set upgrade facts, stop if upgrading
├── migrate_data.yml    Move data from inside version dir to persistent location (upgrade safety)
├── install.yml         Download tarball, extract, symlink, create data dir, logs dir
├── cleanup.yml         Remove old version directory and tarball (exact version targeting)
├── config.yml          Template zoo.cfg, myid, java.env, logrotate
├── service.yml         Deploy systemd unit, enable, start, conditional restart
└── verify.yml          Service active, port listening, ruok health, mode detection
```

---

## Post-Deployment Verification

1. Check service status:
   ```bash
   systemctl status zookeeper
   ```

2. Verify the node is healthy:
   ```bash
   echo ruok | nc 127.0.0.1 2181
   # Expected: imok
   ```

3. Check server mode:
   ```bash
   echo srvr | nc 127.0.0.1 2181
   # Shows: Mode: leader/follower/standalone
   ```

4. Verify ensemble connectivity:
   ```bash
   echo mntr | nc 127.0.0.1 2181 | grep zk_server_state
   # Shows: zk_server_state	leader (or follower)
   ```

5. Check metrics endpoint:
   ```bash
   curl -s http://127.0.0.1:61007/metrics | head -20
   ```

6. Verify configuration:
   ```bash
   echo conf | nc 127.0.0.1 2181
   ```

---

## Upgrade Process

1. Update `version.zookeeper` in `versions.yml` for the target environment.
2. Run the playbook — it will:
   - Detect the version mismatch
   - Stop the running service
   - **Migrate data** from inside the old version dir (`/apps/zookeeper/data`) to persistent location (`/apps/zookeeper_data`) if not already migrated
   - Download and extract the new version
   - Update the symlink
   - Clean up old version files
   - Apply configuration (zoo.cfg, java.env)
   - Start the new version
3. Verify each node is healthy (`ruok → imok`) before proceeding to the next.
4. **Rolling upgrade:** For zero-downtime, run with `--limit` targeting one node at a time. The ensemble maintains quorum while individual nodes restart.
5. **Note:** Application logs inside the version directory are NOT preserved across upgrades. This is by design — only data (snapshots + txnlogs) is persistent.

---

## Troubleshooting

### Checking Logs

```bash
# Recent logs (journald)
journalctl -u zookeeper --no-pager -n 50

# Follow logs in real time
journalctl -u zookeeper -f

# Errors only
journalctl -u zookeeper -p err

# Time range
journalctl -u zookeeper --since "2026-06-30 10:00" --until "2026-06-30 11:00"

# Application log file (inside version dir — lost on upgrade)
tail -100 /apps/zookeeper/logs/zookeeper.log

# Check for leader election issues
grep -i "election" /apps/zookeeper/logs/zookeeper.log | tail -20
```

### Common Issues

| Problem | Diagnostic | Solution |
|---------|-----------|----------|
| Service fails to start | `journalctl -u zookeeper -n 50` | Check `java.env` heap settings, verify Java installed |
| Node stuck in election | `echo srvr \| nc 127.0.0.1 2181` | Check connectivity between peer/election ports on all nodes |
| `imok` not returned | `echo ruok \| nc 127.0.0.1 2181` | Wait for leader election (up to `initLimit * tickTime` ms) |
| Too many open files | `journalctl -u zookeeper \| grep "Too many"` | Increase `zk_nofile_limit` in config_coordination.yml |
| OOM killed | `dmesg \| grep -i oom` | Increase `zk_memory_limit` and/or reduce `zk_heap_max_mb` |
| Disk full on data dir | `df -h /apps` | Auto-purge is enabled (hourly, retains 3 snapshots) — check if snapshots are actually being purged |
| Slow followers | `echo mntr \| nc 127.0.0.1 2181` | Increase `zk_sync_limit`, check network between nodes |
| Connection refused | `ss -tlnp \| grep 2181` | Verify clientPort in zoo.cfg matches inventory, check firewall |

### Service Account Access

```bash
# Switch to the zookeeper service account (from root)
su -s /bin/bash zookeeper

# Run a single command as zookeeper
su -s /bin/bash -c "/apps/zookeeper/bin/zkCli.sh -server 127.0.0.1:2181" zookeeper
```

---

## File Structure

```
roles/coordination/zookeeper/
├── defaults/
│   └── main.yml                  # All configurable variables with defaults
├── handlers/
│   └── main.yml                  # Restart handler
├── tasks/
│   ├── main.yml                  # Entrypoint — imports all task files in order
│   ├── validate.yml              # Pre-flight checks
│   ├── create_user.yml           # Service user/group creation
│   ├── pre_install.yml           # Version detection and upgrade facts
│   ├── migrate_data.yml          # Move data from version dir to persistent location
│   ├── install.yml               # Download, extract, symlink
│   ├── cleanup.yml               # Remove old version artifacts
│   ├── config.yml                # Configuration deployment
│   ├── service.yml               # Systemd management
│   └── verify.yml                # Health checks
├── templates/
│   ├── zoo.cfg.j2                # ZooKeeper main configuration
│   ├── java.env.j2               # JVM environment (heap, GC, log dir)
│   ├── zookeeper.service.j2      # Systemd unit file
│   └── logrotate.j2              # Log rotation configuration
└── README.md                     # This file
```

---

## Security Notes

- ZooKeeper runs as an unprivileged system user (`zookeeper`) with `/sbin/nologin` shell.
- Configuration files are mode `0640` (readable by service user only).
- The `myid` file is mode `0644` — it only contains the server ID integer.
- The admin server is disabled by default — monitoring uses 4-letter commands via the client port.
- No authentication is configured by default (ZooKeeper 3.9 supports SASL/Kerberos) — rely on network-level isolation.
- Download uses `validate_certs: false` due to corporate proxy MITM interception of HTTPS traffic.

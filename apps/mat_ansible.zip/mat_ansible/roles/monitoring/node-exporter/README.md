# Node Exporter Role

Installs and manages Prometheus Node Exporter on bare-metal Linux servers. Exposes hardware and OS metrics for Prometheus to scrape. Supports fresh installs, version upgrades (idempotent), and custom metrics via the textfile collector.

## Latest Version

Check for updates: https://github.com/prometheus/node_exporter/releases

Current deployed: `1.9.1` (prod FN), `1.10.2` (some environments)

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Network** | Port reachable from Prometheus server | `curl http://<host>:<port>/metrics` |
| **Proxy** | `http_proxy`/`https_proxy` for GitHub download | Defined in `all_secrets.yml` |

## What It Does

- Creates a dedicated `node-exporter` system user
- Downloads and installs Node Exporter binary from GitHub
- Configures systemd service with 37 collectors
- Supports in-place upgrades (change version in inventory → re-run playbook)
- Cleans up old versions automatically
- Verifies service is running and metrics endpoint responds

## Collectors Enabled (37)

| Category | Collectors |
|----------|-----------|
| **CPU / Load** | cpu, cpufreq, loadavg |
| **Memory** | meminfo, vmstat |
| **Disk / Filesystem** | diskstats, filesystem, mountstats |
| **Network** | netdev, netstat, netclass, arp, ethtool, sockstat, tcpstat, softnet |
| **System** | stat, uname, os, time, systemd, processes, entropy, selinux, sysctl |
| **Hardware** | hwmon, thermal_zone, edac, interrupts |
| **Storage** | bcache, btrfs, mdadm |
| **File Descriptors** | filefd, conntrack |
| **NFS** | nfs, nfsd |
| **Pressure (PSI)** | pressure — CPU/memory/IO pressure stall information |
| **Custom Metrics** | textfile — reads `.prom` files from a configurable directory |

## Upgrade Behavior

The role is idempotent and handles upgrades automatically:

1. Checks if node_exporter is already installed
2. Compares running version against target version from `versions.yml`
3. If versions match → **skips** download/install (only ensures service is running)
4. If versions differ → **stops** service, removes old version, installs new, starts service
5. Verifies new version is running and `/metrics` responds HTTP 200

To upgrade: simply change the version in `versions.yml` and re-run the playbook.

## Custom Metrics (Textfile Collector)

The textfile collector allows you to expose custom metrics without modifying node_exporter. Drop `.prom` files into the textfile directory and they'll be automatically served at `/metrics`.

**Directory:** `{{ node_exporter_base_dir }}/textfile_collector/` (default: `/apps/node_exporter/textfile_collector/`)

**Example — SSL certificate expiry:**
```bash
# /apps/node_exporter/textfile_collector/ssl_cert_expiry.prom
# HELP ssl_cert_expiry_days Days until SSL certificate expires
# TYPE ssl_cert_expiry_days gauge
ssl_cert_expiry_days{domain="app.example.com"} 45
```

**Example — Backup status:**
```bash
# /apps/node_exporter/textfile_collector/backup_status.prom
# HELP backup_last_success_timestamp Unix timestamp of last successful backup
# TYPE backup_last_success_timestamp gauge
backup_last_success_timestamp{job="daily-db-backup"} 1717286400
```

You can use cron jobs or scripts to generate these `.prom` files periodically.

## Variable Reference

### defaults/main.yml

| Variable | Default | Description |
|----------|---------|-------------|
| `node_exporter_version` | from `version.node_exporter` | Binary version to install |
| `node_exporter_base_dir` | from `paths.node_exporter.base_dir` | Installation directory (e.g., `/apps`) |
| `node_exporter_port` | from `ports.node_exporter.service` | Metrics listen port (e.g., `61088`) |
| `node_exporter_user` | `node-exporter` | System user running the service |
| `node_exporter_group` | `node-exporter` | System group |
| `node_exporter_listen_address` | `0.0.0.0` | Listen address (all interfaces) |
| `node_exporter_max_requests` | `40` | Max concurrent scrape requests |
| `node_exporter_arch` | `linux-amd64` | Binary architecture (`linux-arm64` for ARM) |
| `node_exporter_textfile_dir` | `{{ base_dir }}/textfile_collector` | Directory for custom `.prom` files |
| `node_exporter_http_proxy` | from `http_proxy` | Proxy for GitHub download |
| `node_exporter_https_proxy` | from `https_proxy` | Proxy for GitHub download |
| `node_exporter_download_timeout` | `30` | Download timeout in seconds |
| `node_exporter_memory_limit` | `512M` | Systemd `MemoryMax` — max RAM. If exceeded, process is killed and restarted. |
| `node_exporter_nofile_limit` | `1024` | Systemd `LimitNOFILE` — max open file descriptors |

### versions.yml
```yaml
version:
  node_exporter: 1.10.2
```

### paths.yml
```yaml
paths:
  node_exporter:
    base_dir: /apps
```

### networks.yml
```yaml
ports:
  node_exporter:
    service: 61088
```

## Running the Playbook

```bash
# Fresh install or upgrade
ansible-playbook -i inventories/barista/test/hosts playbook/node_exporter.yaml --vault-password-file .vault

# Target specific hosts
ansible-playbook -i inventories/barista/test/hosts playbook/node_exporter.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=exporter_hosts"
```

## How It Works

```
main.yml
├── validate.yml         # Pre-flight checks (version, port, base_dir)
├── create_user.yml      # Create node-exporter system user/group
├── pre_install.yml      # Check version, stop if upgrade needed
├── install.yml          # Download, extract, symlink, create textfile dir
├── cleanup.yml          # Remove old version (detected, no patterns)
├── service.yml          # Systemd unit, enable, start, conditional restart
└── verify.yml           # Service + port + version + metrics endpoint
```

## File Structure

```
roles/node-exporter/
├── defaults/main.yml                    # All variables with defaults
├── tasks/
│   ├── main.yml                         # Orchestrator
│   ├── validate.yml                     # Pre-flight checks (version, port, base_dir)
│   ├── create_user.yml                  # System user/group creation
│   ├── pre_install.yml                  # Version check + stop if upgrade needed
│   ├── install.yml                      # Download + extract + symlink
│   ├── cleanup.yml                      # Remove old version (detected, no patterns)
│   ├── service.yml                      # Systemd unit, enable, start, conditional restart
│   └── verify.yml                       # Service + port + version + metrics check
├── templates/
│   └── node_exporter.service.j2        # Systemd unit file with all collectors
└── README.md                            # This file
```

## Post-Deployment Verification

### 1. Check Service Status
```bash
systemctl status node_exporter
# Expected: Active: active (running)
```

### 2. Check Port is Listening
```bash
ss -tlnp | grep 61088
# Expected: LISTEN  0  128  *:61088  *:*  users:(("node_exporter",...))
```

### 3. Check Version
```bash
/apps/node_exporter/node_exporter --version
# Expected: node_exporter, version 1.9.1 (branch: HEAD, revision: ...)
```

### 4. Check Metrics Endpoint
```bash
curl -s http://localhost:61088/metrics | head -20
# Expected: Prometheus exposition format with # HELP and # TYPE lines
```

### 5. Verify Specific Metrics Are Present
```bash
# CPU metrics
curl -s http://localhost:61088/metrics | grep node_cpu_seconds_total | head -3

# Memory metrics
curl -s http://localhost:61088/metrics | grep node_memory_MemTotal_bytes

# Disk metrics
curl -s http://localhost:61088/metrics | grep node_filesystem_avail_bytes | head -3

# Network metrics
curl -s http://localhost:61088/metrics | grep node_network_receive_bytes_total | head -3
```

### 6. Check from Prometheus
```bash
# On Prometheus server — verify target is UP
curl -s http://localhost:61087/api/v1/targets | grep -A2 node_exporter
```

### 7. Check Textfile Collector Directory
```bash
ls -la /apps/node_exporter/textfile_collector/
# Should exist and be owned by node-exporter user
```

## Troubleshooting

### Checking Logs

Node Exporter does **not** write log files — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u node_exporter --no-pager -n 50

# Follow live (tail)
journalctl -u node_exporter -f

# Since last boot
journalctl -u node_exporter -b

# Errors only
journalctl -u node_exporter -p err

# Specific time range
journalctl -u node_exporter --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Service won't start
```bash
systemctl status node_exporter
journalctl -u node_exporter --no-pager -n 50
# Common: port conflict, binary permissions, missing collectors
```

### Metrics not accessible
```bash
curl http://localhost:61088/metrics | head -20
# Check: firewall, listen address, port conflict
```

### Textfile metrics not showing
- Ensure files end with `.prom` extension
- Ensure files are readable by `node-exporter` user
- Check for syntax errors: each metric line must follow Prometheus format

### Upgrade failed
- Check if old process is still running: `ps aux | grep node_exporter`
- Verify download URL is accessible through proxy
- Check disk space in base directory

### Service Account Access

The `node-exporter` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as node-exporter
su -s /bin/bash node-exporter

# Run a single command as node-exporter
su -s /bin/bash -c "whoami" node-exporter
```

# Blackbox Exporter Role

Installs and configures [Prometheus Blackbox Exporter](https://github.com/prometheus/blackbox_exporter) — probes endpoints over HTTP, HTTPS, TCP, ICMP, and DNS and exposes probe results as Prometheus metrics. Used for external endpoint monitoring (is this service reachable? is the certificate valid? what's the response time?).

---

## Latest Version

Check for updates: https://github.com/prometheus/blackbox_exporter/releases

Current deployed: `0.26.0`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (`/apps`) | `ls -la /apps` |
| **Proxy** | For GitHub download | `all_secrets.yml` |
| **ICMP** | Requires `CAP_NET_RAW` (handled by systemd) | Automatic |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/monitoring/blackbox_exporter.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.blackbox_exporter` | `0.26.0` | Exporter version |
| `paths.yml` | `paths.blackbox_exporter.base_dir` | `/apps` | Base directory |
| `networks.yml` | `ports.blackbox_exporter.service` | `9115` | Metrics/probe port |

### Optional (from config_monitoring.yml)

| Variable | Default | Description |
|----------|---------|-------------|
| `config_monitoring.blackbox_exporter.user` | `blackbox-exporter` | Service user |
| `config_monitoring.blackbox_exporter.listen_address` | `0.0.0.0` | Bind address |
| `config_monitoring.blackbox_exporter.memory_limit` | `256M` | Systemd MemoryMax |
| `config_monitoring.blackbox_exporter.nofile_limit` | `1024` | Systemd LimitNOFILE |
| `config_monitoring.blackbox_exporter.download_timeout` | `60` | Download timeout (seconds) |

---

## Probe Modules (Built-in)

| Module | Prober | Use Case |
|--------|--------|----------|
| `http_2xx` | HTTP GET | Service health check (skip TLS verify) |
| `http_2xx_tls` | HTTP GET | Service health with TLS cert validation |
| `http_post_2xx` | HTTP POST | API endpoint test |
| `tcp_connect` | TCP | Port is open and accepting connections |
| `ssh_banner` | TCP | SSH service responding |
| `icmp` | ICMP | Host is alive (ping) |
| `dns_resolution` | DNS | DNS resolver is working |

---

## Prometheus Integration

Add to your `prometheus.yml`:

```yaml
- job_name: 'blackbox-http'
  metrics_path: /probe
  params:
    module: [http_2xx]
  static_configs:
    - targets:
        - http://grafana:3000/api/health
        - http://kibana:5601/api/status
        - http://clickhouse:8123/ping
  relabel_configs:
    - source_labels: [__address__]
      target_label: __param_target
    - source_labels: [__param_target]
      target_label: instance
    - target_label: __address__
      replacement: <blackbox-host>:9115

- job_name: 'blackbox-icmp'
  metrics_path: /probe
  params:
    module: [icmp]
  static_configs:
    - targets:
        - 10.6.97.10
        - 10.6.102.110
  relabel_configs:
    - source_labels: [__address__]
      target_label: __param_target
    - source_labels: [__param_target]
      target_label: instance
    - target_label: __address__
      replacement: <blackbox-host>:9115
```

---

## What Gets Installed

```
/apps/
├── blackbox_exporter -> blackbox_exporter-0.26.0.linux-amd64/  # symlink
├── blackbox_exporter-0.26.0.linux-amd64/                        # extracted
│   ├── blackbox_exporter                                         # binary
│   ├── blackbox.yml                                              # probe config
│   ├── LICENSE
│   └── NOTICE
└── blackbox_exporter-0.26.0.linux-amd64.tar.gz                  # archive

/etc/systemd/system/blackbox_exporter.service                    # systemd unit
```

---

## Task Execution Flow

```
validate → create_user → pre_install → install → cleanup → config → service → verify
    │           │             │            │          │         │         │         │
    ├─ version  ├─ group      ├─ get ver   ├─ download├─ rm old ├─ yml    ├─ template├─ active
    ├─ base dir └─ user       ├─ set facts ├─ extract │  dir    │         ├─ daemon  ├─ port
    └─ port                   └─ stop(upg) ├─ perms   └─ rm old │         ├─ enable  ├─ /metrics
                                           └─ symlink    tar    │         └─ restart └─ status
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status blackbox_exporter

# 2. Metrics endpoint
curl http://localhost:9115/metrics | head -10

# 3. Test HTTP probe
curl "http://localhost:9115/probe?target=http://localhost:9115/metrics&module=http_2xx"

# 4. Test ICMP probe
curl "http://localhost:9115/probe?target=127.0.0.1&module=icmp"

# 5. Test TCP probe
curl "http://localhost:9115/probe?target=localhost:22&module=tcp_connect"
```

---

## Upgrade Process

1. Update `version.blackbox_exporter` in `versions.yml`
2. Re-run the playbook
3. Role will: detect mismatch → stop → download new → symlink → remove old → start → verify

---

## Troubleshooting

### Checking Logs

```bash
journalctl -u blackbox_exporter --no-pager -n 50
journalctl -u blackbox_exporter -f
```

### ICMP probes fail

```bash
# Check CAP_NET_RAW is set
getcap /apps/blackbox_exporter/blackbox_exporter
# Should show: cap_net_raw=ep (or handled via systemd AmbientCapabilities)

# Test manually
curl "http://localhost:9115/probe?target=127.0.0.1&module=icmp"
```

### Probe returns 0 (failure) but target is up

Check the probe debug output:
```bash
curl "http://localhost:9115/probe?target=<url>&module=http_2xx&debug=true"
```

---

## File Structure

```
roles/monitoring/blackbox_exporter/
├── defaults/main.yml              # All variables (config_monitoring.blackbox_exporter.*)
├── handlers/main.yml              # restart blackbox_exporter
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks
│   ├── create_user.yml            # System user (nologin)
│   ├── pre_install.yml            # Version check, conditional stop
│   ├── install.yml                # Download, extract, symlink
│   ├── cleanup.yml                # Remove old version (exact, no globs)
│   ├── config.yml                 # Deploy blackbox.yml probe config
│   ├── service.yml                # Systemd, enable, start, conditional restart
│   └── verify.yml                 # Service active, port, /metrics
├── templates/
│   ├── blackbox_exporter.service.j2  # Systemd (CAP_NET_RAW, MemoryMax, security hardening)
│   └── blackbox.yml.j2              # Probe modules (http, tcp, icmp, dns, ssh)
└── README.md                         # This file
```

---

## Security Notes

- Runs as unprivileged `blackbox-exporter` user (not root)
- `CAP_NET_RAW` granted via systemd `AmbientCapabilities` (required for ICMP only)
- `ProtectSystem=strict` + `NoNewPrivileges=yes` (systemd hardening)
- `ProtectHome=yes` — cannot access home directories
- TLS verification skipped by default in `http_2xx` module (corporate proxy MITM) — use `http_2xx_tls` for strict cert checks
- No secrets handled by this role

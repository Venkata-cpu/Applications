# Pushgateway Role

Installs and configures [Prometheus Pushgateway](https://github.com/prometheus/pushgateway) — a metrics cache that allows short-lived batch jobs to push their metrics to it, which Prometheus then scrapes on its normal schedule.

Pushgateway is useful when jobs can't expose a `/metrics` endpoint for Prometheus to scrape directly (e.g., cron jobs, one-off scripts, CI pipelines).

---

## Latest Version

Check for updates: https://github.com/prometheus/pushgateway/releases

Current deployed across environments: `1.6.2`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Network** | Pushgateway port reachable from Prometheus server | `curl http://<host>:<port>/metrics` |
| **Proxy** | `http_proxy` and `https_proxy` in vault (for GitHub download) | Defined in `all_secrets.yml` |
| **Inventory** | Version, port, and base_dir defined in inventory | See "Required Variables" below |

---

## How to Run

```bash
# Standard deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/pushgateway.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=pushgateway"

# Example: Deploy to prod fixed network
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/pushgateway.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required Variables (from inventory)

These MUST be defined — the role will fail without them.

| Source File | Variable | Example | Description |
|-------------|----------|---------|-------------|
| `versions.yml` | `version.pushgateway` | `1.6.2` | Pushgateway version to install |
| `paths.yml` | `paths.pushgateway.base_dir` | `/apps` | Directory where pushgateway is installed. Must exist (mount point). |
| `networks.yml` | `ports.pushgateway.service` | `61001` | Port the pushgateway listens on |

### Optional Variables (from app_configs.yml)

These have sensible defaults — only override if needed.

```yaml
config:
  pushgateway:
    user: pushgateway
    group: pushgateway
    log_level: warn
    listen_address: "0.0.0.0"
    enable_admin_api: false
    memory_limit: "512M"
    nofile_limit: 1024
    arch: linux-amd64
    download_timeout: 120
```

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|-----------------|
| `user` | `pushgateway` | Linux user that runs the service | Change only if you have naming conventions. User is created as a system account with no login shell. |
| `group` | `pushgateway` | Linux group for the service | Should match `user` unless you need shared group access. |
| `log_level` | `warn` | Logging verbosity: `debug`, `info`, `warn`, `error` | **debug/info:** Very verbose, fills logs quickly. Use only for troubleshooting. **warn:** Production default — only logs problems. **error:** Minimal — might miss useful context on issues. |
| `listen_address` | `0.0.0.0` | IP address to bind to | `0.0.0.0` = all interfaces (accessible from any network). Change to `127.0.0.1` if you want only local access (Prometheus must be on same host). |
| `enable_admin_api` | `false` | Enables `DELETE /api/v1/admin/wipe` endpoint | **true:** Anyone with network access can wipe all metrics. Useful in dev/test. **false:** Recommended for production — prevents accidental or malicious data deletion. |
| `memory_limit` | `512M` | Systemd `MemoryMax` — max RAM the process can use | **Increase:** If pushgateway handles many metrics (e.g. `1G`, `2G`). **Decrease:** To protect shared hosts from memory leaks. If exceeded, systemd kills and restarts the process. Accepts: `256M`, `512M`, `1G`, `2G`, etc. |
| `nofile_limit` | `1024` | Systemd `LimitNOFILE` — max open file descriptors | **Increase:** Only if you see `too many open files` errors. Pushgateway uses very few FDs. **Decrease:** Rarely needed below 1024. |
| `arch` | `linux-amd64` | Binary architecture | Change to `linux-arm64` for ARM servers. Must match your server's CPU architecture. |
| `download_timeout` | `120` | Seconds to wait for GitHub download | **Increase:** If you're behind a slow proxy. **Decrease:** If you want faster failure detection on network issues. |

---

## What Gets Installed

After a successful run:

```
/apps/
├── pushgateway -> pushgateway-1.6.2.linux-amd64/    # symlink to current version
├── pushgateway-1.6.2.linux-amd64/                   # extracted binary + files
│   ├── pushgateway                                   # the binary
│   ├── LICENSE
│   └── NOTICE
└── pushgateway-1.6.2.linux-amd64.tar.gz             # downloaded archive

/etc/systemd/system/pushgateway.service              # systemd unit
```

---

## Task Execution Flow

```
validate.yml → create_user.yml → pre_install.yml → install.yml → cleanup.yml → service.yml → verify.yml
      │               │               │                │              │              │              │
      ├─ version      ├─ group        ├─ get version   ├─ download    ├─ rm old dir  ├─ template    ├─ service active
      ├─ port         └─ user         ├─ set facts     ├─ extract     └─ rm old tar  ├─ daemon      ├─ port listening
      ├─ base_dir                     └─ stop (upg)    ├─ permissions                ├─ enable      ├─ /metrics 200
      └─ memory fmt                                    └─ symlink                    └─ restart*    └─ version check
```

*restart only if service file changed or upgrade happened

- **Idempotent:** If the target version is already installed, it skips download/extract.
- **Upgrade safe:** Detects old version from running binary before upgrade, removes only that specific version after install.
- **No downtime on re-run:** If version hasn't changed, only service.yml and verify.yml run meaningful work.
- **No pattern-based deletion:** Cleanup targets only the exact old version detected — never uses glob patterns.

---

## Post-Deployment Verification

### 1. Check Service Status

```bash
systemctl status pushgateway

# Expected:
#   Active: active (running) since ...
#   Main PID: XXXXX (/apps/pushgateway/pushgateway)
```

### 2. Check Port is Listening

```bash
ss -tlnp | grep 61001

# Expected:
# LISTEN  0  128  *:61001  *:*  users:(("pushgateway",pid=XXXXX,fd=3))
```

### 3. Check Metrics Endpoint

```bash
curl -s http://localhost:61001/metrics | head -10

# Expected: Prometheus exposition format metrics
# # HELP pushgateway_build_info ...
# # TYPE pushgateway_build_info gauge
# pushgateway_build_info{...} 1
```

### 4. Check Version

```bash
/apps/pushgateway/pushgateway --version

# Expected:
# pushgateway, version 1.6.2 (branch: HEAD, revision: ...)
```

### 5. Test Push a Metric

```bash
# Push a test metric
echo "test_deployment_check 1" | curl --data-binary @- \
  http://localhost:61001/metrics/job/ansible_test

# Verify it was received
curl -s http://localhost:61001/metrics | grep test_deployment_check

# Expected:
# test_deployment_check{instance="",job="ansible_test"} 1

# Clean up (only works if enable_admin_api: true)
curl -X DELETE http://localhost:61001/metrics/job/ansible_test
```

### 6. Check from Prometheus

On your Prometheus server, verify the pushgateway target is UP:

```bash
curl -s http://<prometheus-host>:61087/api/v1/targets | \
  python3 -c "import sys,json; [print(t['labels']['job'], t['health']) for t in json.load(sys.stdin)['data']['activeTargets'] if 'pushgateway' in t['labels'].get('job','')]"

# Expected:
# pushgateway up
```

---

## Upgrade Process

To upgrade pushgateway:

1. Update `version.pushgateway` in the relevant `versions.yml`
2. Re-run the playbook
3. The role will: detect old version → stop service → download new → extract → update symlink → remove old version → start service → verify

```bash
# Example: upgrade from 1.6.2 to 1.10.0
# Edit: inventories/mat_fixed_network/prod/group_vars/all/versions.yml
#   pushgateway: 1.10.0

ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/pushgateway.yaml \
  --vault-password-file .vault
```

---

## Troubleshooting

### Checking Logs

Pushgateway does **not** write log files — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u pushgateway --no-pager -n 50

# Follow live (tail)
journalctl -u pushgateway -f

# Errors only
journalctl -u pushgateway -p err

# Since last boot
journalctl -u pushgateway -b

# Specific time range
journalctl -u pushgateway --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Service fails to start

```bash
# Check journal
journalctl -u pushgateway --no-pager -n 30

# Common issues:
# - Port already in use: ss -tlnp | grep <port>
# - Permission denied: check binary ownership
# - Base dir missing: ls -la /apps
```

### Download fails

```bash
# Check proxy is set
echo $http_proxy $https_proxy

# Test GitHub access manually
curl -v https://github.com/prometheus/pushgateway/releases/download/v1.6.2/pushgateway-1.6.2.linux-amd64.tar.gz

# Increase timeout in config if slow network
config:
  pushgateway:
    download_timeout: 300
```

### Metrics not appearing in Prometheus

```bash
# 1. Check pushgateway is running
curl http://localhost:61001/metrics

# 2. Check Prometheus scrape config includes pushgateway target
grep -A5 pushgateway /apps/prometheus/prometheus.yml

# 3. Check Prometheus can reach pushgateway
curl http://<pushgateway-host>:61001/metrics  # from prometheus server
```

### Old versions not cleaned up

Cleanup only runs during an upgrade (when old version differs from target). If it didn't run (e.g. fresh install with no previous version), old files may remain:

```bash
# Check what's in the base directory
ls /apps/ | grep pushgateway
# Manually remove if needed
rm -rf /apps/pushgateway-<old-version>.linux-amd64
rm -f /apps/pushgateway-<old-version>.linux-amd64.tar.gz
```

---

## File Structure

```
roles/pushgateway/
├── defaults/main.yml              # All variables (from inventory + config defaults)
├── handlers/main.yml              # Restart handler
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks (version, port, base_dir, memory format)
│   ├── create_user.yml            # System user and group
│   ├── pre_install.yml            # Version check, stop if upgrade needed
│   ├── install.yml                # Download, extract, symlink
│   ├── cleanup.yml                # Remove old version (detected from pre_install, no patterns)
│   ├── service.yml                # Systemd unit, enable, start, conditional restart
│   └── verify.yml                 # Health checks (service, port, metrics, version)
├── templates/
│   └── pushgateway.service.j2     # Systemd unit template
└── README.md                       # This file
```

---

### Service Account Access

The `pushgateway` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as pushgateway
su -s /bin/bash pushgateway

# Run a single command as pushgateway
su -s /bin/bash -c "whoami" pushgateway
```

---

## Security Notes

- Service runs as unprivileged user (`pushgateway`) — not root
- Admin API disabled by default (prevents metric wipe attacks)
- Binary downloaded from official GitHub releases
- `validate_certs: false` on download (required behind corporate proxy with MITM inspection)
- No authentication on the metrics endpoint by default (rely on network-level access control / firewall)

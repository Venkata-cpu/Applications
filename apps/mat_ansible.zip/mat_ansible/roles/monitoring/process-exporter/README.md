# Process Exporter Role

Installs and manages Prometheus Process Exporter on bare-metal Linux servers. Exposes per-process CPU, memory, I/O, and thread metrics for Prometheus to scrape. Useful for monitoring specific applications (Kafka, ClickHouse, HAProxy, etc.) at the process level.

## Latest Version

Check for updates: https://github.com/ncabatoff/process-exporter/releases

Current deployed: `0.8.5` (prod), `0.8.7` (some environments)

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Network** | Port reachable from Prometheus | `curl http://<host>:<port>/metrics` |
| **Proxy** | `http_proxy`/`https_proxy` for GitHub download | Defined in `all_secrets.yml` |

## What It Does

- Creates a dedicated `process-exporter` system user
- Downloads and installs process-exporter binary from GitHub
- Deploys a process matching config (`process-exporter.yaml`)
- Configures systemd service
- Supports in-place upgrades (change version → re-run playbook)
- Cleans up old versions automatically
- Verifies service is running and metrics endpoint responds

## Metrics Exposed

Process exporter provides per-process metrics:

| Metric | Description |
|--------|-------------|
| `namedprocess_namegroup_cpu_seconds_total` | CPU time consumed (user + system) |
| `namedprocess_namegroup_memory_bytes` | Memory usage (resident, virtual) |
| `namedprocess_namegroup_read_bytes_total` | Bytes read from disk |
| `namedprocess_namegroup_write_bytes_total` | Bytes written to disk |
| `namedprocess_namegroup_num_procs` | Number of processes in group |
| `namedprocess_namegroup_num_threads` | Number of threads |
| `namedprocess_namegroup_open_filedesc` | Open file descriptors |
| `namedprocess_namegroup_states` | Process states (running, sleeping, zombie) |

## Process Matching Config

The config file `files/process-exporter.yaml` defines which processes to monitor:

```yaml
process_names:
  - name: "{{.Comm}}"
    cmdline:
      - '.+'
```

This default matches **all processes** grouped by command name. It's the safest approach for a role deployed across many different server types — covers everything without per-host configuration.

### Grouping Strategies

Process exporter supports three matching methods. Rules are evaluated top-to-bottom — first match wins:

```yaml
process_names:
  # Method 1: Match by comm (executable name)
  - name: "clickhouse"
    comm:
      - clickhouse-server

  # Method 2: Match by cmdline regex (useful for Java apps that all show as 'java')
  - name: "kafka-broker"
    cmdline:
      - 'kafka\.Kafka'

  # Method 3: Match by exe path
  - name: "haproxy"
    exe:
      - /usr/sbin/haproxy

  # Catch-all (must be last — picks up anything not explicitly matched)
  - name: "{{.Comm}}"
    cmdline:
      - '.+'
```

### Example: Targeted Config for MAT Stack

For more specific monitoring with lower cardinality:

```yaml
process_names:
  # Data Pipeline
  - name: "kafka-broker"
    cmdline: ['kafka\.Kafka']
  - name: "schema-registry"
    cmdline: ['SchemaRegistryMain']
  - name: "clickhouse-server"
    comm: ['clickhouse-server']
  - name: "clickhouse-keeper"
    comm: ['clickhouse-keeper']
  # Monitoring
  - name: "prometheus"
    comm: ['prometheus']
  - name: "grafana"
    comm: ['grafana']
  - name: "node-exporter"
    comm: ['node_exporter']
  # Load Balancing
  - name: "haproxy"
    comm: ['haproxy']
  # ELK
  - name: "elasticsearch"
    cmdline: ['elasticsearch']
  - name: "logstash"
    cmdline: ['logstash']
  # Kubernetes
  - name: "kubelet"
    comm: ['kubelet']
  - name: "containerd"
    comm: ['containerd']
  # Catch-all
  - name: "{{.Comm}}"
    cmdline: ['.+']
```

### When to Use Targeted vs Catch-All

| Approach | Pros | Cons |
|----------|------|------|
| **Catch-all** (default) | No maintenance, covers everything, works on any server | Higher cardinality in Prometheus, can't distinguish Java apps |
| **Targeted** | Lower cardinality, clear grouping, Java apps separated | Must maintain per-environment configs |

To use a targeted config, replace `files/process-exporter.yaml` with your custom version and re-run the playbook.

## Upgrade Behavior

Idempotent — same as node-exporter:

1. Checks running version against target from `versions.yml`
2. Same version → skips (only ensures service running)
3. Different version → stops, removes old, installs new, starts
4. Verifies port is listening and `/metrics` returns 200

## Variable Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `process_exporter_version` | from `version.process_exporter` | Binary version |
| `process_exporter_base_dir` | from `paths.process_exporter.base_dir` | Install directory |
| `process_exporter_port` | from `ports.process_exporter.service` | Metrics port (e.g., `61077`) |
| `process_exporter_user` | `process-exporter` | System user |
| `process_exporter_group` | `process-exporter` | System group |
| `process_exporter_listen_address` | `0.0.0.0` | Listen address |
| `process_exporter_arch` | `linux-amd64` | Binary architecture |
| `process_exporter_http_proxy` | from `http_proxy` | Download proxy |
| `process_exporter_https_proxy` | from `https_proxy` | Download proxy |
| `process_exporter_download_timeout` | `30` | Download timeout (seconds) |
| `process_exporter_memory_limit` | `512M` | Systemd `MemoryMax` — max RAM. If exceeded, process is killed and restarted. |
| `process_exporter_nofile_limit` | `1024` | Systemd `LimitNOFILE` — max open file descriptors |

### versions.yml
```yaml
version:
  process_exporter: 0.8.7
```

### paths.yml
```yaml
paths:
  process_exporter:
    base_dir: /apps
```

### networks.yml
```yaml
ports:
  process_exporter:
    service: 61077
```

## Running the Playbook

```bash
ansible-playbook -i inventories/barista/test/hosts playbook/process_exporter.yaml --vault-password-file .vault
```

## How It Works

```
main.yml
├── validate.yml         # Pre-flight checks (version, port, base_dir)
├── create_user.yml      # System user/group
├── pre_install.yml      # Version check + stop if upgrade needed
├── install.yml          # Download + extract + symlink
├── cleanup.yml          # Remove old version (detected from pre_install, no patterns)
├── config.yml           # Process matching config + systemd unit
├── service.yml          # Systemd enable, start, conditional restart
└── verify.yml           # Service + port + metrics endpoint check
```

## File Structure

```
roles/process-exporter/
├── defaults/main.yml                      # All variables
├── files/
│   └── process-exporter.yaml             # Process matching config
├── tasks/
│   ├── main.yml                           # Orchestrator
│   ├── create_user.yml                    # User/group creation
│   ├── validate.yml                           # Pre-flight checks (version, port, base_dir)
│   ├── create_user.yml                        # User/group creation
│   ├── pre_install.yml                        # Version check + stop if upgrade needed
│   ├── install.yml                            # Download + extract + symlink
│   ├── cleanup.yml                            # Remove old version (no patterns, uses detected version)
│   ├── config.yml                             # Process matching config + systemd unit
│   ├── service.yml                            # Systemd enable, start, conditional restart
│   └── verify.yml                             # Service + port + metrics check
├── templates/
│   └── process_exporter.service.j2       # Systemd unit file
└── README.md                              # This file
```

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status process_exporter

# 2. Port listening
ss -tlnp | grep <port>

# 3. Metrics endpoint
curl -s http://localhost:<port>/metrics | head -20

# 4. Check specific process is being tracked
curl -s http://localhost:<port>/metrics | grep namedprocess_namegroup_num_procs

# 5. Version check
/apps/process-exporter/process-exporter --version

# 6. Config validation
cat /apps/process-exporter/process-exporter.yaml
```

## Troubleshooting

### Checking Logs

Process Exporter does **not** write log files — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u process_exporter --no-pager -n 50

# Follow live (tail)
journalctl -u process_exporter -f

# Errors only
journalctl -u process_exporter -p err

# Since last boot
journalctl -u process_exporter -b

# Specific time range
journalctl -u process_exporter --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### No metrics for a specific process
- Check process matching config: `cat /apps/process-exporter/process-exporter.yaml`
- Verify the process is running: `ps aux | grep <name>`
- Check exporter logs: `journalctl -u process_exporter --no-pager -n 50`

### High cardinality warning
- The default `{{.Comm}}` config creates a label per unique command name
- If you have many unique process names, consider using explicit matching instead of catch-all

### Service Account Access

The `process-exporter` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as process-exporter
su -s /bin/bash process-exporter

# Run a single command as process-exporter
su -s /bin/bash -c "whoami" process-exporter
```

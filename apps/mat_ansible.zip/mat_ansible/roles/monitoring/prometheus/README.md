# Prometheus Role

Installs and configures Prometheus server and Alertmanager for monitoring the MAT data pipeline infrastructure. Handles fresh installs, version upgrades, config and alert rule deployment, email alerting with priority-based routing, and optional webhook integration.

## Latest Versions

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Prometheus** | https://github.com/prometheus/prometheus/releases | 3.5.0 |
| **Alertmanager** | https://github.com/prometheus/alertmanager/releases | 0.27.0 / 0.28.1 |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must already exist (mount point: `/apps`) | `ls -la /apps` |
| **Network** | Prometheus port reachable from Grafana and all exporters | `curl http://<host>:<port>/-/healthy` |
| **Proxy** | `http_proxy`/`https_proxy` for GitHub download | Defined in `all_secrets.yml` |
| **Config templates** | `prometheus.yml.j2` in inventory configs | `ls inventories/<mod>/<env>/configs/prometheus/` |
| **Alert rules** | Optional: `alert_rules/` directory in inventory configs | Skipped if not present |
| **SMTP** | SMTP relay reachable for alert emails | `telnet smtpb.intra.bt.com 25` |

---

## How to Run

```bash
# Full deployment (install + config + service)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/prometheus.yaml \
  --vault-password-file .vault

# Target specific host
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/prometheus.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=prometheus"
```

---

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.prometheus` | `3.5.0` | Prometheus binary version |
| `versions.yml` | `version.alert_manager` | `0.27.0` | Alertmanager binary version |
| `paths.yml` | `paths.prometheus.base_dir` | `/apps` | Install directory (must exist) |
| `networks.yml` | `ports.prometheus.service` | `61087` | Prometheus listen port |
| `networks.yml` | `ports.alert_manager.service` | `61090` | Alertmanager listen port |
| `app_configs.yml` | `config.prometheus.retention` | `30d` | TSDB data retention period |
| `app_configs.yml` | `config.alert_manager.toMail` | `["team@bt.com"]` | Alert email TO recipients |
| `app_configs.yml` | `config.alert_manager.ccMail` | `["mgr@bt.com"]` | Alert email CC recipients |
| `app_configs.yml` | `config.alert_manager.fromMail` | `alerts@mat.bt.com` | Alert email sender |
| `app_configs.yml` | `config.alert_manager.smtpHost` | `smtpb.intra.bt.com:25` | SMTP relay host:port |
| `app_configs.yml` | `config.alert_manager.group_wait` | `30s` | Wait before first notification |
| `app_configs.yml` | `config.alert_manager.p1_repeat_interval` | `2h` | P1 alert repeat interval |
| `app_configs.yml` | `config.alert_manager.p2_repeat_interval` | `6h` | P2 alert repeat interval |
| `app_configs.yml` | `config.alert_manager.p3_repeat_interval` | `24h` | P3 alert repeat interval |
| `app_configs.yml` | `config.alert_manager.resolve_timeout` | `5m` | Time to wait before marking resolved |

### Optional Variables (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.prometheus.data_dir` | `/apps/prometheus_data` | TSDB storage path (persists across upgrades) | Use a dedicated data partition for large environments |
| `config.prometheus.user` | `prometheus` | Service account | Change only for naming conventions |
| `config.prometheus.group` | `prometheus` | Service group | Change only for naming conventions |
| `config.prometheus.listen_address` | `0.0.0.0` | Bind address | `127.0.0.1` for local-only access |
| `config.prometheus.arch` | `linux-amd64` | Binary architecture | `linux-arm64` for ARM servers |
| `config.prometheus.download_timeout` | `120` | Download timeout in seconds | **Increase:** For slow proxies. **Decrease:** Faster failure detection. |
| `config.prometheus.memory_limit` | `4G` | Systemd `MemoryMax` for Prometheus | **Increase:** For large environments with many targets/series (e.g. `8G`, `16G`). **Decrease:** To protect shared hosts. If exceeded, systemd kills and restarts. |
| `config.prometheus.nofile_limit` | `65536` | Systemd `LimitNOFILE` for Prometheus | **Increase:** If you see `too many open files` errors (e.g. `200000`). Each scrape target and TSDB chunk uses a file descriptor. **Decrease:** Rarely needed. |
| `config.alert_manager.memory_limit` | `1G` | Systemd `MemoryMax` for Alertmanager | **Increase:** If handling many alerts (e.g. `2G`). **Decrease:** Alertmanager is lightweight, `512M` often sufficient. |
| `config.prometheus.nameservers` | `[]` (skip) | DNS servers to add to resolv.conf | Empty list = DNS task skipped entirely |

### Webhook Configuration (optional)

```yaml
config:
  alert_manager:
    webhook:
      enabled: true
      url: "http://10.6.102.112:61061/webhook"
      priorities: ["P1", "P2"]
      send_resolved: true
```

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `webhook.enabled` | `false` | Enable/disable webhook | `false` = no webhook rendered. Validation fails if `true` but `url` not set. |
| `webhook.url` | (none — required if enabled) | Webhook receiver URL | Must be defined when `enabled: true` or validation fails |
| `webhook.priorities` | `["P1"]` | Which priorities trigger webhook | `["P1"]` = critical only. `["P1","P2"]` = critical + major. `["P1","P2","P3"]` = all. |
| `webhook.send_resolved` | `true` | Send resolved notifications | `false` = fire-only, no recovery notification |

### Alert Priority Explanation

| Priority | Label | Default Repeat | Severity | Use For |
|----------|-------|----------------|----------|---------|
| **P1** | `priority: "P1"` | 2h | Critical | Service down, data loss risk, immediate action |
| **P2** | `priority: "P2"` | 6h | Major | Degraded performance, approaching thresholds |
| **P3** | `priority: "P3"` | 24h | Information | Non-urgent, awareness only |

**Impact of repeat interval changes:**
- **Decrease:** More frequent emails, faster re-notification, risk of alert fatigue
- **Increase:** Fewer emails, less noise, but slower awareness of persistent issues

---

## What Gets Installed

```
/apps/
├── prometheus -> prometheus-3.5.0.linux-amd64/     # symlink (current version)
├── prometheus-3.5.0.linux-amd64/                   # binary directory
│   ├── prometheus                                   # server binary
│   ├── promtool                                     # config validation tool
│   ├── prometheus.yml                               # deployed config
│   └── alert_rules/                                 # alert rule files (if present in inventory)
├── prometheus_data/                                 # TSDB data (PERSISTS across upgrades)
│   ├── chunks_head/
│   ├── wal/
│   └── ...
├── alertmanager -> alertmanager-0.27.0.linux-amd64/ # symlink
└── alertmanager-0.27.0.linux-amd64/
    ├── alertmanager                                  # binary
    ├── amtool                                        # CLI tool
    ├── alertmanager.yml                             # deployed config
    └── data/                                         # alertmanager state/silences

/etc/systemd/system/prometheus.service               # LimitNOFILE=900000, lifecycle enabled
/etc/systemd/system/alertmanager.service
```

### Key Design: Persistent Data Directory

TSDB data lives at `{{ prometheus_data_dir }}` (default: `/apps/prometheus_data/`) — **outside** the version-specific directory. On upgrade, the binary directory is replaced but data stays untouched. No data migration needed.

### Cleanup Safety

Cleanup uses version-based targeted deletion — detects the old version from the running binary **before** upgrading, then removes only that specific directory and tarball. No glob patterns are used, so nothing unexpected gets deleted. The TSDB data directory is never touched.

---

## Task Execution Flow

```
main.yml
│
├── create_user.yml                    # Common user/group
│
├── install_prometheus.yml             # Prometheus wrapper
│   ├── prometheus/validate.yml        # Check version, port, base_dir, retention
│   ├── prometheus/pre_install.yml     # Get current version, stop if upgrade needed
│   ├── prometheus/install.yml         # Download → extract → symlink → data dir
│   ├── prometheus/cleanup.yml         # Remove old version (detected, no patterns)
│   ├── prometheus/config.yml          # prometheus.yml + alert_rules (if exists)
│   ├── prometheus/service.yml         # Systemd unit → enable → start
│   └── prometheus/verify.yml          # Service + port + health + config validation
│
├── install_alertmanager.yml           # Alertmanager wrapper
│   ├── alertmanager/validate.yml      # Check version, port, email, smtp, webhook
│   ├── alertmanager/pre_install.yml   # Get current version, stop if upgrade needed
│   ├── alertmanager/install.yml       # Download → extract → symlink
│   ├── alertmanager/cleanup.yml       # Remove old version (detected, no patterns)
│   ├── alertmanager/config.yml        # alertmanager.yml template
│   ├── alertmanager/service.yml       # Systemd unit → enable → start
│   └── alertmanager/verify.yml        # Service + port + health
│
└── config_dns.yml                     # Optional nameservers (if configured)
```

**Note:** Cleanup uses version-based targeted deletion (detects old version from running binary before upgrade). No glob patterns — only the exact previous version is removed.

---

## Post-Deployment Verification

### Prometheus

```bash
# 1. Service status
systemctl status prometheus

# 2. Port listening
ss -tlnp | grep 61087

# 3. Health endpoint
curl -s http://localhost:61087/-/healthy
# Expected: Prometheus Server is Healthy.

# 4. Config validation
/apps/prometheus/promtool check config /apps/prometheus/prometheus.yml
# Expected: SUCCESS: ... is valid prometheus config file

# 5. Check targets
curl -s http://localhost:61087/api/v1/targets | python3 -c "
import sys, json
data = json.load(sys.stdin)
for t in data['data']['activeTargets']:
    print(f\"{t['labels']['job']:30s} {t['health']}\")" | head -20

# 6. Check TSDB
du -sh /apps/prometheus_data/
```

### Alertmanager

```bash
# 1. Service status
systemctl status alertmanager

# 2. Port listening
ss -tlnp | grep 61090

# 3. Health endpoint
curl -s http://localhost:61090/-/healthy
# Expected: OK

# 4. Check active alerts
curl -s http://localhost:61090/api/v2/alerts | python3 -c "
import sys, json
alerts = json.load(sys.stdin)
print(f'Active alerts: {len(alerts)}')"

# 5. Test email (manual)
# Create a test alert via Prometheus alert rule, or use amtool:
/apps/alertmanager/amtool alert add test_alert severity=critical env=test \
  --alertmanager.url=http://localhost:61090
```

---

## Upgrade Process

1. Update versions in `versions.yml`:
   ```yaml
   version:
     prometheus: 3.6.0
     alert_manager: 0.28.1
   ```
2. Re-run playbook:
   - Validation runs first (fails fast if config is wrong)
   - Detects old version from running binary
   - Stops service → downloads new → extracts → updates symlink → starts
   - Removes only the specific old version directory and tarball (no patterns)
   - Data directory untouched
   - Health verified after restart

---

## Troubleshooting

### Checking Logs

Prometheus and AlertManager do **not** write log files — all output goes to systemd journal:

```bash
# Prometheus — recent logs (last 50 lines)
journalctl -u prometheus --no-pager -n 50

# Prometheus — follow live
journalctl -u prometheus -f

# Prometheus — errors only
journalctl -u prometheus -p err

# AlertManager — recent logs
journalctl -u alertmanager --no-pager -n 50

# AlertManager — follow live
journalctl -u alertmanager -f

# AlertManager — errors only
journalctl -u alertmanager -p err

# Specific time range (either service)
journalctl -u prometheus --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Prometheus won't start
```bash
journalctl -u prometheus --no-pager -n 30
/apps/prometheus/promtool check config /apps/prometheus/prometheus.yml
# Common: config syntax error, port in use, permission denied on data dir
```

### Alert emails not sending
```bash
journalctl -u alertmanager --no-pager -n 30 | grep -i "email\|smtp\|error"
# Test SMTP:
echo "test" | mail -S smtp=smtpb.intra.bt.com:25 -r alerts@mat.bt.com test@bt.com
```

### Targets showing as DOWN
```bash
curl -s http://localhost:61087/api/v1/targets | python3 -c "
import sys, json
for t in json.load(sys.stdin)['data']['activeTargets']:
    if t['health'] != 'up':
        print(f\"{t['labels']['job']} -> {t['lastError']}\")"
```

### Webhook not firing
```bash
# Verify webhook is in alertmanager config
curl -s http://localhost:61090/api/v2/status | grep webhook
# If missing: check config.alert_manager.webhook.enabled = true and url is set
```

### TSDB disk full
```bash
du -sh /apps/prometheus_data/
# Reduce retention: config.prometheus.retention: "15d"
# Re-run playbook to apply
```

### Validation fails on missing webhook URL
```
FAILED: config.alert_manager.webhook.url must be defined when webhook.enabled is true.
```
Fix: Either set `webhook.url` in app_configs.yml, or set `webhook.enabled: false`.

---

## File Structure

```
roles/prometheus/
├── defaults/main.yml                              # All variables
├── handlers/main.yml                              # restart prometheus / restart alertmanager
├── tasks/
│   ├── main.yml                                   # Orchestrator
│   ├── create_user.yml                            # Common user/group
│   ├── config_dns.yml                             # Optional DNS nameservers
│   ├── install_prometheus.yml                     # Prometheus wrapper (validate → install → config → service → verify)
│   ├── install_alertmanager.yml                   # Alertmanager wrapper (validate → install → config → service → verify)
│   ├── prometheus/
│   │   ├── validate.yml                           # Pre-flight checks (version, port, retention)
│   │   ├── pre_install.yml                        # Get current version, stop if upgrade needed
│   │   ├── install.yml                            # Download + extract + symlink + data dir
│   │   ├── cleanup.yml                            # Remove old version (detected, no patterns)
│   │   ├── config.yml                             # prometheus.yml + alert_rules (optional)
│   │   ├── service.yml                            # Systemd + enable + start
│   │   └── verify.yml                             # Health checks
│   └── alertmanager/
│       ├── validate.yml                           # Pre-flight checks (version, port, email, webhook)
│       ├── pre_install.yml                        # Get current version, stop if upgrade needed
│       ├── install.yml                            # Download + extract + symlink
│       ├── cleanup.yml                            # Remove old version (detected, no patterns)
│       ├── config.yml                             # alertmanager.yml template
│       ├── service.yml                            # Systemd + enable + start
│       └── verify.yml                             # Health checks
├── templates/
│   ├── alertmanager.yml.j2                        # Alertmanager routing + email + conditional webhook
│   └── service/
│       ├── prometheus.service.j2                  # Prometheus systemd unit (LimitNOFILE=900000)
│       └── alertmanager.service.j2                # Alertmanager systemd unit
└── README.md                                       # This file
```

---

### Service Account Access

The `prometheus` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as prometheus
su -s /bin/bash prometheus

# Run a single command as prometheus
su -s /bin/bash -c "whoami" prometheus
```

---

## Security Notes

- Services run as unprivileged `prometheus` user — not root
- `--web.enable-lifecycle` enabled (allows hot config reload via `POST /-/reload`)
- SMTP uses `insecure_skip_verify: true` for TLS (corporate relay with self-signed cert)
- Download uses `validate_certs: false` (required behind corporate MITM proxy)
- Old versions are removed via version-based targeting (no patterns) — only the exact detected old version gets deleted
- TSDB data directory is never touched by cleanup
- Webhook URL must be explicitly configured — no auto-derivation that could expose unintended endpoints

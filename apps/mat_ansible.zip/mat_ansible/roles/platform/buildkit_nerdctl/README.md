# BuildKit + nerdctl Role (Root Mode)

Installs [BuildKit](https://github.com/moby/buildkit) and [nerdctl](https://github.com/containerd/nerdctl) as standalone binaries in root mode. Requires containerd to be pre-installed on the target server.

## What This Does

1. **Validates** containerd is installed and running
2. **Installs BuildKit** — downloads, extracts, deploys `buildctl` + `buildkitd`, creates systemd service
3. **Installs nerdctl** — downloads and places the standalone CLI binary
4. **Configures sudoers** — adds `/usr/local/bin` to `secure_path`
5. **Verifies** all components are running

## Versions

| Component | Default | Source |
|-----------|---------|--------|
| BuildKit | `0.30.0` | `version.buildkit` |
| nerdctl | `1.7.7` | `version.nerdctl_standalone` |

## Prerequisites

- containerd must be installed and running (`systemctl status containerd`)
- `/apps` directory must exist (or override `paths.buildkit_nerdctl.base_dir`)
- Network proxy access for GitHub downloads

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/buildkit_nerdctl.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=<host_group>"
```

## Variable Reference

### Versions (from `versions.yml`)

| Variable | Default | Description |
|----------|---------|-------------|
| `version.buildkit` | `0.30.0` | BuildKit version |
| `version.nerdctl_standalone` | `1.7.7` | nerdctl standalone version |

### Paths (from `paths.yml`)

| Variable | Default | Description |
|----------|---------|-------------|
| `paths.buildkit_nerdctl.base_dir` | `/apps` | Base directory for downloads |

### Config (from `config_platform.yml`)

| Variable | Default | Description |
|----------|---------|-------------|
| `config_platform.buildkit_nerdctl.arch` | `linux-amd64` | Binary architecture |
| `config_platform.buildkit_nerdctl.download_timeout` | `120` | Download timeout (seconds) |
| `config_platform.buildkit_nerdctl.secure_path` | (see defaults) | Sudoers secure_path value |

## Task Execution Flow

```
main.yml
├── validate.yml         # Confirm containerd is present
├── install_buildkit.yml # Download + install buildkit, systemd service
├── install_nerdctl.yml  # Download + install nerdctl binary
├── config.yml           # sudoers secure_path
└── verify.yml           # Confirm all components are running
```

## Files Deployed

```
/usr/local/bin/buildctl        # BuildKit client CLI
/usr/local/bin/buildkitd       # BuildKit daemon
/usr/local/bin/nerdctl         # Container CLI (Docker-compatible)
/etc/buildkit/buildkitd.toml   # BuildKit config
/etc/systemd/system/buildkit.service  # Systemd unit
```

## Differences from `containerd_nerdctl` Role

| Feature | This role (`buildkit_nerdctl`) | `containerd_nerdctl` |
|---------|-------------------------------|---------------------|
| Mode | Root (systemd) | Rootless (user systemd) |
| containerd | Must be pre-installed | Included in nerdctl-full |
| BuildKit | Standalone download | Included in nerdctl-full |
| Target user | root | gitlab-runner |
| Use case | Servers with existing containerd | Fresh CI runners |

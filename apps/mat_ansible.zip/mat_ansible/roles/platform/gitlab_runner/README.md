# GitLab Runner Role

Installs and configures a GitLab Runner as a shell executor for CI/CD pipeline job execution. Supports automated registration of new runners via environment variables — no manual steps needed. Multiple runners can be registered on a single host, each with its own tags and concurrency limit.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **GitLab Runner** | https://gitlab.com/gitlab-org/gitlab-runner/-/releases | `19.0.1` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | `/apps` must exist | `ls /apps` |
| **Network** | Access to GitLab server + S3 for binary download | `curl -I https://gitlab.prod.ec.devops.nat.bt.com/` |
| **Runner token** | Generated from GitLab UI (for registration) | GitLab → Settings → CI/CD → Runners → New Runner |

---

## How to Run

### Full Install + Register (new server)

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/gitlab_runner.yaml \
  --vault-password-file .vault \
  -e "runner_token=glrt-xxxxx" \
  -e "runner_tags=MAT-Ansible-DRZ2"
```

Or via CI variables: `RUNNER_ACTION=INSTALL`, `RUNNER_TOKEN=glrt-xxx`, `RUNNER_TAGS=MAT-Ansible-DRZ2`

### Install Only (no registration)

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/gitlab_runner.yaml \
  --vault-password-file .vault
```

Or via CI: `RUNNER_ACTION=INSTALL` (no token/tags)

### Register Only (runner already installed, add another runner)

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/gitlab_runner.yaml \
  --vault-password-file .vault \
  -e "runner_token=glrt-yyyyy" \
  -e "runner_tags=MAT-Prim-EERAN"
```

Or via CI: `RUNNER_ACTION=REGISTER`, `RUNNER_TOKEN=glrt-yyy`, `RUNNER_TAGS=MAT-Prim-EERAN`

### CI/CD (GitLab)

- **APP_GROUP:** `platform`
- **APP:** `gitlab_runner`
- **RUNNER_ACTION:** `INSTALL` (default) or `REGISTER`
- **RUNNER_TOKEN:** Runner authentication token from GitLab UI
- **RUNNER_TAGS:** Comma-separated tags (also used as runner description)

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.gitlab_runner` | `19.0.1` | Runner binary version |
| `paths.yml` | `paths.gitlab_runner.base_dir` | `/apps` | Install base directory |

### Environment Variables (passed at runtime)

| Variable | Required | Example | Description |
|----------|----------|---------|-------------|
| `RUNNER_ACTION` | No | `INSTALL` / `REGISTER` | Controls behaviour (default: `INSTALL`) |
| `RUNNER_TOKEN` | For registration | `glrt-xxxxx` | Token from GitLab UI (New Runner) |
| `RUNNER_TAGS` | For registration | `MAT-Ansible-DRZ2` | Tags + description for the runner |

### Optional (with defaults in `config_platform.gitlab_runner.*`)

| Variable | Default | Description |
|----------|---------|-------------|
| `concurrent` | `5` | Max parallel jobs across ALL runners on this host |
| `user` | `gitlab-runner` | Service account user |
| `shell` | `/bin/bash` | Shell for job execution |
| `executor` | `shell` | Executor type |
| `url` | `https://gitlab.prod.ec.devops.nat.bt.com/` | GitLab server URL |
| `builds_dir` | `/apps/gitlab-runner/build` | Job workspace directory |
| `check_interval` | `0` | Job check interval (0 = default 3s) |
| `connection_max_age` | `15m0s` | Max connection age to GitLab |
| `session_timeout` | `1800` | Interactive session timeout |
| `git_ssl_no_verify` | `true` | Skip SSL verification for git operations |
| `download_timeout` | `120` | Binary download timeout (seconds) |

---

## Concurrency Model

```toml
# /etc/gitlab-runner/config.toml

concurrent = 5          # Global: up to 5 jobs total on this host

[[runners]]
  name = "MAT-Ansible-DRZ2"
  limit = 1             # Per-runner: max 1 job at a time
  environment = ["GIT_SSL_NO_VERIFY=true"]
  ...

[[runners]]
  name = "MAT-Prim-EERAN"
  limit = 1             # Per-runner: max 1 job at a time
  environment = ["GIT_SSL_NO_VERIFY=true"]
  ...
```

- `concurrent = 5` → the host can run up to 5 jobs simultaneously (across all registered runners)
- `limit = 1` per runner → each runner picks at most 1 job at a time
- If you have 5 runners registered, all 5 can run in parallel (one job each)

---

## What Gets Installed

```
/usr/local/bin/gitlab-runner           # Binary
/etc/gitlab-runner/config.toml         # Configuration (global + per-runner sections)
/etc/systemd/system/gitlab-runner.service  # Systemd unit
/apps/gitlab-runner/build/             # Job workspace (builds_dir)
/home/gitlab-runner/                   # Service account home
```

---

## Task Execution Flow

```
main.yml (routes by RUNNER_ACTION)
│
├── INSTALL:
│   ├── validate.yml        # Version defined, base dir exists, user exists
│   ├── create_user.yml     # gitlab-runner system user
│   ├── install.yml         # Download binary, set permissions
│   ├── config.yml          # Deploy config.toml skeleton (only if not exists)
│   ├── service.yml         # Install + start systemd service
│   ├── register.yml        # Register if RUNNER_TOKEN + RUNNER_TAGS provided
│   └── verify.yml          # Service active, binary version
│
├── REGISTER:
│   ├── register.yml        # Register only (fails if token/tags missing)
│   └── verify.yml          # Service active
```

---

## Post-Deployment Verification

```bash
# Service status
systemctl status gitlab-runner

# List registered runners
gitlab-runner list

# Verify runner connects to GitLab
gitlab-runner verify

# Check config
cat /etc/gitlab-runner/config.toml

# Test a job manually
gitlab-runner run-single --url https://gitlab.prod.ec.devops.nat.bt.com/ --token <token> --executor shell
```

---

## Troubleshooting

### Checking Logs

```bash
journalctl -u gitlab-runner --no-pager -n 50
journalctl -u gitlab-runner -f
journalctl -u gitlab-runner -p err
```

### Runner registered but not picking up jobs

```bash
# Check runner is online in GitLab UI
# Settings → CI/CD → Runners — should show green dot

# Verify tags match the job requirements
gitlab-runner list

# Check connectivity
gitlab-runner verify --delete
```

### Registration fails

```bash
# Token expired or already used (GitLab 16+ tokens are single-use per runner)
# Generate a new token from GitLab UI

# SSL errors
GIT_SSL_NO_VERIFY=true gitlab-runner register --non-interactive ...
```

### Service Account Access

```bash
su -s /bin/bash gitlab-runner
su -s /bin/bash -c "gitlab-runner list" gitlab-runner
```

---

## File Structure

```
roles/platform/gitlab_runner/
├── defaults/main.yml          # All variables
├── tasks/
│   ├── main.yml               # Action router (INSTALL/REGISTER)
│   ├── validate.yml           # Pre-flight checks
│   ├── create_user.yml        # Service account
│   ├── install.yml            # Binary download
│   ├── config.yml             # config.toml skeleton (preserves existing)
│   ├── service.yml            # Systemd install + start
│   ├── register.yml           # Runner registration + limit + GIT_SSL_NO_VERIFY
│   └── verify.yml             # Health checks
├── templates/
│   └── config.toml.j2         # Global config skeleton
└── README.md
```

---

## Security Notes

- Runner binary downloaded from GitLab S3 (validate_certs: false due to corporate proxy)
- `config.toml` mode `0600` (contains runner tokens)
- `no_log: true` on registration task (token not exposed in logs)
- `GIT_SSL_NO_VERIFY=true` set per-runner via environment (required for BT internal GitLab with proxy-intercepted certs)
- Service runs as `gitlab-runner` user (non-root), but jobs execute with this user's permissions
- Builds directory on `/apps` (not `/home`) to avoid filling small partitions

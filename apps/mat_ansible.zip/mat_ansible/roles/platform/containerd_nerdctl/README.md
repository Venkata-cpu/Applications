# containerd + nerdctl Role (Rootless)

Installs [nerdctl](https://github.com/containerd/nerdctl) — a Docker-compatible CLI for containerd — with rootless BuildKit for building and pushing container images without a Docker daemon. No root/daemon needed for image builds.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **nerdctl (full)** | https://github.com/containerd/nerdctl/releases | `2.1.2` |

The `nerdctl-full` package includes: nerdctl, containerd, BuildKit, runc, CNI plugins, RootlessKit, slirp4netns.

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | `/apps` must exist | `ls -la /apps` |
| **User** | `gitlab-runner` must exist | `id gitlab-runner` |
| **Proxy** | For downloading from GitHub | `all_secrets.yml` |
| **Kernel** | 4.18+ (for user namespaces) | `uname -r` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/containerd_nerdctl.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.nerdctl` | `2.1.2` | nerdctl version |
| `paths.yml` | `paths.nerdctl.base_dir` | `/apps` | Base directory |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `config.nerdctl.user` | `gitlab-runner` | User who runs builds (rootless) |
| `config.nerdctl.data_root` | `/apps/containerd` | containerd data |
| `config.nerdctl.buildkit_root` | `/apps/buildkit` | BuildKit data |
| `config.nerdctl.package_type` | `full` | `full` (all deps) or `nerdctl` (CLI only) |
| `config.nerdctl.arch` | `linux-amd64` | Binary architecture |
| `config.nerdctl.download_timeout` | `120` | Download timeout |
| `config.nerdctl.prune.enabled` | `true` | Enable image prune cron |
| `config.nerdctl.prune.schedule` | `6 0 * * *` | Prune cron schedule |

---

## What Gets Installed

```
/usr/local/bin/
├── nerdctl             # Docker-compatible CLI
├── containerd          # Container runtime
├── buildkitd           # Image build daemon
├── runc                # Container executor
├── containerd-rootless-setuptool.sh  # Rootless setup
└── rootlesskit         # User namespace helper

/apps/containerd/       # Container data (rootless, per-user)
/apps/buildkit/         # Build cache

Rootless services (per-user systemd):
├── containerd.service  # ~/.config/systemd/user/
└── buildkit.service    # ~/.config/systemd/user/
```

---

## Usage (as gitlab-runner)

```bash
# Login to Harbor
nerdctl login harbor.bt.com -u 'robot$ci-push' -p '<token>'

# Build image
nerdctl build -t harbor.bt.com/mat/myapp:v1.0 .

# Push to Harbor
nerdctl push harbor.bt.com/mat/myapp:v1.0

# Pull
nerdctl pull harbor.bt.com/mat/myapp:v1.0

# List local images
nerdctl images

# Run container
nerdctl run --rm harbor.bt.com/mat/myapp:v1.0
```

### In GitLab CI pipeline (.gitlab-ci.yml)

```yaml
build:
  stage: build
  script:
    - nerdctl build -t $HARBOR_URL/$PROJECT/$IMAGE:$CI_COMMIT_SHORT_SHA .
    - nerdctl push $HARBOR_URL/$PROJECT/$IMAGE:$CI_COMMIT_SHORT_SHA
  tags:
    - MAT-Ansible-TEST
```

---

## Docker vs nerdctl Command Comparison

| Docker | nerdctl | Notes |
|--------|---------|-------|
| `docker build` | `nerdctl build` | Identical Dockerfile support |
| `docker push` | `nerdctl push` | Same registry protocol |
| `docker pull` | `nerdctl pull` | Same |
| `docker run` | `nerdctl run` | Same flags |
| `docker login` | `nerdctl login` | Same |
| `docker images` | `nerdctl images` | Same |
| `docker image prune` | `nerdctl image prune` | Same |

---

## Task Execution Flow

```
main.yml
├── validate.yml   # Version, base dir, user exists
├── install.yml    # System packages, download nerdctl-full, extract, PATH
├── config.yml     # Rootless containerd + buildkit setup, proxy, prune cron
└── verify.yml     # Version checks, rootless status
```

---

## Troubleshooting

### Checking Logs

```bash
# Rootless containerd (as gitlab-runner)
su - gitlab-runner -c 'journalctl --user -u containerd --no-pager -n 50'

# Rootless buildkit
su - gitlab-runner -c 'journalctl --user -u buildkit --no-pager -n 50'
```

### nerdctl build fails
```bash
# Check buildkit is running
su - gitlab-runner -c 'systemctl --user status buildkit'

# Restart if needed
su - gitlab-runner -c 'systemctl --user restart buildkit'
```

### Permission denied
```bash
# Check user namespaces enabled
sysctl user.max_user_namespaces
# Should be > 0 (default 15000 on OEL 8+)
```

### Push fails with TLS error
```bash
# Skip TLS verification for self-signed Harbor
mkdir -p ~/.config/containerd/certs.d/harbor.bt.com
cat > ~/.config/containerd/certs.d/harbor.bt.com/hosts.toml <<EOF
server = "https://harbor.bt.com"
[host."https://harbor.bt.com"]
  skip_verify = true
EOF
```

---

## Upgrade Process

1. Update `version.nerdctl` in `versions.yml`
2. Re-run playbook — downloads new version, extracts over existing

---

## Security Notes

- Runs entirely rootless — no daemon with root privileges
- User namespaces provide container isolation
- No Docker socket to exploit
- BuildKit cache under user's home — no shared state
- Proxy set in user's `.bashrc` (not system-wide)

---

## File Structure

```
roles/platform/containerd_nerdctl/
├── defaults/main.yml     # Variables
├── tasks/
│   ├── main.yml          # Orchestrator
│   ├── validate.yml      # Pre-flight
│   ├── install.yml       # Download + extract + system packages
│   ├── config.yml        # Rootless setup, proxy, prune cron
│   └── verify.yml        # Version + status checks
└── README.md             # This file
```

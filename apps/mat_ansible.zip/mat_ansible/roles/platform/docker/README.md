# Docker CE Role

Installs [Docker CE](https://docs.docker.com/engine/) for building and pushing container images in CI/CD pipelines. Configures custom data paths (off `/var`), proxy for image pulls, and automatic image pruning.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Docker CE** | https://docs.docker.com/engine/release-notes/ | Latest from Docker CE repo |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | `/apps` must exist with space | `df -h /apps` |
| **Proxy** | For Docker CE repo + image pulls | `all_secrets.yml` |
| **User** | `gitlab-runner` (or configured user) must exist | `id gitlab-runner` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/docker.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Optional (all have defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `config.docker.data_root` | `/apps/docker` | Docker image/container storage |
| `config.docker.containerd_root` | `/apps/containerd` | containerd root |
| `config.docker.containerd_state` | `/apps/containerd/state` | containerd state |
| `config.docker.scripts_dir` | `/apps/script` | Script directory |
| `config.docker.group_user` | `gitlab-runner` | User added to docker group |
| `config.docker.prune.enabled` | `true` | Enable daily image prune |
| `config.docker.prune.schedule` | `6 0 * * *` | Prune cron schedule (daily 00:06) |
| `config.docker.prune.log` | `/apps/script/docker-prune.log` | Prune log file |

---

## What Gets Installed

```
Docker CE (docker-ce package)
├── /usr/bin/dockerd                           # Docker daemon
├── /apps/docker/                              # Image + container storage (data-root)
├── /apps/containerd/                          # containerd root
├── /apps/containerd/state/                    # containerd state
├── /etc/systemd/system/docker.service.d/
│   └── proxy.conf                             # HTTP/HTTPS proxy for daemon
└── /apps/script/docker-prune.log              # Prune cron output

Cron: daily prune of unused images
User: gitlab-runner added to docker group
```

---

## Task Execution Flow

```
main.yml
├── validate.yml   # Data root parent exists, user exists
├── install.yml    # Prereqs, Docker CE repo, install, create dirs
├── config.yml     # data-root, containerd paths, proxy, user group, prune cron
├── service.yml    # daemon-reload, enable, start, conditional restart
└── verify.yml     # Service active, version, data-root, user access
```

---

## Post-Deployment Verification

```bash
# 1. Service
systemctl status docker

# 2. Data root
docker info | grep "Docker Root Dir"
# Expected: /apps/docker

# 3. Run as gitlab-runner
su - gitlab-runner -c 'docker ps'

# 4. Pull test
docker pull hello-world
docker run --rm hello-world

# 5. Prune cron
crontab -l | grep docker-prune
```

---

## Troubleshooting

### Checking Logs

```bash
# Docker daemon logs
journalctl -u docker --no-pager -n 50

# Follow live
journalctl -u docker -f

# containerd logs
journalctl -u containerd --no-pager -n 50
```

### Permission denied for gitlab-runner
The user needs to re-login after being added to docker group:
```bash
# Verify group membership
id gitlab-runner | grep docker
# If present but still fails, restart gitlab-runner service
systemctl restart gitlab-runner
```

### Image pull fails (proxy)
```bash
cat /etc/systemd/system/docker.service.d/proxy.conf
# Verify HTTP_PROXY and HTTPS_PROXY are set
```

---

## Security Notes

- Docker daemon runs as root (standard Docker architecture)
- `gitlab-runner` user in docker group = effectively root-equivalent
- Proxy configured via systemd drop-in (not environment variable)
- Image prune runs daily to prevent disk fill
- Docker CE repo removed after install (no auto-updates)
- `gpgcheck=0`, `sslverify=0` in repo (corporate proxy SSL inspection)

---

## File Structure

```
roles/platform/docker/
├── defaults/main.yml     # Variables
├── tasks/
│   ├── main.yml          # Orchestrator
│   ├── validate.yml      # Pre-flight
│   ├── install.yml       # Packages + dirs
│   ├── config.yml        # Paths, proxy, user, cron
│   ├── service.yml       # Enable + start + restart
│   └── verify.yml        # Health checks
├── playbook: platform/docker.yaml
└── README.md             # This file
```

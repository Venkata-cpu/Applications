# Gradle Build Tool Role

Installs [Gradle](https://gradle.org/) — the build automation tool used by CI/CD pipelines. Downloads a pinned version and configures PATH for the runner user.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Gradle** | https://gradle.org/releases/ | `9.2.1` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Java** | 17+ (required by Gradle 9.x) | `java -version` |
| **Base directory** | Must exist (`/apps/Software`) | `ls -la /apps/Software` |
| **User** | `gitlab-runner` user must exist | `id gitlab-runner` |
| **Proxy** | For services.gradle.org download | `all_secrets.yml` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/gradle.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.gradle` | `9.2.1` | Gradle version |
| `paths.yml` | `paths.gradle.base_dir` | `/apps/Software` | Install directory |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `config.gradle.user` | `gitlab-runner` | User who gets PATH configured |
| `config.gradle.download_type` | `all` | `all` (sources + docs) or `bin` (binary only) |
| `config.gradle.download_timeout` | `120` | Download timeout (seconds) |

---

## What Gets Installed

```
/apps/Software/gradle-9.2.1/
├── bin/gradle         # Main executable
├── lib/               # Gradle libraries
└── ...

~/.bashrc → export PATH="/apps/Software/gradle-9.2.1/bin:$PATH"
```

---

## Task Execution Flow

```
main.yml
├── validate.yml   # Version defined, base dir exists, user exists
├── install.yml    # Download, extract, set ownership, PATH
└── verify.yml     # Binary exists, version check
```

---

## Upgrade Process

1. Update `version.gradle` in `versions.yml`
2. Re-run playbook — downloads new version alongside old, updates PATH in `.bashrc`
3. Old version remains on disk (manual cleanup if needed)

---

## Troubleshooting

### Gradle command not found
```bash
# Check PATH
su - gitlab-runner -c 'echo $PATH'
# Or source bashrc
su - gitlab-runner -c 'source ~/.bashrc && gradle --version'
```

### Download fails
```bash
# Test proxy connectivity
curl --proxy http://cloudproxy-d.nat.bt.com:8080 -k https://services.gradle.org/distributions/
```

---

## File Structure

```
roles/platform/gradle/
├── defaults/main.yml    # Variables
├── tasks/
│   ├── main.yml         # Orchestrator
│   ├── validate.yml     # Pre-flight
│   ├── install.yml      # Download + extract + PATH
│   └── verify.yml       # Version check
└── README.md            # This file
```

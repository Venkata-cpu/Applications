# OnePatch Role

Automates BT's OnePatch OS patching system. Enables addon repositories, optionally runs the OnePatch script for monthly patching, sets up cron jobs for scheduled patching and addons repo persistence, and optionally reboots.

## Latest Version

| Component | Check Latest |
|-----------|-------------|
| OnePatch | Internal BT patching system — version managed by BT Linux team |

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| BT repo file | `/etc/yum.repos.d/BT-OL8.repo` or `BT-OL9.repo` must exist | `ls /etc/yum.repos.d/BT-OL*.repo` |
| Network access | Server must reach `patch.linux.nat.bt.com` | `curl -sI https://patch.linux.nat.bt.com/onepatch` |
| Root access | Playbook runs with `become: true` | N/A |

## How to Run

```bash
# Repo enablement only (default — safe, no patching)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/onepatch.yaml \
  --vault-password-file .vault

# Full patch + reboot (set in inventory config_platform.yml)
# config_platform.onepatch.run_patch: true
# config_platform.onepatch.reboot: true

# Override target hosts
ansible-playbook -i inventories/barista/test/hosts \
  playbook/platform/onepatch.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=onepatch_zone1"
```

---

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `config_platform.yml` | `config_platform.onepatch.mode` | `monthly` | Patch mode |

### Optional Variables (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_platform.onepatch.run_patch` | `false` | Execute the OnePatch script | `false` = only enable repos. `true` = full patching (10-30 min). |
| `config_platform.onepatch.reboot` | `false` | Reboot after patching | `true` = auto-reboot + wait for server to come back (300s timeout). |
| `config_platform.onepatch.mode` | `monthly` | Patch mode | `monthly` = standard BT monthly patches. `full` = all available updates. |
| `config_platform.onepatch.url` | `https://patch.linux.nat.bt.com/onepatch` | OnePatch script URL | Change if mirror/alternate URL needed. |
| `config_platform.onepatch.timeout` | `1800` | Async timeout (seconds) | Increase if patching takes longer than 30 minutes. |
| `config_platform.onepatch.cron.enabled` | `false` | Enable cron-based scheduled patching | `true` = deploys cron job with `--rebootyes`. |
| `config_platform.onepatch.cron.weekday` | `0` (Sunday) | Cron weekday | `0` = Sunday, `1` = Monday, etc. |
| `config_platform.onepatch.cron.day` | `8-14` | Cron day range | `8-14` targets 2nd week of month. |
| `config_platform.onepatch.cron.hour` | `2` | Cron hour | Hour to run (24h format). |
| `config_platform.onepatch.cron.minute` | `0` | Cron minute | Minute to run. |
| `config_platform.onepatch.cron.log` | `/var/log/onepatch-cron.log` | Cron output log | Path for stdout/stderr redirect. |

---

## Task Execution Flow

```
main.yml
├── validate.yml   # Pre-flight checks (URL defined, mode valid, cron vars if enabled)
├── setup.yml      # Enable [addons] section in BT-OL8/OL9 repos
├── patch.yml      # Run OnePatch script (only if run_patch=true), optional reboot
├── cron.yml       # Deploy addons repo persistence cron + OnePatch scheduled patching cron
└── status.yml     # Display current patch level, kernel version, recent packages
```

---

## Post-Deployment Verification

1. Check addons repo is enabled:
   ```bash
   grep -A2 '\[addons\]' /etc/yum.repos.d/BT-OL*.repo | grep enabled
   # Expected: enabled=1
   ```

2. Check cron jobs (if enabled):
   ```bash
   crontab -l | grep -E "(addons|OnePatch)"
   # Expected: two entries — addons repo check + OnePatch patching
   ```

3. Check patch status:
   ```bash
   grep OnePatch /etc/sysconfig/BT-Build-id
   uname -r
   rpm -qa --last | head -5
   ```

---

## Troubleshooting

### Patching Times Out
- Increase `config_platform.onepatch.timeout` (default 1800s = 30 min)
- Check network connectivity to `patch.linux.nat.bt.com`

### Addons Repo Keeps Getting Disabled
- OS updates or other automation may reset `enabled=0`
- The addons cron job (first Monday of every month) re-enables it automatically
- To check: `crontab -l | grep addons`

### Checking Logs
```bash
# Cron patching log
cat /var/log/onepatch-cron.log

# System journal for reboot events
journalctl --list-boots | head -5
```

---

## File Structure

```
roles/platform/onepatch/
├── defaults/main.yml    # Variables with defaults
├── tasks/
│   ├── main.yml         # Orchestrator
│   ├── validate.yml     # Pre-flight validation
│   ├── setup.yml        # Enable addon repos
│   ├── patch.yml        # Run OnePatch + optional reboot
│   ├── cron.yml         # Addons persistence cron + scheduled patching cron
│   └── status.yml       # Display current patch status
└── README.md            # This file
```

---

## Security Notes

- OnePatch script is downloaded via `curl -Ls` from internal BT infrastructure (not public internet)
- Cron patching always uses `--rebootyes` since no human is monitoring
- Manual runs default to `--rebootno` — Ansible handles reboot separately with proper wait

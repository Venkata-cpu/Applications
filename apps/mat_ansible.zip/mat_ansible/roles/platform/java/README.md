# Java OpenJDK Role

Installs [OpenJDK](https://openjdk.org/) from the OS repository and sets it as the system default using `alternatives`. If another Java version is already installed, this role makes the configured version the active default.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **OpenJDK** | `yum list available java-*-openjdk` | `17` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Repos** | OS base repos available | `yum repolist` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/java17.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.java` | `17` | Java major version |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.java.install_devel` | `true` | Install JDK (javac) in addition to JRE | `false` = JRE only (no compilation). `true` = full JDK for building. |

---

## What Gets Installed

```
/usr/lib/jvm/java-17-openjdk-*/    # OpenJDK installation
/etc/profile.d/java.sh              # JAVA_HOME for all users
/etc/alternatives/java → java-17    # System default

Packages: java-17-openjdk, java-17-openjdk-devel (optional)
```

---

## Task Execution Flow

```
main.yml
├── validate.yml   # Version defined
├── install.yml    # yum install + alternatives --set + JAVA_HOME
└── verify.yml     # java -version confirms correct version is default
```

---

## How alternatives Works

If Java 11 was previously default:
```
Before: java → /usr/lib/jvm/java-11-openjdk/bin/java
After:  java → /usr/lib/jvm/java-17-openjdk/bin/java
```

The old version stays installed but is no longer the default. Apps using `/usr/bin/java` or `$JAVA_HOME` will use 17.

---

## Upgrade Process

1. Change `version.java` in `versions.yml` (e.g., `17` → `21`)
2. Re-run playbook — installs new version, sets as default via alternatives
3. Old version remains installed (other apps may depend on it)

---

## Troubleshooting

### java -version shows wrong version
```bash
# Check alternatives
alternatives --display java

# Force set
alternatives --set java /usr/lib/jvm/java-17-openjdk-*/bin/java

# Check JAVA_HOME
source /etc/profile.d/java.sh && echo $JAVA_HOME
```

---

## File Structure

```
roles/platform/java_17/
├── defaults/main.yml    # Variables
├── tasks/
│   ├── main.yml         # Orchestrator
│   ├── validate.yml     # Pre-flight
│   ├── install.yml      # Install + alternatives + JAVA_HOME
│   └── verify.yml       # Version check
└── README.md            # This file
```

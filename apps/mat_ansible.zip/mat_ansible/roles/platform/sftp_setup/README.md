# SFTP Setup Role

Configures a **dedicated SFTP service** running on a custom port via a separate `sshd` instance called `sshd_lock`. This service runs independently from the main SSH daemon (port 22), so changes to SFTP config do not affect normal SSH access.

Supports multiple users with password authentication, SSH key authentication, or both.

---

## What This Role Does

1. Installs `openssh-server` if not present
2. Configures SELinux to allow the custom SFTP port (auto-detected)
3. Opens the SFTP port in the firewall
4. Deploys a hardened `sshd_lock_config` file
5. Creates a `sshd_lock.service` systemd unit (separate from main `sshd`)
6. Creates SFTP user accounts with passwords from vault
7. Deploys SSH public keys for key-auth users
8. Verifies the service is running and accepting connections

---

## Prerequisites

| Requirement | Details |
|-------------|---------|
| **OS** | Oracle Enterprise Linux (OEL) 8 or 9, RHEL 8 or 9 |
| **Package** | `openssh-server` (installed automatically by the role) |
| **Ansible Collection** | None required (uses built-in modules) |
| **Vault** | Password for each user must be stored in `all_secrets.yml` (vault-encrypted) |
| **Network** | The SFTP port (default 50022) must be reachable from clients |
| **Existing SSH** | The role does NOT touch the main `sshd` service on port 22 |

---

## How to Run

```bash
# Deploy SFTP setup to target hosts
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/sftp_setup.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=<host_group>"

# Example: Deploy to all haproxy servers in prod
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/sftp_setup.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=haproxy"
```

---

## Configuration

All configuration lives in `app_configs.yml` under `config.sftp`. If a value is not specified, the default (shown below) is used.

### app_configs.yml Example

```yaml
config:
  sftp:
    port: 50022
    max_sessions: 10
    max_startup: "80:30:200"
    client_alive_interval: 300
    client_alive_count_max: 3
    login_grace_time: 60
    max_auth_tries: 4
    users:
      - name: martinilive
        auth: password
      - name: dataexport
        auth: both
        public_key: "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA... user@host"
      - name: automation_svc
        auth: key
        public_key: "ssh-rsa AAAAB3NzaC1yc2EAAAA... jenkins@ci"
        shell: /bin/bash
        home: /home/automation_svc
```

### all_secrets.yml (vault-encrypted)

```yaml
# One entry per user that uses password auth
# Variable naming: sftp_password_<username>_vault
sftp_password_martinilive_vault: "SecureP@ssw0rd123"
sftp_password_dataexport_vault: "An0therStr0ngPass!"
# Key-only users (auth: key) do NOT need a password entry
```

---

## Variable Reference

### Server Settings

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|-----------------|
| `port` | `50022` | TCP port the SFTP service listens on | **Increase/Change:** Use any unused port between 1024-65535. Must update firewall rules and client configs. Using a non-standard port reduces automated scan attacks. |
| `max_sessions` | `10` | Maximum concurrent SFTP sessions per single connection | **Increase:** Allows more parallel file transfers over one connection. **Decrease:** Limits resource usage per user. A transfer typically uses 1 session, so 10 is generous. |
| `max_startup` | `"80:30:200"` | Format: `start:rate:full`. Controls connection throttling. Before `start` unauthenticated connections: accept all. Between `start` and `full`: drop new connections with probability `rate`%. At `full`: reject all new connections. | **Increase `full`:** Allows more simultaneous login attempts (use if many users connect at once). **Decrease:** Stricter DDoS protection but may reject legitimate users during peaks. |
| `client_alive_interval` | `300` | Seconds of inactivity before server sends a keepalive probe to the client | **Increase:** Tolerates longer idle periods (good for slow transfers). **Decrease:** Detects dead connections faster (frees resources sooner). Set to `0` to disable keepalives entirely. |
| `client_alive_count_max` | `3` | Number of keepalive probes with no response before disconnecting | **Total idle timeout = interval × count** (default: 300 × 3 = 900 seconds = 15 minutes). **Increase:** More tolerant of network blips. **Decrease:** Faster cleanup of dead sessions. |
| `login_grace_time` | `60` | Seconds a user has to complete authentication after connecting | **Increase:** Gives slow users/scripts more time to enter credentials. **Decrease:** Drops hanging connections faster (protects against slowloris-style attacks). Set to `0` for no limit (not recommended). |
| `max_auth_tries` | `4` | Maximum password attempts before disconnecting | **Increase:** More retries for users who mistype. **Decrease:** Limits brute-force window. After this many failures, the connection is dropped and the client must reconnect. |

### User Settings

Each entry in `config.sftp.users` supports:

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `name` | Yes | — | Linux username to create. Must be a valid username (lowercase, no spaces). |
| `auth` | No | `password` | Authentication method: `password`, `key`, or `both`. |
| `public_key` | Only if auth=key/both | — | Full SSH public key string (e.g. `ssh-ed25519 AAAA... comment`). |
| `shell` | No | `/sbin/nologin` | User's login shell. `/sbin/nologin` prevents interactive SSH login (SFTP still works). Set to `/bin/bash` if user needs shell access. |
| `home` | No | `/home/<name>` | Home directory path. Created automatically if it doesn't exist. |

### Auth Modes Explained

| Mode | What it means | When to use |
|------|---------------|-------------|
| `password` | User logs in with username + password (from vault) | Human users who connect interactively |
| `key` | User logs in with SSH private key (no password needed) | Automated scripts, CI/CD pipelines, service accounts |
| `both` | User can log in with EITHER password OR key | Flexibility — key for automation, password as fallback |

### Security Settings (Advanced — usually leave defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `permit_root_login` | `no` | Never allow root to log in via SFTP |
| `allow_tcp_forwarding` | `no` | Prevent SSH tunneling through SFTP |
| `x11_forwarding` | `no` | Disable X11 (graphical) forwarding |
| `permit_empty_passwords` | `no` | Reject accounts with blank passwords |
| `password_authentication` | `yes` | Allow password-based login |
| `pubkey_authentication` | `yes` | Allow SSH key-based login |

### Crypto Settings (Advanced — change only if security team requires)

| Variable | Default | Notes |
|----------|---------|-------|
| `ciphers` | `chacha20-poly1305, aes256-ctr, aes256-gcm` | Encryption algorithms. Removing weaker ones improves security but may break old clients. |
| `macs` | `hmac-sha2-512-etm, hmac-sha2-256-etm, hmac-sha2-512` | Message authentication codes. ETM variants are more secure. |
| `kex_algorithms` | `curve25519-sha256, dh-group14/16/18` | Key exchange algorithms. Curve25519 is the fastest and most secure. |
| `host_key_algorithms` | `ed25519, rsa-sha2-512/256, ecdsa` | Host key types. ed25519 is preferred. |

---

## Post-Deployment Verification

### 1. Check Service Status

```bash
# On the target server
systemctl status sshd_lock

# Expected output should show:
#   Active: active (running)
#   Loaded: loaded (/usr/lib/systemd/system/sshd_lock.service; enabled)
```

### 2. Check Port is Listening

```bash
ss -tlnp | grep 50022

# Expected output:
# LISTEN  0  128  0.0.0.0:50022  0.0.0.0:*  users:(("sshd",pid=XXXXX,fd=3))
```

### 3. Test SFTP Login (Password)

```bash
# From any machine that can reach the server
sftp -P 50022 martinilive@<server-ip>

# You should see:
#   martinilive@<server-ip>'s password: <enter password>
#   Connected to <server-ip>.
#   sftp>

# Type 'ls' to list files, 'quit' to exit
```

### 4. Test SFTP Login (Key)

```bash
# For key-auth users
sftp -P 50022 -i /path/to/private_key automation_svc@<server-ip>

# Should connect without prompting for password
```

### 5. Test File Upload

```bash
# Upload a test file
echo "test" > /tmp/test_upload.txt
sftp -P 50022 martinilive@<server-ip> <<EOF
put /tmp/test_upload.txt
ls -la test_upload.txt
rm test_upload.txt
quit
EOF
```

### 6. Check Logs for Issues

```bash
# View SFTP auth logs
tail -50 /var/log/secure | grep sshd_lock

# Successful login looks like:
#   Accepted password for martinilive from <ip> port <port> ssh2

# Failed login looks like:
#   Failed password for martinilive from <ip> port <port> ssh2
```

### 7. Verify User Exists

```bash
# Check user was created
id martinilive

# Expected:
#   uid=XXXX(martinilive) gid=XXXX(martinilive) groups=XXXX(martinilive)

# Check password is set (x means password in /etc/shadow)
grep martinilive /etc/passwd
```

---

## Troubleshooting

### "Connection refused" when trying to connect

```bash
# Check if service is running
systemctl status sshd_lock

# Check if port is listening
ss -tlnp | grep 50022

# Check firewall
firewall-cmd --list-ports | grep 50022

# If SELinux is enforcing, check port label
semanage port -l | grep ssh_port_t
```

### "Permission denied" after entering correct password

```bash
# Check if user exists
id <username>

# Check if password is set
passwd -S <username>
# Should show: <username> PS ... (PS = Password Set)

# Check PAM config
cat /etc/pam.d/sshd

# Check if user is in AllowUsers
grep AllowUsers /etc/ssh/sshd_lock_config
```

### Service fails to start

```bash
# Check config syntax
/usr/sbin/sshd -t -f /etc/ssh/sshd_lock_config

# Check journal for errors
journalctl -u sshd_lock --no-pager -n 30

# Common issue: port already in use
ss -tlnp | grep 50022
```

### SELinux blocking the port

```bash
# Check if SELinux is the problem
ausearch -m avc -ts recent | grep sshd

# Fix: add the port to SELinux policy
semanage port -a -t ssh_port_t -p tcp 50022
```

---

## File Structure

```
roles/sftp_setup/
├── defaults/main.yml                    # All variables (Core, User, Service, Security, Crypto)
├── tasks/
│   ├── main.yml                         # Orchestrator (validate → install → users → config → service → verify)
│   ├── validate.yml                     # Pre-flight checks (port, users, passwords, keys)
│   ├── install.yml                      # Packages, SELinux, firewall
│   ├── users.yml                        # User creation, passwords, SSH keys
│   ├── config.yml                       # sshd_lock_config + systemd unit templates
│   ├── service.yml                      # Systemd enable, start, conditional restart
│   └── verify.yml                       # Service status, port check, login test
├── templates/
│   ├── sshd_lock_config.j2             # SSHD config (hardened, templated)
│   └── sshd_lock.service.j2            # Systemd unit file
└── README.md                            # This file
```

---

## Important Notes

- This role does **NOT** touch the main SSH service (`sshd` on port 22). It runs a completely separate instance.
- Re-running the role is safe (idempotent). It only restarts the SFTP service if the config file changed.
- User passwords are hashed with SHA-512 before being set. The plaintext password never appears in logs (`no_log: true`).
- If you add a new user, just add them to the `config.sftp.users` list and re-run. Existing users are not affected.
- Removing a user from the list does NOT delete the user from the system. To remove a user, manually run `userdel <username>` on the server.

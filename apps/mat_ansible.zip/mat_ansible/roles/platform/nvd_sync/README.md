# NVD Sync

Ansible role that downloads NVD (National Vulnerability Database) CVE data using the OWASP Dependency-Check CLI and stores it in a shared PostgreSQL database. On first run (empty DB), it pulls all CVE data; on subsequent runs, it automatically fetches only the delta based on the last sync timestamp stored in the database. A cron job is configured for automated daily synchronisation.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| Dependency-Check CLI | [GitHub Releases](https://github.com/dependency-check/DependencyCheck/releases) | Defined in `version.nvd_sync.dependency_check` |
| PostgreSQL JDBC Driver | [Download Page](https://jdbc.postgresql.org/download/) | Defined in `version.nvd_sync.pg_driver` |

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Java 17+ | Required by Dependency-Check CLI | `java -version` |
| PostgreSQL database | DB, user, schema must be created manually (see below) | `psql -h <host> -U dcuser -d dependencycheck -c "SELECT 1;"` |
| Network access | Outbound HTTPS to NVD API + network to PG host | `curl -I https://services.nvd.nist.gov` |
| NVD API Key | Required for reasonable rate limits | Request at https://nvd.nist.gov/developers/request-an-api-key |

### Database Setup (manual — run once on PostgreSQL server before first playbook run)

The database user (`dcuser`) and database name (`dependencycheck`) are hardcoded — required by the Dependency-Check `initialize_postgres.sql` schema. Run these commands on the PostgreSQL server:

```sql
-- Connect as postgres superuser
sudo -u postgres psql

-- Create the database user
CREATE USER dcuser WITH PASSWORD '<your_secure_password>';

-- Create the database
CREATE DATABASE dependencycheck OWNER dcuser;

-- Connect to the new database
\c dependencycheck

-- Grant schema permissions
GRANT ALL ON SCHEMA public TO dcuser;
GRANT ALL PRIVILEGES ON DATABASE dependencycheck TO dcuser;

-- Apply the schema (download the SQL file matching your DC version)
-- https://github.com/dependency-check/DependencyCheck/blob/v<version>/core/src/main/resources/data/initialize_postgres.sql
\i /path/to/initialize_postgres.sql
```

Download the schema SQL for your version:
```bash
curl -o initialize_postgres.sql \
  "https://raw.githubusercontent.com/dependency-check/DependencyCheck/v12.2.2/core/src/main/resources/data/initialize_postgres.sql"
```

Verify connectivity from the Ansible runner node:
```bash
PGPASSWORD='<your_secure_password>' psql -h <db_host> -p 5432 -U dcuser -d dependencycheck -c "SELECT 1;"
```

## How to Run

```bash
# Run NVD sync (first run = full pull, subsequent runs = delta)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/nvd_sync.yaml \
  --vault-password-file .vault

# Target a specific host
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/platform/nvd_sync.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=nvd_sync"
```

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.nvd_sync.dependency_check` | `12.2.2` | Dependency-Check CLI version |
| `versions.yml` | `version.nvd_sync.pg_driver` | `42.7.11` | PostgreSQL JDBC driver version |
| `paths.yml` | `paths.nvd_sync.base_dir` | `/apps` | Base installation directory |
| `app_configs.yml` | `config.nvd_sync.db_host` | `10.11.21.249` | PostgreSQL host address |
| `all_secrets.yml` | `nvd_sync_db_password_vault` | (vault-encrypted) | Database password for `dcuser` |
| `all_secrets.yml` | `nvd_sync_api_key_vault` | (vault-encrypted) | NVD API key |

> **Note:** Database user (`dcuser`) and database name (`dependencycheck`) are hardcoded — required by the Dependency-Check schema SQL and cannot be changed.

### Optional Variables (with defaults)

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|-----------------|
| `config.nvd_sync.user` | `nvd-sync` | Service user | Affects file ownership and cron user |
| `config.nvd_sync.group` | `nvd-sync` | Service group | Affects file ownership |
| `config.nvd_sync.db_port` | `5432` | PostgreSQL port | Must match DB server config |
| `config.nvd_sync.api_delay` | `2000` | Delay between NVD API calls (ms) | Lower = faster but risk rate limiting |
| `config.nvd_sync.api_max_retries` | `15` | Max retry count for NVD API | Higher = more resilient to transient failures |
| `config.nvd_sync.java_home` | `/apps/java` | Java installation path | Must point to Java 17+ |
| `config.nvd_sync.connection_timeout` | `5000` | JDBC connection timeout (ms) | Higher for slow networks |
| `config.nvd_sync.read_timeout` | `10000` | JDBC read timeout (ms) | Higher for large result sets |
| `config.nvd_sync.cron_enabled` | `true` | Enable daily cron job | `false` disables automated sync |
| `config.nvd_sync.cron_minute` | `0` | Cron minute | When daily sync runs |
| `config.nvd_sync.cron_hour` | `2` | Cron hour | When daily sync runs (default: 2 AM) |
| `config.nvd_sync.log_retention_days` | `30` | Days to keep log files | Higher = more disk usage |
| `config.nvd_sync.download_timeout` | `120` | Download timeout (seconds) | Higher for slow connections |

## What Gets Installed

```
/apps/
└── nvd_sync/
    ├── dependency-check -> dependency-check-<version>/   (symlink)
    ├── dependency-check-<version>/
    │   └── bin/
    │       └── dependency-check.sh
    ├── dependency-check-<version>-release.zip
    ├── lib/
    │   └── postgresql-<pg_driver_version>.jar
    ├── nvd-sync.sh                                       (templated sync script)
    └── logs/
        ├── nvd-sync-YYYYMMDD.log                         (daily sync logs)
        └── nvd-sync-cron.log                             (cron output)

/etc/logrotate.d/
└── nvd-sync                                              (log rotation config)

crontab (nvd-sync user):
  0 2 * * * /apps/nvd_sync/nvd-sync.sh >> /apps/nvd_sync/logs/nvd-sync-cron.log 2>&1
```

## Task Execution Flow

```
main.yml
├── validate.yml          — Pre-flight checks (vars defined, base_dir exists, DB params valid)
├── create_user.yml       — Create nvd-sync system user/group
├── pre_verify.yml        — Verify Java available, DB reachable, user exists
├── install.yml           — Download DC CLI + PG JDBC driver (idempotent, version-pinned)
├── sync.yml              — Deploy sync script + run NVD update
├── cron.yml              — Deploy cron job + logrotate config
└── verify.yml            — Check CLI works, DB tables exist, cron configured
```

## Post-Deployment Verification

1. Check Dependency-Check CLI version:
   ```bash
   /apps/nvd_sync/dependency-check/bin/dependency-check.sh --version
   ```

2. Check database tables exist:
   ```bash
   PGPASSWORD='***' psql -h <db_host> -p 5432 -U dcuser -d dependencycheck \
     -c "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public';"
   ```

3. Check CVE count (after sync):
   ```bash
   PGPASSWORD='***' psql -h <db_host> -p 5432 -U dcuser -d dependencycheck \
     -c "SELECT COUNT(*) FROM vulnerability;"
   ```

4. Check cron job is configured:
   ```bash
   crontab -u nvd-sync -l
   ```

5. Check sync logs:
   ```bash
   tail -20 /apps/nvd_sync/logs/nvd-sync-cron.log
   ls -la /apps/nvd_sync/logs/
   ```

## Upgrade Process

1. Update `version.nvd_sync.dependency_check` in `versions.yml` to the new version.
2. Update `version.nvd_sync.pg_driver` if a newer JDBC driver is needed.
3. Run the playbook — the install step will download the new version and update the symlink.
4. Verify: `/apps/nvd_sync/dependency-check/bin/dependency-check.sh --version`
5. If a schema migration is required (check DC release notes), manually apply the new `initialize_postgres.sql` on the PostgreSQL server.

## Troubleshooting

### Checking Logs

```bash
# Recent sync output
tail -50 /apps/nvd_sync/logs/nvd-sync-cron.log

# Today's sync log
cat /apps/nvd_sync/logs/nvd-sync-$(date '+%Y%m%d').log

# Follow live sync output
tail -f /apps/nvd_sync/logs/nvd-sync-cron.log
```

### Common Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| `ERROR: dependency-check CLI not found` | CLI not installed or symlink broken | Re-run playbook; check symlink at `nvd_sync/dependency-check` |
| `Connection refused` to DB | PG not running or firewall | Check `pg_isready -h <host> -p <port>` |
| NVD API 403/429 errors | Rate limited or invalid API key | Increase `api_delay`, verify API key |
| `java: command not found` | JAVA_HOME incorrect | Verify `config.nvd_sync.java_home` points to Java 17+ |
| Schema errors on first run | DB schema not applied | Manually apply `initialize_postgres.sql` on PG server |
| Cron not running | User shell is `/sbin/nologin` | This is expected — cron still executes for the user |

### Service Account Access

The `nvd-sync` user is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as nvd-sync
su -s /bin/bash nvd-sync

# Run a single command as nvd-sync
su -s /bin/bash -c "/apps/nvd_sync/nvd-sync.sh" nvd-sync
```

## File Structure

```
roles/platform/nvd_sync/
├── defaults/
│   └── main.yml
├── tasks/
│   ├── main.yml
│   ├── validate.yml
│   ├── create_user.yml
│   ├── pre_verify.yml
│   ├── install.yml
│   ├── sync.yml
│   ├── cron.yml
│   └── verify.yml
├── templates/
│   ├── nvd-sync.sh.j2
│   └── nvd-sync-logrotate.j2
└── README.md
```

## Security Notes

- NVD API key and DB password are vault-encrypted — never stored in plaintext.
- Sync script is owned by `nvd-sync` user with mode `0750` — not world-readable (contains DB credentials).
- The `nvd-sync` user has `/sbin/nologin` shell — cannot be used for interactive login.
- Downloads use `validate_certs: false` due to corporate proxy TLS inspection.
- Database password is passed via `PGPASSWORD` environment variable (not command-line arg) to avoid exposure in process lists.
- Database user (`dcuser`) and database name (`dependencycheck`) are hardcoded for schema compatibility.

# Headlamp (Kubernetes Web UI)

Deploys [Headlamp](https://headlamp.dev/) — a lightweight Kubernetes web dashboard with token-based authentication. Provides admin (full cluster access) and read-only (view-only) access levels via service account tokens.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Headlamp** | https://github.com/headlamp-k8s/headlamp/releases | Defined in `version.kubernetes.headlamp` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Kubernetes cluster | Running with kubectl access on master | `kubectl get nodes` |
| Ingress controller | HAProxy Ingress (for context-path access) | `kubectl get ingressclass` |
| DNS entry | Pointing to ingress/master node | `nslookup <host>` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_headlamp.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.headlamp` | `v0.26.0` | Container image tag |
| `config_kubernetes.yml` | `config_k8s.headlamp.ingress.host` | `barista.nat.bt.com` | Ingress hostname |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.headlamp.namespace` | `headlamp` | K8s namespace | All resources deployed here |
| `config_k8s.headlamp.port` | `4466` | Container/service port | Must match ingress backend port |
| `config_k8s.headlamp.base_path` | `/headlamp` | URL context path | Access at `http://host/headlamp/` |
| `config_k8s.headlamp.ingress.enabled` | `true` | Deploy ingress resource | `false` = use NodePort instead |
| `config_k8s.headlamp.ingress.class` | `haproxy` | Ingress class | Must match deployed ingress controller |
| `config_k8s.headlamp.ingress.tls` | `false` | Enable TLS on ingress | Requires cert-manager or manual cert |
| `config_k8s.headlamp.resources.requests_cpu` | `50m` | CPU request | |
| `config_k8s.headlamp.resources.requests_memory` | `128Mi` | Memory request | |
| `config_k8s.headlamp.resources.limits_cpu` | `500m` | CPU limit | |
| `config_k8s.headlamp.resources.limits_memory` | `256Mi` | Memory limit | Increase if many users |
| `config_k8s.headlamp.wait_retries` | `10` | Readiness check retries | |
| `config_k8s.headlamp.wait_delay` | `15` | Seconds between retries | |

### Inventory Example

```yaml
# versions.yml
version:
  kubernetes:
    headlamp: "v0.26.0"

# config_kubernetes.yml (under config_k8s)
  headlamp:
    namespace: headlamp
    port: 4466
    base_path: "/headlamp"
    ingress:
      enabled: true
      host: "barista.nat.bt.com"
      class: haproxy
      tls: false
```

---

## What Gets Deployed

| Resource | Namespace | Purpose |
|----------|-----------|---------|
| Deployment (headlamp) | `headlamp` | The Headlamp web UI pod |
| Service (ClusterIP) | `headlamp` | Internal service for ingress |
| Ingress | `headlamp` | External access via context path |
| ServiceAccount (headlamp-admin) | `headlamp` | Full cluster-admin access |
| ServiceAccount (headlamp-readonly) | `headlamp` | Read-only cluster access |
| ClusterRole (headlamp-readonly) | cluster-scoped | Read-only permissions |
| Secret (headlamp-admin-token) | `headlamp` | Admin login token |
| Secret (headlamp-readonly-token) | `headlamp` | Read-only login token |

---

## Task Execution Flow

```
main.yaml
├── validate.yml    — Check version, namespace, ingress host, kubectl available
├── install.yml     — Create namespace, apply deployment + service + ingress
├── tokens.yml      — Create admin + read-only service accounts and tokens
└── verify.yml      — Wait for rollout, verify pod running, tokens exist
```

---

## Post-Deployment Verification

```bash
# 1. Check pod
kubectl get pods -n headlamp

# 2. Get admin token (use to login)
kubectl get secret headlamp-admin-token -n headlamp -o jsonpath='{.data.token}' | base64 -d

# 3. Get read-only token
kubectl get secret headlamp-readonly-token -n headlamp -o jsonpath='{.data.token}' | base64 -d

# 4. Access UI
# Via ingress: http://<host>/headlamp/
# Paste the token when prompted
```

---

## Upgrade Process

1. Update `version.kubernetes.headlamp` in `versions.yml`
2. Re-run playbook — applies updated deployment with new image tag
3. Pod restarts automatically with new version

---

## Troubleshooting

### UI not accessible
```bash
# Check ingress
kubectl get ingress -n headlamp
kubectl describe ingress headlamp-ingress -n headlamp

# Check pod logs
kubectl logs -n headlamp -l app=headlamp --tail=20

# Check service
kubectl get svc -n headlamp
```

### Token login fails
```bash
# Verify token secret exists
kubectl get secret headlamp-admin-token -n headlamp

# Regenerate token (delete and re-run playbook)
kubectl delete secret headlamp-admin-token -n headlamp
```

### Blank page / base path issues
Ensure `HEADLAMP_BASE_PATH` matches the ingress path. Both must be `/headlamp` (or whatever you configured).

---

## Security Notes

- Headlamp runs as non-root (UID 100)
- Admin token grants `cluster-admin` — share only with trusted users
- Read-only token provides view-only access across the cluster
- Tokens are K8s secrets — not displayed in Ansible output (`no_log` on token retrieval)
- No LDAP/OIDC — uses static service account tokens

---

## File Structure

```
roles/kubernetes/frontend/headlamp/
├── defaults/main.yml
├── tasks/
│   ├── main.yaml              # Orchestrator
│   ├── validate.yml           # Pre-flight checks
│   ├── install.yml            # Namespace + deployment + ingress
│   ├── tokens.yml             # Admin + read-only tokens
│   └── verify.yml             # Readiness checks
├── templates/
│   ├── headlamp.yaml.j2                    # Deployment + Service + Ingress
│   ├── headlamp-admin-token-secret.yaml.j2 # Admin SA token
│   ├── headlamp-readonly-role.yaml.j2      # Read-only ClusterRole
│   └── headlamp-readonly-token.yaml.j2     # Read-only SA + token
└── README.md
```

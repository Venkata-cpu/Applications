# Grafana on Kubernetes

Deploys Grafana as a Kubernetes Deployment with external PostgreSQL for storage (dashboards, users, sessions). Supports LDAP authentication (BT AD), SMTP alerts, configurable plugins, and Ingress with context path.

## Latest Version

| Component | Check Latest |
|-----------|-------------|
| **Grafana** | https://grafana.com/grafana/download |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Kubernetes cluster | Running with kubectl access | `kubectl get nodes` |
| PostgreSQL database | External DB for Grafana storage (create DB + user first) | `psql -h <host> -U grafana -d grafana -c "SELECT 1;"` |
| Ingress controller | HAProxy Ingress (for context path) | `kubectl get ingressclass` |
| LDAP (optional) | BT AD at `iuserldap.nat.bt.com:389` | `ldapsearch -x -H ldap://iuserldap.nat.bt.com` |

### Database Setup (before first run)

Grafana stores dashboards, users, sessions, and alerts in an external database. Create the database and user **before** running the Grafana playbook.

#### Option A: PostgreSQL (recommended for K8s Grafana)

```sql
-- On the CNPG PostgreSQL cluster (via psql)
CREATE DATABASE grafana;
CREATE USER grafana WITH PASSWORD '<password>';
GRANT ALL PRIVILEGES ON DATABASE grafana TO grafana;
\c grafana
GRANT ALL ON SCHEMA public TO grafana;
```

Or if using the CNPG cluster on K8s:
```bash
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -c "CREATE DATABASE grafana;"
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -c "CREATE USER grafana WITH PASSWORD '<password>';"
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE grafana TO grafana;"
kubectl exec -n postgres <cluster-name>-1 -- psql -U postgres -d grafana -c "GRANT ALL ON SCHEMA public TO grafana;"
```

#### Option B: MySQL

```sql
-- On the MySQL server (connect as root)
CREATE DATABASE grafana CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'grafana'@'%' IDENTIFIED BY '<password>';
GRANT ALL PRIVILEGES ON grafana.* TO 'grafana'@'%';
FLUSH PRIVILEGES;
```

Or via the `mysql/setup` role — add to your `config_database.mysql` config and run `mysql_user_setup.yaml` first.

**Verify connectivity:**
```bash
# PostgreSQL
psql -h <host> -U grafana -d grafana -c "SELECT 1;"

# MySQL
mysql -u grafana -p -h <host> -P <port> -e "USE grafana; SELECT 1;"
```

**Note:** Grafana auto-creates all required tables on first start (schema migration runs automatically).

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_grafana.yaml \
  --vault-password-file .vault
```

---

## Accessing Grafana

### Via Ingress (recommended)

```
http://<ingress-host>/grafana/
```

Example: `http://martini.preprod.nat.bt.com/grafana/`

### Via NodePort (when ingress disabled)

```
http://<any-worker-ip>:<nodeport>/grafana/
```

### Default Login

- **With LDAP enabled:** Use your BT AD credentials (sAMAccountName)
- **Without LDAP:** Username `admin`, password from vault (`k8s_grafana_admin_password_vault`)

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.grafana` | `12.1.1` | Grafana image tag |
| `config_kubernetes.yml` | `config_k8s.grafana.database.host` | `mat-pre-prod-rw.postgres.svc` | PostgreSQL host |
| `all_secrets.yml` | `k8s_grafana_admin_password_vault` | (vault) | Admin password |
| `all_secrets.yml` | `k8s_grafana_db_password_vault` | (vault) | DB password |
| `all_secrets.yml` | `k8s_grafana_ldap_bind_password_vault` | (vault) | LDAP bind password (if LDAP enabled) |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.grafana.namespace` | `grafana` | K8s namespace | |
| `config_k8s.grafana.replicas` | `1` | Pod replicas | Multiple works since DB is external |
| `config_k8s.grafana.port` | `3000` | Container port | |
| `config_k8s.grafana.base_path` | `/grafana` | URL context path | Must match ingress path |
| `config_k8s.grafana.ingress.enabled` | `true` | Enable ingress | `false` = use NodePort |
| `config_k8s.grafana.ingress.host` | — | Ingress hostname | Required when ingress enabled |
| `config_k8s.grafana.ingress.class` | `haproxy` | Ingress class | |
| `config_k8s.grafana.database.type` | `postgres` | DB type | `postgres` or `mysql` |
| `config_k8s.grafana.database.port` | `5432` | DB port | |
| `config_k8s.grafana.database.name` | `grafana` | DB name | Must exist before deploy |
| `config_k8s.grafana.database.user` | `grafana` | DB user | |
| `config_k8s.grafana.database.ssl_mode` | `disable` | PostgreSQL SSL mode | `require` for external DB |
| `config_k8s.grafana.ldap.enabled` | `false` | Enable LDAP auth | |
| `config_k8s.grafana.ldap.host` | `iuserldap.nat.bt.com` | LDAP server | |
| `config_k8s.grafana.ldap.port` | `389` | LDAP port | |
| `config_k8s.grafana.ldap.bind_dn` | — | Bind DN for searches | |
| `config_k8s.grafana.ldap.search_filter` | `(sAMAccountName=%s)` | User search filter | |
| `config_k8s.grafana.ldap.search_base_dns` | `[]` | Base DNs to search | |
| `config_k8s.grafana.ldap.group_mappings` | `[]` | LDAP group → role mappings | |
| `config_k8s.grafana.smtp.enabled` | `false` | Enable email alerts | |
| `config_k8s.grafana.smtp.host` | `smtpb.intra.bt.com:25` | SMTP relay | |
| `config_k8s.grafana.smtp.from_address` | `noreply.martini@bt.com` | From address | |
| `config_k8s.grafana.plugins` | `[]` | Plugins to install | Installed on pod startup |
| `config_k8s.grafana.resources.requests_cpu` | `100m` | CPU request | |
| `config_k8s.grafana.resources.limits_memory` | `512Mi` | Memory limit | Increase for many users |

---

## LDAP Configuration

### Group Mappings

Each mapping assigns a Grafana org role to an LDAP group. A group can have multiple entries for different orgs:

```yaml
config_k8s:
  grafana:
    ldap:
      enabled: true
      host: "iuserldap.nat.bt.com"
      port: 389
      bind_dn: "CN=mat_func_account,OU=functional,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com"
      search_filter: "(sAMAccountName=%s)"
      search_base_dns:
        - "ou=employee,ou=btplc,dc=iuser,dc=iroot,dc=adidom,dc=com"
        - "ou=functional,ou=btplc,dc=iuser,dc=iroot,dc=adidom,dc=com"
      group_mappings:
        # SuperAdmin → Admin in default org + Grafana Server Admin
        - group_dn: "cn=mygrp-mat-grafana-SuperAdmin,OU=group,OU=mygrp,OU=application,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com"
          org_role: "Admin"
          grafana_admin: true

        # Same group → Admin in org 5 (e.g., "MAT RAN" org)
        - group_dn: "cn=mygrp-mat-grafana-Admin,OU=group,OU=mygrp,OU=application,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com"
          org_role: "Admin"
          org_id: 5

        # Same group → Editor in org 7 (e.g., "MAT FN" org)
        - group_dn: "cn=mygrp-mat-grafana-Admin,OU=group,OU=mygrp,OU=application,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com"
          org_role: "Editor"
          org_id: 7

        # Editor group
        - group_dn: "cn=mygrp-mat-grafana-editor,OU=group,OU=mygrp,OU=application,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com"
          org_role: "Editor"
          org_id: 5

        # Readonly group
        - group_dn: "cn=mygrp-mat-grafana-readonly,OU=group,OU=mygrp,OU=application,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com"
          org_role: "Viewer"
          org_id: 5
```

### Group Mapping Fields

| Field | Required | Description |
|-------|----------|-------------|
| `group_dn` | Yes | Full LDAP group DN |
| `org_role` | Yes | Grafana role: `Admin`, `Editor`, `Viewer` |
| `org_id` | No | Grafana org ID (omit for default org 1) |
| `grafana_admin` | No | Set `true` for Grafana Server Admin (superuser) |

**Note:** A wildcard `group_dn: "*"` is automatically appended as `Viewer` fallback — any authenticated LDAP user gets at least Viewer access.

---

## Plugins

Install Grafana plugins by listing them in config:

```yaml
config_k8s:
  grafana:
    plugins:
      - grafana-clock-panel
      - grafana-piechart-panel
      - grafana-polystat-panel
      - yesoreyeram-infinity-datasource
```

Plugins are installed on pod startup via `GF_INSTALL_PLUGINS` environment variable. After adding new plugins, re-run the playbook — pods restart with new plugins.

Find available plugins: https://grafana.com/grafana/plugins/

---

## Adding Data Sources (post-deployment)

After Grafana is running, add data sources via the UI:

### Prometheus (in-cluster)
- URL: `http://prometheus.monitoring.svc:9090`
- Type: Prometheus

### Loki (in-cluster)
- URL: `http://loki.loki.svc:3100`
- Type: Loki

### Elasticsearch (in-cluster)
- URL: `http://elasticsearch.elasticsearch.svc:9200`
- Index: `kubelogs-*`
- Type: Elasticsearch

### External Prometheus (bare-metal)
- URL: `http://<bare-metal-prometheus-ip>:61087`
- Type: Prometheus

---

## What Gets Deployed

```
Namespace: grafana
├── Secret/grafana-secrets              # Admin password, DB password, LDAP bind
├── ConfigMap/grafana-ldap (optional)   # LDAP config (ldap.toml)
├── Deployment/grafana                  # Grafana pods (1 or more replicas)
├── Service/grafana (ClusterIP)         # Internal service
└── Ingress/grafana-ingress (optional)  # External access via context path
```

No PVC needed — all data stored in external PostgreSQL.

---

## Task Execution Flow

```
main.yml
├── validate.yml    — Version, DB host, admin password, ingress host, kubectl
├── install.yml     — Namespace, secrets, deployment, LDAP config, rollout wait
└── verify.yml      — Pod running, display status + URL
```

---

## Upgrade Process

1. Update `version.kubernetes.grafana` in `versions.yml`
2. Re-run playbook — Deployment image tag updates, pods restart
3. Database migrations run automatically on Grafana startup
4. Dashboards/datasources preserved (stored in PostgreSQL)

---

## Troubleshooting

### LDAP login fails
```bash
# Check LDAP config
kubectl get cm grafana-ldap -n grafana -o yaml

# Check Grafana logs for LDAP errors
kubectl logs -n grafana -l app=grafana --tail=30 | grep -i ldap

# Test LDAP connectivity from pod
kubectl exec -n grafana deploy/grafana -- wget -qO- ldap://iuserldap.nat.bt.com:389
```

### Database connection fails
```bash
# Check DB env vars
kubectl get deploy grafana -n grafana -o yaml | grep -A2 GF_DATABASE

# Test DB connectivity from pod
kubectl exec -n grafana deploy/grafana -- wget -qO- http://localhost:3000/api/health
```

### Plugins not loading
```bash
# Check GF_INSTALL_PLUGINS env
kubectl get deploy grafana -n grafana -o jsonpath='{.spec.template.spec.containers[0].env}' | python3 -m json.tool | grep PLUGIN

# Check pod startup logs
kubectl logs -n grafana -l app=grafana | grep -i plugin
```

### Context path / 404
- Ensure `GF_SERVER_SERVE_FROM_SUB_PATH=true` is set
- Ensure ingress path matches `base_path` config
- Check ingress controller logs

---

## Security Notes

- Admin and DB passwords stored as K8s Secret (from vault)
- LDAP bind password in Secret (not ConfigMap)
- Pods run as non-root (UID 472 — grafana user)
- No PVC — no persistent data on disk (DB stores everything)
- Prometheus metrics annotations for auto-scraping
- SMTP uses plain SMTP (port 25) — internal relay only

### Service Account Access

Grafana pods run as non-root UID 472. To exec into the pod:

```bash
kubectl exec -it -n grafana deploy/grafana -- /bin/bash
```

---

## File Structure

```
roles/kubernetes/frontend/grafana/
├── defaults/main.yml
├── tasks/
│   ├── main.yml              # Orchestrator
│   ├── validate.yml          # Pre-flight checks
│   ├── install.yml           # Namespace, secrets, deployment, LDAP, rollout
│   └── verify.yml            # Readiness check + status
├── templates/
│   ├── grafana-deployment.yaml.j2   # Secret + Deployment + Service + Ingress
│   └── grafana-ldap.yaml.j2        # LDAP ConfigMap (ldap.toml)
└── README.md
```

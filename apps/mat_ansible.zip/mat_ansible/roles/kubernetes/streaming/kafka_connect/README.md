# Kubernetes Kafka Connect (Strimzi) Role

Deploys Kafka Connect on Kubernetes using the Strimzi Operator. Supports deploying the Connect cluster itself and individual connector instances as `KafkaConnector` CRs. Inherits topology, rack awareness, and node affinity from the Kafka cluster by default.

## Latest Version

| Component | Check Latest |
|-----------|-------------|
| Strimzi Operator | [GitHub Releases](https://github.com/strimzi/strimzi-kafka-operator/releases) |
| Kafka Connect (bundled with Kafka) | [Apache Kafka Downloads](https://kafka.apache.org/downloads) |
| Debezium Connectors | [Debezium Releases](https://debezium.io/releases/) |
| Confluent JDBC Connector | [Confluent Hub](https://www.confluent.io/hub/confluentinc/kafka-connect-jdbc) |

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Strimzi Operator | Must be deployed (via `kubernetes_strimzi_kafka` playbook) | `kubectl get deployment strimzi-cluster-operator -n kafka` |
| Kafka Cluster | Must be in Ready state | `kubectl get kafka -n kafka` |
| Node labels | Kafka-designated nodes must be labelled | `kubectl get nodes -l node-role.kubernetes.io/kafka=true` |
| Harbor registry (for build) | Required only if using Strimzi Build feature | `kubectl get pods -n harbor` |

## How to Run

```bash
# Deploy Kafka Connect cluster (default action)
ansible-playbook -i inventories/bhrigu/pre_prod/hosts \
  playbook/kubernetes/kubernetes_kafka_connect.yaml \
  --vault-password-file .vault

# Deploy connectors (requires Connect cluster to be running)
KAFKA_CONNECT_ACTION=deploy_connector ansible-playbook \
  -i inventories/bhrigu/pre_prod/hosts \
  playbook/kubernetes/kubernetes_kafka_connect.yaml \
  --vault-password-file .vault

# With target host override
ansible-playbook -i inventories/bhrigu/pre_prod/hosts \
  playbook/kubernetes/kubernetes_kafka_connect.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kubernetes_master_zone2"
```

### Environment Variables

| Variable | Values | Default | Description |
|----------|--------|---------|-------------|
| `KAFKA_CONNECT_ACTION` | `install`, `deploy_connector` | `install` | Controls which action to run |

## Connector Lifecycle & Reconciliation

The `deploy_connector` action implements **full declarative reconciliation** — the cluster state is always brought into sync with what's defined in the inventory:

| Scenario | Behaviour |
|----------|-----------|
| New connector added to config | Created in cluster via `kubectl apply` |
| Existing connector config changed | Updated in-place — Strimzi reconciles (restarts tasks with new config) |
| Re-run with no changes | Idempotent — `kubectl apply` returns "unchanged", zero restarts |
| Connector removed from config | **Deleted from cluster** — the role detects stale CRs and removes them |
| Config list is empty (`connectors: []`) | All managed connectors are deleted from the cluster |

### How reconciliation works

1. Queries the cluster for all `KafkaConnector` CRs labelled with `strimzi.io/cluster=<connect-cluster-name>`
2. Compares the set of running connector names vs the names in `config_k8s.kafka_connect.connectors`
3. Applies desired connectors (create/update)
4. Deletes any connectors that exist in the cluster but are no longer in the config

A reconciliation plan is displayed before execution:

```
Kafka Connect Reconciliation Plan:
  Cluster:           bhrigu-kafka-cluster-connect
  Desired:           postgres-sink-analytics
  Currently running: postgres-sink-analytics, mysql-cdc-source
  To create/update:  postgres-sink-analytics
  To remove:         mysql-cdc-source
```

### Important notes

- Only connectors labelled with `strimzi.io/cluster=<connect-cluster-name>` are considered for removal. Connectors created manually with different labels are not touched.
- If you want to temporarily stop a connector without removing it from the cluster, use the `pause: true` field in the connector config rather than removing it from the list.
- Updating a connector's `config` section (e.g., changing `topics`, `connection.url`, or `tasks_max`) triggers a rolling reconfiguration by Strimzi — tasks are restarted with the new settings.

## Variable Reference

### Required (from inventory `config_kubernetes.yml`)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `config_k8s.kafka_connect.cluster_name` | Cluster name | `bhrigu-kafka-cluster-connect` | KafkaConnect CR name |
| `config_k8s.kafka_connect.replicas` | Replicas | `3` | Number of Connect workers |
| `config_k8s.kafka_connect.connectors` | Connector list | See below | List of KafkaConnector definitions |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `namespace` | Same as Kafka | K8s namespace |
| `bootstrap_servers` | Auto-derived from Kafka cluster | Bootstrap address |
| `image` | `''` (uses default Strimzi image) | Pre-built connector image |
| `build.enabled` | `false` | Enable Strimzi Build for custom connectors |
| `build.output_image` | `''` | Registry path for built image |
| `build.output_type` | `docker` | Build output type (`docker` or `imagestream`) |
| `build.plugins` | `[]` | List of connector plugins to include |
| `resources.requests.cpu` | `250m` | CPU request |
| `resources.requests.memory` | `1Gi` | Memory request |
| `resources.limits.cpu` | `1000m` | CPU limit |
| `resources.limits.memory` | `2Gi` | Memory limit |
| `topology.node_label_key` | Inherits from `kafka.topology` | Node affinity label key |
| `topology.rack_enabled` | Inherits from `kafka.topology` | Rack awareness |
| `metrics.enabled` | Inherits from `kafka.metrics` | JMX Prometheus exporter |
| `use_connector_resources` | `true` | Manage connectors via CRs (not REST API) |
| `timeouts.ready_timeout` | `300s` | Wait timeout for Connect ready |

## Inventory Configuration Example

Add to `config_kubernetes.yml` under `config_k8s:`:

```yaml
config_k8s:
  # ... existing kafka section ...

  # --- Kafka Connect (Strimzi) ---
  kafka_connect:
    cluster_name: bhrigu-kafka-cluster-connect
    replicas: 3
    # Option 1: Pre-built image with connectors baked in
    # image: "harbor.bhrigu-martini-preprod.nat.bt.com:61043/kafka-connect/custom:1.0"

    # Option 2: Let Strimzi build the image
    build:
      enabled: true
      output_image: "harbor.bhrigu-martini-preprod.nat.bt.com:61043/kafka-connect/bhrigu-connect:latest"
      output_type: docker
      plugins:
        - name: jdbc-sink
          artifacts:
            - type: maven
              group: io.confluent
              artifact: kafka-connect-jdbc
              version: "10.7.6"
        - name: debezium-mysql
          artifacts:
            - type: tgz
              url: "https://repo1.maven.org/maven2/io/debezium/debezium-connector-mysql/2.7.3.Final/debezium-connector-mysql-2.7.3.Final-plugin.tar.gz"
        - name: debezium-postgres
          artifacts:
            - type: tgz
              url: "https://repo1.maven.org/maven2/io/debezium/debezium-connector-postgres/2.7.3.Final/debezium-connector-postgres-2.7.3.Final-plugin.tar.gz"

    # Resources
    resources:
      requests:
        cpu: "250m"
        memory: "1Gi"
      limits:
        cpu: "1000m"
        memory: "2Gi"

    # Topology (defaults to kafka.topology if omitted)
    topology:
      node_label_key: node-role.kubernetes.io/kafka
      node_label_value: "true"
      topology_key: kubernetes.io/hostname
      max_skew: 1
      rack_enabled: false
      rack_topology_key: topology.kubernetes.io/region

    # Metrics
    metrics:
      enabled: true

    # Timeouts
    timeouts:
      ready_timeout: "300s"
      retries: 5
      delay: 30

    # Connectors (deployed via deploy_connector action)
    connectors:
      - name: mysql-sink-orders
        class: io.confluent.connect.jdbc.JdbcSinkConnector
        tasks_max: 3
        auto_restart:
          enabled: true
          max_restarts: 5
        config:
          topics: "orders,payments"
          connection.url: "jdbc:mysql://mysql-host:3306/analytics"
          connection.user: "connect_user"
          connection.password: "{{ kafka_connect_mysql_password }}"
          auto.create: "true"
          insert.mode: "upsert"
          pk.mode: "record_key"
          pk.fields: "id"
          table.name.format: "${topic}"

      - name: postgres-sink-events
        class: io.confluent.connect.jdbc.JdbcSinkConnector
        tasks_max: 2
        auto_restart:
          enabled: true
        config:
          topics: "events,audit-log"
          connection.url: "jdbc:postgresql://postgres-host:5432/warehouse"
          connection.user: "connect_user"
          connection.password: "{{ kafka_connect_pg_password }}"
          auto.create: "true"
          insert.mode: "insert"
          batch.size: "3000"
          table.name.format: "${topic}"
```

## Connector Configuration

Each connector in the `connectors` list supports:

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | KafkaConnector CR name (must be unique) |
| `class` | Yes | Fully qualified connector class name |
| `tasks_max` | No (default: 1) | Maximum parallel tasks |
| `auto_restart.enabled` | No (default: false) | Auto-restart on failure |
| `auto_restart.max_restarts` | No | Max restart attempts |
| `pause` | No (default: false) | Deploy in paused state (connector exists but doesn't run) |
| `config` | Yes | Key-value map of connector-specific config |

### Common Connector Classes

| Connector | Class | Plugin Source |
|-----------|-------|--------------|
| JDBC Sink | `io.confluent.connect.jdbc.JdbcSinkConnector` | Maven: `io.confluent:kafka-connect-jdbc` |
| JDBC Source | `io.confluent.connect.jdbc.JdbcSourceConnector` | Maven: `io.confluent:kafka-connect-jdbc` |
| Debezium MySQL (CDC) | `io.debezium.connector.mysql.MySqlConnector` | TGZ from Maven Central |
| Debezium PostgreSQL (CDC) | `io.debezium.connector.postgresql.PostgresConnector` | TGZ from Maven Central |
| File Stream Source | `org.apache.kafka.connect.file.FileStreamSourceConnector` | Built-in (no plugin needed) |
| File Stream Sink | `org.apache.kafka.connect.file.FileStreamSinkConnector` | Built-in (no plugin needed) |

## Topology & Multi-DC

Kafka Connect workers follow the same scheduling rules as Kafka brokers by default:

- **Node Affinity** — only scheduled on nodes with the configured label
- **Pod Anti-Affinity** — prefers spreading workers across different nodes (soft constraint)
- **Topology Spread** — distributes workers evenly across zones with configurable `maxSkew`
- **Rack Awareness** — when enabled, Connect workers know their rack/zone for local data preference

Override topology settings independently of the Kafka cluster by specifying them under `config_k8s.kafka_connect.topology`.

## Task Execution Flow

```
main.yml
├── validate.yml            Always runs — pre-flight checks, Kafka cluster ready
├── install.yml             Action: install — metrics ConfigMap + KafkaConnect CR + wait
├── deploy_connector.yml    Action: deploy_connector — reconcile connectors (apply desired + delete stale)
└── verify.yml              Always runs — status summary of pods and connectors
```

### deploy_connector detail

```
deploy_connector.yml
├── Verify KafkaConnect is Ready
├── Get existing connectors from cluster (kubectl get kafkaconnectors -l strimzi.io/cluster=...)
├── Compare existing vs desired (set_fact: connectors_to_remove)
├── Display reconciliation plan
├── Template + apply desired connectors (kubectl apply — idempotent)
├── Wait for each connector Ready
├── Delete stale connectors (kubectl delete — only those removed from config)
└── Cleanup temp files
```

## Post-Deployment Verification

```bash
# Check Connect cluster status
kubectl get kafkaconnect -n kafka

# Check connector status
kubectl get kafkaconnectors -n kafka

# Check connector tasks and state
kubectl get kafkaconnector <name> -n kafka -o jsonpath='{.status}'

# Check Connect worker logs
kubectl logs -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect --tail=50

# List connector plugins available in the Connect image
kubectl exec -n kafka $(kubectl get pod -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect -o name | head -1) -- \
  curl -s localhost:8083/connector-plugins | jq '.[].class'
```

## Troubleshooting

### Connect cluster stuck in NotReady

```bash
# Check operator logs
kubectl logs -n kafka deploy/strimzi-cluster-operator --tail=100 | grep -i connect

# Check Connect pod events
kubectl describe pod -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect
```

### Build fails (when using Strimzi Build)

```bash
# Check build pod logs
kubectl logs -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect,strimzi.io/kind=KafkaConnect,build=true

# Verify Harbor/registry is accessible from build pods
kubectl run test-registry --rm -i --tty --image=busybox -- \
  wget -O- https://bhrigu-martini-preprod.nat.bt.com:61043/v2/
```

### Connector in FAILED state

```bash
# Get connector status with error details
kubectl get kafkaconnector <name> -n kafka -o yaml | grep -A20 status

# Restart a connector (Strimzi will recreate all tasks)
kubectl annotate kafkaconnector <name> -n kafka strimzi.io/restart=true --overwrite

# Restart a specific task only
kubectl annotate kafkaconnector <name> -n kafka strimzi.io/restart-task=0 --overwrite
```

### Connector config not taking effect

If you update a connector's config but the change doesn't apply:

```bash
# Verify the CR was actually updated
kubectl get kafkaconnector <name> -n kafka -o yaml | grep -A50 config:

# Force Strimzi to re-reconcile
kubectl annotate kafkaconnector <name> -n kafka strimzi.io/restart=true --overwrite
```

### Checking Logs

```bash
# Connect worker logs (all pods)
kubectl logs -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect --tail=100

# Follow logs in real-time
kubectl logs -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect -f

# Errors only
kubectl logs -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect | grep -i error

# Specific connector task logs (filter by connector name in log output)
kubectl logs -n kafka -l strimzi.io/cluster=bhrigu-kafka-cluster-connect | grep "postgres-sink"
```

## File Structure

```
roles/kubernetes/streaming/kafka_connect/
├── defaults/main.yml                              # All variables with sources and defaults
├── tasks/
│   ├── main.yml                                   # Orchestrator — routes by kafka_connect_action
│   ├── validate.yml                               # Pre-flight checks (all actions)
│   ├── install.yml                                # Deploy KafkaConnect CR + wait
│   ├── deploy_connector.yml                       # Reconcile KafkaConnector CRs (apply + delete stale)
│   └── verify.yml                                 # Status summary (all actions)
├── templates/
│   ├── kafka-connect.yml.j2                       # KafkaConnect CR
│   ├── kafka-connect-metrics-configmap.yml.j2     # JMX exporter rules
│   └── kafka-connector.yml.j2                     # KafkaConnector CR (looped per connector)
└── README.md                                      # This file
```

## Security Notes

- Connector credentials (database passwords) should be stored in vault (`all_secrets.yml`) and referenced via `{{ variable }}` in the connector config
- The `strimzi.io/use-connector-resources` annotation means connectors can only be managed via CRs — the REST API is disabled for connector CRUD
- Connect workers run as non-root inside the Strimzi-managed container
- If using Strimzi Build with Harbor, ensure the build pod can push to the registry (Harbor robot account or pull secret configured as an image pull secret in the namespace)

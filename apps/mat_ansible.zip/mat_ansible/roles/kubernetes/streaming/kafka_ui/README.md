# Kubernetes Kafka UI (Kafbat) Role

Deploys Kafbat Kafka UI on Kubernetes — a web interface for managing Apache Kafka clusters. Supports multi-cluster, authentication, and role-based access control.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Kafbat UI** | https://github.com/kafbat/kafka-ui/releases | Defined in `version.kubernetes.kafka_ui` |
| **Container Image** | https://hub.docker.com/r/kafbat/kafka-ui/tags | `kafbat/kafka-ui` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ cluster running | `kubectl version` |
| **Kafka** | At least one Kafka cluster reachable from K8s pods | `kubectl exec -- kafkacat -L -b <bootstrap>` |
| **kubectl** | Available on master node | `which kubectl` |
| **ansible_user** | Has kubectl access | `sudo -u <user> --set-home kubectl get nodes` |
| **Vault secrets** | User passwords defined in `all_secrets.yml` | Check vault file |

---

## Features

- Multi-cluster management (single UI for all Kafka clusters)
- Authentication (login form with username/password)
- RBAC (per-cluster permissions: view, create, delete, produce)
- Topic management (create, delete, configure)
- Message browsing (view messages, produce test messages)
- Consumer group monitoring (lag, offsets)
- Health probes (liveness + readiness)
- NodePort for external access

## How It Works

Deploys as a single pod with:
- Deployment (1 replica)
- NodePort Service (external access)
- Configuration via environment variables

The UI connects to Kafka bootstrap servers (on-prem or K8s) and provides a web interface for management.

## Configuration

### app_configs.yml (under config.kubernetes)

```yaml
kafka_ui:
  namespace: kafka
  release_name: kafka-ui
  # Clusters (add as many as needed)
  clusters:
    - name: barista-test
      bootstrap_servers: "kafka-cluster-kafka-bootstrap.kafka.svc:9092"
      readonly: false
      disable_topic_delete: false
    - name: mat-fn-prod
      bootstrap_servers: "10.6.122.107:61000,10.6.122.108:61000,10.6.122.109:61000"
      readonly: true                    # Prod: view only
      disable_topic_delete: true        # Prevent accidental deletion
  # Authentication
  auth:
    enabled: true
    type: LOGIN_FORM
  # Users (passwords from vault)
  users:
    - username: admin
      role: admin
      password: "{{ kafka_ui_admin_password }}"
    - username: developer
      role: dev-readwrite
      password: "{{ kafka_ui_dev_password }}"
    - username: viewer
      role: readonly
      password: "{{ kafka_ui_viewer_password }}"
  # RBAC
  rbac:
    - name: admin
      clusters:
        - name: "*"
          permissions: [ALL]
    - name: dev-readwrite
      clusters:
        - name: barista-test
          permissions: [ALL]
        - name: mat-fn-prod
          permissions: [VIEW_TOPIC, VIEW_CONSUMER]
    - name: readonly
      clusters:
        - name: "*"
          permissions: [VIEW_TOPIC, VIEW_CONSUMER]
  # Resources (optional)
  resources:
    requests:
      cpu: "100m"
      memory: "256Mi"
    limits:
      cpu: "500m"
      memory: "512Mi"
```

### versions.yml
```yaml
version:
  kubernetes:
    kafka_ui: v1.3.0
```

### networks.yml
```yaml
ports:
  kubernetes:
    kafka_ui:
      service: 8080
      nodeport: 61070
```

### Vault secrets (all_secrets.yml)
```yaml
kafka_ui_admin_password: "<admin-password>"
kafka_ui_dev_password: "<dev-password>"
kafka_ui_viewer_password: "<viewer-password>"
```

## Cluster Config Options

| Option | Default | Description |
|--------|---------|-------------|
| `name` | (required) | Display name in UI |
| `bootstrap_servers` | (required) | Kafka bootstrap address |
| `readonly` | `false` | Disable all write operations |
| `disable_topic_delete` | `false` | Prevent topic deletion |
| `disable_topic_creation` | `false` | Prevent topic creation |
| `properties` | (optional) | Extra Kafka client properties (SSL, SASL) |

### Connecting to SSL-enabled Kafka

```yaml
clusters:
  - name: mat-fn-prod-ssl
    bootstrap_servers: "10.6.122.77:61008"
    properties:
      security.protocol: SSL
      ssl.truststore.location: /etc/kafka-ui/truststore.jks
      ssl.truststore.password: changeit
```

## RBAC Permissions

| Permission | What it allows |
|------------|---------------|
| `VIEW_TOPIC` | View topic list, config, partitions, messages |
| `CREATE_TOPIC` | Create new topics |
| `DELETE_TOPIC` | Delete topics |
| `EDIT_TOPIC` | Modify topic configuration (retention, partitions) |
| `VIEW_CONSUMER` | View consumer groups, lag, offsets |
| `DELETE_CONSUMER` | Delete/reset consumer groups |
| `PRODUCE_MESSAGE` | Send messages to topics |
| `VIEW_SCHEMA` | View Schema Registry schemas |
| `CREATE_SCHEMA` | Create/update schemas |
| `DELETE_SCHEMA` | Delete schemas |
| `VIEW_CONNECT` | View Kafka Connect connectors |
| `CREATE_CONNECT` | Create/update connectors |
| `DELETE_CONNECT` | Delete connectors |
| `VIEW_KSQL` | View ksqlDB queries |
| `EXECUTE_KSQL` | Execute ksqlDB statements |
| `VIEW_ACL` | View Kafka ACLs |
| `EDIT_ACL` | Create/modify ACLs |
| `ALL` | Full access (all above) |

### Common Role Examples

```yaml
# Admin — full access everywhere
- name: admin
  clusters:
    - name: "*"
      permissions: [ALL]

# Developer — full on test, read-only on prod
- name: developer
  clusters:
    - name: test-cluster
      permissions: [ALL]
    - name: prod-cluster
      permissions: [VIEW_TOPIC, VIEW_CONSUMER]

# Viewer — read-only everywhere
- name: readonly
  clusters:
    - name: "*"
      permissions: [VIEW_TOPIC, VIEW_CONSUMER]

# Ops — view + produce (for testing) but no delete
- name: ops
  clusters:
    - name: "*"
      permissions: [VIEW_TOPIC, VIEW_CONSUMER, PRODUCE_MESSAGE, EDIT_TOPIC]
```

## Running the Playbook

```bash
ansible-playbook -i inventories/barista/test/hosts playbook/kubernetes_kafka_ui.yaml --vault-password-file .vault
```

## Accessing

```
http://<any-node-ip>:61070
```

Login with credentials configured in `users` section.

## File Structure

```
roles/kubernetes/kafka_ui/
├── defaults/main.yml              # All variables
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── deploy.yml                 # Template + kubectl apply
│   └── verify.yml                 # Wait + status
├── templates/
│   └── kafka-ui.yaml.j2          # Deployment + Service + ConfigMap
└── README.md
```

## Migrating from Kafdrop

Kafbat UI replaces Kafdrop with:
- Multi-cluster support (Kafdrop: single cluster)
- Built-in auth + RBAC (Kafdrop: no auth)
- Per-cluster read-only mode (Kafdrop: all or nothing)
- Active development (Kafdrop: maintenance mode)
- Message production/consumption (Kafdrop: view only)

Same NodePort access pattern — just update port in HAProxy/DNS.

---

## Upgrade Process

1. Update `version.kubernetes.kafka_ui` in `versions.yml`
2. Re-run the playbook — `kubectl apply` updates the Deployment image tag
3. Pod restarts with new version automatically
4. User sessions are reset (stateless — users re-login)

---

## Post-Deployment Verification

```bash
# 1. Pod running
kubectl get pods -n kafka -l app=kafka-ui

# 2. Service accessible
curl -s -o /dev/null -w "%{http_code}" http://<node-ip>:61070
# Expected: 200 or 401 (auth enabled)

# 3. Check pod logs
kubectl logs -n kafka -l app=kafka-ui --tail=20
```

---

## Troubleshooting

### Pod CrashLoopBackOff

```bash
kubectl logs -n kafka -l app=kafka-ui --tail=30
# Common: Kafka unreachable, invalid cluster config, wrong bootstrap address
```

### Login fails

- Verify passwords match vault values
- Check environment variables in deployment: `kubectl get deploy kafka-ui -n kafka -o yaml | grep -A1 SPRING_SECURITY`

### Cannot connect to Kafka cluster

```bash
# From inside the pod — test connectivity
kubectl exec -n kafka deploy/kafka-ui -- curl -v telnet://<bootstrap>:<port>
```

---

## Security Notes

- Authentication via LOGIN_FORM (credentials in environment variables, sourced from vault)
- RBAC per cluster per user — granular permission control
- No TLS by default on NodePort — run behind ingress/HAProxy for HTTPS
- User passwords set via environment variables (not ConfigMap) — `no_log: true` on credential tasks
- Stateless — no persistent data (all config is from environment variables)

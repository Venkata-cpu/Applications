# Kubernetes Kafka (Strimzi) Role

Deploys Apache Kafka on Kubernetes using the Strimzi Operator with KRaft mode (no ZooKeeper).

## Components Deployed

- Strimzi Kafka Operator (via Helm)
- KafkaNodePool: Controllers (KRaft metadata quorum)
- KafkaNodePool: Brokers (data handling)
- Kafka CR with internal + external (NodePort) listeners
- Entity Operator (Topic + User management)
- JMX Prometheus metrics exporter (optional)

## Prerequisites

- Kubernetes cluster (1.30+)
- Helm installed on the control node
- `kubernetes.core` Ansible collection installed (`ansible-galaxy collection install kubernetes.core`)
- Longhorn StorageClass (or any configured StorageClass)
- Nodes labeled for Kafka scheduling (see below)
- `http_proxy` and `https_proxy` defined in global secrets/variables

## Node Labeling

Before running the playbook, label the nodes where Kafka pods should run:

```bash
kubectl label node <node-name> node-role.kubernetes.io/kafka=true
```

The label key and value are configurable via:
```yaml
topology:
  node_label_key: node-role.kubernetes.io/kafka
  node_label_value: "true"
```

## Single Data Center Configuration

For a single DC, pods are spread across individual nodes (one broker per node):

```yaml
config:
  kubernetes:
    kafka:
      broker_replicas: 3
      controller_replicas: 3
      topology:
        node_label_key: node-role.kubernetes.io/kafka
        node_label_value: "true"
        topology_key: kubernetes.io/hostname
        max_skew: 1
        rack_enabled: false
```

Node labeling:
```bash
kubectl label node worker-1 node-role.kubernetes.io/kafka=true
kubectl label node worker-2 node-role.kubernetes.io/kafka=true
kubectl label node worker-3 node-role.kubernetes.io/kafka=true
```

This ensures:
- Kafka pods only run on labeled nodes
- No two broker pods on the same node
- No two controller pods on the same node

## Multi Data Center Configuration

For multi-DC, pods are spread evenly across zones and Kafka becomes rack-aware (partition replicas distributed across DCs):

```yaml
config:
  kubernetes:
    kafka:
      broker_replicas: 5
      controller_replicas: 3
      topology:
        node_label_key: node-role.kubernetes.io/kafka
        node_label_value: "true"
        topology_key: topology.kubernetes.io/zone
        max_skew: 1
        rack_enabled: true
        rack_topology_key: topology.kubernetes.io/zone
```

Node labeling (assign nodes to zones):
```bash
# DC1 nodes
kubectl label node worker-1 node-role.kubernetes.io/kafka=true
kubectl label node worker-1 topology.kubernetes.io/zone=dc1

# DC2 nodes
kubectl label node worker-3 node-role.kubernetes.io/kafka=true
kubectl label node worker-3 topology.kubernetes.io/zone=dc2

# DC3 nodes
kubectl label node worker-5 node-role.kubernetes.io/kafka=true
kubectl label node worker-5 topology.kubernetes.io/zone=dc3
```

### How pods distribute across DCs

| Brokers | DC1 | DC2 | DC3 | Skew |
|---------|:---:|:---:|:---:|:----:|
| 3       | 1   | 1   | 1   | 0    |
| 5       | 2   | 2   | 1   | 1    |
| 6       | 2   | 2   | 2   | 0    |

### Rack Awareness

When `rack_enabled: true`, Kafka becomes aware of which DC/rack each broker is in via `broker.rack` configuration. This ensures partition replicas are distributed across different DCs for fault tolerance.

**When it matters:** Rack awareness is only relevant when you have **more brokers than the replication factor**. For example, with 6 brokers across 2 DCs and `replication_factor: 3`, without rack awareness Kafka could place all 3 replicas in the same DC. With rack awareness, it guarantees cross-DC distribution.

**When it doesn't matter:** If you have exactly 3 brokers and `replication_factor: 3`, every broker already gets one replica — there's no choice to make. Rack awareness adds no value in this case.

| Brokers | Replication Factor | Rack Awareness Needed? |
|---------|-------------------|------------------------|
| 3 | 3 | No — replicas already on all brokers |
| 5+ | 3 | Yes — prevents replicas clustering in one DC |
| 6 (3 per DC) | 3 | Yes — ensures cross-DC placement |

## Proxy Configuration (Important)

If your environment uses an HTTP proxy for outbound traffic, you must configure `no_proxy` correctly. The Kafka role uses `kubectl` and Helm which make API calls to the Kubernetes API server. If the K8s API hostname/IP is not in `no_proxy`, these calls will be routed through the proxy and fail.

```yaml
config:
  kubernetes:
    kafka:
      no_proxy: "localhost,127.0.0.1,.svc,.cluster.local,10.13.0.0/16,.nat.bt.com"
```

The `no_proxy` value must include:
- `localhost,127.0.0.1` — loopback
- `.svc,.cluster.local` — Kubernetes internal DNS
- Your K8s API server IP/subnet (e.g., `10.13.0.0/16`)
- Any internal DNS domain your cluster uses (e.g., `.nat.bt.com`)

`http_proxy` and `https_proxy` must be defined in global secrets/variables. The playbook will fail if they are not defined.

## Metrics and Monitoring

When `metrics.enabled: true` (default), Strimzi injects a JMX Prometheus exporter sidecar into each Kafka pod. Metrics are exposed on port 9404.

### Prometheus Integration

Add the following scrape job to your Prometheus configuration. The template is available at `templates/kafka-prometheus-scrape.yml.j2`:

```yaml
scrape_configs:
  - job_name: 'strimzi-kafka'
    kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
            - kafka
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_label_strimzi_io_cluster]
        action: keep
        regex: kafka-cluster
      - source_labels: [__meta_kubernetes_pod_container_port_name]
        action: keep
        regex: tcp-prometheus
      - source_labels: [__meta_kubernetes_namespace]
        target_label: namespace
      - source_labels: [__meta_kubernetes_pod_name]
        target_label: pod
```

Prometheus auto-discovers Kafka pods via the Kubernetes API. No static IPs needed.

### Key Metrics to Watch

| Metric | What it tells you |
|--------|-------------------|
| `kafka_server_replicamanager_underreplicatedpartitions` | Partitions with insufficient replicas (should be 0) |
| `kafka_server_replicamanager_isrshrinkspersec_total` | ISR shrinking rate (indicates broker issues) |
| `kafka_server_brokertopicmetrics_messagesinpersec_total` | Ingestion rate per topic |
| `kafka_server_brokertopicmetrics_bytesinpersec_total` | Throughput per topic |
| `kafka_network_socketserver_networkprocessoravgidlepercent` | Network thread utilization |
| `jvm_memory_heap_used_bytes` | JVM heap usage per broker |

## Kafka Configuration Settings Reference

All settings are configurable via `config.kubernetes.kafka` in `app_configs.yml`. Settings with defaults can be omitted — they'll use the default value.

### Replication & Durability

| Setting | Default | Impact |
|---------|---------|--------|
| `default_replication_factor` | 3 | Number of copies of each partition. Higher = more durable but uses more disk. Must be ≤ number of brokers. |
| `min_insync_replicas` | 2 | Minimum replicas that must acknowledge a write. If fewer replicas are in-sync, producers get errors. Set to `replication_factor - 1` for balance between durability and availability. |
| `transaction_state_log_replication_factor` | 3 | Replication for internal transaction log. Should match or exceed `default_replication_factor`. |
| `transaction_state_log_min_isr` | 2 | Min ISR for transaction log. If using exactly-once semantics, this must be ≥ 2. |

### Partitions & Retention

| Setting | Default | Impact |
|---------|---------|--------|
| `default_num_partitions` | 3 | Default partitions per new topic. More partitions = more parallelism for consumers but more files on disk and longer leader elections. |
| `log_retention_hrs` | 6 | How long data is kept. Increasing means more disk usage. Decreasing means consumers must keep up or lose data. |
| `log_segment_bytes` | 1073741824 (1GB) | Size of each log segment file. Smaller = more frequent file rolls and faster cleanup of old data. Larger = fewer files but slower cleanup. |
| `log_cleanup_policy` | delete | `delete` removes old segments by time/size. `compact` keeps latest value per key (useful for changelogs). `delete,compact` does both. |

### Message Size

| Setting | Default | Impact |
|---------|---------|--------|
| `message_max_bytes` | 10485760 (10MB) | Maximum size of a single message. If a producer sends a larger message, it's rejected. Setting too high risks OOM if many large messages arrive simultaneously. |
| `replica_fetch_max_bytes` | 10485760 (10MB) | Must be ≥ `message_max_bytes`. If smaller, replication breaks for large messages. |
| `socket_request_max_bytes` | 104857600 (100MB) | Max size of a request the broker accepts (includes batch of messages). Protects against malformed/oversized requests. |

### Performance & Threading

| Setting | Default | Impact |
|---------|---------|--------|
| `num_network_threads` | 3 | Threads handling network I/O (reading requests, sending responses). Increase if you see high network wait times. Each thread handles multiple connections. |
| `num_io_threads` | 8 | Threads handling disk I/O (reading/writing to log segments). Increase if I/O wait is high. Should roughly match number of disks. |
| `num_replica_fetchers` | 1 | Threads each broker uses to replicate from leaders. Increase if replication lag is high with many partitions. Too many can overwhelm the leader. |
| `socket_send_buffer_bytes` | 102400 (100KB) | TCP send buffer. Increase for high-throughput, high-latency networks. Set to -1 for OS default. |
| `socket_receive_buffer_bytes` | 102400 (100KB) | TCP receive buffer. Same guidance as send buffer. |

### Consumer Groups

| Setting | Default | Impact |
|---------|---------|--------|
| `group_initial_rebalance_delay_ms` | 3000 (3s) | How long the coordinator waits for consumers to join before starting the first rebalance. Higher = fewer rebalances during rolling deploys. Lower = faster initial consumption start. |

## Variable Reference

### versions.yml
```yaml
version:
  kubernetes:
    kafka:
      version: 4.2.0
      operator: 1.0.0
```

### networks.yml
```yaml
ports:
  kubernetes:
    kafka:
      nodeport_base: 61061
      internal: 9092
      external: 9094
      metrics: 9404
```

### app_configs.yml (under config.kubernetes)
```yaml
kafka:
  # Core
  namespace: kafka
  cluster_name: kafka-cluster
  # Replicas
  broker_replicas: 3
  controller_replicas: 3
  # Storage
  storage_class: longhorn
  broker_storage_size: 10Gi
  controller_storage_size: 4Gi
  # Listeners
  listeners:
    internal_tls: false
    external_tls: false
  # Resources
  resources:
    broker:
      requests:
        cpu: "500m"
        memory: "2Gi"
      limits:
        cpu: "2000m"
        memory: "4Gi"
    controller:
      requests:
        cpu: "250m"
        memory: "1Gi"
      limits:
        cpu: "1000m"
        memory: "2Gi"
  # Kafka Config (required)
  default_replication_factor: 3
  min_insync_replicas: 2
  default_num_partitions: 3
  log_retention_hrs: 6
  # Kafka Config (optional — defaults used if omitted)
  # message_max_bytes: 10485760
  # replica_fetch_max_bytes: 10485760
  # log_segment_bytes: 1073741824
  # log_cleanup_policy: delete
  # num_network_threads: 3
  # num_io_threads: 8
  # num_replica_fetchers: 1
  # socket_send_buffer_bytes: 102400
  # socket_receive_buffer_bytes: 102400
  # socket_request_max_bytes: 104857600
  # transaction_state_log_replication_factor: 3
  # transaction_state_log_min_isr: 2
  # group_initial_rebalance_delay_ms: 3000
  # Node Pool Names
  broker_pool_name: broker-pool
  controller_pool_name: controller-pool
  # Topology & Affinity
  topology:
    node_label_key: node-role.kubernetes.io/kafka
    node_label_value: "true"
    topology_key: kubernetes.io/hostname
    max_skew: 1
    rack_enabled: false
    rack_topology_key: topology.kubernetes.io/zone
  # Metrics
  metrics:
    enabled: true
  # Proxy
  no_proxy: "localhost,127.0.0.1,.svc,.cluster.local"
  # Helm (override only if using private registry/mirror)
  # helm:
  #   repo_name: strimzi
  #   repo_url: https://strimzi.io/charts/
  #   release_name: strimzi
  #   chart_name: strimzi/strimzi-kafka-operator
  # Timeouts (override only if needed)
  # timeouts:
  #   cluster_ready: "600s"
  #   operator_retries: 10
  #   operator_delay: 20
  #   cluster_retries: 5
  #   cluster_delay: 30
```

## Running the Playbook

```bash
# Install
ansible-playbook -i inventories/barista/pre_prod/hosts playbook/kubernetes/kubernetes_strimzi_kafka.yaml --vault-password-file .vault

# With target host override
ansible-playbook -i inventories/barista/pre_prod/hosts playbook/kubernetes/kubernetes_strimzi_kafka.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kubernetes_master_zone2"
```

## Pre-flight Validations

The role runs automated checks before deploying. If any check fails, the playbook stops with a clear error message:

| Check | Rule | Why |
|-------|------|-----|
| Broker replicas vs replication factor | `broker_replicas >= default_replication_factor` | Can't replicate to more brokers than exist |
| Min ISR vs replication factor | `min_insync_replicas < default_replication_factor` | If equal, one broker down = all writes fail |
| Controller replicas odd | `controller_replicas` is 1, 3, or 5 | KRaft quorum requires odd number for leader election |
| Fetch size vs message size | `replica_fetch_max_bytes >= message_max_bytes` | Otherwise replication breaks for large messages |
| Minimum brokers | `broker_replicas >= 3` | Less than 3 means no fault tolerance |
| Node label defined | `node_label_key` is not empty | Empty means no node targeting, pods go anywhere |

## How It Works

1. **Validate** (`validate.yml`) — pre-flight checks on all critical config values
2. **Operator** (`operator.yml`) — adds Helm repo, installs/upgrades Strimzi operator, waits for readiness
3. **Deploy** (`deploy.yml`) — creates controller pool, broker pool, metrics ConfigMap, Kafka CR, waits for cluster Ready

## File Structure

```
roles/kubernetes/streaming/kafka/
├── defaults/main.yml                         # All variables with sources and defaults
├── tasks/
│   ├── main.yml                              # Orchestrator — imports validate, operator, deploy
│   ├── validate.yml                          # Pre-flight config validation (6 checks)
│   ├── operator.yml                          # Helm repo + install operator + wait
│   └── deploy.yml                            # Node pools + metrics + Kafka CR + wait
├── templates/
│   ├── kafka-values.yml.j2                   # Kafka CR (cluster config)
│   ├── kafka-broker.yml.j2                   # Broker KafkaNodePool
│   ├── kafka-controller.yml.j2              # Controller KafkaNodePool
│   ├── kafka-metrics-configmap.yml.j2       # JMX exporter rules
│   └── kafka-prometheus-scrape.yml.j2       # Prometheus scrape job (reference)
└── README.md                                 # This file
```

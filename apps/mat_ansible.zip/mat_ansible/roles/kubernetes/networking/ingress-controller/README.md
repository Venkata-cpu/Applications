# Kubernetes HAProxy Ingress Controller Role

Deploys [HAProxy Ingress Controller](https://www.haproxy.com/documentation/kubernetes-ingress/) on Kubernetes via Helm. Uses the official HAProxy Technologies chart. Routes external HTTP/HTTPS traffic to internal K8s services based on Ingress resources. Runs as a DaemonSet with hostPort by default — binds directly to ports 80/443 on every node.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **HAProxy Ingress Controller (Helm chart)** | https://github.com/haproxytech/helm-charts/releases | `1.52.0` |
| **Helm Repo** | https://haproxytech.github.io/helm-charts | `haproxytech/kubernetes-ingress` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ cluster running | `kubectl get nodes` |
| **Helm** | 3.x installed on master | `helm version` |
| **Proxy** | For Helm chart download | `all_secrets.yml` |
| **Ports 80/443** | Free on all nodes (for hostPort mode) | `ss -tlnp \| grep ':80\|:443'` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes-ingress-controller.yaml \
  --vault-password-file .vault
```

---

## Architecture

```
External Traffic → Node IP:80/443 → HAProxy Pod (hostPort) → K8s Service → Pod
```

With DaemonSet + hostPort, every node runs one ingress controller pod bound directly to ports 80 and 443. No LoadBalancer or NodePort needed — traffic goes straight to the pod.

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.ingress_controller` | `1.52.0` | Helm chart version |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `config.kubernetes.ingress_controller.namespace` | `ingress-controller` | K8s namespace |
| `config.kubernetes.ingress_controller.release_name` | `haproxy-ingress` | Helm release name |
| `config.kubernetes.ingress_controller.kind` | `DaemonSet` | `DaemonSet` or `Deployment` |
| `config.kubernetes.ingress_controller.use_host_port` | `true` | Bind to node ports 80/443 |
| `config.kubernetes.ingress_controller.timeouts.client` | `5m` | Max wait for client data |
| `config.kubernetes.ingress_controller.timeouts.server` | `5m` | Max wait for backend response |
| `config.kubernetes.ingress_controller.timeouts.connect` | `10s` | Max connection establish time |
| `config.kubernetes.ingress_controller.resources.requests.cpu` | `100m` | CPU request per pod |
| `config.kubernetes.ingress_controller.resources.requests.memory` | `256Mi` | Memory request per pod |
| `config.kubernetes.ingress_controller.resources.limits.cpu` | `500m` | CPU limit per pod |
| `config.kubernetes.ingress_controller.resources.limits.memory` | `512Mi` | Memory limit per pod |
| `config.kubernetes.ingress_controller.no_proxy` | `localhost,...` | No-proxy list |
| `config.kubernetes.ingress_controller.wait_retries` | `10` | Verification retries |
| `config.kubernetes.ingress_controller.wait_delay` | `15` | Delay between retries (seconds) |

---

## Deployment Modes

### DaemonSet + hostPort (Default — on-prem/bare-metal)

Every node gets one ingress pod bound to ports 80/443. External LB or DNS points to node IPs.

```yaml
config:
  kubernetes:
    ingress_controller:
      kind: DaemonSet
      use_host_port: true
```

### Deployment + NodePort (Cloud or scaled replicas)

Only N replicas, exposed via NodePort. Use when you don't want every node running ingress.

```yaml
config:
  kubernetes:
    ingress_controller:
      kind: Deployment
      use_host_port: false
```

| Mode | Use Case |
|------|----------|
| **DaemonSet + hostPort** | On-prem, bare-metal, every node reachable |
| **Deployment + NodePort** | Cloud, or limited ingress nodes |

---

## What Gets Deployed

```
Namespace: ingress-controller
├── DaemonSet/haproxy-ingress   # HAProxy pods (one per node)
├── ConfigMap/haproxy-ingress-kubernetes-ingress  # Timeout settings
└── Service/haproxy-ingress     # ClusterIP (internal routing)
```

---

## Task Execution Flow

```
main.yaml
├── install.yml      # Add helm repo, deploy chart, wait
├── configure.yml    # Patch ConfigMap with timeout settings
└── verify.yml       # Wait for pods ready, display status
```

---

## Timeout Configuration

After deployment, the role patches the HAProxy ConfigMap with timeout values:

| Setting | Default | Description |
|---------|---------|-------------|
| `timeout-client` | `5m` | How long to wait for client to send request |
| `timeout-server` | `5m` | How long to wait for backend to respond |
| `timeout-connect` | `10s` | How long to wait to establish backend connection |

These can be tuned for long-running connections (WebSocket, streaming) or tightened for API traffic.

---

## Upgrade Process

1. Update `version.kubernetes.ingress_controller` in `versions.yml`
2. Re-run playbook — `helm upgrade --install` performs rolling update
3. If upgrade fails: `helm rollback haproxy-ingress -n ingress-controller`

---

## Post-Deployment Verification

```bash
# 1. Pods running (one per node in DaemonSet mode)
kubectl get pods -n ingress-controller -o wide

# 2. Ports bound on nodes
ss -tlnp | grep ':80\|:443'

# 3. Test routing (create a test ingress)
kubectl create deployment test --image=nginx
kubectl expose deployment test --port=80
kubectl create ingress test --rule="test.local/=test:80"
curl -H "Host: test.local" http://<node-ip>

# 4. Check ConfigMap (timeout values)
kubectl get configmap -n ingress-controller haproxy-ingress-kubernetes-ingress -o yaml
```

---

## Troubleshooting

### Checking Logs

```bash
# Pod logs (last 50 lines)
kubectl logs -n ingress-controller -l app.kubernetes.io/name=kubernetes-ingress --tail=50

# Follow live
kubectl logs -n ingress-controller -l app.kubernetes.io/name=kubernetes-ingress -f

# Events
kubectl get events -n ingress-controller --sort-by='.lastTimestamp'
```

### Pods not starting
```bash
kubectl describe pod -n ingress-controller <pod-name>
# Common: port 80/443 already in use, image pull failure
```

### Port 80/443 already in use
```bash
ss -tlnp | grep ':80\|:443'
# Solution: stop conflicting service or switch to Deployment + NodePort mode
```

### Ingress not routing
```bash
kubectl get ingress -A
kubectl describe ingress <name> -n <namespace>
# Check HAProxy logs for connection errors
```

### Helm release issues
```bash
helm status haproxy-ingress -n ingress-controller
helm get values haproxy-ingress -n ingress-controller
helm history haproxy-ingress -n ingress-controller
```

---

## Security Notes

- DaemonSet runs with hostPort — pods have direct network access on 80/443
- No TLS termination by default — configure via Ingress TLS secrets per service
- Helm values written to temp file with mode `0600`, deleted after deploy
- Proxy-aware for chart download

---

## File Structure

```
roles/kubernetes/networking/ingress-controller/
├── defaults/main.yml              # All variables with defaults
├── tasks/
│   ├── main.yaml                  # Orchestrator
│   ├── install.yml                # Helm repo + deploy
│   ├── configure.yml              # Patch timeouts in ConfigMap
│   └── verify.yml                 # Wait for pods + display status
├── templates/
│   └── values.yaml.j2            # Helm chart values
└── README.md                      # This file
```

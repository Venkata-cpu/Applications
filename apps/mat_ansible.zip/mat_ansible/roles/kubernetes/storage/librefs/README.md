# libreFS on Kubernetes Role

Deploys libreFS (community MinIO fork) as a distributed object storage cluster on Kubernetes using raw manifests. Uses local persistent volumes (hostPath) on designated worker nodes to avoid circular dependency with Longhorn. Provides S3-compatible API for Longhorn backup and general object storage.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **libreFS Server** | https://github.com/orgs/librefs/packages/container/package/librefs | Check `version.kubernetes.librefs.server` |
| **Website** | https://librefs.org | Release notes and docs |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ | `kubectl version` |
| **Worker nodes** | 4+ nodes with local disk for data | `kubectl get nodes` |
| **hostPath dir** | Auto-created by role on worker nodes | `ls -la /apps/librefs_data` |
| **Node labels** | Target nodes labeled for affinity (optional) | `kubectl get nodes --show-labels` |
| **Vault secret** | `k8s_librefs_root_password_vault` defined | In `all_secrets.yml` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_librefs.yaml \
  --vault-password-file .vault
```

---

## Web Console (UI)

libreFS includes a web management console exposed via NodePort.

**Access:** `http://<any-worker-node>:<console_nodeport>` (default: `61006`)
**Login:** Use root credentials from vault

**Features:** Browse/create buckets, manage users/policies, monitor health, configure lifecycle rules.

**NOTE:** Buckets are created via the Console UI after deployment — not managed by Ansible.

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.librefs.server` | `RELEASE.2026-05-04T00-42-47Z` | libreFS image tag |
| `all_secrets.yml` | `k8s_librefs_root_password_vault` | (vault encrypted) | Root password |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.librefs.namespace` | `librefs` | K8s namespace | |
| `config_k8s.librefs.release_name` | `librefs` | StatefulSet name | |
| `config_k8s.librefs.worker_node_hosts` | `kubernetes_worker` | Inventory group for worker nodes | Used for hostPath dir creation |
| `config_k8s.librefs.mode` | `distributed` | `single-node` or `distributed` | `distributed` requires 4+ replicas |
| `config_k8s.librefs.replicas` | `4` | StatefulSet replicas | Must be 1 or >= 4 |
| `config_k8s.librefs.host_path` | `/apps/librefs_data` | Local path on worker nodes | Auto-created by role. Actual disk usage is unlimited — use LVM/partition for hard limits |
| `config_k8s.librefs.root_user` | `admin` | S3 access key / console login | |
| `config_k8s.librefs.image` | `ghcr.io/librefs/librefs` | Server container image | |
| `ports.kubernetes.librefs.api` | `9000` | Internal API port | |
| `ports.kubernetes.librefs.console` | `9001` | Internal console port | |
| `ports.kubernetes.librefs.api_nodeport` | `61005` | S3 API NodePort | |
| `ports.kubernetes.librefs.console_nodeport` | `61006` | Console NodePort | |
| `config_k8s.librefs.topology.node_label_key` | `''` | Node affinity label key | Empty = no affinity |
| `config_k8s.librefs.topology.node_label_value` | `''` | Node affinity label value | |
| `config_k8s.librefs.topology.zone_spread_enabled` | `false` | Enable zone-aware pod spreading | `true` = topologySpreadConstraints added |
| `config_k8s.librefs.topology.zone_label_key` | `topology.kubernetes.io/zone` | Zone label for topology spread | Must match labels on nodes |
| `config_k8s.librefs.topology.zone_max_skew` | `1` | Max pod imbalance between zones | `1` = even spread, `2` = allow slight imbalance |
| `config_k8s.librefs.resources.requests_cpu` | `250m` | CPU request | |
| `config_k8s.librefs.resources.requests_memory` | `512Mi` | Memory request | |
| `config_k8s.librefs.resources.limits_cpu` | `2000m` | CPU limit | |
| `config_k8s.librefs.resources.limits_memory` | `2Gi` | Memory limit | |
| `config_k8s.librefs.wait_retries` | `30` | Verification retries | |
| `config_k8s.librefs.wait_delay` | `10` | Delay between retries (seconds) | |

---

## What Gets Deployed

```
Namespace: librefs
├── StorageClass/librefs-local             # No provisioner, WaitForFirstConsumer
├── PersistentVolume/librefs-pv-{0..N}     # One per worker node (local path)
├── Secret/librefs-credentials             # rootUser + rootPassword
├── Service/librefs-headless (ClusterIP:None) # StatefulSet DNS
├── Service/librefs (NodePort)             # External access (API + Console)
└── StatefulSet/librefs                    # libreFS server pods
    └── Pod/librefs-{0..N}                 # Each with local PV
```

---

## Deployment Modes

### Distributed (Production) — default

Erasure coding across 4+ replicas. Survives loss of up to N/2 nodes.

| Replicas | Parity | Can Lose | Usable % of raw |
|----------|--------|----------|-----------------|
| 4 | 2 | 2 nodes | ~50% |
| 5 | 2 | 2 nodes | ~60% |
| 6 | 3 | 3 nodes | ~67% |

### Single-Node (Test only)

```yaml
config_k8s:
  librefs:
    mode: single-node
    replicas: 1
```

---

## Zone-Aware Pod Spreading (Multi-Rack / Multi-DC)

For clusters spanning multiple racks or datacenters on the same network, libreFS pods can be spread across zones to ensure a single rack/DC failure doesn't take out more erasure-coded shards than the cluster can tolerate.

### How to Enable

Nodes must be pre-labelled with `topology.kubernetes.io/zone` (either manually, via the `label_management` role, or via Longhorn's zone config which uses the same label).

```yaml
config_k8s:
  librefs:
    topology:
      node_label_key: storage
      node_label_value: "true"
      zone_spread_enabled: true
      zone_label_key: topology.kubernetes.io/zone  # optional, this is the default
      zone_max_skew: 1                             # optional, default 1
```

### What it Does

Adds `topologySpreadConstraints` to the StatefulSet:
- **`maxSkew: 1`** — at most 1 pod difference between zones (even distribution)
- **`whenUnsatisfiable: ScheduleAnyway`** — soft constraint, won't block scheduling if perfect balance isn't achievable
- **`topologyKey: topology.kubernetes.io/zone`** — groups nodes by zone label

### Behaviour

| Replicas | Zones | Distribution |
|----------|-------|--------------|
| 4 | dc1, dc2 | 2 pods per zone |
| 5 | dc1, dc2 | 3 in one, 2 in the other |
| 6 | dc1, dc2, dc3 | 2 per zone |

### Erasure Coding + Zone Spread

With distributed mode and zone spread:
- 4 replicas across 2 zones → can tolerate 1 full zone failure (2 parity shards)
- 6 replicas across 2 zones → can tolerate 1 full zone failure (3 parity shards)
- This is the recommended production setup for multi-rack environments

---

## Task Execution Flow

```
main.yml
├── prerequisites.yml  # Create data directory on worker nodes (delegate_to)
├── validate.yml       # Version, password, replicas/mode coherence, kubectl available
├── install.yml        # Namespace, secret, local PVs, StorageClass, StatefulSet, wait
└── verify.yml         # Rollout status, pod health, service listing
```

---

## Longhorn Integration

After deployment, configure Longhorn backup target via the Longhorn UI:

1. Create a bucket in libreFS Console UI (e.g., `longhorn-backup`)
2. In Longhorn UI → Settings → Backup Target:
   - URL: `s3://longhorn-backup@us-east-1/`
   - Secret: Create `longhorn-backup-credentials` in `longhorn-system` namespace with:
     ```
     AWS_ACCESS_KEY_ID=<librefs_root_user>
     AWS_SECRET_ACCESS_KEY=<librefs_root_password>
     AWS_ENDPOINTS=http://librefs-headless.librefs.svc:9000
     ```

---

## Upgrade Process

1. Update `version.kubernetes.librefs.server` in `versions.yml`
2. Re-run playbook — `kubectl apply` updates the StatefulSet image tag
3. Pods restart in rolling fashion (one at a time via StatefulSet update strategy)
4. Data on local volumes is never touched

---

## Post-Deployment Verification

```bash
# 1. Pod status
kubectl get pods -n librefs -o wide

# 2. Service endpoints
kubectl get svc -n librefs

# 3. Health check (from any cluster node)
curl -s http://<node-ip>:61005/minio/health/live
# Expected: 200 OK

# 4. Cluster health (distributed mode)
curl -s http://<node-ip>:61005/minio/health/cluster
# Expected: 200 OK

# 5. Console UI
# Open in browser: http://<node-ip>:61006
# Login: admin / <vault password>
```

---

## Troubleshooting

### Checking Logs

```bash
# Pod logs
kubectl logs -n librefs librefs-0 --tail=50

# All pods
kubectl logs -n librefs -l app=librefs --tail=20

# Events
kubectl get events -n librefs --sort-by='.lastTimestamp'
```

### Pods stuck in Pending
```bash
kubectl describe pod -n librefs librefs-0
# Common: PV not bound, node affinity not matching, hostPath dir missing
```

### Pods in Error
```bash
kubectl logs -n librefs librefs-0
# Common: wrong binary command, credentials mismatch, port conflict
```

### PVCs unbound
```bash
kubectl get pvc -n librefs
kubectl get pv -l app=librefs
# Check storageClass matches and node affinity aligns
```

---

## Security Notes

- Credentials stored in vault-encrypted secrets, deployed as K8s Secret
- Secret created with `--dry-run=client | kubectl apply` (idempotent)
- No SSL by default (designed to run behind ingress/SSL-terminating proxy)
- Container images pulled from `ghcr.io/librefs/librefs` (GitHub Container Registry)
- `no_log: true` on all tasks handling credentials
- Pods run as non-root (UID 1000)
- No telemetry — libreFS is community-governed with no phone-home
- AGPL-3.0 licensed — free forever

---

## File Structure

```
roles/kubernetes/storage/librefs/
├── defaults/main.yml                  # All variables with defaults
├── tasks/
│   ├── main.yml                       # Orchestrator
│   ├── prerequisites.yml              # Create hostPath dir on workers
│   ├── validate.yml                   # Pre-flight checks
│   ├── install.yml                    # Namespace, secret, PVs, StatefulSet
│   └── verify.yml                     # Rollout status + pod/svc display
├── templates/
│   ├── local-storage.yaml.j2         # StorageClass + PVs per node
│   └── librefs-statefulset.yaml.j2   # Headless svc + NodePort svc + StatefulSet
└── README.md                          # This file
```

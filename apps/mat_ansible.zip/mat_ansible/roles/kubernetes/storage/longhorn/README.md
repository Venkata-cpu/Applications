# Longhorn Distributed Storage Role

Deploys [Longhorn](https://longhorn.io/) — a lightweight, reliable distributed block storage system for Kubernetes. Provides persistent volumes with built-in replication, snapshots, and online expansion. Includes engine-image liveness probe tuning (removes operator ownerReference to prevent revert), resource limits on longhorn-manager, Prometheus metrics annotation, and an nginx auth proxy for the UI. Backup to S3/MinIO is configured via the Longhorn UI after deployment.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Longhorn** | https://github.com/longhorn/longhorn/releases | `1.12.0` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ cluster running | `kubectl get nodes` |
| **Worker nodes** | 3+ nodes for replication | `kubectl get nodes` |
| **iSCSI** | Auto-installed by this role on workers | `rpm -q iscsi-initiator-utils` |
| **Data disk** | `/apps/longhorn` available on each worker | `df -h /apps` |
| **Proxy** | For downloading Longhorn manifest from GitHub | Verify `http_proxy`/`https_proxy` set |
| **Vault secret** | `longhorn_ui_password` for UI auth | `all_secrets.yml` |

---

## How to Run

```bash
# Install (default)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/longhorn.yaml \
  --vault-password-file .vault

# Uninstall (removes K8s resources, NOT data on disk)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/longhorn.yaml \
  --vault-password-file .vault \
  -e "LONGHORN_ACTION=uninstall"
```

### CI/CD (GitLab)
- **APP_GROUP:** `kubernetes`
- **APP:** `longhorn`
- **LONGHORN_ACTION:** `install` (default) or `uninstall`

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.longhorn_version` | `1.12.0` | Longhorn version |
| `paths.yml` | `paths.longhorn.base_dir` | `/apps/longhorn` | Data directory on workers |
| `networks.yml` | `ports.kubernetes.longhorn.node_port` | `61066` | UI NodePort |
| `all_secrets.yml` | `longhorn_ui_password` | (vault) | UI basic auth password |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `config_k8s.longhorn.worker_node_hosts` | `kubernetes_worker` | Inventory host group for worker nodes |
| `config_k8s.longhorn.node_label_key` | `node.longhorn.io/create-default-disk` | Label key applied to restrict Longhorn to designated nodes |
| `config_k8s.longhorn.node_label_value` | `true` | Label value for node restriction |
| `config_k8s.longhorn.replica_count` | `3` | Default volume replica count |
| `config_k8s.longhorn.storage_reserved_percentage` | `15` | Disk space reserved from Longhorn scheduling |
| `config_k8s.longhorn.storage_minimal_available_percentage` | `10` | Min free space before scheduling stops |
| `config_k8s.longhorn.zone.enabled` | `false` | Enable zone-aware replica spreading |
| `config_k8s.longhorn.zone.label_key` | `topology.kubernetes.io/zone` | K8s node label key for zone identity |
| `config_k8s.longhorn.zone.nodes` | `[]` | List of `{node, zone}` mappings |
| `config_k8s.longhorn.zone.soft_anti_affinity` | `true` | Prefer (not require) cross-zone replica placement |
| `config_k8s.longhorn.zone.auto_balance` | `best-effort` | Auto-rebalance replicas across zones (`disabled`, `least-effort`, `best-effort`) |
| `config_k8s.longhorn.ui_auth.username` | `admin` | UI login username |
| `config_k8s.longhorn.resources.manager.requests_cpu` | `100m` | Manager pod CPU request |
| `config_k8s.longhorn.resources.manager.requests_memory` | `128Mi` | Manager pod memory request |
| `config_k8s.longhorn.resources.manager.limits_cpu` | `500m` | Manager pod CPU limit |
| `config_k8s.longhorn.resources.manager.limits_memory` | `512Mi` | Manager pod memory limit |
| `config_k8s.longhorn.resources.engine.guaranteed_cpu` | `100m` | Engine instance CPU guarantee |
| `config_k8s.longhorn.wait_retries` | `60` | Max retries for readiness checks |
| `config_k8s.longhorn.wait_delay` | `15` | Seconds between retries |

**Note:** Namespace is fixed at `longhorn-system` (hardcoded in the official Longhorn manifest — cannot be changed).

---

## Node Restriction

Longhorn is restricted to **only** run on nodes in the `longhorn_worker_nodes` host group. New nodes added to the cluster will **NOT** get Longhorn unless they are explicitly added to the inventory host group and the playbook is re-run.

This is enforced via three mechanisms:

1. **Node labelling** — nodes in the host group get labelled `node.longhorn.io/create-default-disk=true` during prerequisites.
2. **`create-default-disk-labeled-nodes: true`** — Longhorn only creates default disks on labelled nodes (instead of all nodes).
3. **`system-managed-components-node-selector`** — restricts Longhorn system components (manager, driver deployer, engine-image) to labelled nodes only.
4. **DaemonSet nodeSelector** — the `longhorn-manager` DaemonSet is patched with a nodeSelector matching the label, preventing scheduling on unlabelled nodes.

### Adding New Worker Nodes to Longhorn

1. Add the new node(s) to the `longhorn_worker_nodes` host group in inventory
2. Re-run the playbook — the role will label the new nodes, install iSCSI prerequisites, and Longhorn will automatically start using them

---

## Zone-Aware Replica Spreading (Multi-Rack / Multi-DC)

For clusters spanning multiple racks or datacenters on the same low-latency network, Longhorn can be configured to spread volume replicas across zones. This ensures a single rack/DC failure doesn't lose all replicas of a volume.

**Important:** This requires all nodes to be part of the same Kubernetes cluster. For separate prod/DR clusters, use Longhorn backup to S3 instead.

### How to Enable

Add to your `config_kubernetes.yml`:

```yaml
config_k8s:
  longhorn:
    zone:
      enabled: true
      label_key: topology.kubernetes.io/zone   # optional, this is the default
      soft_anti_affinity: true                  # optional, prefer (not require) cross-zone
      auto_balance: best-effort                 # optional, rebalance replicas across zones
      nodes:
        - { node: blt20919021, zone: dc1 }
        - { node: blt20919022, zone: dc1 }
        - { node: blt20919023, zone: dc1 }
        - { node: blt20919024, zone: dc2 }
        - { node: blt20919025, zone: dc2 }
        - { node: blt20919026, zone: dc2 }
```

### What it Does

1. **Labels nodes** with `topology.kubernetes.io/zone=<zone>` during prerequisites
2. **`replica-zone-soft-anti-affinity: true`** — Longhorn prefers placing replicas in different zones (soft = won't fail if not possible, hard = rejects scheduling)
3. **`replica-auto-balance: best-effort`** — Longhorn automatically rebalances replicas across zones when nodes are added/removed

### Behaviour

| Replicas | Zones | Distribution |
|----------|-------|--------------|
| 2 | dc1, dc2 | 1 replica per zone |
| 3 | dc1, dc2 | 2 in one zone, 1 in the other (best-effort) |
| 3 | dc1, dc2, dc3 | 1 per zone |

### Note on Latency

Longhorn replication is **synchronous**. If zones are in different physical datacenters with WAN latency (>1ms), write performance will be impacted. This feature is designed for:
- Multiple racks in the same datacenter
- Metro-distance DCs with <1ms latency
- NOT for geographically separated DCs

---

## What Gets Deployed

```
longhorn-system namespace:
├── DaemonSets:
│   ├── longhorn-manager        (control plane, on labelled workers only — nodeSelector enforced)
│   ├── longhorn-csi-plugin     (CSI driver, on labelled workers only)
│   └── engine-image-ei-*       (engine binary, on labelled workers only — probe tuned)
├── Deployments:
│   ├── longhorn-driver-deployer
│   ├── longhorn-ui
│   ├── longhorn-auth-proxy     (nginx basic auth for UI)
│   └── csi-attacher/provisioner/resizer/snapshotter
├── Services:
│   ├── longhorn-backend        (annotated for Prometheus scraping on port 9500)
│   ├── longhorn-frontend       (ClusterIP for UI)
│   └── longhorn-frontend-nodeport (NodePort for external access)
├── StorageClass: longhorn      (default, Immediate binding, best-effort locality)
└── ConfigMap: longhorn-default-setting
    ├── default-data-path, default-replica-count, storage-reserved-%, guaranteed-cpu
    ├── create-default-disk-labeled-nodes: true
    └── system-managed-components-node-selector: node.longhorn.io/create-default-disk:true
```

---

## Task Execution Flow

```
main.yaml (routes by LONGHORN_ACTION)
├── install.yml
│   ├── prerequisites.yml       # Label workers → Disable external repos → install iSCSI → data dir
│   │   ├── Label nodes with node.longhorn.io/create-default-disk=true
│   │   ├── Disable external repos on workers (delegate_to)
│   │   ├── Install iscsi-initiator-utils (delegate_to)
│   │   ├── Load + persist iscsi_tcp kernel module (delegate_to)
│   │   ├── Enable iscsid service (delegate_to)
│   │   └── Create data directory (delegate_to)
│   ├── deploy.yml              # Download manifest → inject settings → apply
│   │   ├── Download manifest from GitHub
│   │   ├── Inject settings (data-path, replica-count, reserved-%, guaranteed-cpu)
│   │   ├── Inject node restriction (create-default-disk-labeled-nodes, system-managed-components-node-selector)
│   │   ├── Apply manifest
│   │   ├── Wait for longhorn-manager ready
│   │   ├── Annotate longhorn-backend for Prometheus (port 9500)
│   │   ├── Patch longhorn-manager resource limits
│   │   ├── Patch longhorn-manager nodeSelector (restrict to labelled nodes)
│   │   ├── Wait for rollout
│   │   └── Create StorageClass (Immediate binding, best-effort dataLocality)
│   ├── security.yml            # NodePort service + nginx auth proxy (basic auth)
│   └── verify.yml              # Wait for engine-image ready on all workers → node schedulable → status
└── uninstall.yml               # Scale down → delete PVCs/PVs → remove CRDs → delete namespace
```

---

## Engine Image Liveness Probe Fix

The Longhorn operator hardcodes engine-image DaemonSet probe values (timeout=4s, failure=3, period=5s) which are too aggressive for nodes under I/O load. The role fixes this by:

1. **Removing `ownerReferences`** from the engine-image DaemonSet — disconnects it from the operator's reconciliation loop
2. **Patching probes** to timeout=10s, period=30s, failureThreshold=10

This survives operator restarts. On Longhorn **upgrade** (version change), the operator creates a new engine-image DaemonSet — the patch is re-applied automatically on next role run.

---

## Post-Deployment Verification

```bash
# 1. All pods running
kubectl get pods -n longhorn-system

# 2. Nodes schedulable
kubectl get nodes.longhorn.io -n longhorn-system

# 3. StorageClass exists and is default
kubectl get storageclass longhorn

# 4. Engine-image probe values (should show timeout=10, period=30, failure=10)
DS=$(kubectl get ds -n longhorn-system -l longhorn.io/component=engine-image -o name)
kubectl get $DS -n longhorn-system -o jsonpath='{.spec.template.spec.containers[0].livenessProbe}' | python3 -m json.tool

# 5. Prometheus metrics
curl -s http://<node-ip>:9500/metrics | head -5

# 6. UI access
# Open: http://<node-ip>:<nodeport>
# Login: admin / <vault password>

# 7. Test PVC
kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: test-longhorn-pvc
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: longhorn
  resources:
    requests:
      storage: 1Gi
EOF
kubectl get pvc test-longhorn-pvc   # Expected: Bound
kubectl delete pvc test-longhorn-pvc
```

---

## Upgrade Process

1. Update `version.kubernetes.longhorn_version` in `versions.yml`
2. Re-run the role — downloads new manifest, applies (operator handles rolling upgrade)
3. Engine-image probe patch is re-applied for the new DaemonSet
4. Existing volumes remain available during upgrade (rolling update)

---

## Troubleshooting

### Checking Logs

```bash
# Manager logs
kubectl logs -n longhorn-system -l app=longhorn-manager --tail=50

# Follow live
kubectl logs -n longhorn-system -l app=longhorn-manager -f

# Engine-image logs
kubectl logs -n longhorn-system -l longhorn.io/component=engine-image --tail=20

# Events
kubectl get events -n longhorn-system --sort-by='.lastTimestamp' | tail -20
```

### Engine-image pods CrashLoopBackOff
```bash
# Check if the probe was reverted
kubectl get ds -n longhorn-system -l longhorn.io/component=engine-image -o jsonpath='{.items[0].spec.template.spec.containers[0].livenessProbe.timeoutSeconds}'
# If shows 4 instead of 10, re-run the role to re-apply the fix

# Check disk I/O on the node
iostat -x 1 5
```

### PVC stuck in Pending
```bash
kubectl describe pvc <name>
# Common: no schedulable nodes, insufficient disk, replica count > node count
```

### Unbalanced replica distribution
```bash
# Enable auto-rebalance
kubectl patch setting replica-auto-balance -n longhorn-system --type merge -p '{"value":"best-effort"}'
```

---

## File Structure

```
roles/kubernetes/storage/longhorn/
├── defaults/main.yml              # All variables
├── tasks/
│   ├── main.yaml                  # Install/uninstall router (via LONGHORN_ACTION)
│   ├── install.yml                # Install orchestrator
│   ├── install/
│   │   ├── prerequisites.yml      # iSCSI + data dir on workers
│   │   ├── deploy.yml             # Manifest + settings + probe fix + resources + StorageClass
│   │   ├── security.yml           # NodePort + nginx auth proxy
│   │   └── verify.yml             # Engine readiness + node schedulability + status
│   ├── uninstall.yml              # Uninstall orchestrator
│   └── uninstall/
│       ├── remove_addons.yml      # Remove backup targets, auth proxy
│       ├── remove_core.yml        # Remove PVCs, PVs, CRDs
│       └── delete.yaml            # Delete namespace
├── templates/
│   ├── longhorn-auth-proxy.yaml.j2   # Nginx basic auth deployment
│   ├── longhorn-service.yaml.j2      # NodePort service for UI
│   ├── longhorn-storageclass.yaml.j2 # StorageClass (Immediate, best-effort)
└── README.md
```

---

## Security Notes

- UI protected by nginx basic auth proxy (htpasswd, `no_log: true` on credential tasks)
- Longhorn backend annotated for Prometheus scraping (port 9500)
- StorageClass uses `reclaimPolicy: Delete` — PV data is removed when PVC is deleted
- Engine-image pods run as privileged (required for block device access)
- ownerReferences removed from engine-image DaemonSet — operator cannot revert probe config

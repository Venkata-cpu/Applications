# MinIO on Kubernetes Role

Deploys MinIO Community Edition as a distributed object storage cluster on Kubernetes using Helm. Uses local persistent volumes (hostPath) on designated worker nodes to avoid circular dependency with Longhorn backups.

**Note:** MinIO Community Edition's last release is `RELEASE.2025-09-07T16-13-09Z`. The upstream repo is archived. For actively maintained builds, see the `kubernetes/storage/librefs` role.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **MinIO Server** | https://github.com/minio/minio/releases (archived) | `RELEASE.2025-09-07T16-13-09Z` |
| **Helm Chart** | https://charts.min.io | `minio/minio` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ | `kubectl version` |
| **Helm** | 3.x installed on master | `helm version` |
| **Worker nodes** | 4+ nodes with local disk for MinIO data | `kubectl get nodes` |
| **hostPath dir** | `/apps/minio_data` pre-created on target nodes | `ls -la /apps/minio_data` |
| **Node labels** | Target nodes labeled for affinity (optional) | `kubectl get nodes --show-labels` |
| **Proxy** | For Helm chart download (charts.min.io) | `all_secrets.yml` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_minio.yaml \
  --vault-password-file .vault
```

---

## Web Console (UI)

MinIO includes the full web management console, exposed via NodePort.

**Access:** `http://<any-worker-node>:<console_nodeport>` (default: `61061`)
**Login:** Use root credentials from vault

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.minio.server` | `RELEASE.2025-09-07T16-13-09Z` | MinIO image tag |
| `all_secrets.yml` | `k8s_minio_root_password_vault` | (vault encrypted) | Root password |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.kubernetes.minio.namespace` | `minio` | K8s namespace | |
| `config.kubernetes.minio.release_name` | `minio` | Helm release name | |
| `config.kubernetes.minio.mode` | `distributed` | `single-node` or `distributed` | `distributed` requires 4+ replicas |
| `config.kubernetes.minio.replicas` | `4` | StatefulSet replicas | Must be 1 or >= 4 |
| `config.kubernetes.minio.volumes_per_node` | `1` | Volumes per pod | |
| `config.kubernetes.minio.storage_size` | `100Gi` | PV size per replica | |
| `config.kubernetes.minio.host_path` | `/apps/minio_data` | Local path on worker nodes | Must pre-exist |
| `config.kubernetes.minio.root_user` | `minioadmin` | S3 access key | |
| `config.kubernetes.minio.buckets` | `['longhorn-backup']` | Auto-created buckets | |
| `config.kubernetes.minio.image` | `minio/minio` | Server container image | |
| `config.kubernetes.minio.mc_image` | `minio/mc` | Client image (for bucket init) | |
| `ports.kubernetes.minio.api` | `9000` | Internal API port | |
| `ports.kubernetes.minio.console` | `9001` | Internal console port | |
| `ports.kubernetes.minio.api_nodeport` | `61060` | S3 API NodePort | |
| `ports.kubernetes.minio.console_nodeport` | `61061` | Console NodePort | |
| `config.kubernetes.minio.topology.node_label_key` | `''` | Node affinity label key | Empty = no affinity |
| `config.kubernetes.minio.topology.node_label_value` | `''` | Node affinity label value | |
| `config.kubernetes.minio.resources.requests_cpu` | `250m` | CPU request | |
| `config.kubernetes.minio.resources.requests_memory` | `512Mi` | Memory request | |
| `config.kubernetes.minio.resources.limits_cpu` | `2000m` | CPU limit | |
| `config.kubernetes.minio.resources.limits_memory` | `2Gi` | Memory limit | |
| `config.kubernetes.minio.wait_retries` | `30` | Verification retries | |
| `config.kubernetes.minio.wait_delay` | `10` | Delay between retries (seconds) | |

---

## What Gets Deployed

```
Namespace: minio
├── Secret/minio-credentials         # rootUser + rootPassword
├── StatefulSet/minio                 # MinIO server pods (1 or 4+ replicas)
│   └── Pod/minio-{0..N}             # Each with hostPath PVC
├── Service/minio (NodePort)          # S3 API → 61060
├── Service/minio-console (NodePort)  # Web UI → 61061
└── PVC/data-minio-{0..N}            # Bound to local PVs
```

**Note:** PersistentVolumes (hostPath-based) must be pre-provisioned on target worker nodes, or a local-path provisioner must be configured. The `hostPath` directory (`/apps/minio_data`) must exist on each designated node before deployment.

---

## Deployment Modes

### Single-Node (Test environments)

No redundancy — single pod, single volume. Good for dev/test.

```yaml
config:
  kubernetes:
    minio:
      mode: single-node
      replicas: 1
```

### Distributed (Production)

Erasure coding across 4+ replicas. Survives loss of up to N/2 nodes.

```yaml
config:
  kubernetes:
    minio:
      mode: distributed
      replicas: 4   # minimum 4, can be 4, 6, 8, etc.
```

**Why minimum 4?** MinIO's erasure coding splits data into data + parity shards. The minimum is 2 data + 2 parity = 4. Values of 2 or 3 are not valid for erasure coding and will fail validation.

| Replicas | Parity | Can Lose | Use Case |
|----------|--------|----------|----------|
| 1 | 0 | 0 nodes | Test/dev only |
| 4 | 2 | 2 nodes | Small prod |
| 6 | 3 | 3 nodes | Medium prod |
| 8 | 4 | 4 nodes | Large prod |

---

## Task Execution Flow

```
main.yml
├── validate.yml    # Version, password, replicas/mode coherence, helm available
├── install.yml     # Create namespace, secret, template values, helm upgrade --install
├── verify.yml      # Rollout status, pod health, service listing
└── buckets.yml     # Ephemeral mc pod to create configured buckets
```

---

## Longhorn Integration

```bash
kubectl create secret generic minio-secret \
  --from-literal=AWS_ACCESS_KEY_ID=minioadmin \
  --from-literal=AWS_SECRET_ACCESS_KEY=<password> \
  --from-literal=AWS_ENDPOINTS=http://minio.minio.svc:9000 \
  -n longhorn-system
```

Set Longhorn backup target: `s3://longhorn-backup@us-east-1/`

---

## Upgrade Process

1. Update `version.kubernetes.minio.server` in `versions.yml`
2. Re-run playbook:
   - `helm upgrade --install` detects image tag change → performs rolling update
   - Data on hostPath volumes is NEVER touched
   - Helm `--wait` ensures all pods healthy before proceeding
3. If upgrade fails, rollback via: `helm rollback minio -n minio`

---

## Post-Deployment Verification

```bash
# 1. Pod status
kubectl get pods -n minio -o wide

# 2. Service endpoints
kubectl get svc -n minio

# 3. Health check (from any cluster node)
curl -s http://<node-ip>:61060/minio/health/live
# Expected: 200 OK

# 4. Cluster health (distributed mode)
curl -s http://<node-ip>:61060/minio/health/cluster
# Expected: 200 OK

# 5. Console UI
# Open in browser: http://<node-ip>:61061
# Login: minioadmin / <vault password>

# 6. Test via mc (from inside cluster)
kubectl run mc-test --rm -i --restart=Never -n minio \
  --image=minio/mc:latest --command -- sh -c '
  mc alias set local http://minio.minio.svc:9000 minioadmin <password> &&
  mc ls local/'
```

---

## Troubleshooting

### Checking Logs

```bash
# Pod logs (last 50 lines)
kubectl logs -n minio -l app=minio --tail=50

# Follow live
kubectl logs -n minio -l app=minio -f

# Specific pod
kubectl logs -n minio minio-0 --tail=100

# Events (useful for scheduling/PV issues)
kubectl get events -n minio --sort-by='.lastTimestamp'
```

### Pods stuck in Pending
```bash
kubectl describe pod -n minio minio-0
# Common: PV not bound, node affinity not matching, hostPath dir missing
```

### Helm release issues
```bash
# Check release status
helm status minio -n minio

# View rendered values
helm get values minio -n minio

# History (for rollback)
helm history minio -n minio
```

### Bucket creation fails
```bash
# Run mc manually
kubectl run mc-debug --rm -it --restart=Never -n minio \
  --image=minio/mc:latest --command -- sh
# Then inside: mc alias set local http://minio.minio.svc:9000 minioadmin <pass>
```

---

## Security Notes

- Credentials stored in vault-encrypted secrets, deployed as K8s Secret
- Secret created with `--dry-run=client | kubectl apply` (idempotent, no duplication)
- Helm values written to `/tmp` with mode `0600` and deleted immediately after deploy
- No SSL by default (designed to run behind ingress/SSL-terminating proxy)
- Container images pulled from official `minio/minio` and `minio/mc` registries
- `no_log: true` on all tasks handling credentials
- Bucket creation job uses `--rm` flag — pod auto-deleted after completion

---

## File Structure

```
roles/kubernetes/storage/minio/
├── defaults/main.yml              # All variables with defaults
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks
│   ├── install.yml                # Namespace, secret, helm deploy
│   ├── verify.yml                 # Rollout status + pod/svc display
│   └── buckets.yml                # Auto-create buckets via mc pod
├── templates/
│   └── values.yaml.j2            # Helm chart values
└── README.md                      # This file
```

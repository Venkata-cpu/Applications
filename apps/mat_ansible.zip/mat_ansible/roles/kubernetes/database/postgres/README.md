# Kubernetes PostgreSQL (CNPG) Role

Deploys a production-grade PostgreSQL cluster on Kubernetes using the [CloudNativePG](https://cloudnative-pg.io/) (CNPG) operator. Supports HA replication, PgBouncer connection pooling, Longhorn volume snapshots for backup, and configurable PostgreSQL extensions.

## What is CloudNativePG?

CloudNativePG (CNPG) is an open-source Kubernetes operator that automates the full lifecycle of PostgreSQL clusters:

- **Automated failover** — if the primary crashes, a replica is promoted within seconds
- **Rolling updates** — PostgreSQL and operator upgrades with zero downtime
- **Backup/Recovery** — Longhorn volume snapshots for fast restore
- **Self-healing** — recreates failed pods automatically with their data intact
- **Native Kubernetes** — uses CRDs, no external dependencies (no etcd, no Patroni)

Think of it as "PostgreSQL managed service" but running on your own cluster. You define a `Cluster` YAML manifest, and the operator handles everything: provisioning, replication, failover, backups, and monitoring.

## Version Reference Links

| Component | Check Latest | Current Recommended |
|-----------|-------------|---------------------|
| CNPG Operator | [Releases](https://github.com/cloudnative-pg/cloudnative-pg/releases) | 1.29.1 |
| CNPG Helm Chart | [Chart Releases](https://github.com/cloudnative-pg/charts/releases) | 0.28.3 (maps to operator 1.29.x) |
| PostgreSQL Server | [PGDG Downloads](https://www.postgresql.org/download/) | 18.4 (latest), 17.10 (LTS) |
| CNPG Container Images | [ghcr.io/cloudnative-pg](https://github.com/cloudnative-pg/postgres-containers/pkgs/container/postgresql) | 18.4, 17.10 |
| CNPG Docs | [cloudnative-pg.io/docs](https://cloudnative-pg.io/docs/) | — |
| PgBouncer (via CNPG Pooler) | [CNPG Pooler Docs](https://cloudnative-pg.io/docs/1.28/connection_pooling/) | Built-in (no separate version) |
| Barman (backup) | [pgBarman](https://pgbarman.org/) | Built into CNPG images (not used — Longhorn snapshots preferred) |

**Note on versioning:** The Helm chart version (e.g., `0.28.3`) maps to the operator version (e.g., `1.29.x`). Use the Helm chart version in `version.kubernetes.postgres.helm_chart`. Check [charts/releases](https://github.com/cloudnative-pg/charts/releases) for the exact mapping.

**PostgreSQL 18 Note:** In PostgreSQL 18 with CNPG 1.29+, `shared_preload_libraries` is a fixed parameter managed by the operator. Do NOT set it manually — it will cause a validation error. Extensions are loaded automatically via the CNPG extension management system.

**CNPG Support Lifecycle:**
| Version | EOL |
|---------|-----|
| 1.25.x | Oct 2025 (EOL) |
| 1.26.x | Dec 2025 (EOL) |
| 1.27.x | Mar 2026 |
| 1.28.x | Jun 2026 |
| 1.29.x | Latest (active) |

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    CNPG Operator                         │
│              (cnpg-system namespace)                     │
│   Installed via Helm: cnpg/cloudnative-pg               │
└─────────────────────┬───────────────────────────────────┘
                      │ manages
┌─────────────────────▼───────────────────────────────────┐
│              PostgreSQL Cluster                           │
│           (configurable namespace)                        │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│  │ Primary  │  │ Replica  │  │ Replica  │  (3 instances)│
│  │  (RW)    │  │  (RO)    │  │  (RO)    │              │
│  └────┬─────┘  └──────────┘  └──────────┘              │
│       │         streaming replication                    │
│  ┌────▼──────────────────┐                              │
│  │ PgBouncer Pooler (RW) │  (optional, CNPG native)    │
│  │ transaction mode      │                              │
│  └───────────────────────┘                              │
│                                                          │
│  ┌──────────┐                                           │
│  │ Longhorn │  Volume snapshot backups                   │
│  │  Backup  │  (scheduled via VolumeSnapshot)            │
│  └──────────┘                                           │
└─────────────────────────────────────────────────────────┘
```

---

## Features

- **High Availability** — automatic failover with synchronous streaming replication
- **PgBouncer** — native CNPG Pooler CRD for connection pooling
- **Longhorn Snapshots** — fast volume-level backup via scheduled VolumeSnapshots
- **Extensions** — install any PostgreSQL extension from a simple config list
- **Resource Limits** — CPU/memory requests and limits per instance
- **Node Affinity** — pin pods to labeled nodes
- **Pod Anti-Affinity** — required spread across different nodes
- **Migration** — bootstrap from existing PostgreSQL via `pg_basebackup`
- **Separate WAL Storage** — optional dedicated volume for WAL files (reduces I/O contention)
- **NodePort** — optional external access on a fixed port
- **Monitoring** — PodMonitor for Prometheus auto-discovery (built into CNPG)

---

## Prerequisites

- Kubernetes 1.26+ (CNPG 1.28+ requires 1.26)
- Helm 3.x on control node
- StorageClass available (Longhorn recommended)
- `http_proxy` and `https_proxy` defined in global secrets

---

## Quick Start (First-Time Setup)

If you've never deployed this before, follow these steps:

### Step 1: Add configuration to inventory

Add to `versions.yml`:
```yaml
version:
  kubernetes:
    postgres:
      helm_chart: "0.28.3"
      server: "18.4"
```

Add to `networks.yml`:
```yaml
ports:
  kubernetes:
    postgres:
      internal: 5432
      nodeport: 61020
      metrics: 9187
      pgbouncer: 5432
```

Add to `app_configs.yml` under `config.kubernetes`:
```yaml
    postgres:
      namespace: cnpg-postgres
      cluster_name: barista-test
      instances: 1                    # Use 1 for test, 3 for production
      db_name: postgres
      db_user: postgres
      extensions: []
      storage_class: longhorn
      storage_size: 10Gi
      resources:
        requests:
          cpu: "250m"
          memory: "512Mi"
        limits:
          cpu: "1000m"
          memory: "2Gi"
      parameters:
        max_connections: 100
        shared_buffers: "512MB"
        effective_cache_size: "1536MB"
      pgbouncer:
        enabled: false
      backup:
        longhorn:
          enabled: false
          enabled: false
      topology:
        node_label_key: ""
        node_label_value: ""
      superuser_enabled: true
      bootstrap_mode: initdb
      no_proxy: "localhost,127.0.0.1,.svc,.cluster.local"
```

Add to `all_secrets.yml` (vault-encrypted):
```yaml
postgres_db_password_vault: "your-strong-password-here"
```

### Step 2: Run the playbook

```bash
ansible-playbook -i inventories/barista/test/hosts playbook/postgres.yaml --vault-password-file .vault
```

### Step 3: Verify

```bash
# Check cluster is healthy
kubectl get cluster -n cnpg-postgres

# Connect to PostgreSQL
kubectl -n cnpg-postgres exec -it barista-test-1 -- psql -U postgres -d postgres
```

### Step 4: Connect your application

Use this connection string from within the cluster:
```
postgresql://postgres:<password>@barista-test-rw.cnpg-postgres.svc.cluster.local:5432/postgres
```

---

## How It Works

1. **Validate** (`validate.yml`) — checks namespace, credentials, storage class, instance count, extension list
2. **Operator** (`operator.yml`) — installs/upgrades CNPG operator via Helm chart
3. **Deploy** (`deploy.yml`) — creates namespace, secrets, applies Cluster CR + Pooler + ScheduledBackup, waits for health
4. **Extensions** (`extensions.yml`) — connects to primary pod and runs `CREATE EXTENSION IF NOT EXISTS` for each entry
5. **Verify** (`verify.yml`) — validates connectivity, displays connection strings and status

---

## Extensions

Extensions are installed from a config list. Any valid PostgreSQL extension name works:

```yaml
config:
  kubernetes:
    postgres:
      extensions:
        - pgjwt
        - pgcrypto
        - uuid-ossp
        - pg_stat_statements
        - pg_trgm
        - hstore
```

The role:
1. Adds extensions to `postInitSQL` during fresh bootstrap (initdb mode) — so they exist from first boot
2. Runs `CREATE EXTENSION IF NOT EXISTS` on the primary after deployment — handles adding extensions to existing clusters

**Extensions requiring `shared_preload_libraries`:**

Some extensions (e.g., `pg_stat_statements`, `pg_cron`, `auto_explain`) need to be loaded at server start. Add them:

```yaml
parameters:
  shared_preload_libraries: "pg_stat_statements,auto_explain"
```

CNPG will rolling-restart instances when this changes.

---

## PostgreSQL Parameters — Detailed Reference

Each parameter explained with tuning guidance:

### Memory Parameters

| Parameter | Default | Formula | Impact |
|-----------|---------|---------|--------|
| `shared_buffers` | `256MB` | 25% of pod memory limit | **Most impactful setting.** PostgreSQL's internal page cache. Too low = excessive disk reads. Too high (>40%) = diminishing returns + OS cache competition. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-resource.html#GUC-SHARED-BUFFERS) |
| `effective_cache_size` | `1GB` | 70-80% of pod memory limit | **Does NOT allocate memory.** Tells the query planner how much total cache (shared_buffers + OS page cache) is available. Higher = planner prefers index scans. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-query.html#GUC-EFFECTIVE-CACHE-SIZE) |
| `work_mem` | `4MB` | Total memory / (max_connections × 4) | Per-sort/hash operation memory. **Multiplied by concurrent operations!** 200 connections × 4MB = 800MB potential. Too high = OOM risk. Too low = disk sorts. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-resource.html#GUC-WORK-MEM) |
| `maintenance_work_mem` | `128MB` | 256MB–1GB for production | Used for VACUUM, CREATE INDEX, ALTER TABLE. Higher = faster maintenance. Safe to set higher than `work_mem` since few concurrent maintenance ops. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-resource.html#GUC-MAINTENANCE-WORK-MEM) |

### Replication & WAL Parameters

| Parameter | Default | Options | Impact |
|-----------|---------|---------|--------|
| `wal_level` | `replica` | `minimal`, `replica`, `logical` | Must be `replica` or `logical` for HA. `logical` needed for logical replication/CDC. Higher = more WAL generated. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-wal.html#GUC-WAL-LEVEL) |
| `max_wal_senders` | `10` | instances + 2 + backup slots | Max concurrent WAL streaming connections. Must be ≥ replicas + backup processes. Too low = replicas can't connect. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-replication.html#GUC-MAX-WAL-SENDERS) |
| `max_replication_slots` | `10` | ≥ max_wal_senders | Slots retain WAL until consumer acknowledges. Must accommodate replicas + backup. Too few = failover fails. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-replication.html#GUC-MAX-REPLICATION-SLOTS) |
| `synchronous_commit` | `remote_write` | See below | Trade-off between durability and latency. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-wal.html#GUC-SYNCHRONOUS-COMMIT) |

**`synchronous_commit` options:**

| Value | Durability | Latency | When to use |
|-------|-----------|---------|-------------|
| `off` | Lowest (data loss on crash) | Fastest | Non-critical test data |
| `local` | Local WAL only | Fast | Single instance, no replicas |
| `remote_write` | Written to replica OS cache | Good balance | **Recommended default** — data reaches replica but not fsynced |
| `on` | Fsynced to replica disk | Higher latency | Maximum durability (financial data) |
| `remote_apply` | Applied on replica (visible) | Highest latency | Read-your-writes from replicas |

### Performance Parameters

| Parameter | Default | Optimal | Impact |
|-----------|---------|---------|--------|
| `checkpoint_completion_target` | `0.9` | `0.9` (PG 14+ default) | Spread checkpoint writes over this fraction of checkpoint interval. `0.9` = smoother I/O. Lower = bursty writes. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-wal.html#GUC-CHECKPOINT-COMPLETION-TARGET) |
| `random_page_cost` | `1.1` | `1.1` for SSD/NVMe, `4.0` for HDD | Tells planner cost of random page access relative to sequential. SSD has near-sequential speed. Too high on SSD = planner avoids indexes. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-query.html#GUC-RANDOM-PAGE-COST) |
| `effective_io_concurrency` | `200` | `200` for SSD, `2` for HDD | How many parallel I/O requests the OS can handle. SSD handles many concurrent requests. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-resource.html#GUC-EFFECTIVE-IO-CONCURRENCY) |

### Connection Parameters

| Parameter | Default | Guidance | Impact |
|-----------|---------|----------|--------|
| `max_connections` | `200` | Actual concurrent connections expected | Each connection uses ~5-10MB. 200 connections = 1-2GB overhead. **Use PgBouncer** to handle 1000+ app connections with 50-100 real PG connections. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-connection.html#GUC-MAX-CONNECTIONS) |

### Logging Parameters

| Parameter | Default | Options | Impact |
|-----------|---------|---------|--------|
| `log_min_duration_statement` | `1000` (1s) | `-1` (disable), `0` (all), ms value | Logs queries slower than this. `0` logs everything (very verbose). `1000` = only queries > 1 second. Good for finding slow queries. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-logging.html#GUC-LOG-MIN-DURATION-STATEMENT) |
| `log_statement` | `ddl` | `none`, `ddl`, `mod`, `all` | What SQL commands to log. `ddl` = schema changes only. `mod` = ddl + INSERT/UPDATE/DELETE. `all` = everything (very verbose). [PG Docs](https://www.postgresql.org/docs/17/runtime-config-logging.html#GUC-LOG-STATEMENT) |
| `shared_preload_libraries` | `pg_stat_statements` | Comma-separated list | Libraries loaded at server start. Required for some extensions. Adding libraries increases startup time slightly. [PG Docs](https://www.postgresql.org/docs/17/runtime-config-client.html#GUC-SHARED-PRELOAD-LIBRARIES) |

### Quick Tuning Guide by Pod Memory Limit

| Pod Memory | shared_buffers | effective_cache_size | work_mem | maintenance_work_mem | max_connections |
|-----------|----------------|---------------------|----------|---------------------|-----------------|
| 2Gi | 512MB | 1.5GB | 4MB | 128MB | 100 |
| 4Gi | 1GB | 3GB | 4MB | 256MB | 200 |
| 8Gi | 2GB | 6GB | 8MB | 512MB | 300 |
| 16Gi | 4GB | 12GB | 16MB | 1GB | 500 |

---

## PgBouncer (Connection Pooler)

CNPG natively supports PgBouncer via the [Pooler CRD](https://cloudnative-pg.io/docs/1.25/connection_pooling/):

```yaml
config:
  kubernetes:
    postgres:
      pgbouncer:
        enabled: true
        pool_mode: transaction
        default_pool_size: 25
        max_client_conn: 100
        instances: 2
```

### Pool Mode Comparison

| Mode | Connection returned after | Session state preserved | Use case |
|------|--------------------------|------------------------|----------|
| `transaction` | Each transaction ends | **No** — no prepared statements, temp tables across transactions | **Recommended for most apps** (REST APIs, microservices) |
| `session` | Client disconnects | **Yes** — full session state | Apps that use prepared statements, `SET` commands |
| `statement` | Each statement ends | **No** — dangerous with multi-statement transactions | Read-only workloads only |

### PgBouncer Parameters

| Parameter | Default | Impact |
|-----------|---------|--------|
| `default_pool_size` | `25` | Max connections from PgBouncer to PostgreSQL per user/database pair. Higher = more real PG connections used. Formula: roughly `max_connections / pgbouncer_instances` |
| `max_client_conn` | `100` | Max client connections PgBouncer accepts. Can be much higher than `max_connections` since PgBouncer multiplexes |
| `instances` | `2` | Number of PgBouncer pods. 2 for HA (one can restart without downtime) |

### When to Connect Via Pooler vs Direct

| Connection target | Service name | Use for |
|------------------|-------------|---------|
| **PgBouncer (pooled)** | `<cluster>-pooler-rw` | Application traffic, microservices, REST APIs |
| **Direct (non-pooled)** | `<cluster>-rw` | Admin operations, migrations, VACUUM, extensions, long transactions |

---

## Backup Configuration

### Longhorn Volume Snapshots

Provides fast volume-level backup using Longhorn's built-in VolumeSnapshot capability. Configure via `config_k8s.postgres.backup.longhorn`:

```yaml
backup:
  longhorn:
    enabled: true
    schedule: "0 3 * * *"
    retain: 7
```
    retention: "7d"
    wal_compression: gzip
```

| Parameter | Default | Impact |
|-----------|---------|--------|
| `schedule` | `0 3 * * *` | Cron for Longhorn snapshots. Daily at 3 AM recommended |
| `retain` | `7` | Number of snapshots to keep |
| `wal_compression` | `gzip` | `gzip`, `bzip2`, `snappy`. Reduces WAL storage 60-80% |

**How it works:**
1. WAL segments are continuously shipped to S3 (every ~16MB or 5 minutes)
2. Scheduled base backup creates a full snapshot (daily)
3. Recovery = restore base backup + replay WAL to any point in time

### Longhorn Volume Snapshots

Simpler but **no WAL-level PITR** — restores to snapshot time only:

```yaml
backup:
  longhorn:
    enabled: true
    schedule: "0 3 * * *"
    retain: 7
```

### Backup Strategy Recommendations

| Environment | Longhorn | Why |
|------------|:--------:|-----|
| Test | ❌ | Data is reproducible |
| Staging | ✅ | Need backup for testing recovery |
| Production | ✅ | Fast volume-level restore |

---

## Topology & Affinity

### Pod Anti-Affinity (Always On)

CNPG enforces `required` pod anti-affinity by default — each PostgreSQL instance runs on a **different node**. This means you need at least as many nodes as instances.

### Node Targeting (Optional)

Pin PostgreSQL pods to specific nodes:

```bash
kubectl label node <node-name> node-role.kubernetes.io/database=true
```

```yaml
topology:
  node_label_key: node-role.kubernetes.io/database
  node_label_value: "true"
  topology_key: kubernetes.io/hostname
```

| Parameter | Default | Impact |
|-----------|---------|--------|
| `node_label_key` | `""` (empty = any node) | When set, pods only schedule on nodes with this label |
| `topology_key` | `kubernetes.io/hostname` | Anti-affinity domain. `hostname` = one pod per node. `topology.kubernetes.io/zone` = one pod per AZ |

---

## Security

| Parameter | Default | Impact |
|-----------|---------|--------|
| `superuser_enabled` | `true` | When `true`, creates a `postgres` superuser secret. **Set to `false` in production** to prevent superuser access from within pods. Admin can still `kubectl exec` |

---

## Maintenance & Updates

| Parameter | Default | Options | Impact |
|-----------|---------|---------|--------|
| `primary_update_strategy` | `unsupervised` | `unsupervised`, `supervised` | `unsupervised` = operator handles rolling updates automatically. `supervised` = requires manual annotation to proceed |
| `primary_update_method` | `switchover` | `switchover`, `restart` | `switchover` = promotes replica first (near-zero downtime). `restart` = restarts primary in place (brief downtime) |
| `reuse_pvc` | `true` | `true`, `false` | When `true`, deleted pods reuse their PVC on restart (faster recovery). `false` = new PVC each time |

---

## Migration from Existing PostgreSQL

Bootstrap a CNPG cluster from an existing PostgreSQL using streaming replication:

```yaml
config:
  kubernetes:
    postgres:
      bootstrap_mode: pg_basebackup
      migration:
        source_host: "old-postgres.default.svc.cluster.local"
        source_port: 5432
        replication_user: replication
```

**Requirements on source:**
1. `wal_level = replica`
2. `max_wal_senders >= 2`
3. Replication user with `REPLICATION` privilege
4. `pg_hba.conf` allows replication from CNPG pod IPs

---

## Variable Reference

### versions.yml
```yaml
version:
  kubernetes:
    postgres:
      helm_chart: "0.28.3"   # CNPG Helm chart version (maps to operator 1.29.x)
      server: "18.4"         # PostgreSQL server version (17.x, 18.x supported)
```

### networks.yml
```yaml
ports:
  kubernetes:
    postgres:
      internal: 5432             # ClusterIP service port
      nodeport: 61020            # NodePort for external access (empty string to disable)
      metrics: 9187              # Prometheus exporter port (built into CNPG)
      pgbouncer: 5432            # PgBouncer pooler port
```

### app_configs.yml (under config.kubernetes)
```yaml
postgres:
  # --- Core ---
  namespace: cnpg-postgres              # Kubernetes namespace for the cluster
  cluster_name: barista-test            # CNPG Cluster resource name
  instances: 3                          # Must be odd (1, 3, 5) for quorum

  # --- Database ---
  db_name: postgres                     # Default database created at bootstrap
  db_user: postgres                     # Default user (owner of db_name)

  # --- Extensions ---
  extensions:                           # List of extensions to CREATE on the database
    - pgjwt
    - pgcrypto
    - uuid-ossp
    - pg_stat_statements

  # --- Storage ---
  storage_class: longhorn               # StorageClass for data PVCs
  storage_size: 20Gi                    # Data volume size per instance
  wal_storage:                          # Separate WAL volume (reduces I/O contention)
    enabled: false                      # true = dedicated WAL PVC
    size: 2Gi                           # WAL volume size
    # storage_class: longhorn           # Defaults to main storage_class

  # --- Resources ---
  resources:
    requests:
      cpu: "500m"                       # Min CPU per instance (guaranteed)
      memory: "1Gi"                     # Min memory per instance
    limits:
      cpu: "2000m"                      # Max CPU per instance
      memory: "4Gi"                     # Max memory (OOM-killed if exceeded)

  # --- PostgreSQL Parameters ---
  parameters:
    max_connections: 200                # Real PG connections (use PgBouncer for more)
    shared_buffers: "1GB"               # 25% of memory limit
    effective_cache_size: "3GB"         # 75% of memory limit
    work_mem: "4MB"                     # Per-sort memory
    maintenance_work_mem: "256MB"       # VACUUM/INDEX memory
    wal_level: replica                  # replica | logical
    max_wal_senders: 10                 # >= instances + backup slots
    max_replication_slots: 10           # >= max_wal_senders
    synchronous_commit: remote_write    # off | local | remote_write | on | remote_apply
    checkpoint_completion_target: "0.9" # Spread checkpoints
    random_page_cost: "1.1"            # 1.1 for SSD, 4.0 for HDD
    effective_io_concurrency: 200       # 200 for SSD, 2 for HDD
    log_min_duration_statement: "1000"  # Log queries > 1s (-1 to disable)
    log_statement: ddl                  # none | ddl | mod | all
    shared_preload_libraries: "pg_stat_statements"

  # --- PgBouncer ---
  pgbouncer:
    enabled: true                       # Deploy CNPG Pooler CRD
    pool_mode: transaction              # transaction | session | statement
    default_pool_size: 25               # Real PG connections per pool
    max_client_conn: 100                # Max app connections to PgBouncer
    instances: 2                        # PgBouncer pod count (2 for HA)

  # --- Backup (Longhorn Snapshots) ---
  backup:
    longhorn:
      enabled: true
      schedule: "0 3 * * *"
      retain: 7
      wal_compression: gzip             # gzip | bzip2 | snappy
    longhorn:
      enabled: false
      schedule: "0 3 * * *"
      retain: 7

  # --- Topology ---
  topology:
    node_label_key: ""                  # Empty = schedule on any node
    node_label_value: ""
    topology_key: kubernetes.io/hostname # Anti-affinity domain

  # --- Security ---
  superuser_enabled: true               # false for production lockdown

  # --- Maintenance ---
  reuse_pvc: true                       # Reuse PVCs on pod restart
  primary_update_strategy: unsupervised # unsupervised | supervised
  primary_update_method: switchover     # switchover (zero-downtime) | restart

  # --- Migration ---
  bootstrap_mode: initdb                # initdb | pg_basebackup
  # migration:
  #   source_host: "old-pg.default.svc.cluster.local"
  #   source_port: 5432
  #   replication_user: replication

  # --- Proxy ---
  no_proxy: "localhost,127.0.0.1,.svc,.cluster.local"

  # --- Helm (override only if needed) ---
  # helm:
  #   repo_name: cnpg
  #   repo_url: https://cloudnative-pg.github.io/charts
  #   chart_name: cnpg/cloudnative-pg
  #   release_name: cnpg-operator

  # --- Timeouts ---
  # timeouts:
  #   operator_retries: 30
  #   operator_delay: 10
  #   cluster_retries: 90
  #   cluster_delay: 20
```

### Vault secrets (all_secrets.yml)
```yaml
postgres_db_password_vault: "<strong-password>"

# Required when bootstrap_mode is pg_basebackup:
# postgres_replication_password_vault: "<replication-password>"
```

---

## Running the Playbook

```bash
# Fresh install
ansible-playbook -i inventories/barista/test/hosts playbook/postgres.yaml --vault-password-file .vault

# With target host override
ansible-playbook -i inventories/barista/test/hosts playbook/postgres.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kubernetes_master_zone2"
```

---

## Post-Installation Verification

After the playbook completes, verify everything is working:

### 1. Check Cluster Status
```bash
# Cluster should show "Cluster in healthy state"
kubectl get cluster -n cnpg-postgres

# All pods should be Running (1 primary + N-1 replicas)
kubectl get pods -n cnpg-postgres -l cnpg.io/cluster=barista-test

# Expected output for 3 instances:
# barista-test-1   1/1   Running   (primary)
# barista-test-2   1/1   Running   (replica)
# barista-test-3   1/1   Running   (replica)
```

### 2. Identify Primary and Replicas
```bash
# Which pod is primary?
kubectl get pods -n cnpg-postgres -l cnpg.io/cluster=barista-test,cnpg.io/instanceRole=primary

# Which are replicas?
kubectl get pods -n cnpg-postgres -l cnpg.io/cluster=barista-test,cnpg.io/instanceRole=replica
```

### 3. Test Database Connectivity
```bash
# Connect to primary and run a query
kubectl -n cnpg-postgres exec -it barista-test-1 -- psql -U postgres -d postgres -c "SELECT version();"

# Verify database exists
kubectl -n cnpg-postgres exec -it barista-test-1 -- psql -U postgres -l

# Verify extensions installed
kubectl -n cnpg-postgres exec -it barista-test-1 -- psql -U postgres -d postgres -c "SELECT extname, extversion FROM pg_extension;"
```

### 4. Check Replication (multi-instance only)
```bash
# On primary — shows connected replicas and their lag
kubectl -n cnpg-postgres exec -it barista-test-1 -- \
  psql -U postgres -c "SELECT client_addr, state, sent_lsn, write_lsn, flush_lsn, replay_lsn FROM pg_stat_replication;"
```

### 5. Check Services
```bash
# List services — should see -rw, -ro, -r, and optionally -nodeport, -pooler-rw
kubectl get svc -n cnpg-postgres

# Test connection via RW service from another pod
kubectl run pg-test --rm -it --restart=Never --image=postgres:17-alpine -- \
  psql "postgresql://postgres:<password>@barista-test-rw.cnpg-postgres.svc.cluster.local:5432/postgres" -c "SELECT 1;"
```

### 6. Check PgBouncer (if enabled)
```bash
kubectl get pooler -n cnpg-postgres
kubectl get pods -n cnpg-postgres -l cnpg.io/poolerName=barista-test-pooler-rw
```

### 7. Check Backups (if Longhorn snapshots enabled)
```bash
kubectl get volumesnapshots -n cnpg-postgres
kubectl get backups -n cnpg-postgres

# Trigger a manual backup to verify
kubectl apply -f - <<EOF
apiVersion: postgresql.cnpg.io/v1
kind: Backup
metadata:
  name: test-backup
  namespace: cnpg-postgres
spec:
  cluster:
    name: barista-test
EOF

# Wait and check status
kubectl get backup test-backup -n cnpg-postgres -w
```

### 8. External Access (if NodePort configured)
```bash
# From any machine that can reach the K8s nodes:
psql -h <node-ip> -p 61020 -U postgres -d postgres
```

### 9. Web UI (pgAdmin)
If you need a web interface to manage PostgreSQL, deploy pgAdmin:
```bash
ansible-playbook -i inventories/barista/test/hosts playbook/pgadmin.yaml --vault-password-file .vault
```
Access at: `http://<node-ip>:<pgadmin-nodeport>`

pgAdmin connects to PostgreSQL using the same `-rw` service. See `roles/kubernetes/pgadmin/README.md`.

---

## What to Deploy Before This Role

| Prerequisite | Role/Playbook | Why needed |
|-------------|---------------|------------|
| Kubernetes cluster | `kubernetes_master_setup.yaml` + `kubernetes_worker_setup.yaml` | CNPG runs on K8s |
| Longhorn StorageClass | `longhorn.yaml` | PVCs for PostgreSQL data |

## What to Deploy After (Optional)

| Component | Role/Playbook | Why |
|-----------|---------------|-----|
| pgAdmin | `pgadmin.yaml` | Web UI for database management |
| Application services | Your app playbooks | Connect to PostgreSQL |

---

## Connecting Applications

Applications inside the cluster connect via Kubernetes service DNS:

```
# Read-Write (primary only — for writes and reads that need latest data)
<cluster-name>-rw.<namespace>.svc.cluster.local:5432

# Read-Only (replicas — for read scaling)
<cluster-name>-ro.<namespace>.svc.cluster.local:5432

# Read-Any (any instance — for non-critical reads)
<cluster-name>-r.<namespace>.svc.cluster.local:5432

# PgBouncer Pooled (if enabled — recommended for application traffic)
<cluster-name>-pooler-rw.<namespace>.svc.cluster.local:5432
```

**Example connection string:**
```
postgresql://postgres:<password>@barista-test-rw.cnpg-postgres.svc.cluster.local:5432/postgres
```

**When to use which service:**

| Service | Use for |
|---------|---------|
| `<cluster>-rw` | Writes, DDL, migrations, admin, sessions with prepared statements |
| `<cluster>-ro` | Read scaling (queries that can tolerate slight replication lag) |
| `<cluster>-pooler-rw` | Application traffic (high connection count, short-lived transactions) |

**External access (NodePort):** If `ports.kubernetes.postgres.nodeport` is set, connect from outside the cluster using `<any-node-ip>:<nodeport>`. Only the primary is exposed.

**Important for PgBouncer users:** If your application uses prepared statements or session-level SET commands across transactions, connect directly to `-rw` instead of `-pooler-rw`. Transaction pool mode resets session state between transactions.

---

## Manual Operations

### Trigger manual backup
```bash
kubectl apply -f - <<EOF
apiVersion: postgresql.cnpg.io/v1
kind: Backup
metadata:
  name: manual-$(date +%Y%m%d%H%M)
  namespace: cnpg-postgres
spec:
  cluster:
    name: barista-test
EOF
```

### Check backup status
```bash
kubectl get backups -n cnpg-postgres
kubectl get scheduledbackups -n cnpg-postgres
```

### Promote replica (manual failover)
```bash
kubectl -n cnpg-postgres annotate cluster barista-test \
  cnpg.io/targetPrimary=barista-test-2
```

### Connect to primary
```bash
kubectl -n cnpg-postgres exec -it barista-test-1 -- psql -U postgres -d postgres
```

### List extensions
```bash
kubectl -n cnpg-postgres exec -it barista-test-1 -- \
  psql -U postgres -d postgres -c "SELECT extname, extversion FROM pg_extension;"
```

### Check replication lag
```bash
kubectl -n cnpg-postgres exec -it barista-test-1 -- \
  psql -U postgres -c "SELECT client_addr, state, sent_lsn, write_lsn, flush_lsn, replay_lsn FROM pg_stat_replication;"
```

### Restore from backup (new cluster)
```yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: restored-cluster
spec:
  instances: 3
  bootstrap:
    recovery:
      source: barista-test
  externalClusters:
    - name: barista-test
      connectionParameters:
        host: "source-primary.source-namespace.svc.cluster.local"
        user: "postgres"
        dbname: "postgres"
      password:
        name: migration-credentials
        key: password
```

---

## File Structure

```
roles/kubernetes/postgres/
├── defaults/main.yml                    # All variables with sources and defaults
├── tasks/
│   ├── main.yaml                        # Orchestrator
│   ├── validate.yml                     # Pre-flight checks (7 validations)
│   ├── operator.yml                     # CNPG operator Helm install/upgrade
│   ├── deploy.yml                       # Namespace + secrets + cluster CR + wait
│   ├── extensions.yml                   # Install PostgreSQL extensions
│   └── verify.yml                       # Health check + connection info
├── templates/
│   ├── cnpg-cluster.yaml.j2           # Cluster CR + Pooler + ScheduledBackup
│   └── cnpg-nodeport.yaml.j2          # NodePort service for external access
└── README.md                            # This file
```

---

## Configuration Examples

### Test (Single Instance, Minimal)
```yaml
postgres:
  namespace: cnpg-postgres
  cluster_name: barista-test
  instances: 1
  db_name: postgres
  db_user: postgres
  extensions: [pgjwt, pgcrypto]
  storage_class: longhorn
  storage_size: 10Gi
  resources:
    requests: { cpu: "250m", memory: "512Mi" }
    limits: { cpu: "1000m", memory: "2Gi" }
  parameters:
    shared_buffers: "512MB"
    effective_cache_size: "1536MB"
  pgbouncer: { enabled: false }
  backup:
    longhorn: { enabled: false }
```

### Production (3 Instances, Full HA)
```yaml
postgres:
  namespace: cnpg-postgres
  cluster_name: mat-prod
  instances: 3
  db_name: postgres
  db_user: postgres
  extensions: [pgjwt, pgcrypto, uuid-ossp, pg_stat_statements, pg_trgm]
  storage_class: longhorn
  storage_size: 50Gi
  wal_storage: { enabled: true, size: 10Gi }
  resources:
    requests: { cpu: "1000m", memory: "4Gi" }
    limits: { cpu: "4000m", memory: "8Gi" }
  parameters:
    max_connections: 500
    shared_buffers: "2GB"
    effective_cache_size: "6GB"
    work_mem: "8MB"
    maintenance_work_mem: "512MB"
    synchronous_commit: "on"
    shared_preload_libraries: "pg_stat_statements"
  pgbouncer:
    enabled: true
    pool_mode: transaction
    default_pool_size: 50
    max_client_conn: 200
    instances: 2
  backup:
    longhorn:
      enabled: true
      schedule: "0 3 * * *"
      retain: 7
    longhorn:
      enabled: true
      schedule: "0 3 * * *"
      retain: 14
  topology:
    node_label_key: node-role.kubernetes.io/database
    node_label_value: "true"
  superuser_enabled: false
```

---

## Troubleshooting

### Cluster stuck in "Setting up primary"
```bash
kubectl -n cnpg-postgres describe cluster barista-test
kubectl -n cnpg-postgres logs barista-test-1
# Check events for PVC binding issues
kubectl -n cnpg-postgres get events --sort-by='.lastTimestamp'
```

### Extension install fails
Some extensions require `shared_preload_libraries`. Add to parameters:
```yaml
parameters:
  shared_preload_libraries: "pg_stat_statements,pg_cron"
```
Re-run playbook — CNPG rolling-restarts instances.

### PgBouncer "prepared statement does not exist"
This happens in `transaction` pool mode when the app uses prepared statements across transactions. Options:
1. Switch to `session` mode (reduces pooling efficiency)
2. Fix the app to not use cross-transaction prepared statements
3. Connect that specific service directly to `-rw` (bypass PgBouncer)

### Backup failing
```bash
kubectl -n cnpg-postgres get backups
kubectl -n cnpg-postgres describe backup <name>
```

### Pod OOMKilled
Increase memory limit. Check if `shared_buffers` + `work_mem × max_connections` exceeds the pod memory limit.

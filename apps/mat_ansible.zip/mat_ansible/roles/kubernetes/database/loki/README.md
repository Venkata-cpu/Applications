# Loki on Kubernetes

Deploys [Grafana Loki](https://grafana.com/oss/loki/) as a StatefulSet on Kubernetes for log aggregation. Loki receives logs pushed by Fluent Bit (deployed via the K8s logging role) and makes them queryable via LogQL in Grafana. Uses TSDB storage on a Longhorn PVC for persistence. Deployed as a single-binary (all-in-one) mode suitable for small-to-medium clusters.

---

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Grafana Loki** | https://github.com/grafana/loki/releases | Defined in `version.kubernetes.loki` |
| **Container Image** | https://hub.docker.com/r/grafana/loki/tags | `grafana/loki` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ cluster running | `kubectl version` |
| **Longhorn StorageClass** | For persistent log data | `kubectl get sc longhorn` |
| **kubectl** | Available on master node | `which kubectl` |
| **ansible_user** | Has kubectl access on master | `sudo -u <user> --set-home kubectl get nodes` |
| **Fluent Bit** (optional) | To push logs into Loki | Deploy via `kubernetes_logging` role with Loki target |

---

## How to Run

```bash
# Standard deployment
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_loki.yaml \
  --vault-password-file .vault

# With target host override
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_loki.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kubernetes_master_init"
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.loki` | `3.7.0` | Loki container image tag |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.loki.namespace` | `loki` | K8s namespace | All resources deployed here |
| `config_k8s.loki.release_name` | `loki` | StatefulSet and service name | Used in service DNS |
| `config_k8s.loki.storage_class` | `longhorn` | PVC StorageClass | Must exist in cluster |
| `config_k8s.loki.storage_size` | `20Gi` | PVC size for log data | **Increase** for high-volume environments. Size = ingestion rate × retention period. |
| `config_k8s.loki.http_port` | `3100` | HTTP API / push endpoint | Standard Loki port |
| `config_k8s.loki.grpc_port` | `9096` | gRPC port (internal) | Only used in multi-node mode |
| `ports.kubernetes.loki.nodeport` | `0` | NodePort (0 = ClusterIP only) | Set to enable external access (e.g., from bare-metal Grafana) |
| `config_k8s.loki.retention_period` | `168h` | How long to keep log data (7 days) | **Increase:** More history, more disk. **Decrease:** Less disk, shorter query range. |
| `config_k8s.loki.retention_enabled` | `true` | Whether compactor deletes old data | **false:** Data grows unbounded — monitor disk! |
| `config_k8s.loki.ingestion_rate_mb` | `10` | Max MB/s ingestion per tenant | **Increase** for high-volume log producers. If exceeded, Loki returns 429. |
| `config_k8s.loki.ingestion_burst_mb` | `20` | Burst above rate limit | Should be 2× `ingestion_rate_mb`. |
| `config_k8s.loki.max_streams` | `10000` | Max active log streams per tenant | **Increase** if many unique label combinations. |
| `config_k8s.loki.resources.requests_cpu` | `100m` | CPU request | |
| `config_k8s.loki.resources.requests_memory` | `256Mi` | Memory request | |
| `config_k8s.loki.resources.limits_cpu` | `1000m` | CPU limit | |
| `config_k8s.loki.resources.limits_memory` | `1Gi` | Memory limit | **Increase** for high-ingestion or heavy query load. OOM-killed if exceeded. |
| `config_k8s.loki.wait_retries` | `15` | Readiness verification retries | |
| `config_k8s.loki.wait_delay` | `10` | Seconds between retries | |

### Inventory Example

```yaml
# versions.yml
version:
  kubernetes:
    loki: "3.7.0"

# networks.yml
ports:
  kubernetes:
    loki:
      nodeport: 0          # 0 = ClusterIP only. Set e.g. 61075 for external access.

# config_kubernetes.yml (under config_k8s)
  loki:
    namespace: loki
    release_name: loki
    storage_class: longhorn
    storage_size: "20Gi"
    retention_period: "168h"
    retention_enabled: true
    ingestion_rate_mb: 10
    ingestion_burst_mb: 20
    max_streams: 10000
    resources:
      requests_cpu: "100m"
      requests_memory: "256Mi"
      limits_cpu: "1000m"
      limits_memory: "1Gi"
```

---

## What Gets Deployed

```
Namespace: loki
├── ConfigMap/loki-config           # Full Loki config (TSDB, retention, ingestion limits)
├── Service/loki-headless (ClusterIP:None)  # StatefulSet DNS for internal comms
├── Service/loki (ClusterIP or NodePort)    # External/internal access
└── StatefulSet/loki                        # Loki server pod
    └── Pod/loki-0                          # Single replica with Longhorn PVC
        ├── /etc/loki (ConfigMap mount)
        └── /loki (PVC: chunks, index, compactor data)
```

**Prometheus annotations:** Both Service and Pod are annotated with `prometheus.io/scrape: "true"` for auto-discovery.

---

## Task Execution Flow

```
main.yml
├── validate.yml    — Version defined, kubectl available, display config summary
├── install.yml     — Create namespace, template manifest, kubectl apply, wait for rollout
└── verify.yml      — Pod Running, /ready endpoint responding, display connection info
```

- **Deploy method:** Raw K8s manifests (no Helm dependency) — uses `loki-statefulset.yaml.j2` applied via `kubectl apply`
- **Idempotent:** Re-running with same config produces no changes. Updated config triggers a rolling restart.
- **Manifest lifecycle:** Templated to `/tmp/k8s-loki.yaml` with mode `0600`, deleted after apply.

---

## Fluent Bit Integration

Point the K8s Fluent Bit role (logging) to Loki instead of Elasticsearch. In your inventory config:

```yaml
config_k8s:
  logging:
    # Use Loki as output instead of Elasticsearch
    loki:
      host: "loki.loki.svc.cluster.local"
      port: 3100
```

Or configure Fluent Bit manually with the Loki output plugin:

```ini
[OUTPUT]
    Name          loki
    Match         kube.*
    Host          loki.loki.svc.cluster.local
    Port          3100
    Labels        job=fluent-bit
    Auto_Kubernetes_Labels on
```

---

## Grafana Integration

### Add as Data Source in Grafana

1. Open Grafana → **Connections** → **Data Sources** → **Add data source**
2. Type: **Loki**
3. Settings:
   - **URL:** `http://loki.loki.svc.cluster.local:3100` (if Grafana is in K8s)
   - **URL:** `http://<node-ip>:<nodeport>` (if external Grafana + NodePort enabled)
4. Click **Save & Test**

### Example LogQL Queries

```logql
# All logs from a namespace
{namespace="harbor"}

# Error logs from a specific pod
{pod="librefs-0"} |= "error"

# Logs with JSON parsing
{namespace="kafka"} | json | level="ERROR"

# Rate of log lines per minute
rate({namespace="supabase"}[5m])

# Top 10 pods by log volume
topk(10, sum by (pod) (rate({namespace=~".+"}[1h])))
```

---

## Accessing Loki

### From inside the cluster (Fluent Bit, Grafana, other K8s pods)

```
http://loki.loki.svc.cluster.local:3100
```

### From K8s master/worker nodes

```bash
# Via pod exec
kubectl exec -n loki loki-0 -- wget -qO- http://localhost:3100/ready

# Via ClusterIP
kubectl run curl-test --rm -it --restart=Never --image=alpine/curl -- \
  curl -s http://loki.loki.svc:3100/ready
```

### From external (bare-metal Grafana, dev machine)

If NodePort is configured (e.g., `61075`):
```bash
curl http://<any-k8s-node-ip>:61075/ready
```

---

## Post-Deployment Verification

```bash
# 1. Pod running
kubectl get pods -n loki -o wide

# 2. Ready endpoint
kubectl exec -n loki loki-0 -- wget -qO- http://localhost:3100/ready
# Expected: "ready"

# 3. Metrics endpoint
kubectl exec -n loki loki-0 -- wget -qO- http://localhost:3100/metrics | head -5
# Expected: Prometheus metrics output

# 4. Service
kubectl get svc -n loki
# Expected: loki (ClusterIP or NodePort) + loki-headless (ClusterIP:None)

# 5. PVC bound
kubectl get pvc -n loki
# Expected: data-loki-0  Bound  <pv>  20Gi  RWO  longhorn

# 6. Test log push
kubectl exec -n loki loki-0 -- wget -qO- --post-data='{"streams":[{"stream":{"job":"test"},"values":[["'$(date +%s)000000000'","test from verification"]]}]}' \
  --header='Content-Type: application/json' \
  http://localhost:3100/loki/api/v1/push
# Expected: 204 No Content

# 7. Query logs back
kubectl exec -n loki loki-0 -- wget -qO- 'http://localhost:3100/loki/api/v1/query?query={job="test"}'
# Expected: JSON with your test log entry
```

---

## Upgrade Process

1. Update `version.kubernetes.loki` in `versions.yml`
2. Re-run the playbook — `kubectl apply` updates the StatefulSet image tag
3. Pod restarts with new version (RollingUpdate strategy)
4. Data on Longhorn PVC is preserved — no data loss
5. Loki may take 15-30s to become ready (TSDB replay)

```bash
# Example: upgrade from 3.5.0 to 3.7.0
# Edit: inventories/<module>/<env>/group_vars/all/versions.yml
#   kubernetes:
#     loki: "3.7.0"

ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_loki.yaml \
  --vault-password-file .vault
```

---

## Troubleshooting

### Checking Logs

```bash
# Pod logs (last 50 lines)
kubectl logs -n loki loki-0 --tail=50

# Follow live
kubectl logs -n loki loki-0 -f

# Events
kubectl get events -n loki --sort-by='.lastTimestamp'
```

### Pod stuck in Pending

```bash
kubectl describe pod -n loki loki-0
# Common: PVC not bound (Longhorn not ready), insufficient resources
```

### Pod CrashLoopBackOff

```bash
kubectl logs -n loki loki-0 --previous
# Common: config syntax error, port conflict, data corruption
```

### Ingestion rate limit (HTTP 429)

```bash
# Check metrics
kubectl exec -n loki loki-0 -- wget -qO- http://localhost:3100/metrics | grep loki_discarded_samples_total

# Increase limits:
config_k8s:
  loki:
    ingestion_rate_mb: 20
    ingestion_burst_mb: 40
```

### Disk full / PVC full

```bash
# Check PVC usage
kubectl exec -n loki loki-0 -- df -h /loki

# Options:
# 1. Reduce retention_period
# 2. Expand PVC (if Longhorn supports)
kubectl patch pvc data-loki-0 -n loki -p '{"spec":{"resources":{"requests":{"storage":"50Gi"}}}}'
```

### Ready endpoint not responding

```bash
# Check startup logs
kubectl logs -n loki loki-0 | head -30

# Common: TSDB replay taking time (large dataset), OOMKilled (increase memory)
kubectl describe pod -n loki loki-0 | grep -A2 "Last State"
```

---

## Security Notes

- Pods run as non-root (UID 10001, fsGroup 10001)
- No authentication on API — rely on network-level access control (namespace network policies, firewall)
- `analytics.reporting_enabled: false` — no telemetry sent to Grafana Labs
- Manifest templated to `/tmp` with mode `0600`, deleted immediately after apply
- Prometheus metrics exposed via annotations (auto-discovered)
- NodePort disabled by default (ClusterIP only) — set `nodeport > 0` to expose externally

---

## File Structure

```
roles/kubernetes/database/loki/
├── defaults/main.yml                  # All variables with defaults
├── tasks/
│   ├── main.yml                       # Orchestrator (validate → install → verify)
│   ├── validate.yml                   # Pre-flight checks (version, kubectl)
│   ├── install.yml                    # Namespace, template, apply, rollout wait
│   └── verify.yml                     # Pod running, /ready, status summary
├── templates/
│   └── loki-statefulset.yaml.j2      # ConfigMap + Headless svc + Service + StatefulSet
└── README.md                          # This file
```

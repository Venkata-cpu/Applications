# Kubernetes pgAdmin Role

Deploys [pgAdmin 4](https://www.pgadmin.org/) — a web-based PostgreSQL administration tool — on Kubernetes. Pre-configures the connection to the CNPG PostgreSQL cluster automatically (no manual server setup needed after login).

## What is pgAdmin?

pgAdmin is the most popular open-source GUI for PostgreSQL. It provides:
- SQL editor with auto-complete
- Visual query builder
- Table/index/constraint management
- Server monitoring (active queries, locks, stats)
- Backup/restore wizards
- User/role management

## Version Reference

| Component | Check Latest | Current |
|-----------|-------------|---------|
| pgAdmin 4 | [Docker Hub Tags](https://hub.docker.com/r/dpage/pgadmin4/tags) | Check `version.kubernetes.pgadmin` in inventory |
| pgAdmin Docs | [pgadmin.org/docs](https://www.pgadmin.org/docs/pgadmin4/latest/) | — |

## Prerequisites

| Prerequisite | Why |
|-------------|-----|
| Kubernetes cluster running | pgAdmin runs as a K8s Deployment |
| StorageClass available (Longhorn) | PVC for pgAdmin session/config data |
| PostgreSQL deployed (CNPG role) | pgAdmin connects to it — deploy postgres first |

## How It Works

1. **Validate** (`validate.yml`) — checks credentials, warns if PostgreSQL not found yet
2. **Deploy** (`deploy.yml`) — creates namespace, secret, PVC, ConfigMap (auto-server), deployment, service
3. **Verify** (`verify.yml`) — checks pod status, displays access URL

**Auto-server registration:** The role creates a `servers.json` ConfigMap that pre-configures the PostgreSQL connection. When you log into pgAdmin, the server appears automatically under "CNPG Clusters" — no need to manually add it.

**Password-less login to PG:** A `.pgpass` file is injected via init container so pgAdmin connects to PostgreSQL without prompting for the DB password.

## Configuration

### versions.yml
```yaml
version:
  kubernetes:
    pgadmin: "8.14"              # pgAdmin 4 Docker image tag
```

### networks.yml
```yaml
ports:
  kubernetes:
    pgadmin:
      nodeport: 61030            # NodePort for web UI access
```

### app_configs.yml (under config.kubernetes)
```yaml
    pgadmin:
      email: admin@example.com           # Login email for pgAdmin web UI
      # namespace: cnpg-postgres         # Defaults to postgres namespace
      # storage_class: longhorn          # Defaults to postgres storage class
      # storage_size: 2Gi               # Session/config storage
      # image: dpage/pgadmin4            # Override only if using private registry
      # resources:
      #   requests:
      #     cpu: "100m"
      #     memory: "256Mi"
      #   limits:
      #     cpu: "500m"
      #     memory: "512Mi"
      # topology:
      #   node_label_key: ""
      #   node_label_value: ""
```

### Vault secrets (all_secrets.yml)
```yaml
pgadmin_password_vault: "<pgadmin-login-password>"
```

**Note:** `postgres_db_password_vault` is also required (used to auto-configure the PG connection). This is the same secret used by the postgres role — no duplication needed.

## Running the Playbook

```bash
# Deploy pgAdmin (after PostgreSQL is running)
ansible-playbook -i inventories/barista/test/hosts playbook/pgadmin.yaml --vault-password-file .vault
```

## Accessing pgAdmin

After deployment:

1. Get the URL from playbook output, or:
   ```bash
   # Find node IP
   kubectl get nodes -o wide

   # Access pgAdmin
   http://<node-ip>:61030
   ```

2. Login with:
   - **Email:** value from `config.kubernetes.pgadmin.email`
   - **Password:** value from `pgadmin_password_vault`

3. The PostgreSQL server is **already configured** — expand "CNPG Clusters" in the left panel.

## Post-Installation Verification

```bash
# 1. Check pod is running
kubectl get pods -n cnpg-postgres -l app=pgadmin

# 2. Check service
kubectl get svc pgadmin -n cnpg-postgres

# 3. Check logs if pod is crashing
kubectl logs -n cnpg-postgres -l app=pgadmin

# 4. Verify web UI is responding
curl -s -o /dev/null -w "%{http_code}" http://<node-ip>:61030/misc/ping
# Should return: 200
```

## File Structure

```
roles/kubernetes/pgadmin/
├── defaults/main.yml                    # All variables (sources from postgres config)
├── tasks/
│   ├── main.yaml                        # Orchestrator
│   ├── validate.yml                     # Pre-flight checks
│   ├── deploy.yml                       # Secret + PVC + ConfigMap + Deployment + Service
│   └── verify.yml                       # Status check + URL display
├── templates/
│   ├── pgadmin-secret.yaml.j2          # Login credentials
│   ├── pgadmin-pvc.yaml.j2            # Persistent storage (Longhorn)
│   ├── pgadmin-servers.json.j2        # Auto-register PostgreSQL server
│   ├── pgadmin-deployment.yaml.j2     # Pod spec with probes + resources
│   └── pgadmin-service.yaml.j2        # NodePort service
└── README.md                            # This file
```

## Key Design Decisions

| Decision | Why |
|----------|-----|
| **PVC instead of hostPath** | Data survives pod rescheduling. hostPath ties you to one node |
| **servers.json auto-config** | No manual server setup after login — ready to use immediately |
| **pgpass file injection** | Seamless PG connection without password prompts in UI |
| **No RBAC** | pgAdmin only connects to PostgreSQL via TCP — no K8s API access needed |
| **Liveness/readiness probes** | K8s restarts unhealthy pod, doesn't route traffic until ready |
| **Resource limits** | Prevents pgAdmin from consuming excessive resources |
| **securityContext (UID 5050)** | pgAdmin's official container runs as user 5050 |

## Troubleshooting

### Pod stuck in Init
```bash
kubectl describe pod -n cnpg-postgres -l app=pgadmin
# Check if PVC is bound
kubectl get pvc pgadmin-data -n cnpg-postgres
```

### Login fails
- Verify email matches `config.kubernetes.pgadmin.email` exactly
- Verify password matches `pgadmin_password_vault`
- Check secret: `kubectl get secret pgadmin-secret -n cnpg-postgres -o yaml`

### PostgreSQL server not showing in pgAdmin
- Check ConfigMap: `kubectl get configmap pgadmin-servers -n cnpg-postgres -o yaml`
- Verify PostgreSQL is running: `kubectl get cluster -n cnpg-postgres`
- Check pgAdmin logs: `kubectl logs -n cnpg-postgres -l app=pgadmin`

### "Connection refused" when clicking the server
- PostgreSQL must be deployed first
- Check the host in servers.json matches the actual service name
- Test connectivity: `kubectl exec -n cnpg-postgres deploy/pgadmin -- pg_isready -h <pg-host> -p 5432`

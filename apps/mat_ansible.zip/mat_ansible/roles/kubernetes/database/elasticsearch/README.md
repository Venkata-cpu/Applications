# Elasticsearch on Kubernetes

Deploys Elasticsearch as a StatefulSet on Kubernetes for K8s pod log storage (Fluent Bit → Elasticsearch). Supports single-node (test) and multi-node cluster (production) modes with Longhorn PVC persistence.

## Latest Version

| Component | Check Latest |
|-----------|-------------|
| **Elasticsearch** | https://www.elastic.co/downloads/elasticsearch |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Kubernetes cluster | Running with kubectl access | `kubectl get nodes` |
| Longhorn StorageClass | For persistent data | `kubectl get sc longhorn` |
| Vault secrets | Not required (security disabled by default) | — |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_elasticsearch.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.elasticsearch` | `8.19.16` | Elasticsearch image tag |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.elasticsearch.namespace` | `elasticsearch` | K8s namespace | |
| `config_k8s.elasticsearch.replicas` | `1` | Nodes (1=single-node, 3+=cluster) | 3+ enables HA with shard replication |
| `config_k8s.elasticsearch.cluster_name` | `k8s-logs` | ES cluster name | |
| `config_k8s.elasticsearch.storage_class` | `longhorn` | StorageClass for PVCs | |
| `config_k8s.elasticsearch.storage_size` | `30Gi` | PVC size per node | Size based on log volume × retention |
| `config_k8s.elasticsearch.heap_size` | `1g` | JVM heap (Xms=Xmx) | Never exceed 50% of memory limit or 31g |
| `config_k8s.elasticsearch.retention_days` | `7` | Log retention (for reference) | Actual ILM configured separately |
| `config_k8s.elasticsearch.security_enabled` | `false` | Enable xpack security | `true` requires auth setup |
| `config_k8s.elasticsearch.resources.requests_cpu` | `500m` | CPU request | |
| `config_k8s.elasticsearch.resources.requests_memory` | `2Gi` | Memory request | |
| `config_k8s.elasticsearch.resources.limits_cpu` | `2000m` | CPU limit | |
| `config_k8s.elasticsearch.resources.limits_memory` | `4Gi` | Memory limit | Must be >= 2× heap_size |
| `config_k8s.elasticsearch.topology.node_label_key` | `''` | Node affinity label | Empty = no affinity |
| `ports.kubernetes.elasticsearch.nodeport` | `0` | NodePort (0=ClusterIP only) | Set to enable external access |

---

## Deployment Modes

### Single Node (Test/Pre-prod)

```yaml
config_k8s:
  elasticsearch:
    replicas: 1
    storage_size: "30Gi"
    heap_size: "1g"
```

### Multi-Node Cluster (Production)

```yaml
config_k8s:
  elasticsearch:
    replicas: 3
    storage_size: "100Gi"
    heap_size: "4g"
    resources:
      limits_memory: "8Gi"
```

---

## What Gets Deployed

```
Namespace: elasticsearch
├── Service/elasticsearch-headless (ClusterIP:None)  # StatefulSet DNS
├── Service/elasticsearch (ClusterIP or NodePort)    # External access
└── StatefulSet/elasticsearch                        # ES nodes
    ├── Pod/elasticsearch-0                          # + Longhorn PVC
    ├── Pod/elasticsearch-1 (if replicas >= 3)
    └── Pod/elasticsearch-2 (if replicas >= 3)
```

---

## Task Execution Flow

```
main.yml
├── validate.yml    — Version, replicas valid, memory >= 2x heap, kubectl available
├── install.yml     — Namespace, template manifest, apply StatefulSet, wait for rollout
└── verify.yml      — All pods Running, cluster health green/yellow, display status
```

---

## Fluent Bit Integration

Point the K8s Fluent Bit role (logging) to this Elasticsearch. In your inventory config:

```yaml
config_k8s:
  logging:
    elasticsearch:
      host: "elasticsearch.elasticsearch.svc.cluster.local"
      port: 9200
```

Fluent Bit will send all K8s pod logs to this Elasticsearch. Index pattern: `kubelogs-*` (daily indices like `kubelogs-19.06.2026`).

---

## Accessing Elasticsearch

### From inside the cluster (other K8s pods/services)

```
http://elasticsearch.elasticsearch.svc.cluster.local:9200
```

Use this URL in any K8s-deployed application (Fluent Bit, Kibana, Grafana, custom apps).

### From K8s master or worker nodes

```bash
# Via ClusterIP (from any node with kubectl access)
kubectl exec -n elasticsearch elasticsearch-0 -- curl -s http://localhost:9200/

# Via NodePort (if configured, e.g., 61007)
curl http://<any-node-ip>:61007/
```

### From external services (bare-metal Grafana, Kibana, etc.)

If NodePort is enabled (e.g., `61007`), use:
```
http://<k8s-worker-ip>:61007
```

Or via HAProxy if you route through it:
```
http://<haproxy-vip>:<external-port>
```

---

## Grafana Integration

### Add as Data Source in Grafana

1. Open Grafana → **Configuration** → **Data Sources** → **Add data source**
2. Type: **Elasticsearch**
3. Settings:
   - **URL:** `http://<k8s-worker-ip>:<nodeport>` (external) or `http://elasticsearch.elasticsearch.svc:9200` (if Grafana is in K8s)
   - **Index name:** `kubelogs-*`
   - **Time field:** `@timestamp`
   - **Version:** `8.0+`
4. Click **Save & Test**

### Example Grafana Queries

- All logs from a namespace: `kubernetes_namespace_name: "harbor"`
- Error logs: `log: *error* OR log: *ERROR*`
- Specific pod: `kubernetes_pod_name: "librefs-0"`

---

## Kibana Integration

### Deploy Kibana pointing to this Elasticsearch

If using the existing bare-metal Kibana or deploying Kibana on K8s:

```yaml
# Kibana config (elasticsearch.hosts)
elasticsearch.hosts: ["http://elasticsearch.elasticsearch.svc.cluster.local:9200"]

# Or external
elasticsearch.hosts: ["http://<k8s-worker-ip>:<nodeport>"]
```

### Index Pattern Setup in Kibana

1. Open Kibana → **Stack Management** → **Index Patterns**
2. Create pattern: `kubelogs-*`
3. Time field: `@timestamp`
4. Now browse logs in **Discover** tab

---

## Useful Elasticsearch API Commands

```bash
# Set ES variable for convenience
ES="http://<node-ip>:<nodeport>"

# Cluster health
curl -s $ES/_cluster/health?pretty

# List indices
curl -s $ES/_cat/indices?v&s=index

# Search recent logs
curl -s "$ES/kubelogs-*/_search?size=5&sort=@timestamp:desc&pretty"

# Search logs by namespace
curl -s "$ES/kubelogs-*/_search?pretty" -H 'Content-Type: application/json' -d '
{
  "query": { "match": { "kubernetes_namespace_name": "harbor" } },
  "size": 10,
  "sort": [{ "@timestamp": "desc" }]
}'

# Check index size
curl -s "$ES/_cat/indices?v&h=index,docs.count,store.size&s=store.size:desc"

# Delete old indices (manual cleanup)
curl -s -X DELETE "$ES/kubelogs-01.06.2026"

# Set ILM policy (auto-delete after N days)
curl -s -X PUT "$ES/_ilm/policy/logs-retention" -H 'Content-Type: application/json' -d '
{
  "policy": {
    "phases": {
      "hot": { "actions": {} },
      "delete": {
        "min_age": "7d",
        "actions": { "delete": {} }
      }
    }
  }
}'

# Apply ILM to kubelogs template
curl -s -X PUT "$ES/_index_template/kubelogs" -H 'Content-Type: application/json' -d '
{
  "index_patterns": ["kubelogs-*"],
  "template": {
    "settings": {
      "index.lifecycle.name": "logs-retention"
    }
  }
}'
```

---

## Post-Deployment Verification

```bash
# 1. Pod status
kubectl get pods -n elasticsearch -o wide

# 2. Cluster health
kubectl exec -n elasticsearch elasticsearch-0 -- curl -s http://localhost:9200/_cluster/health?pretty

# 3. Indices
kubectl exec -n elasticsearch elasticsearch-0 -- curl -s http://localhost:9200/_cat/indices?v

# 4. Node info
kubectl exec -n elasticsearch elasticsearch-0 -- curl -s http://localhost:9200/_cat/nodes?v

# 5. From outside (if NodePort enabled)
curl http://<node-ip>:<nodeport>/_cluster/health?pretty
```

---

## Upgrade Process

1. Update `version.kubernetes.elasticsearch` in `versions.yml`
2. Re-run playbook — StatefulSet updates pods one at a time (RollingUpdate)
3. Data persists on Longhorn PVCs — no data loss during upgrade

---

## Troubleshooting

### Pods stuck in Init
```bash
kubectl describe pod -n elasticsearch elasticsearch-0
# Common: vm.max_map_count init container needs privileged (already included)
```

### Cluster health RED
```bash
kubectl exec -n elasticsearch elasticsearch-0 -- curl -s 'http://localhost:9200/_cluster/allocation/explain?pretty'
```

### Out of disk
```bash
# Check PVC usage
kubectl exec -n elasticsearch elasticsearch-0 -- df -h /usr/share/elasticsearch/data

# Expand PVC (if Longhorn supports expansion)
kubectl patch pvc data-elasticsearch-0 -n elasticsearch -p '{"spec":{"resources":{"requests":{"storage":"50Gi"}}}}'
```

---

## Security Notes

- Security disabled by default (`xpack.security.enabled: false`) — suitable for internal cluster traffic
- Enable security for production with external access (requires user/password setup)
- `vm.max_map_count` set via privileged init container (required by Elasticsearch)
- Pods use fsGroup 1000 (elasticsearch user)
- Prometheus metrics exposed via annotations (auto-discovered)

---

## File Structure

```
roles/kubernetes/database/elasticsearch/
├── defaults/main.yml
├── tasks/
│   ├── main.yml             # Orchestrator
│   ├── validate.yml         # Pre-flight checks
│   ├── install.yml          # Namespace + manifest + rollout wait
│   └── verify.yml           # Cluster health + status
├── templates/
│   └── elasticsearch-statefulset.yaml.j2   # Headless svc + NodePort svc + StatefulSet
└── README.md
```

# Kubernetes MongoDB (Percona Operator) Role

Deploys MongoDB on Kubernetes using the Percona Operator for MongoDB with ReplicaSet mode. The Percona Operator manages the full lifecycle of MongoDB — provisioning, scaling, backup, monitoring, and recovery — as a Kubernetes-native CRD.

## Components Deployed

- **Percona Operator for MongoDB** — installed via Helm, manages PSMDB custom resources
- **PerconaServerMongoDB CR** — ReplicaSet with configurable member count (1 for test, 3+ for prod)
- **NodePort service** — external access for applications outside the cluster
- **MongoDB Exporter** — sidecar for Prometheus metrics (optional, enabled by default)
- **Automated backups** — scheduled logical backups with retention (optional)

## Prerequisites

- Kubernetes cluster (1.28+)
- Helm installed on the control node
- `kubernetes.core` Ansible collection installed (`ansible-galaxy collection install kubernetes.core`)
- Longhorn StorageClass available (deployed via the Longhorn role)
- Nodes labeled for MongoDB scheduling (see below)
- `http_proxy` and `https_proxy` defined in global secrets/variables

## Node Labeling

Before running the playbook, label the nodes where MongoDB pods should run:

```bash
kubectl label node <node-name> node-role.kubernetes.io/mongodb=true
```

For production with 3 replicas, label at least 3 nodes:
```bash
kubectl label node worker-1 node-role.kubernetes.io/mongodb=true
kubectl label node worker-2 node-role.kubernetes.io/mongodb=true
kubectl label node worker-3 node-role.kubernetes.io/mongodb=true
```

The label key and value are configurable:
```yaml
topology:
  node_label_key: node-role.kubernetes.io/mongodb
  node_label_value: "true"
```

## Configuration for Different Environments

### Test (1 replica, no backup, minimal resources)
```yaml
config:
  kubernetes:
    mongodb:
      replicas: 1
      data_size: 20Gi
      resources:
        requests:
          cpu: "500m"
          memory: "1Gi"
        limits:
          cpu: "2000m"
          memory: "4Gi"
      backup:
        enabled: false
      metrics:
        enabled: true
```

### Production (3 replicas, daily backup, multi-node spread, more resources)
```yaml
config:
  kubernetes:
    mongodb:
      replicas: 3
      data_size: 100Gi
      resources:
        requests:
          cpu: "1000m"
          memory: "4Gi"
        limits:
          cpu: "4000m"
          memory: "8Gi"
      topology:
        node_label_key: node-role.kubernetes.io/mongodb
        node_label_value: "true"
        topology_key: kubernetes.io/hostname
      backup:
        enabled: true
        schedule: "0 3 * * *"
        storage_size: 50Gi
      metrics:
        enabled: true
```

### Multi Data Center (3 replicas spread across zones)
```yaml
config:
  kubernetes:
    mongodb:
      replicas: 3
      topology:
        node_label_key: node-role.kubernetes.io/mongodb
        node_label_value: "true"
        topology_key: topology.kubernetes.io/zone    # spread per zone
```

Node labeling for multi-DC:
```bash
kubectl label node worker-1 node-role.kubernetes.io/mongodb=true
kubectl label node worker-1 topology.kubernetes.io/zone=dc1

kubectl label node worker-3 node-role.kubernetes.io/mongodb=true
kubectl label node worker-3 topology.kubernetes.io/zone=dc2

kubectl label node worker-5 node-role.kubernetes.io/mongodb=true
kubectl label node worker-5 topology.kubernetes.io/zone=dc3
```

## Proxy Configuration (Important)

If your environment uses an HTTP proxy for outbound traffic, you must configure `no_proxy` correctly. The MongoDB role uses `kubectl` and Helm which make API calls to the Kubernetes API server. If the K8s API hostname/IP is not in `no_proxy`, these calls will be routed through the proxy and fail.

```yaml
config:
  kubernetes:
    mongodb:
      no_proxy: "localhost,127.0.0.1,.svc,.cluster.local,10.13.0.0/16,.nat.bt.com"
```

The `no_proxy` value must include:
- `localhost,127.0.0.1` — loopback addresses
- `.svc,.cluster.local` — Kubernetes internal DNS suffixes
- Your K8s API server IP/subnet (e.g., `10.13.0.0/16`)
- Any internal DNS domain your cluster uses (e.g., `.nat.bt.com`)

`http_proxy` and `https_proxy` must be defined in global secrets/variables. The playbook will fail if they are not defined — this is intentional to prevent silent misconfigurations.

## Pre-flight Validations

The role runs automated checks before deploying. If any check fails, the playbook stops immediately with a clear error message:

| Check | Rule | Why |
|-------|------|-----|
| Replicas is odd | 1, 3, or 5 | MongoDB ReplicaSet election requires a majority vote. Even numbers risk split-brain scenarios. |
| Node label defined | Not empty | Empty means no node targeting — pods could go anywhere including non-designated nodes. |
| Admin user defined | Not empty | MongoDB requires authentication. Empty admin user would create an insecure cluster. |

## How It Works

1. **Validate** (`validate.yml`) — pre-flight checks on replica count, node labels, admin user
2. **Operator** (`operator.yml`) — adds Percona Helm repo, installs/upgrades operator, waits for deployment readiness
3. **Deploy** (`deploy.yml`) — creates admin secret, deploys PSMDB cluster CR with all config, deploys NodePort service, waits for cluster ready state

The role is idempotent — re-running with updated config values will patch the existing resources (Percona Operator handles rolling updates automatically).

## Metrics and Monitoring

When `metrics.enabled: true` (default), the Percona Operator deploys a MongoDB Exporter sidecar in each replica pod. Metrics are exposed on port 9216 in Prometheus format.

### Prometheus Integration

Add the scrape job from `templates/mongodb-prometheus-scrape.yml.j2` to your Prometheus config. Prometheus auto-discovers MongoDB pods via Kubernetes API — no static IPs needed:

```yaml
scrape_configs:
  - job_name: 'percona-mongodb'
    kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
            - mongodb
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_label_app_kubernetes_io_instance]
        action: keep
        regex: mongodb-rs
      - source_labels: [__meta_kubernetes_pod_container_port_name]
        action: keep
        regex: metrics
      - source_labels: [__meta_kubernetes_namespace]
        target_label: namespace
      - source_labels: [__meta_kubernetes_pod_name]
        target_label: pod
      - source_labels: [__meta_kubernetes_pod_label_app_kubernetes_io_replset]
        target_label: replset
```

### Key Metrics to Watch

| Metric | What it tells you | Alert if |
|--------|-------------------|----------|
| `mongodb_up` | Whether the instance is reachable | == 0 for > 30s |
| `mongodb_ss_repl_myState` | ReplicaSet member state (1=PRIMARY, 2=SECONDARY) | No PRIMARY exists |
| `mongodb_ss_opcounters_insert` | Insert operations per second | Sudden drop (data pipeline issue) |
| `mongodb_ss_opcounters_query` | Query operations per second | Unexpected spike (possible abuse) |
| `mongodb_ss_connections_current` | Current active connections | > 80% of max connections |
| `mongodb_ss_mem_resident` | Resident memory usage (MB) | Approaching container memory limit |
| `mongodb_ss_wiredTiger_cache_bytes_currently_in_the_cache` | WiredTiger cache usage | > 80% of configured cache |
| `mongodb_ss_repl_oplog_timeDiff` | Oplog window in seconds | < 3600 (less than 1 hour means secondaries may not recover from outage) |
| `mongodb_ss_repl_lag` | Replication lag in seconds | > 10s (secondary falling behind) |

## Backup Configuration

When `backup.enabled: true`, the Percona Operator deploys Percona Backup for MongoDB (PBM) and schedules automated logical backups:

```yaml
backup:
  enabled: true
  schedule: "0 3 * * *"      # Daily at 3 AM
  storage_class: longhorn     # Where to store backups
  storage_size: 10Gi          # PVC size for backup storage
```

Backups are:
- **Logical** (mongodump-based) — portable, can restore to different clusters
- **Retained** for 7 days (last 7 backups kept)
- **Stored on Longhorn** PVC — can be expanded if needed

To restore from backup, use `kubectl` with the Percona backup CRDs (see Percona documentation).

## Variable Reference

### versions.yml
```yaml
version:
  kubernetes:
    mongodb:
      operator: 1.22.0      # Percona Operator Helm chart version
      server: 8.0.17-6      # Percona Server for MongoDB version
      exporter: 0.43.1      # MongoDB Prometheus exporter version
```

### networks.yml
```yaml
ports:
  kubernetes:
    mongodb:
      nodeport: 61017       # Legacy single-port (used when expose.enabled: false)
      nodeports:            # Per-member fixed ports (used when expose.enabled: true)
        - 61017
        - 61018
        - 61019
      internal: 27017       # MongoDB internal port
      metrics: 9216         # Prometheus metrics port
```

### app_configs.yml (under config.kubernetes)
```yaml
mongodb:
  # Core
  namespace: mongodb
  cluster_name: mongodb-rs
  # Replicas (1 for test, 3 for prod — must be odd)
  replicas: 1
  # Storage
  storage_class: longhorn
  data_size: 20Gi
  # Resources
  resources:
    requests:
      cpu: "500m"
      memory: "1Gi"
    limits:
      cpu: "2000m"
      memory: "4Gi"
  # Auth
  admin_user: admin
  # Expose (per-member NodePort for external replica set connections)
  expose:
    enabled: true                          # false = single NodePort, true = per-member + replsetOverrides
    external_hostname: barista.nat.bt.com  # LB/DNS hostname for external clients
    split_horizons:                        # One entry per replica — sets the advertised host:port
      - "barista.nat.bt.com:61017"
      - "barista.nat.bt.com:61018"
      - "barista.nat.bt.com:61019"
  # Topology & Affinity
  topology:
    node_label_key: node-role.kubernetes.io/mongodb
    node_label_value: "true"
    topology_key: kubernetes.io/hostname      # Single DC: hostname, Multi DC: topology.kubernetes.io/zone
  # Backup (optional)
  backup:
    enabled: false
    schedule: "0 3 * * *"
    storage_class: longhorn
    storage_size: 10Gi
  # Metrics
  metrics:
    enabled: true
  # Proxy
  no_proxy: "localhost,127.0.0.1,.svc,.cluster.local"
  # Helm (override only if using private registry/mirror)
  # helm:
  #   repo_name: percona
  #   repo_url: https://percona.github.io/percona-helm-charts/
  #   release_name: psmdb-operator
  #   chart_name: percona/psmdb-operator
  # Timeouts (override only if needed)
  # timeouts:
  #   operator_retries: 10
  #   operator_delay: 20
  #   cluster_retries: 15
  #   cluster_delay: 30
```

### Vault secrets (all_secrets.yml)
```yaml
mongodb_admin_password_secret: "<admin-password>"
```

## Running the Playbook

```bash
# Install / Update
ansible-playbook -i inventories/barista/prod/hosts \
  playbook/kubernetes/kubernetes_mongodb.yaml \
  --vault-password-file .vault \
  -e "ansible_user=app-manager"

# With target host override
ansible-playbook -i inventories/barista/prod/hosts \
  playbook/kubernetes/kubernetes_mongodb.yaml \
  --vault-password-file .vault \
  -e "ansible_user=app-manager" \
  --extra-vars="target_host=kubernetes_master_zone2"

# One-time TLS cert rotation (only needed if splitHorizons SANs are missing)
ansible-playbook -i inventories/barista/prod/hosts \
  playbook/kubernetes/kubernetes_mongodb_rotate_tls.yaml \
  --vault-password-file .vault \
  -e "ansible_user=app-manager"
```

### Via GitLab CI

| Variable | Value |
|----------|-------|
| APP_INSTANCE | Barista |
| ENV | Prod |
| ZONE | zone-2 |
| APP_GROUP | kubernetes |
| APP | kubernetes_mongodb |
| ANSIBLE_USER | app-manager |

## Connecting to MongoDB

After deployment, connect using any MongoDB client:

```bash
# From inside the cluster (direct pod DNS)
mongosh "mongodb://admin:<password>@mongodb-rs-rs0-0.mongodb-rs-rs0.mongodb.svc.cluster.local:27017,mongodb-rs-rs0-1.mongodb-rs-rs0.mongodb.svc.cluster.local:27017,mongodb-rs-rs0-2.mongodb-rs-rs0.mongodb.svc.cluster.local:27017/admin?replicaSet=rs0"

# From outside the cluster (via LB + replsetOverrides)
mongosh "mongodb://admin:<password>@<external_hostname>:61017,<external_hostname>:61018,<external_hostname>:61019/admin?replicaSet=rs0&authSource=admin"
```

When `expose.enabled: true` with `split_horizons` configured, the MongoDB driver automatically discovers primary/secondary members using the external hostnames. No `directConnection=true` or TLS flags needed.

## External Access (replsetOverrides)

For applications outside the Kubernetes cluster to connect as a proper replica set (with automatic primary/secondary routing and failover), configure:

```yaml
mongodb:
  expose:
    enabled: true
    external_hostname: barista.nat.bt.com
    split_horizons:
      - "barista.nat.bt.com:61017"
      - "barista.nat.bt.com:61018"
      - "barista.nat.bt.com:61019"
```

```yaml
ports:
  kubernetes:
    mongodb:
      nodeport: 61017           # Legacy single-port (unused when expose enabled)
      nodeports:
        - 61017                 # Member 0 fixed NodePort
        - 61018                 # Member 1 fixed NodePort
        - 61019                 # Member 2 fixed NodePort
      internal: 27017
```

### How it works

1. The role creates per-member NodePort services (`*-external`) with fixed ports matching the LB config
2. The Percona CR uses `replsetOverrides` to set each member's advertised hostname to `<external_hostname>:<port>`
3. When an external client sends `hello`, MongoDB returns the external hostnames in the topology
4. The MongoDB driver connects to all members using those hostnames and routes reads/writes correctly

### Load Balancer Requirements

Each member port must have a dedicated TCP passthrough (no TLS termination) pool on the LB:

| LB Listen Port | Backend NodePort | Target |
|---------------|-----------------|--------|
| 61017 | 61017 (all K8s nodes) | mongodb-rs-rs0-0 |
| 61018 | 61018 (all K8s nodes) | mongodb-rs-rs0-1 |
| 61019 | 61019 (all K8s nodes) | mongodb-rs-rs0-2 |

LB virtual server protocol: `stream` or `client_first` (raw TCP passthrough — no SSL termination).

### Why replsetOverrides instead of splitHorizons

The Percona operator supports both, but `splitHorizons` requires the client to connect with TLS and include an SNI hostname matching the horizon name. This makes external connectivity depend on:
- Client TLS configuration
- Certificate SANs including the external hostname
- `allowConnectionsWithoutCertificates` in MongoDB config

`replsetOverrides` directly changes what each member advertises as its hostname in the replica set configuration — no TLS/SNI required. The client connects with plain TCP and receives externally-routable addresses immediately.

## File Structure

```
roles/kubernetes/mongodb/
├── defaults/main.yml                         # All variables with sources and defaults
├── tasks/
│   ├── main.yml                              # Orchestrator — imports validate, operator, deploy
│   ├── validate.yml                          # Pre-flight config validation (3 checks)
│   ├── operator.yml                          # Helm repo + install Percona operator + wait
│   └── deploy.yml                            # Admin secret + PSMDB CR + NodePort + wait
├── templates/
│   ├── psmdb-cluster.yaml.j2                # PerconaServerMongoDB CR (ReplicaSet + affinity + metrics + backup)
│   ├── psmdb-nodeport.yaml.j2              # NodePort service for external access
│   └── mongodb-prometheus-scrape.yml.j2    # Prometheus scrape job config (reference)
└── README.md                                 # This file
```

## Why Percona Operator

- **Apache 2.0 licensed** — free, open source, no vendor lock-in
- **Actively maintained** — latest release 1.22.0 (Feb 2026), regular updates
- **Built-in automated backups** — logical backups with retention, point-in-time recovery
- **Monitoring out of the box** — MongoDB exporter sidecar for Prometheus
- **Supports sharding** — can scale beyond ReplicaSet when needed
- **Encryption at rest** — optional data encryption
- **Multi-DC support** — topology spread and pod anti-affinity
- **Replaces the archived MongoDB Community Operator** — which is now read-only with no future releases

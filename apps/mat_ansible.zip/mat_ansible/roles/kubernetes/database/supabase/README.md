# Kubernetes Supabase Role

Deploys Supabase (open-source Firebase alternative) on Kubernetes using the community Helm chart. Supabase provides PostgreSQL database, authentication, real-time subscriptions, storage, and edge functions as a unified backend platform.

## Latest Version Links

Check for the latest versions of all components before upgrading:

| Component | Check Latest Version | Current |
|-----------|---------------------|---------|
| **Helm Chart** | https://github.com/supabase-community/supabase-kubernetes/releases | 0.5.6 |
| **GoTrue (Auth)** | https://github.com/supabase/gotrue/releases | v2.186.0 |
| **PostgREST** | https://github.com/PostgREST/postgrest/releases | v14.8 |
| **Realtime** | https://github.com/supabase/realtime/releases | v2.76.5 |
| **Storage API** | https://github.com/supabase/storage-api/releases | v1.48.26 |
| **Studio** | https://github.com/supabase/supabase/tree/master/apps/studio | 2026.04.27 |
| **Edge Runtime (Functions)** | https://github.com/supabase/edge-runtime/releases | v1.71.2 |
| **Postgres Meta** | https://github.com/supabase/postgres-meta/releases | v0.96.3 |
| **Kong** | https://github.com/Kong/kong/releases | 3.9.1 |
| **Logflare (Analytics)** | https://github.com/Logflare/logflare/releases | 1.36.1 |
| **Imgproxy** | https://github.com/imgproxy/imgproxy/releases | v3.30.1 |
| **Supabase Postgres** | https://github.com/supabase/postgres/releases | 15.8.1.085 |
| **Longhorn** | https://github.com/longhorn/longhorn/releases | (cluster CSI) |

> **Note:** Image versions are controlled by the Helm chart. Upgrading `version.kubernetes.supabase.chart` in `versions.yml` will pull the chart's bundled image versions automatically. You do not need to pin individual image tags unless overriding.

---

## Components Deployed

| Component | Role | Port |
|-----------|------|------|
| **PostgreSQL** | Primary datastore (built-in or external) | 5432 |
| **Kong** | API gateway — routes all external traffic to services | 8000 (NodePort) |
| **GoTrue (Auth)** | User authentication and JWT management | 9999 |
| **PostgREST** | Auto-generated REST API from PostgreSQL schema | 3000 |
| **Realtime** | Real-time WebSocket subscriptions for DB changes | 4000 |
| **Storage** | S3-compatible file storage backed by PostgreSQL | 5000 |
| **Studio** | Web-based dashboard for managing your project | 3000 |
| **Meta** | Database management API for Studio | 8080 |
| **Edge Functions** | Deno-based serverless functions | 9000 |
| **Imgproxy** | On-the-fly image transformations | 5001 |

---

## Prerequisites

### Cluster Requirements

| Requirement | Minimum | How to Check |
|-------------|---------|--------------|
| Kubernetes | 1.28+ | `kubectl version --short` |
| Helm | 3.x | `helm version --short` |
| Longhorn StorageClass | Installed and default | `kubectl get sc` |
| Ingress Controller | HAProxy / nginx / Kong | `kubectl get ingressclass` |
| Available worker nodes | 1+ (test), 3+ (prod) | `kubectl get nodes` |
| Available CPU | 4 cores minimum | `kubectl describe nodes \| grep -A5 "Allocated"` |
| Available Memory | 8Gi minimum | (same as above) |

### Ansible Requirements

```bash
# Required collection
ansible-galaxy collection install kubernetes.core

# Verify
ansible-galaxy collection list | grep kubernetes.core
```

### Network Requirements

- `http_proxy` and `https_proxy` defined in global secrets (for Helm repo access)
- Ingress controller reachable from clients
- DNS resolving `ingress.host` to your cluster's ingress IP
- No IPv6 requirement (Realtime is configured for IPv4-only)

### Secrets Required (in vault)

| Secret Variable | Description | How to Generate |
|----------------|-------------|-----------------|
| `supabase_jwt_secret_vault` | JWT signing secret (min 64 chars) | `openssl rand -base64 48` |
| `supabase_anon_key_vault` | Anonymous access JWT | See JWT generation below |
| `supabase_service_role_key_vault` | Service role JWT | See JWT generation below |
| `supabase_dashboard_password_vault` | Studio login password | Choose a strong password |
| `supabase_db_password_vault` | PostgreSQL password | `openssl rand -base64 24` |
| `supabase_s3_access_key_vault` | (Optional) MinIO/S3 access key | Required when `config_k8s.supabase.s3.enabled: true` |
| `supabase_s3_secret_key_vault` | (Optional) MinIO/S3 secret key | Required when `config_k8s.supabase.s3.enabled: true` |

### Generating JWT Secrets

```bash
# 1. Generate JWT secret (MUST be 64+ characters for Phoenix/Realtime)
JWT_SECRET=$(openssl rand -base64 48)
echo "JWT Secret: $JWT_SECRET"

# 2. Generate anon key
# Payload: {"role": "anon", "iss": "supabase", "iat": 1700000000, "exp": 1900000000}
# Sign with HS256 using your JWT_SECRET
# Tool: https://supabase.com/docs/guides/self-hosting#api-keys

# 3. Generate service role key
# Payload: {"role": "service_role", "iss": "supabase", "iat": 1700000000, "exp": 1900000000}
# Sign with HS256 using the same JWT_SECRET
```

---

## How It Works

```
validate.yml → pre_deploy.yml → deploy.yml → post_install.yml
     │              │                │              │
     ├─ namespace   ├─ create S3     ├─ helm repo   ├─ pgjwt extension
     ├─ ingress     │  bucket (if    ├─ namespace   ├─ supabase_admin role
     ├─ jwt secret  │  s3.enabled)   ├─ stale pods  ├─ pod verification
     ├─ db password │                ├─ template    └─ status report
     ├─ storage     │                ├─ helm install
     └─ chart ver                    ├─ wait pods
                                     └─ stability check
```

**Playbook target:** `kubernetes_master_init` (blp25082025 @ 10.6.103.192 in prod)

**Variable source:** `config_k8s.supabase.*` from `inventories/barista/prod/group_vars/all/config_kubernetes.yml`

The role is idempotent — re-running with updated config patches the existing deployment via `helm upgrade --install`.

---

## How to Run

### Barista Test

```bash
ansible-playbook -i inventories/barista/test/hosts \
  playbook/kubernetes/kubernetes_supabase.yaml \
  --vault-password-file .vault

# With target host override
ansible-playbook -i inventories/barista/test/hosts \
  playbook/kubernetes/kubernetes_supabase.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kubernetes_master_zone2"
```

### Barista Prod

```bash
ansible-playbook -i inventories/barista/prod/hosts \
  playbook/kubernetes/kubernetes_supabase.yaml \
  --vault-password-file .vault

# Dry run (check mode)
ansible-playbook -i inventories/barista/prod/hosts \
  playbook/kubernetes/kubernetes_supabase.yaml \
  --vault-password-file .vault \
  --check --diff
```

### CI/CD (GitLab)

- **APP_INSTANCE:** `Barista`
- **ENV:** `Prod` or `Test`
- **APP_GROUP:** `kubernetes`
- **APP:** `kubernetes_supabase`

---

## Post-Deployment Verification

### Quick Health Check

```bash
# 1. All pods should be Running (no CrashLoopBackOff, no Pending)
kubectl get pods -n supabase -o wide

# Expected output (prod — built-in DB, 3 replicas):
# NAME                                          READY   STATUS    NODE
# supabase-supabase-db-0                        1/1     Running   <node>
# supabase-supabase-kong-xxx                    1/1     Running   <derby|reigate|stalbans>
# supabase-supabase-kong-yyy                    1/1     Running   <derby|reigate|stalbans>
# supabase-supabase-kong-zzz                    1/1     Running   <derby|reigate|stalbans>
# supabase-supabase-auth-xxx                    1/1     Running   <node>
# supabase-supabase-auth-yyy                    1/1     Running   <node>
# supabase-supabase-auth-zzz                    1/1     Running   <node>
# supabase-supabase-rest-xxx                    1/1     Running   <node>
# supabase-supabase-rest-yyy                    1/1     Running   <node>
# supabase-supabase-rest-zzz                    1/1     Running   <node>
# supabase-supabase-realtime-xxx                1/1     Running   <node>
# supabase-supabase-realtime-yyy                1/1     Running   <node>
# supabase-supabase-realtime-zzz                1/1     Running   <node>
# supabase-supabase-studio-xxx                  1/1     Running   <node>
# supabase-supabase-studio-yyy                  1/1     Running   <node>
# supabase-supabase-studio-zzz                  1/1     Running   <node>
# supabase-supabase-storage-xxx                 1/1     Running   <node>
# supabase-supabase-meta-xxx                    1/1     Running   <node>
# supabase-supabase-functions-xxx               1/1     Running   <node>
# supabase-supabase-imgproxy-xxx                1/1     Running   <node>

# Total expected pods (prod): ~18-20 (DB:1 + Kong:3 + Auth:3 + REST:3 + Realtime:3 + Studio:3 + Storage + Meta + Functions + Imgproxy)
```

### Verify PVCs Are Bound

```bash
kubectl get pvc -n supabase

# Expected:
# NAME                              STATUS   VOLUME         CAPACITY   ACCESS MODES   STORAGECLASS
# data-supabase-supabase-db-0       Bound    pvc-xxx        20Gi       RWO            longhorn
# supabase-supabase-storage         Bound    pvc-xxx        10Gi       RWO            longhorn
# supabase-supabase-functions       Bound    pvc-xxx        1Gi        RWO            longhorn
```

### Verify Services Are Accessible

```bash
# 2. Kong API gateway responding
kubectl exec -n supabase deploy/supabase-supabase-kong -- \
  curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/

# Expected: 404 (no route matched) or 200

# 3. REST API health
kubectl exec -n supabase deploy/supabase-supabase-kong -- \
  curl -s http://localhost:8000/rest/v1/ \
  -H "apikey: <your-anon-key>" \
  -H "Authorization: Bearer <your-anon-key>"

# Expected: JSON response (empty array or schema info)

# 4. Auth API health
kubectl exec -n supabase deploy/supabase-supabase-kong -- \
  curl -s http://localhost:8000/auth/v1/health

# Expected: {"status":"ok"} or similar

# 5. Studio accessible via ingress
curl -s -o /dev/null -w "%{http_code}" http://<ingress-host>/

# Expected: 200 or 302 (redirect to login)

# 6. Realtime WebSocket (check if port is listening)
kubectl exec -n supabase deploy/supabase-supabase-realtime -- \
  curl -s -o /dev/null -w "%{http_code}" http://localhost:4000/api/health

# Expected: 200
```

### Verify Realtime IPv4 (No IPv6 Issues)

```bash
# Check Realtime pod logs for IPv6 errors
kubectl logs -n supabase -l app.kubernetes.io/name=supabase-realtime --tail=50

# Should NOT contain:
#   - "econnrefused" with "::1" or IPv6 addresses
#   - "nxdomain" errors
#   - "Protocol 'inet6_tcp' not loaded"

# Should contain:
#   - "Access control: ... allowed"
#   - "Running RealtimeWeb.Endpoint"
```

### Verify Functions Co-location

```bash
# Functions and Studio should be on the SAME node
kubectl get pods -n supabase -l "app.kubernetes.io/name in (supabase-studio, supabase-functions)" \
  -o custom-columns="POD:.metadata.name,NODE:.spec.nodeName,STATUS:.status.phase"

# Expected: both show same NODE value
```

### Verify Database Connectivity

```bash
# Built-in DB mode
kubectl exec -n supabase deploy/supabase-supabase-kong -- \
  curl -s http://localhost:8000/rest/v1/ \
  -H "apikey: <your-anon-key>" | head -5

# External DB mode - check auth pod isn't restarting
kubectl get pods -n supabase -l app.kubernetes.io/name=supabase-auth --no-headers
# STATUS should be "Running", RESTARTS should be 0
```

### Full Endpoint Reference

| Endpoint | URL | Auth Required |
|----------|-----|---------------|
| Studio Dashboard | `http://<host>/project/default/editor` | Dashboard username/password |
| REST API | `http://<host>/rest/v1/` | apikey header (anon or service_role) |
| Auth API | `http://<host>/auth/v1/` | apikey header |
| Storage API | `http://<host>/storage/v1/` | apikey + Authorization header |
| Realtime WS | `ws://<host>/realtime/v1/websocket` | apikey query param |
| Functions | `http://<host>/functions/v1/<function-name>` | Authorization header |
| Health (Kong) | `http://<host>/` | None |

---

## Pre-flight Validations

| # | Check | Rule | Fails If |
|---|-------|------|----------|
| 1 | Namespace | Not empty | `config.kubernetes.supabase.namespace` missing |
| 2 | Ingress host | Not empty (when enabled) | No hostname for external access |
| 3 | JWT secret exists | Not empty | Vault secret undefined |
| 4 | JWT secret length | >= 64 characters | Phoenix Realtime will crash |
| 5 | DB password | Not empty | PostgreSQL won't authenticate |
| 6 | Storage class | Not empty | PVCs can't be provisioned |
| 7 | DB storage size | Not empty (built-in) | PVC creation fails |
| 8 | Chart version | Not empty | Helm can't resolve chart |
| 9 | External DB host | Not empty (external mode) | Services can't connect |
| 10 | External DB port | Not empty (external mode) | Services can't connect |

---

## Database Modes

### Built-in Database (Default)

```yaml
db:
  enabled: true
```

- Single PostgreSQL pod with Longhorn PVC
- Automatic pgjwt extension and supabase_admin role
- Good for: test/dev environments

### External Database (Production)

```yaml
db:
  enabled: false
  external_host: "cnpg-cluster-rw.postgres.svc.cluster.local"
  external_port: 5432
  external_name: postgres
```

- Connects to CNPG, RDS, or any external PostgreSQL
- pgjwt must be pre-installed on external cluster
- Good for: production (HA with streaming replication)

---

---

## Variable Reference

### versions.yml

```yaml
version:
  kubernetes:
    supabase:
      chart: "0.5.6"
      pg_exporter: "0.15.0"
    longhorn_version: "1.12.0"     # Supabase PVCs backed by Longhorn
```

### networks.yml

```yaml
ports:
  kubernetes:
    supabase:
      kong: 8000
      studio: 3000
      db: 5432
      metrics: 9542
```

### app_configs.yml (under config_k8s)

```yaml
# In inventories/barista/prod/group_vars/all/config_kubernetes.yml
config_k8s:
  supabase:
    namespace: supabase
    release_name: supabase
    storage_class: longhorn
    db_storage_size: 20Gi
    # file_storage_size: 10Gi          # Default 10Gi (only used when s3.enabled=false)

    db:
      enabled: true                    # Built-in DB for prod
      # external_host: ""
      # external_port: 5432
      # external_name: postgres

    # S3 / MinIO Storage (optional — replaces local PVC for file storage)
    s3:
      enabled: false                    # Set true to use external MinIO for file storage
      endpoint: ""                      # e.g., "http://minio.minio.svc.cluster.local:9000"
      region: "us-east-1"              # MinIO doesn't use this, but required by S3 API
      bucket: "supabase-storage"       # Created automatically if not exists (needs mc on master)
      force_path_style: true           # Required for MinIO (not AWS S3)

    ingress:
      enabled: true
      host: barista.nat.bt.com         # Prod DNS
      path: /supabase
      class: kong
      tls: false

    resources:
      db:
        requests: { cpu: "500m", memory: "1Gi" }
        limits: { cpu: "2000m", memory: "4Gi" }
      kong:
        requests: { cpu: "100m", memory: "256Mi" }
        limits: { cpu: "500m", memory: "512Mi" }

    replicas:                           # Prod: 3 replicas for HA
      kong: 3
      auth: 3
      rest: 3
      studio: 3
      realtime: 3

    realtime_enabled: true

    studio:
      username: admin

    topology:
      node_label_key: ""
      node_label_value: ""

    analytics:
      enabled: false
    vector:
      enabled: false
    metrics:
      enabled: true

    no_proxy: "localhost,127.0.0.1,.svc,.cluster.local"
```

### Prod Cluster Topology

| Host Group | Nodes | DataCenter | Usage |
|-----------|-------|------------|-------|
| `kubernetes_master_init` | blp25082025 | Derby | Master (kubeadm init) |
| `kubernetes_master_join` | blp25082026, blp25082027 | Reigate, St.Albans | Master (join) |
| `kubernetes_worker_set1` | 15 nodes | Derby (5), Reigate (5), St.Albans (5) | All workers run Longhorn + Supabase |
| `supabase_workers` | 15 nodes | All regions | Supabase-eligible workers |
| `kafka_workers` | 3 nodes | 1 per region | Kafka brokers |
| `mongodb_workers` | 3 nodes | 1 per region | MongoDB replicas |
| `minio_workers` | 3 nodes | 1 per region | MinIO distributed |

### S3/MinIO Storage — Variable Details

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.supabase.s3.enabled` | `false` | Use external MinIO for file storage | `true` = files in MinIO, no storage PVC. `false` = files on Longhorn PVC |
| `config_k8s.supabase.s3.endpoint` | `""` | MinIO endpoint URL | Internal: `http://minio.minio.svc.cluster.local:9000`. External: `http://<host>:<port>` |
| `config_k8s.supabase.s3.region` | `us-east-1` | S3 region | MinIO ignores this but the S3 SDK requires it |
| `config_k8s.supabase.s3.bucket` | `supabase-storage` | Bucket name for file storage | Created automatically during pre_deploy if not exists |
| `config_k8s.supabase.s3.force_path_style` | `true` | Use path-style URLs (`endpoint/bucket`) | Must be `true` for MinIO. Set `false` only for AWS S3 |
| `supabase_s3_access_key_vault` | — | MinIO access key (vault) | Required when `s3.enabled: true` |
| `supabase_s3_secret_key_vault` | — | MinIO secret key (vault) | Required when `s3.enabled: true` |

### Vault Secrets (all_secrets.yml)

```yaml
supabase_jwt_secret_vault: "<64+ chars - openssl rand -base64 48>"
supabase_anon_key_vault: "<generated-anon-jwt>"
supabase_service_role_key_vault: "<generated-service-role-jwt>"
supabase_dashboard_password_vault: "<studio-password>"
supabase_db_password_vault: "<postgresql-password>"
# Required only when s3.enabled: true
# supabase_s3_access_key_vault: "<minio-access-key>"
# supabase_s3_secret_key_vault: "<minio-secret-key>"
```

---

## File Structure

```
roles/kubernetes/database/supabase/
├── defaults/main.yml                        # All variables with sources and defaults
├── tasks/
│   ├── main.yaml                            # Orchestrator (validate → pre_deploy → deploy → post_install)
│   ├── validate.yml                         # Pre-flight checks (10 validations)
│   ├── pre_deploy.yml                       # Create S3 bucket in MinIO (if s3.enabled)
│   ├── deploy.yml                           # Helm repo + namespace + stale cleanup + install + wait + stability
│   └── post_install.yml                     # DB extensions + full pod verification + status report
├── templates/
│   ├── supabase-values.yaml.j2             # Helm values (chart 0.5.6+ domain structure)
│   └── supabase-prometheus-scrape.yml.j2   # Prometheus scrape config (reference)
└── README.md                                # This file

playbook/kubernetes/kubernetes_supabase.yaml  # Playbook (targets kubernetes_master_init)
```

---

## Troubleshooting

### Pod stuck in Pending

```bash
kubectl describe pod <pod-name> -n supabase
# Look for: "0/N nodes are available" or "Insufficient cpu/memory"
# Fix: Free up resources or add worker nodes
```

### Helm timeout during install

```bash
# Increase timeout
timeouts:
  helm_timeout: "900s"

# Or check what's blocking
kubectl get events -n supabase --sort-by='.lastTimestamp' | tail -20
```

### CrashLoopBackOff on any pod

```bash
# Get logs from the crashing container
kubectl logs -n supabase <pod-name> --previous

# Common causes:
# - DB connection refused → check DB pod is ready
# - JWT secret invalid → regenerate secrets
# - Port conflict → check networks.yml
```

### PVC stuck in Pending

```bash
kubectl describe pvc -n supabase <pvc-name>
# Look for: "waiting for first consumer" or "no volume plugin matched"
# Fix: Verify Longhorn is healthy: kubectl get nodes -l node.longhorn.io/create-default-disk=true
```

### Services returning 502/503 via ingress

```bash
# Check Kong routing
kubectl logs -n supabase -l app.kubernetes.io/name=supabase-kong --tail=20

# Verify backend services are up
kubectl get endpoints -n supabase
```

### After node failure — pods not recovering

```bash
# Check if pods are stuck on the failed node
kubectl get pods -n supabase -o wide | grep -v Running

# Force eviction if node is NotReady for too long
kubectl delete pod <stuck-pod> -n supabase --grace-period=0 --force

# Functions should auto-recover with Studio (pod affinity)
# If not, re-run the playbook
```

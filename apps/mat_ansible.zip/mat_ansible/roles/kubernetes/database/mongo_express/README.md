# Mongo Express — MongoDB Web UI on Kubernetes

Deploys [Mongo Express](https://github.com/mongo-express/mongo-express) as a Kubernetes Deployment for MongoDB administration. Similar to pgAdmin for PostgreSQL — provides a web interface to browse databases, collections, run queries, and manage documents.

## Latest Version

| Component | Check Latest |
|-----------|-------------|
| Mongo Express | [Docker Hub](https://hub.docker.com/_/mongo-express/tags) |

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Kubernetes cluster | Running with kubectl access | `kubectl get nodes` |
| MongoDB (Percona) | Deployed via `kubernetes_mongodb.yaml` | `kubectl get pods -n mongodb` |
| MongoDB admin password | In vault as `mongodb_admin_password_vault` | Check `all_secrets.yml` |
| Mongo Express password | In vault as `mongo_express_admin_password_vault` | Check `all_secrets.yml` |

## How to Run

```bash
# Deploy Mongo Express
ansible-playbook -i inventories/bhrigu/pre_prod/hosts \
  playbook/kubernetes/mongo_express.yaml \
  --vault-password-file .vault \
  -e "ansible_user=app-manager"
```

## Variable Reference

### Required variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `config_kubernetes.yml` | `config_k8s.mongo_express.mongodb_host` | `mongodb-rs-0.mongodb-rs.mongodb.svc.cluster.local` | MongoDB connection host |
| `networks.yml` | `ports.kubernetes.mongo_express.nodeport` | `49489` | K8s NodePort for external access |
| `all_secrets.yml` | `mongo_express_admin_password_vault` | (vault) | Mongo Express basic auth password |
| `all_secrets.yml` | `mongodb_admin_password_vault` | (vault) | MongoDB admin password |

### Optional variables (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `mongo_express_image` | `mongo-express` | Docker image name |
| `mongo_express_version` | `1.0.2-20` | Image tag |
| `mongo_express_basic_auth_enabled` | `true` | Enable login page |
| `mongo_express_basic_auth_user` | `admin` | Login username |
| `mongo_express_site_baseurl` | `/` | URL base path |
| `mongo_express_requests_cpu` | `50m` | CPU request |
| `mongo_express_requests_memory` | `128Mi` | Memory request |
| `mongo_express_limits_cpu` | `500m` | CPU limit |
| `mongo_express_limits_memory` | `256Mi` | Memory limit |

## Task Execution Flow

```
main.yaml
├── validate.yml   — Pre-flight checks (namespace, passwords, nodeport)
├── deploy.yml     — Create namespace, secret, deployment, service
└── verify.yml     — Check pod status, display access URL
```

## Post-Deployment Verification

```bash
# 1. Check pod is running
kubectl get pods -n mongodb -l app=mongo-express

# 2. Check service
kubectl get svc -n mongodb mongo-express

# 3. Access via NodePort (direct)
curl http://<node-ip>:49489

# 4. Access via HAProxy (production URL)
curl https://bhrigu-martini-preprod.nat.bt.com:61124
```

## Access

| Method | URL |
|--------|-----|
| HAProxy (SSL) | `https://bhrigu-martini-preprod.nat.bt.com:61124` |
| Direct NodePort | `http://<any-master-ip>:49489` |

## Troubleshooting

### Checking Logs

```bash
# Recent logs
kubectl logs -n mongodb -l app=mongo-express --tail=50

# Follow logs
kubectl logs -n mongodb -l app=mongo-express -f

# Describe pod for events
kubectl describe pod -n mongodb -l app=mongo-express
```

### Service Account Access

```bash
# N/A — runs as container, no host-level service account
```

## File Structure

```
roles/kubernetes/database/mongo_express/
├── defaults/
│   └── main.yml
├── tasks/
│   ├── main.yaml
│   ├── validate.yml
│   ├── deploy.yml
│   └── verify.yml
├── templates/
│   ├── mongo-express-secret.yaml.j2
│   ├── mongo-express-deployment.yaml.j2
│   └── mongo-express-service.yaml.j2
└── README.md
```

## Security Notes

- Basic auth enabled by default — prevents anonymous access
- MongoDB credentials stored in K8s Secret (not plaintext in deployment)
- NodePort exposed only within internal network (behind HAProxy SSL)
- No persistent storage needed — Mongo Express is stateless

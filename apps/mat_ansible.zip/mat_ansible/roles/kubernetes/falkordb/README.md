# FalkorDB (Kubernetes)

Deploys FalkorDB — a graph database built on Redis — as a Helm chart on Kubernetes using the Bitnami Redis chart with FalkorDB image override. The architecture is Redis master + replicas with Sentinel for HA failover, fronted by an HAProxy sidecar that routes traffic exclusively to the master node.

## Latest Version

| Component | Check Latest |
|-----------|-------------|
| FalkorDB Image | [GitHub Releases](https://github.com/FalkorDB/FalkorDB/releases) |
| Bitnami Redis Chart | [Artifact Hub](https://artifacthub.io/packages/helm/bitnami/redis) |

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Kubernetes cluster | v1.28+ with kubectl access | `kubectl version` |
| Helm 3 | Installed on the master node | `helm version` |
| Longhorn StorageClass | For persistent volumes | `kubectl get sc longhorn` |
| Containerd proxy | Workers must reach `docker.io` | `crictl pull docker.io/falkordb/falkordb:4.4.1` |
| Vault secrets | `falkordb_password` defined in `all_secrets.yml` | Decrypt and verify |

## How to Run

```bash
# Install on barista test
ansible-playbook -i inventories/barista/test/hosts \
  playbook/falkordb.yaml \
  --vault-password-file .vault

# Uninstall
ansible-playbook -i inventories/barista/test/hosts \
  playbook/falkordb.yaml \
  --vault-password-file .vault \
  -e "falkordb_action=uninstall"

# Override target host
ansible-playbook -i inventories/barista/test/hosts \
  playbook/falkordb.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kubernetes_master_zone2"
```

Via GitLab CI: `APP_INSTANCE=Barista`, `ENV=Test`, `APP=falkordb`

Set `FALKORDB_ACTION=uninstall` CI variable to remove.

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.falkordb_image` | `"4.4.1"` | FalkorDB Docker image tag |
| `versions.yml` | `version.kubernetes.falkordb_chart` | `"21.1.5"` | Bitnami Redis Helm chart version |
| `paths.yml` | `paths.falkordb.base_dir` | `/apps/falkordb` | Temp directory for rendered manifests |
| `networks.yml` | `ports.kubernetes.falkordb.redis` | `61085` | Redis NodePort |
| `networks.yml` | `ports.kubernetes.falkordb.sentinel` | `61086` | Sentinel port |
| `networks.yml` | `ports.kubernetes.falkordb.browser_ui` | `61084` | Browser UI NodePort |
| `networks.yml` | `ports.kubernetes.falkordb.node_port` | `61085` | HAProxy NodePort |
| `config_kubernetes.yml` | `config_k8s.falkordb.*` | — | All app config (see below) |
| `all_secrets.yml` | `falkordb_password` | — | Auth password (vault-encrypted) |

### Optional Variables (with defaults in role)

| Variable | Default | Description | Impact of Change |
|----------|---------|-------------|-----------------|
| `falkordb_image_repo` | `falkordb/falkordb` | Docker image repository | Change to internal registry if Docker Hub is blocked |
| `falkordb_verification_timeout` | `300` | Seconds to wait for pods Ready | Increase if image pull is slow on first deploy |
| `falkordb_delete_namespace` | `false` | Delete namespace on uninstall | Set true for full cleanup |

### config_k8s.falkordb structure

```yaml
config_k8s:
  falkordb:
    namespace: falkordb
    release_name: falkordb
    replica_count: 3              # master + 2 replicas (Sentinel quorum)
    auth_enabled: true
    service_type: NodePort
    persistence:
      size: 8Gi
      save_schedule: "save 900 1\nsave 300 10\nsave 60 10000"
      appendonly: "yes"
      appendfsync: "everysec"
    sentinel:
      down_after_ms: 5000         # ms before marking node as down
      failover_timeout: 60000     # ms before failover completes
    module:
      thread_count: 4             # FalkorDB query threads
      cache_size: 25              # MB graph cache
      resultset_size: 10000       # max rows per query
      max_queued_queries: 25      # query queue depth
      timeout: 0                  # 0 = unlimited query time
    resources:
      master:
        requests_cpu: "1"
        limits_cpu: "2"
        requests_memory: "2Gi"
        limits_memory: "4Gi"
      replica:
        requests_cpu: "1"
        limits_cpu: "2"
        requests_memory: "2Gi"
        limits_memory: "4Gi"
      sentinel:
        requests_cpu: "100m"
        limits_cpu: "200m"
        requests_memory: "128Mi"
        limits_memory: "256Mi"
    verification_timeout: 300
    delete_namespace: false
```

## What Gets Installed

```
Kubernetes Cluster
└── namespace: falkordb
    ├── StatefulSet: falkordb-redis-node (master + replicas)
    │   ├── container: falkordb (falkordb/falkordb:4.4.1)
    │   └── container: sentinel (bitnami/redis-sentinel:latest)
    ├── Deployment: falkordb-haproxy (master-only proxy)
    ├── Service: falkordb-haproxy (NodePort → master via HAProxy)
    ├── Service: falkordb-browser (NodePort → Browser UI)
    ├── ConfigMap: falkordb-haproxy-config
    └── PVCs: redis-data-falkordb-redis-node-{0,1,2} (Longhorn)
```

On the master node filesystem (temporary, cleaned after deploy):
```
/apps/falkordb/           ← base_dir (empty after deploy, manifests cleaned up)
```

## Task Execution Flow

```
main.yaml
├── install.yml (when action == 'install')
│   ├── Pre-flight validation (versions, config, ports, auth)
│   ├── Create base directory
│   ├── Create namespace
│   ├── Render Helm values → helm upgrade --install (OCI chart)
│   ├── Cleanup temp values file
│   ├── Delete stale external services
│   ├── Deploy HAProxy (ConfigMap → Deployment → NodePort Service)
│   ├── Deploy Browser UI NodePort Service
│   ├── Cleanup rendered manifests
│   └── verify.yml
│       ├── Wait for all pods Ready (timeout: 300s)
│       ├── Display pod status
│       └── Verify Sentinel master election
└── uninstall.yml (when action == 'uninstall')
    ├── Helm uninstall
    ├── Delete services
    ├── Remove PVC finalizers + force delete PVCs
    ├── Remove PV finalizers + force delete PVs
    └── Optionally delete namespace
```

## Post-Deployment Verification

1. Check all pods are running:
   ```bash
   kubectl get pods -n falkordb -o wide
   # Expected: falkordb-redis-node-{0,1,2} (2/2 Running), falkordb-haproxy (1/1 Running)
   ```

2. Verify Sentinel master election:
   ```bash
   kubectl exec falkordb-redis-node-0 -n falkordb -c sentinel -- \
     redis-cli -p 26379 SENTINEL masters
   # Expected: master with status "ok", no sdown/odown flags
   ```

3. Test Redis connectivity via HAProxy NodePort:
   ```bash
   redis-cli -h <worker-node-ip> -p 61085 -a '<password>' PING
   # Expected: PONG
   ```

4. Test FalkorDB graph query:
   ```bash
   redis-cli -h <worker-node-ip> -p 61085 -a '<password>' \
     GRAPH.QUERY test "CREATE (n:Test {name:'hello'}) RETURN n"
   ```

## Upgrade Process

1. Update `version.kubernetes.falkordb_image` in `versions.yml`
2. Update `version.kubernetes.falkordb_chart` in `versions.yml` (if chart version changes)
3. Run the playbook — Helm `upgrade --install` handles rolling updates
4. Sentinel manages failover automatically during pod restarts

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `ImagePullBackOff` on redis-node pods | Workers can't reach `docker.io` | Run `containerd_proxy` playbook on workers, or use internal registry |
| Pods stuck in `Pending` | No Longhorn volumes available | Check `kubectl get pvc -n falkordb` and Longhorn UI |
| Sentinel reports `sdown` | Pod crashed or network partition | Check `kubectl logs <pod> -n falkordb -c sentinel` |
| HAProxy not routing to master | Master pod restarted, DNS stale | Delete HAProxy pod to force reconnect: `kubectl delete pod -n falkordb -l app.kubernetes.io/component=haproxy` |
| Helm timeout on install | Chart OCI registry unreachable | Verify `http_proxy`/`https_proxy` on master node |

## File Structure

```
roles/kubernetes/falkordb/
├── defaults/
│   └── main.yml            ← All variables with config_k8s references
├── tasks/
│   ├── main.yaml           ← Action router (install/uninstall)
│   ├── install.yml         ← Full install orchestration
│   ├── uninstall.yml       ← Full teardown with PV cleanup
│   └── verify.yml          ← Post-deploy health checks
└── templates/
    ├── values.yaml.j2              ← Helm values (image, resources, persistence)
    ├── haproxy-configmap.yaml.j2   ← HAProxy config for master-only routing
    ├── haproxy-deployment.yaml.j2  ← HAProxy sidecar deployment
    ├── haproxy-service.yaml.j2     ← HAProxy external NodePort
    └── browser-service.yaml.j2     ← Browser UI external NodePort
```

## Security Notes

- Authentication is enabled by default (`auth_enabled: true`). The password is sourced from vault-encrypted `falkordb_password` in `all_secrets.yml`.
- HAProxy performs TCP health checks with AUTH before routing — only the authenticated master receives traffic.
- The Helm values file is rendered with mode `0600` and deleted immediately after `helm upgrade`.
- Redis `replica-read-only yes` is enforced — replicas reject write operations.
- Sentinel quorum (2 of 3) prevents split-brain during network partitions.

# Harbor Container Registry on Kubernetes

Deploys [Harbor](https://goharbor.io/) — the CNCF-graduated enterprise container registry — on Kubernetes via Helm. Provides a web UI for image management, RBAC, LDAP authentication, garbage collection policies, vulnerability scanning (optional), and robot accounts for CI/CD pipelines.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Harbor** | https://github.com/goharbor/harbor-helm/releases | Chart `1.19.1` (deploys Harbor 2.14.x) |
| **Helm Chart** | https://helm.goharbor.io | `harbor/harbor` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ with containerd | `kubectl version` |
| **Helm** | 3.x installed on master | `helm version` |
| **Storage class** | Longhorn or local-path provisioner | `kubectl get sc` |
| **Node labels** | Target nodes labeled (optional) | `kubectl get nodes --show-labels` |
| **Proxy** | For Helm chart + image pull | `all_secrets.yml` |
| **HAProxy** | For HTTPS termination in front of Harbor | Existing HAProxy role |
| **LDAP** | AD/LDAP server reachable from cluster | `telnet <ldap-host> 389` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_harbor.yaml \
  --vault-password-file .vault
```

---

## Architecture

```
Clients (docker/containerd push/pull)
    │
    ▼ HTTPS (port 443)
┌─────────────┐
│  HAProxy    │  (SSL termination)
└─────┬───────┘
      │ HTTP
      ▼ NodePort (61064)
┌─────────────────────────────────────────────┐
│  Kubernetes Cluster                          │
│                                              │
│  Namespace: harbor                           │
│  ├── Portal (Web UI)                         │
│  ├── Core (API + auth)                       │
│  ├── Registry (image storage)                │
│  ├── JobService (GC, replication)            │
│  ├── Redis (cache/session)                   │
│  ├── PostgreSQL (metadata)                   │
│  └── Trivy (vulnerability scan, optional)    │
│                                              │
│  Storage: Longhorn PVCs                      │
│  ├── registry-data (200Gi)                   │
│  ├── database (10Gi)                         │
│  ├── redis (5Gi)                             │
│  └── jobservice-logs (5Gi)                   │
└─────────────────────────────────────────────┘
```

---

## Web Console (UI)

**Access:** Only via the configured `external_url` (e.g., `https://martini.preprod.nat.bt.com:61140`)
**Admin login:** `admin` / vault password

**IMPORTANT:** The web UI will NOT work when accessed directly via NodePort IP (e.g., `http://<node-ip>:61002`). CSRF token validation is tied to the `external_url` — accessing from any other URL/port will result in "CSRF token invalid" errors on login. Always access through HAProxy using the configured external URL.

**Features:**
- Project-based image organization
- LDAP/AD group integration with RBAC
- Robot accounts for CI/CD (static credentials)
- Tag retention policies and garbage collection scheduling
- Vulnerability scanning (Trivy, when enabled)
- Image replication between registries
- Audit logs for all operations
- Quota management per project

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.harbor` | `2.13.0` | Harbor chart version |
| `all_secrets.yml` | `harbor_admin_password_vault` | (vault encrypted) | Admin password |
| `app_configs.yml` | `config.kubernetes.harbor.external_url` | `https://harbor.mat.bt.com` | Client-facing URL |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `config.kubernetes.harbor.namespace` | `harbor` | K8s namespace |
| `config.kubernetes.harbor.release_name` | `harbor` | Helm release name |
| `config.kubernetes.harbor.storage_class` | `longhorn` | PVC storage class |
| `config.kubernetes.harbor.registry_size` | `200Gi` | Image storage size |
| `config.kubernetes.harbor.database_size` | `10Gi` | PostgreSQL PVC |
| `config.kubernetes.harbor.redis_size` | `5Gi` | Redis PVC |
| `config.kubernetes.harbor.jobservice_size` | `5Gi` | Job logs PVC |
| `config.kubernetes.harbor.trivy_size` | `10Gi` | Trivy DB PVC |
| `ports.kubernetes.harbor.http` | `61064` | HTTP NodePort |
| `config.kubernetes.harbor.topology.node_label_key` | `''` | Node affinity label |
| `config.kubernetes.harbor.topology.node_label_value` | `''` | Node affinity value |
| `config.kubernetes.harbor.trivy.enabled` | `false` | Enable vulnerability scanning |
| `config.kubernetes.harbor.gc.enabled` | `true` | Enable GC schedule |
| `config.kubernetes.harbor.gc.schedule` | `Daily` | GC frequency |
| `config.kubernetes.harbor.gc.delete_untagged` | `true` | Remove untagged images |
| `config.kubernetes.harbor.auth.mode` | `ldap_auth` | `db_auth` or `ldap_auth` |

### LDAP Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `config.kubernetes.harbor.ldap.url` | `''` | LDAP server URL (e.g., `ldap://ad.bt.com:389`) |
| `config.kubernetes.harbor.ldap.base_dn` | `''` | User search base DN |
| `config.kubernetes.harbor.ldap.search_dn` | `''` | Bind DN for LDAP search |
| `harbor_ldap_search_password_vault` | (vault) | Bind password |
| `config.kubernetes.harbor.ldap.uid` | `sAMAccountName` | Login attribute |
| `config.kubernetes.harbor.ldap.filter` | `''` | User filter (restrict who can login) |
| `config.kubernetes.harbor.ldap.group_base_dn` | `''` | Group search base DN |
| `config.kubernetes.harbor.ldap.group_filter` | `''` | Group membership filter |
| `config.kubernetes.harbor.ldap.group_membership` | `memberOf` | Group membership attribute |
| `config.kubernetes.harbor.ldap.verify_cert` | `false` | Verify LDAP TLS cert |

### Resource Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `config.kubernetes.harbor.resources.core.requests_cpu` | `100m` | Core CPU request |
| `config.kubernetes.harbor.resources.core.requests_memory` | `256Mi` | Core memory request |
| `config.kubernetes.harbor.resources.core.limits_cpu` | `1000m` | Core CPU limit |
| `config.kubernetes.harbor.resources.core.limits_memory` | `512Mi` | Core memory limit |
| `config.kubernetes.harbor.resources.registry.requests_cpu` | `100m` | Registry CPU request |
| `config.kubernetes.harbor.resources.registry.requests_memory` | `256Mi` | Registry memory request |
| `config.kubernetes.harbor.resources.registry.limits_cpu` | `2000m` | Registry CPU limit |
| `config.kubernetes.harbor.resources.registry.limits_memory` | `2Gi` | Registry memory limit |

---

## What Gets Deployed

```
Namespace: harbor
├── Deployment/harbor-core            # API + authentication
├── Deployment/harbor-portal          # Web UI (nginx)
├── Deployment/harbor-registry        # Image storage (distribution)
├── Deployment/harbor-jobservice      # GC, replication jobs
├── StatefulSet/harbor-database       # PostgreSQL (bundled)
├── StatefulSet/harbor-redis          # Redis (bundled)
├── Deployment/harbor-trivy           # Vulnerability scanner (optional)
├── Service/harbor (NodePort)         # HTTP → 61064
├── PVC/harbor-registry               # 200Gi image data
├── PVC/harbor-database               # 10Gi PostgreSQL
├── PVC/harbor-redis                  # 5Gi Redis
├── PVC/harbor-jobservice             # 5Gi job logs
└── Secrets (admin password, internal certs)
```

All PVCs use the configured storage class (Longhorn by default) — data survives pod restarts, node reboots, and rescheduling.

---

## Task Execution Flow

```
main.yml
├── validate.yml     # Version, secrets, LDAP config, helm/kubectl available
├── install.yml      # Create namespace, template values, helm upgrade --install
├── verify.yml       # Rollout status, pod health, API health check
└── configure.yml    # LDAP settings + GC schedule via Harbor API
```

---

## LDAP Authentication & Authorization

### How It Works

1. **Authentication (who can log in):**
   - Configured via `ldap.filter` — e.g., `(memberOf=cn=harbor-users,ou=groups,dc=bt,dc=com)`
   - Only users matching this filter can authenticate
   - Set in role config, deployed automatically

2. **Authorization (what they can do):**
   - Configured in Harbor UI after deployment
   - Go to **Administration → User Groups** → map LDAP group DNs
   - In each **Project → Members** → add groups with roles:
     - **Project Admin** — full control (push/pull/delete/manage)
     - **Maintainer** — push/pull/delete, scan
     - **Developer** — push/pull
     - **Guest** — pull only

### Example LDAP Configuration

```yaml
# In app_configs.yml
config:
  kubernetes:
    harbor:
      external_url: "https://harbor.mat.bt.com"
      auth:
        mode: ldap_auth
      ldap:
        url: "ldap://ad.intra.bt.com:389"
        base_dn: "ou=users,dc=intra,dc=bt,dc=com"
        search_dn: "cn=svc-harbor,ou=service,dc=intra,dc=bt,dc=com"
        uid: "sAMAccountName"
        filter: "(memberOf=cn=harbor-users,ou=groups,dc=intra,dc=bt,dc=com)"
        group_base_dn: "ou=groups,dc=intra,dc=bt,dc=com"
        group_filter: "(objectClass=group)"
        group_membership: "memberOf"
```

---

## Robot Accounts (CI/CD)

After deployment, create robot accounts from the UI:

1. **System-level:** Administration → Robot Accounts → New
2. **Project-level:** Project → Robot Accounts → New

Each robot account gets:
- Username: `robot$<name>` (system) or `robot$<project>+<name>` (project)
- Token: auto-generated, use as password
- Permissions: push, pull, delete (configurable)
- Expiry: configurable (or never)

Use in CI/CD:
```bash
# containerd/nerdctl
nerdctl login harbor.mat.bt.com -u 'robot$ci-push' -p '<token>'
nerdctl push harbor.mat.bt.com/mat/myapp:v1.0

# Docker (if using docker CLI)
docker login harbor.mat.bt.com -u 'robot$ci-push' -p '<token>'
```

Use in Kubernetes:
```bash
kubectl create secret docker-registry harbor-pull \
  --docker-server=harbor.mat.bt.com \
  --docker-username='robot$ci-pull' \
  --docker-password='<token>' \
  -n <app-namespace>
```

---

## Garbage Collection

Harbor manages space via tag retention policies and scheduled GC:

**From UI (Administration → Garbage Collection):**
- Schedule: Daily/Weekly/Custom cron
- Delete untagged artifacts: yes/no
- Workers: parallel GC threads

**From UI (Project → Tag Retention):**
- Keep only N most recent tags
- Keep tags matching pattern (e.g., `v*`, `release-*`)
- Delete tags older than N days
- Combine rules per repository

The role pre-configures daily GC with untagged deletion. Fine-tune retention rules per project in the UI.

---

## HAProxy Configuration

Add to your HAProxy config to front Harbor with HTTPS:

```
frontend ft_harbor
    bind *:443 ssl crt /etc/haproxy/certs/harbor.pem
    default_backend bk_harbor

backend bk_harbor
    server harbor <k8s-node-ip>:61064 check
```

Then configure containerd on K8s worker nodes to trust Harbor:

```toml
# /etc/containerd/certs.d/harbor.mat.bt.com/hosts.toml
server = "https://harbor.mat.bt.com"

[host."https://harbor.mat.bt.com"]
  capabilities = ["pull", "resolve", "push"]
```

---

## Upgrade Process

1. Update `version.kubernetes.harbor` in `versions.yml` (or change config values)
2. Re-run playbook:
   - `helm upgrade --install` uses `Recreate` strategy — kills old pods before creating new ones
   - This avoids Multi-Attach PVC errors (RWO volumes can only attach to one pod at a time)
   - Database migrations run automatically
   - PVC data is preserved — all projects, users, images remain intact
3. If upgrade fails: `helm rollback harbor -n harbor`

---

## Post-Deployment Verification

```bash
# 1. Pod status
kubectl get pods -n harbor

# 2. Services
kubectl get svc -n harbor

# 3. API health
curl -s http://<node-ip>:61064/api/v2.0/health
# Expected: {"status":"healthy", "components":[...]}

# 4. Login test
curl -s -u admin:<password> http://<node-ip>:61064/api/v2.0/users
# Expected: 200 OK with user list

# 5. Web UI
# Open: https://harbor.mat.bt.com (or http://<node-ip>:61064)
# Login: admin / <vault password>
```

---

## Troubleshooting

### Checking Logs

```bash
# Core (API + auth)
kubectl logs -n harbor -l component=core --tail=50

# Registry (image push/pull)
kubectl logs -n harbor -l component=registry --tail=50

# JobService (GC)
kubectl logs -n harbor -l component=jobservice --tail=50

# Portal (web UI)
kubectl logs -n harbor -l component=portal --tail=50

# Follow live
kubectl logs -n harbor -l component=core -f

# Events
kubectl get events -n harbor --sort-by='.lastTimestamp'
```

### Common Issues

**Pods stuck in Pending:**
```bash
kubectl describe pod -n harbor <pod-name>
# Common: PVC not bound (storage class missing), node affinity not matching
```

**LDAP login fails:**
```bash
# Test LDAP connectivity from inside core pod
kubectl exec -n harbor -it <core-pod> -- \
  wget -qO- "ldap://<ldap-host>:389" 2>&1 || echo "Connection failed"
# Check LDAP config in UI: Administration → Configuration → Authentication
```

**Registry out of space:**
```bash
# Check PVC usage
kubectl exec -n harbor -it <registry-pod> -- df -h /storage
# Run GC manually from UI: Administration → Garbage Collection → GC Now
```

**Helm release issues:**
```bash
helm status harbor -n harbor
helm get values harbor -n harbor
helm history harbor -n harbor
```

---

## Security Notes

- Admin password stored in vault, deployed via Helm secret
- LDAP bind password stored in vault
- Internal PostgreSQL not exposed outside cluster
- No TLS between internal components (all pod-to-pod within cluster network)
- HTTPS termination at HAProxy layer
- Robot account tokens are non-reversible — revoke and recreate if compromised
- Helm values written to `/tmp` with mode `0600`, deleted immediately after deploy
- `no_log: true` on all credential-handling tasks
- All PVCs encrypted at rest if Longhorn encryption is enabled

---

## File Structure

```
roles/kubernetes/platform/harbor/
├── defaults/main.yml              # All variables with defaults
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks
│   ├── install.yml                # Namespace + Helm deploy
│   ├── verify.yml                 # Rollout + health checks
│   └── configure.yml              # LDAP + GC config via API
├── templates/
│   └── values.yaml.j2            # Helm chart values
└── README.md                      # This file
```

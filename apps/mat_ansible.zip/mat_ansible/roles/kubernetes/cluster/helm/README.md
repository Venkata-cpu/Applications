# Helm CLI Role

Installs [Helm](https://helm.sh/) — the Kubernetes package manager — on master nodes. Pinned to a specific version for reproducibility.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Helm** | https://github.com/helm/helm/releases | `4.2.1` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes master** | Node must be a K8s master | `kubectl get nodes` |
| **Proxy** | For downloading from get.helm.sh | `all_secrets.yml` |
| **Base directory** | Must exist | `ls -la /apps` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/helm.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.helm` | `3.17.3` | Helm version |

### Optional (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `paths.helm.base_dir` | `paths.kubernetes.base_dir` | Download/work directory |
| `config.kubernetes.ansible_user` | `ansible_user` | User that owns helm binary |
| `config.kubernetes.docker_less.additional_users` | `[]` | Extra users needing helm in PATH |
| `config.kubernetes.helm.download_timeout` | `120` | Download timeout (seconds) |

---

## Task Execution Flow

```
main.yml
├── validate.yml    # Version defined, base dir exists
├── install.yml     # Download, extract, install, PATH setup
└── verify.yml      # helm version check
```

---

## Upgrade Process

1. Update `version.kubernetes.helm` in `versions.yml`
2. Re-run playbook — detects version mismatch, downloads new, replaces binary

---

## Troubleshooting

### Checking Logs

Helm is a CLI tool with no daemon — no logs to check. If it fails:

```bash
# Check if installed
helm version --short

# Check PATH
echo $PATH | grep -o '/usr/local/bin'

# Check permissions
ls -la /usr/local/bin/helm
```

---

## File Structure

```
roles/kubernetes/cluster/helm/
├── defaults/main.yml     # Variables
├── tasks/
│   ├── main.yml          # Orchestrator
│   ├── validate.yml      # Pre-flight
│   ├── install.yml       # Download + install
│   └── verify.yml        # Post-install check
└── README.md             # This file
```

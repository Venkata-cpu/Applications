# Kubernetes Setup (Containerd, No Docker)

Sets up a production Kubernetes cluster on OEL 8/9 using containerd as the container runtime. No Docker dependency. Supports single-master (test) and multi-master HA (production) configurations from the same codebase.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Kubernetes** | https://kubernetes.io/releases/ | `1.36.2` |
| **Calico CNI** | https://github.com/projectcalico/calico/releases | `3.32.0` |
| **containerd** | https://github.com/containerd/containerd/releases | Latest from Docker CE repo |
| **pause image** | https://github.com/kubernetes/kubernetes/blob/master/build/pause/CHANGELOG.md | `3.10` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **CPU** | Minimum 2 cores per node | `nproc` |
| **RAM** | Minimum 4 GB per node | `free -h` |
| **Disk** | `/apps` mount with 50GB+ free | `df -h /apps` |
| **Network** | All nodes reachable on port 6443 | `telnet <master-ip> 6443` |
| **Proxy** | For pkgs.k8s.io + Docker CE repo | `all_secrets.yml` |
| **HAProxy** | For multi-master (prod) — LB in front of API servers | Optional for single-master |

---

## How to Run

```bash
# Step 1: Setup master(s) — always run first
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_master_setup_dockerless.yaml \
  --vault-password-file .vault

# Step 2: Setup workers — run after masters are Ready
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_worker_setup_dockerless.yaml \
  --vault-password-file .vault
```

**Order matters:** Masters must be fully ready before workers join. The worker playbook reaches out to the first master to get a fresh join token.

---

## What Gets Installed

| Component | Version | Purpose |
|-----------|---------|---------|
| containerd | Latest from Docker CE repo | Container runtime (replaces Docker) |
| kubelet | from `version.kubernetes.docker_less.k8s_full` | Node agent — runs and monitors pods |
| kubeadm | from `version.kubernetes.docker_less.k8s_full` | Cluster bootstrapping tool |
| kubectl | from `version.kubernetes.docker_less.k8s_full` | CLI for cluster management |
| Calico | from `version.kubernetes.docker_less.calico` | CNI network plugin (pod networking + network policies) |
| iproute-tc | Latest | Traffic control (required by K8s for QoS) |

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Control Plane (Masters)                │
│                                                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│  │ Master-1 │  │ Master-2 │  │ Master-3 │  (HA: 3 masters)
│  │ API+etcd │  │ API+etcd │  │ API+etcd │              │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘              │
│       │              │              │                    │
│       └──────────────┼──────────────┘                    │
│                      │                                   │
│              ┌───────┴───────┐                           │
│              │  HAProxy VIP  │  (prod: shared endpoint)  │
│              └───────┬───────┘                           │
└──────────────────────┼───────────────────────────────────┘
                       │
┌──────────────────────┼───────────────────────────────────┐
│                      │         Workers                    │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐   │
│  │Worker-1 │  │Worker-2 │  │Worker-3 │  │Worker-N │   │
│  │kubelet  │  │kubelet  │  │kubelet  │  │kubelet  │   │
│  │containrd│  │containrd│  │containrd│  │containrd│   │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘   │
└──────────────────────────────────────────────────────────┘
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.docker_less.k8s` | `1.36` | K8s major.minor (for repo URL) |
| `versions.yml` | `version.kubernetes.docker_less.k8s_full` | `1.36.2` | Full version for package install |
| `versions.yml` | `version.kubernetes.docker_less.calico` | `3.32.0` | Calico CNI version |
| `paths.yml` | `paths.kubernetes.base_dir` | `/apps` | Data base directory |
| `networks.yml` | `ports.kubernetes.docker_less.api` | `6443` | API server port |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.kubernetes.ansible_user` | `ansible_user` | SSH user for kubectl/helm | Gets kubeconfig |
| `config.kubernetes.docker_less.pod_network_cidr` | `192.168.0.0/16` | Pod network CIDR | Must match Calico config |
| `config.kubernetes.docker_less.service_cidr` | `10.96.0.0/12` | Service CIDR | K8s internal services |
| `config.kubernetes.docker_less.nodeport_range` | `51000-61099` | Allowed NodePort range | See NodePort section below |
| `config.kubernetes.docker_less.control_plane_endpoint` | First master IP:6443 | API endpoint | HAProxy VIP for multi-master |
| `config.kubernetes.docker_less.sandbox_image` | `registry.k8s.io/pause:3.10` | Pause container image | |
| `config.kubernetes.docker_less.max_pods` | `110` | Max pods per node | |
| `config.kubernetes.docker_less.eviction.memory_available` | `200Mi` | Eviction threshold | |
| `config.kubernetes.docker_less.eviction.nodefs_available` | `10%` | Eviction threshold | |
| `config.kubernetes.docker_less.eviction.imagefs_available` | `15%` | Eviction threshold | |
| `config.kubernetes.docker_less.eviction.pid_available` | `5%` | Eviction threshold | |
| `config.kubernetes.docker_less.container_logs.max_size` | `50Mi` | Per-container log max | |
| `config.kubernetes.docker_less.container_logs.max_files` | `3` | Rotated log files kept | |
| `config.kubernetes.docker_less.cert_renewal.enabled` | `true` | Auto-renewal cron enabled | |
| `config.kubernetes.docker_less.cert_renewal.schedule` | `0 3 1 * *` | Cron schedule (base, staggered per master) | |
| `config.kubernetes.docker_less.cert_renewal.threshold_days` | `45` | Renew only if cert expires within this many days | Lower = less frequent renewals, higher = more safety margin |
| `config.kubernetes.docker_less.cert_renewal.smtp_host` | `smtpb.intra.bt.com` | SMTP relay for email notifications | |
| `config.kubernetes.docker_less.cert_renewal.from_email` | `noreply.martini@bt.com` | Sender address | |
| `config.kubernetes.docker_less.cert_renewal.to_emails` | `[]` | Recipients notified after renewal | Empty = no email sent |
| `config.kubernetes.docker_less.cert_renewal.log_file` | `/var/log/k8s-cert-renewal.log` | Script log file | |
| `config.kubernetes.docker_less.cgroup_version` | `v2` | cgroups version | Auto-enables + reboots if needed |
| `config.kubernetes.docker_less.no_proxy` | `localhost,...` | Proxy exclusions | Must include node subnet |
| `config.kubernetes.docker_less.additional_users` | `[]` | Extra users getting kubeconfig | |
| `config.kubernetes.docker_less.reboot_timeout` | `300` | Wait time after cgroup reboot | |
| `config.kubernetes.docker_less.download_timeout` | `60` | Package download timeout | |

---

## Hosts File Examples

### Single Master (Test/Pre-Prod)
```ini
[kubernetes:children]
kubernetes_master
kubernetes_worker

[kubernetes_master:children]
kubernetes_master_init

[kubernetes_master_init]
blp20919911  ansible_host=10.6.103.179

[kubernetes_worker]
blp20919912  ansible_host=10.6.103.180
blp20919913  ansible_host=10.6.103.181
```

### Multi-Master HA (Production)
```ini
[kubernetes:children]
kubernetes_master
kubernetes_worker

[kubernetes_master:children]
kubernetes_master_init
kubernetes_master_join

[kubernetes_master_init]
blp20919437  ansible_host=10.6.103.81

[kubernetes_master_join]
blp20919486  ansible_host=10.6.103.82
blp20919487  ansible_host=10.6.103.83

[kubernetes_worker]
blp20919440  ansible_host=10.6.103.85
blp20919441  ansible_host=10.6.103.86
```

For multi-master, set `control_plane_endpoint` to the HAProxy VIP:
```yaml
config:
  kubernetes:
    docker_less:
      control_plane_endpoint: "k8s-api.nat.bt.com:6443"
```

---

## Task Execution Flow

### Master Playbook
```
Prerequisites (all masters):
├── cgroups.yml              # Check/enable cgroups v2 + reboot if needed
├── system_packages.yml      # Install iproute-tc, disable firewalld
├── kernel_modules.yml       # Load overlay, br_netfilter
├── sysctl.yml               # Enable ip_forward, bridge-nf-call
├── disable_swap.yml         # swapoff + remove from fstab
├── containerd.yml           # Install + configure containerd + proxy
└── kubernetes_packages.yml  # Add K8s repo, install kubelet/kubeadm/kubectl

Master Setup:
├── init.yml                 # kubeadm init (first master) + join (others)
├── kubeconfig.yml           # Copy .kube/config to users
├── calico.yml               # Install Calico CNI
├── cert_renewal.yml         # Setup monthly cert renewal cron
└── verify.yml               # Check master is Ready
```

### Worker Playbook
```
Prerequisites (all workers):
├── (same as master prerequisites)

Worker Setup:
├── generate_join.yml        # Get fresh join token from master (delegated)
├── join.yml                 # kubeadm join
└── verify.yml               # Check kubelet is active
```

---

## Data Paths

All K8s data is stored under `/apps/kubernetes_data/` — NOT under `/var`:

| Component | Path | What's stored |
|-----------|------|---------------|
| containerd | `/apps/kubernetes_data/containerd` | Container images, layers, snapshots |
| kubelet | `/apps/kubernetes_data/kubelet` | Pod data, volumes, logs |
| etcd | `/apps/kubernetes_data/etcd` | Cluster state database (masters only) |

This prevents filling up the system `/var` partition.

---

## NodePort Range

Default K8s allows NodePorts only in 30000-32767. This role sets it to **51000-61099**.

| Consideration | Detail |
|---------------|--------|
| **Non-K8s services on same nodes** | Ports within the range could be randomly assigned by K8s |
| **Your service ports** | All explicitly assigned NodePorts must fall within this range |
| **Lower bound** | Above SSH (50022) / SFTP ports — that's why 51000 |
| **Upper bound** | Ports above the range are safe for non-K8s services |

---

## Certificate Auto-Renewal

K8s certificates expire after **1 year**. The role deploys a cron job that checks cert expiry and only renews when certificates are within the configured threshold.

**How it works:**
1. Cron runs on schedule (default: 1st of every month)
2. Script checks earliest cert expiry date via `kubeadm certs check-expiration`
3. If expiry is MORE than threshold days away → logs "no action needed" and exits
4. If expiry is WITHIN threshold days → renews all certs, restarts control plane, sends email notification

**Multi-master stagger:** Each master's cron is offset by 10 minutes (master 0 at :00, master 1 at :10, master 2 at :20) to avoid simultaneous API server restarts.

**Downtime:** ~30 seconds per master during control plane restart. Only one master restarts at a time.

**Configuration:**

| Variable | Default | Description |
|----------|---------|-------------|
| `cert_renewal.enabled` | `true` | Enable/disable auto-renewal |
| `cert_renewal.schedule` | `0 3 1 * *` | Cron schedule (base time, staggered per master) |
| `cert_renewal.threshold_days` | `45` | Renew only if cert expires within this many days |
| `cert_renewal.smtp_host` | `smtpb.intra.bt.com` | SMTP relay for notifications |
| `cert_renewal.smtp_port` | `25` | SMTP port |
| `cert_renewal.from_email` | `noreply.martini@bt.com` | Sender address for notifications |
| `cert_renewal.to_emails` | `[]` | List of email recipients notified after renewal |
| `cert_renewal.log_file` | `/var/log/k8s-cert-renewal.log` | Log file path |

**Inventory example:**
```yaml
config_k8s:
  docker_less:
    cert_renewal:
      enabled: true
      schedule: "0 3 1 * *"
      threshold_days: 45
      smtp_host: "smtpb.intra.bt.com"
      smtp_port: 25
      from_email: "noreply.martini@bt.com"
      to_emails:
        - "martini.devops@bt.com"
        - "platform.team@bt.com"
      log_file: "/var/log/k8s-cert-renewal.log"
```

**Manual commands:**
```bash
# Check cert expiry
kubeadm certs check-expiration

# Manually trigger renewal (ignores threshold — always renews)
/usr/local/bin/k8s-cert-renew.sh

# Check cron (note: minutes differ per master)
cat /etc/cron.d/k8s-cert-renewal

# Check renewal log
cat /var/log/k8s-cert-renewal.log
```

**Email notification (sent only when renewal happens):**
- Subject: `[K8s Cert Renewal] Certificates renewed on <hostname>`
- Body: reason for renewal, new cert status, timestamp

---

## cgroups v2

Kubernetes 1.35+ requires cgroups v2. OEL 8 ships with v1, OEL 9 has v2.

The role auto-detects and if needed:
1. Adds kernel boot parameter
2. **Reboots the node** (automatic)
3. Verifies cgroups v2 after reboot

No manual action needed.

---

## Proxy Configuration

All downloads go through proxy. The `no_proxy` must include:

- `localhost,127.0.0.1` — loopback
- `.svc,.cluster.local` — K8s internal DNS
- `10.96.0.0/12` — service CIDR
- `192.168.0.0/16` — pod CIDR
- Your node subnet (e.g., `10.6.103.0/24`)

Containerd gets a proxy config at `/etc/systemd/system/containerd.service.d/http-proxy.conf` for image pulls.

---

## Upgrade Process

1. Update `version.kubernetes.docker_less.k8s_full` in `versions.yml`
2. Follow Kubernetes upgrade procedure:
   - Upgrade masters first (one at a time): `kubeadm upgrade apply v1.x.y`
   - Then upgrade workers: `kubeadm upgrade node`
   - Update kubelet/kubectl packages
3. Use the `kubernetes_upgrade.yaml` playbook for automated rolling upgrades

---

## Post-Deployment Verification

```bash
# Check cluster status
kubectl get nodes -o wide

# All pods running
kubectl get pods -A

# Component health
kubectl get --raw='/readyz?verbose'

# Check certificates
kubeadm certs check-expiration

# Get join command for new workers
kubeadm token create --print-join-command
```

---

## Troubleshooting

### Checking Logs

```bash
# Kubelet logs (last 50 lines)
journalctl -u kubelet --no-pager -n 50

# Follow live
journalctl -u kubelet -f

# Errors only
journalctl -u kubelet -p err

# Containerd logs
journalctl -u containerd --no-pager -n 50

# Specific time range
journalctl -u kubelet --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### kubeadm init fails
```bash
journalctl -xeu kubelet --no-pager | tail -50
systemctl status containerd
crictl --runtime-endpoint unix:///run/containerd/containerd.sock info
stat -fc %T /sys/fs/cgroup   # must be cgroup2fs
```

### Worker can't join
```bash
# On master: check token hasn't expired (24h default)
kubeadm token list

# Regenerate token
kubeadm token create --print-join-command

# On worker: check connectivity to master API
curl -k https://<master-ip>:6443/healthz
```

### Pods stuck in ContainerCreating
```bash
kubectl get pods -n kube-system -l k8s-app=calico-node
crictl pull nginx:latest
cat /etc/systemd/system/containerd.service.d/http-proxy.conf
```

### Node shows NotReady
```bash
systemctl status kubelet
journalctl -u kubelet | tail -20
# Common: CNI not installed, containerd stopped, disk full
```

### Disk space issues
```bash
du -sh /apps/kubernetes_data/containerd/
du -sh /apps/kubernetes_data/kubelet/
crictl rmi --prune
kubectl describe node <node> | grep -A5 Conditions
```

### Certificates expired
```bash
# Check current expiry status
kubeadm certs check-expiration

# Check renewal log (was renewal attempted?)
cat /var/log/k8s-cert-renewal.log

# Manually trigger renewal (ignores threshold)
/usr/local/bin/k8s-cert-renew.sh

# Check cron is set up
cat /etc/cron.d/k8s-cert-renewal

# If kubectl hangs after renewal — copy new admin.conf
cp /etc/kubernetes/admin.conf /root/.kube/config
```

---

## Security Notes

- Firewalld disabled (K8s manages iptables via kube-proxy)
- Swap disabled (K8s requirement for accurate resource management)
- containerd uses SystemdCgroup (proper resource accounting)
- Node certificates auto-renewed monthly
- API server binds only to advertise address
- etcd data directory mode `0700` (master only)
- No Docker socket exposed — containerd only

---

## File Structure

```
roles/kubernetes/cluster/docker_less/
├── defaults/main.yml
├── tasks/
│   ├── main.yml                              # Prerequisites orchestrator
│   ├── prerequisites/
│   │   ├── cgroups.yml                       # Check/enable cgroups v2 + reboot
│   │   ├── system_packages.yml               # iproute-tc + disable firewalld
│   │   ├── kernel_modules.yml                # overlay, br_netfilter
│   │   ├── sysctl.yml                        # ip_forward, bridge-nf-call
│   │   ├── disable_swap.yml                  # Swap off + fstab
│   │   ├── containerd.yml                    # Install + config + proxy
│   │   └── kubernetes_packages.yml           # Repo + kubelet/kubeadm/kubectl
│   ├── master_setup.yml                      # Master orchestrator
│   ├── master/
│   │   ├── init.yml                          # kubeadm init + multi-master join
│   │   ├── kubeconfig.yml                    # .kube/config for users
│   │   ├── kubeconfig_user.yml               # Helper: copy config to one user
│   │   ├── calico.yml                        # Install Calico CNI
│   │   ├── cert_renewal.yml                  # Monthly cert renewal cron
│   │   └── verify.yml                        # Check master Ready
│   ├── worker_setup.yml                      # Worker orchestrator
│   └── worker/
│       ├── generate_join.yml                 # Get token from master (delegated)
│       ├── join.yml                          # kubeadm join
│       └── verify.yml                        # Check kubelet active
├── templates/
│   └── kubernetes.repo.j2                    # K8s yum repo
└── README.md                                 # This file
```

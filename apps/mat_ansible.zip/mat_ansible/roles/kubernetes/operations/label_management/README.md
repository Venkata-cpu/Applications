# Kubernetes Node Label Management

Manages custom labels on Kubernetes nodes via inventory config. Add labels to groups of nodes and remove specific labels — all driven from `config_kubernetes.yml`.

## Latest Version

This role does not install external software — it uses the cluster's existing `kubectl` binary. No version tracking needed.

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ cluster running | `kubectl get nodes` |
| **kubectl** | Available on master node | `which kubectl` |
| **ansible_user** | Has kubectl access on master | `sudo -u <user> --set-home kubectl get nodes` |
| **Inventory groups** | Node group names referenced in config must exist in hosts file | Check `hosts` file |

---

## How It Works

- **Add labels:** Define nodes + labels in `config_k8s.node_labels.add`
- **Remove labels:** Define nodes + label keys in `config_k8s.node_labels.remove`
- **Host group resolution:** The `nodes` list supports both direct node hostnames AND inventory host group names. If a name matches an inventory group, it is automatically expanded to all hostnames in that group.
- **Default K8s labels are never touched** — the role only operates on labels you explicitly list

Re-running is safe (idempotent) — adding an existing label just overwrites with same value. Removing a non-existent label is ignored.

## Config Format

### config_kubernetes.yml (under config_k8s)

```yaml
node_labels:
  # Add labels (key=value format)
  add:
    # Using inventory host group names (resolved to actual hostnames at runtime)
    - nodes: [kafka_workers]
      labels:
        - "node-role.kubernetes.io/kafka=true"
        - "tier=streaming"

    - nodes: [mongodb_workers]
      labels:
        - "node-role.kubernetes.io/mongodb=true"
        - "tier=data"

    # Using direct node hostnames
    - nodes: [blp25082028, blp25082029]
      labels:
        - "node-role.kubernetes.io/supabase=true"

    # Mixing both is also supported
    - nodes: [kubernetes_worker_reigate]
      labels:
        - "topology.kubernetes.io/region=reigate"

  # Remove labels (key only, no value)
  remove:
    - nodes: [kafka_workers]
      labels:
        - "node-role.kubernetes.io/kafka"
        - "tier"
```

### Node Resolution Rules

| `nodes` entry | Resolution |
|---------------|------------|
| `kafka_workers` | Expanded to all hosts in the `[kafka_workers]` inventory group |
| `blp25082028` | Used as-is (direct hostname) |
| `kubernetes_worker_derby` | Expanded to all hosts in `[kubernetes_worker_derby]` group |

This means you can define application-specific groups in your `hosts` file and reference them directly in the label config — no need to repeat individual hostnames.

### Adding a New Label

Just add an entry to `add` list and re-run:

```yaml
add:
  - nodes: [elasticsearch_workers]
    labels:
      - "node-role.kubernetes.io/elasticsearch=true"
```

### Removing a Label

Add to `remove` list (use key only, no `=value`):

```yaml
remove:
  - nodes: [elasticsearch_workers]
    labels:
      - "node-role.kubernetes.io/elasticsearch"
```

After running, remove the entry from `remove` list to keep config clean.

## Running the Playbook

```bash
# Barista prod
ansible-playbook -i inventories/barista/prod/hosts playbook/kubernetes/kubernetes_labels.yaml --vault-password-file .vault

# Barista test
ansible-playbook -i inventories/barista/test/hosts playbook/kubernetes/kubernetes_labels.yaml --vault-password-file .vault

# Override target host
ansible-playbook -i inventories/barista/prod/hosts playbook/kubernetes/kubernetes_labels.yaml --vault-password-file .vault --extra-vars="target_host=kubernetes_master_init"
```

## Variable Reference

| Variable | Source | Description |
|----------|--------|-------------|
| `label_mgmt_add` | `config_k8s.node_labels.add` | List of node groups with labels to add |
| `label_mgmt_remove` | `config_k8s.node_labels.remove` | List of node groups with labels to remove |
| `label_mgmt_ansible_user` | `config_k8s.ansible_user` | User with kubectl access |

## Task Execution Flow

```
main.yaml
├── add_labels.yml        (loop over add groups)
│   └── add_group.yml     (resolve host groups → apply labels via kubectl)
├── remove_labels.yml     (loop over remove groups)
│   └── remove_group.yml  (resolve host groups → remove labels via kubectl)
└── verify.yml            (resolve all groups → show final labels)
```

## File Structure

```
roles/kubernetes/operations/label_management/
├── defaults/main.yml          # Variables
├── tasks/
│   ├── main.yaml              # Orchestrator
│   ├── add_labels.yml         # Loop over add groups
│   ├── add_group.yml          # Resolve groups + apply labels to one group
│   ├── remove_labels.yml      # Loop over remove groups
│   ├── remove_group.yml       # Resolve groups + remove labels from one group
│   └── verify.yml             # Resolve groups + show final labels
└── README.md
```

## Post-Deployment Verification

```bash
# Check labels on a specific node
kubectl get node blp25082028 --show-labels

# Check all nodes with a specific label
kubectl get nodes -l node-role.kubernetes.io/kafka=true

# Check nodes by tier label
kubectl get nodes -l tier=streaming
```

## Troubleshooting

### Error: nodes "kafka_workers" not found

This means the role is passing an inventory group name directly to kubectl instead of resolving it to actual hostnames. Ensure:
1. The inventory group exists in the `hosts` file
2. The playbook is run with the correct inventory file (`-i inventories/<module>/<env>/hosts`)

### Error: connection refused / permission denied

The role runs on the master node. Ensure `label_mgmt_ansible_user` has a valid kubeconfig:
```bash
sudo -u app-manager --set-home kubectl get nodes
```

### Node not found after resolution

If a hostname from the inventory doesn't match the Kubernetes node name, you may need to use the actual K8s node name (run `kubectl get nodes` to verify).

## Important Notes

- Labels in `add` use `key=value` format
- Labels in `remove` use `key` only (no value, no `=`)
- The role runs on the master node (where kubectl is available)
- `nodes` entries can be inventory host group names OR direct hostnames
- If a node_entry matches an inventory group name, ALL hosts in that group get the label
- Default K8s labels (`kubernetes.io/*`, `node.kubernetes.io/*`) are never modified
- If a resolved node doesn't exist in K8s, kubectl will error — make sure inventory hostnames match `kubectl get nodes`

---

## Upgrade Process

This role has no external binary — no upgrade needed. Changes are purely config-driven:

1. Add/modify entries in `config_k8s.node_labels.add` or `.remove`
2. Re-run the playbook — labels are applied/removed immediately

---

## Security Notes

- Uses `sudo -u <ansible_user> --set-home kubectl` (never runs kubectl as root)
- Only modifies labels you explicitly list — never touches default K8s system labels
- No secrets handled — purely metadata operations
- Idempotent — safe to re-run without side effects

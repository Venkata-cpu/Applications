# Kubernetes Image Cleanup

Deploys a daily cron script on Kubernetes worker nodes to prune unused container images (`crictl rmi --prune`). Prevents disk space exhaustion from stale images left behind after pod updates, rollbacks, or scaling events.

## How It Works

The script runs daily at 00:02 (configurable) and:
1. Lists all images before cleanup
2. Prunes unused images via `crictl rmi --prune`
3. Logs disk usage before/after with space freed
4. Compresses previous day's logs to `.gz`
5. Removes 0-byte log files (cleanup of legacy logrotate artefacts)
6. Deletes logs older than the retention period

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| containerd runtime | crictl must be available on target nodes | `crictl version` |
| Worker nodes | Script targets K8s worker nodes | `kubectl get nodes` |
| Root access | Cron runs as root for crictl access | `whoami` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_image_cleanup.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `cleanup_log_dir` | `/apps/ASG/logs/k8s-cleanup` | Directory for cleanup log files |
| `cleanup_script_dir` | `/apps/ASG/scripts` | Directory where the cleanup script is deployed |
| `cleanup_log_retention_days` | `7` | Days to keep log files (older logs are deleted) |
| `cleanup_schedule_hour` | `0` | Cron hour (24h format) |
| `cleanup_schedule_minute` | `2` | Cron minute |
| `cleanup_enabled` | `true` | Enable/disable the cron job |

---

## What Gets Deployed

| File | Path | Purpose |
|------|------|---------|
| Cleanup script | `/apps/ASG/scripts/k8s-image-cleanup.sh` | Main cleanup logic |
| Cron job | `crontab -l` (root) | Daily trigger |
| Log directory | `/apps/ASG/logs/k8s-cleanup/` | Timestamped log per run |

---

## Log Management

The script handles its own log rotation (no external logrotate dependency):

| Action | Trigger | Details |
|--------|---------|---------|
| Rotate previous day | Start of each run | Compresses yesterday's log to `.gz` |
| Delete old logs | End of each run | Removes `.gz` files older than retention period |
| Remove 0-byte files | End of each run | Cleans up legacy logrotate artefacts |
| Remove legacy files | End of each run | Deletes old-format timestamped log files |

Log file naming: single active file + dated compressed archives.

After cleanup, the log directory will look like:
```
k8s-image-cleanup.log              ← Today's active log
k8s-image-cleanup.log-20260629.gz  ← Yesterday (compressed)
k8s-image-cleanup.log-20260628.gz  ← 2 days ago (compressed)
k8s-image-cleanup.log-20260627.gz  ← 3 days ago (compressed)
...
```

### Rotation Flow Example

```
Run starts at 00:02 on June 30:
├── k8s-image-cleanup.log exists (contains June 29 output)
├── gzip -c → k8s-image-cleanup.log-20260629.gz  ← June 29 data saved
├── > k8s-image-cleanup.log                       ← Now empty, ready for June 30
└── Script writes June 30 cleanup output to k8s-image-cleanup.log
```

No old data is lost — the previous day's log is always compressed and saved before the active log file is overwritten.

---

## Task Execution Flow

```
main.yml
├── Create cleanup directories (log dir + script dir)
├── Deploy k8s-image-cleanup.sh (from template)
├── Add/remove cron job (based on cleanup_enabled)
└── Remove legacy logrotate config (/etc/logrotate.d/k8s-image-cleanup)
```

---

## Post-Deployment Verification

```bash
# Check script is deployed
ls -la /apps/ASG/scripts/k8s-image-cleanup.sh

# Check cron is active
crontab -l | grep "Image Cleanup"

# Check logrotate is removed (should not exist)
ls /etc/logrotate.d/k8s-image-cleanup 2>/dev/null && echo "STALE - remove it" || echo "OK - not present"

# View latest log
cat /apps/ASG/logs/k8s-cleanup/k8s-image-cleanup.log

# Run manually to test
/apps/ASG/scripts/k8s-image-cleanup.sh

# Verify no 0-byte files
find /apps/ASG/logs/k8s-cleanup -size 0
```

---

## Troubleshooting

### Checking Logs

```bash
# View today's log
cat /apps/ASG/logs/k8s-cleanup/k8s-image-cleanup.log

# View previous day's compressed log
zcat /apps/ASG/logs/k8s-cleanup/k8s-image-cleanup.log-20260629.gz

# List all logs
ls -lt /apps/ASG/logs/k8s-cleanup/

# Check cron execution in syslog
journalctl -u crond --no-pager -n 20 | grep image-cleanup
```

### 0-byte files still appearing
```bash
# Check if logrotate config still exists (should have been removed)
cat /etc/logrotate.d/k8s-image-cleanup

# If present, remove it
rm /etc/logrotate.d/k8s-image-cleanup
```

### crictl not found
```bash
# Check containerd is running
systemctl status containerd

# Check crictl is in PATH
which crictl
ls /usr/local/bin/crictl /usr/bin/crictl 2>/dev/null
```

### Disk space not being freed
```bash
# Check if images are actually unused (in-use images won't be pruned)
crictl images | wc -l
crictl ps -a | wc -l

# Force list all images including digests
crictl images --digests
```

---

## Security Notes

- Script runs as root (required for `crictl` access to containerd socket)
- Only prunes **unused** images — images in use by running containers are never removed
- `crictl rmi --prune` is non-destructive — Kubernetes will re-pull images on next pod schedule if needed

---

## File Structure

```
roles/kubernetes/operations/image_cleanup/
├── defaults/main.yml                          # Default variables
├── tasks/main.yml                             # Task orchestration
├── templates/
│   ├── k8s-image-cleanup.sh.j2               # Main cleanup script (deployed to nodes)
│   └── k8s-image-cleanup-standalone.sh.j2    # Standalone installer (manual setup)
└── README.md
```

# Kubernetes Logging (Fluent Bit)

Deploys Fluent Bit as a DaemonSet to collect container logs from Kubernetes and ship them to Elasticsearch.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Fluent Bit** | https://github.com/fluent/fluent-bit/releases | Defined in `version.kubernetes.logging.fluent_bit` |
| **Container Image** | https://hub.docker.com/r/fluent/fluent-bit/tags | `cr.fluentbit.io/fluent/fluent-bit` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kubernetes** | 1.29+ with containerd | `kubectl version` |
| **Elasticsearch** | Running (K8s or bare-metal) | `curl http://<es-host>:<es-port>/_cluster/health` |
| **kubectl** | Available on master node | `kubectl get nodes` |
| **ansible_user** | Has kubectl access | `sudo -u <user> --set-home kubectl get nodes` |

## How It Works

```
Container → writes logs → /var/log/pods/ → Fluent Bit (tail) → Elasticsearch
```

Fluent Bit runs on every node, tails container log files based on pattern matching, enriches with Kubernetes metadata (pod name, namespace, labels), and forwards to Elasticsearch.

## What Gets Deployed

- ServiceAccount + RBAC (ClusterRole for pod/namespace access)
- ConfigMap (Fluent Bit config, parsers, output)
- DaemonSet (one Fluent Bit pod per node)

## Log Pattern Matching

Only logs from containers matching the configured patterns are collected. Define patterns in config:

```yaml
config:
  kubernetes:
    logging:
      match_patterns:
        - _my-namespace_        # all pods in my-namespace
        - _kafka_               # any pod with 'kafka' in name
        - _mat-test_            # specific namespace pattern
```

Patterns match against `/var/log/containers/*<pattern>*.log` file names. The container log filename format is: `<pod-name>_<namespace>_<container-name>-<container-id>.log`

## Variable Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `logging_fluent_bit_version` | `5.0.7` | Fluent Bit image tag |
| `logging_fluent_bit_image` | `cr.fluentbit.io/fluent/fluent-bit` | Image registry/name |
| `logging_namespace` | `kube-system` | Where DaemonSet runs |
| `logging_es_host` | (required) | Elasticsearch host IP/DNS |
| `logging_es_port` | (required) | Elasticsearch port |
| `logging_es_index_prefix` | `kubelogs` | Index name prefix in ES |
| `logging_es_date_format` | `%d.%m.%Y` | Date suffix format for daily indices |
| `logging_es_tls` | `false` | TLS to Elasticsearch |
| `logging_match_patterns` | (required) | List of container name patterns to collect |
| `logging_log_level` | `warn` | Fluent Bit log level (error, warn, info, debug) |
| `logging_requests_cpu` | `100m` | CPU request per pod |
| `logging_requests_memory` | `200Mi` | Memory request per pod |
| `logging_limits_cpu` | `1000m` | CPU limit per pod |
| `logging_limits_memory` | `1536Mi` | Memory limit per pod |
| `logging_mem_buf_limit` | `100MB` | Max memory buffer per input |
| `logging_backlog_mem_limit` | `800M` | Max backlog memory |
| `logging_es_workers` | `1` | Output workers (1=strict ordering, 2+=faster but may reorder) |
| `logging_es_buffer_size` | `2M` | Output buffer size |

### app_configs.yml (under config.kubernetes)
```yaml
logging:
  # Elasticsearch target
  elasticsearch:
    host: "10.13.149.184"
    port: 61003
    index_prefix: kubelogs
    date_format: "%d.%m.%Y"
    tls: false
  # Patterns to collect
  match_patterns:
    - _mat-test_
  # Resources (optional)
  resources:
    requests:
      cpu: "100m"
      memory: "200Mi"
    limits:
      cpu: "1000m"
      memory: "1536Mi"
  # Buffer (optional)
  # buffer:
  #   mem_buf_limit: "100MB"
  #   backlog_mem_limit: "800M"
  #   es_workers: 1              # 1=strict log ordering, 2+=faster but may reorder
  #   es_buffer_size: "2M"
```

### versions.yml
```yaml
version:
  kubernetes:
    logging:
      fluent_bit: "5.0.7"
```

## Running the Playbook

```bash
ansible-playbook -i inventories/barista/test/hosts playbook/kubernetes_logging.yaml --vault-password-file .vault
```

## File Structure

```
roles/kubernetes/logging/
├── defaults/main.yml                    # All variables
├── tasks/
│   ├── main.yaml                        # Orchestrator
│   ├── deploy.yml                       # Template + kubectl apply
│   └── verify.yml                       # Wait for pods + status
├── templates/
│   └── kube_fluent_bit.yaml.j2         # Full manifest (SA, RBAC, ConfigMap, DaemonSet)
└── README.md
```

## Containerd Compatibility

This role works with both Docker and containerd. Container logs are always at `/var/log/containers/` and `/var/log/pods/` regardless of runtime — Kubernetes manages these symlinks.

The old `/var/lib/docker/containers` mount has been removed as it's not needed with containerd.

## Log Ordering

Logs are sent to Elasticsearch in strict order by default (`es_workers: 1`). This ensures log lines appear in the correct sequence in Kibana/ES.

If you need higher throughput and can tolerate occasional reordering:
```yaml
buffer:
  es_workers: 2    # parallel output — faster but may shuffle order
```

**Why reordering happens with workers > 1:** Multiple threads send chunks to ES in parallel. Chunk A (earlier logs) might arrive after Chunk B if the network is congested.

## Timestamp Precision

Timestamps are sent with **nanosecond precision** (`%9N`). This ensures correct ordering in Elasticsearch even when multiple log lines occur within the same millisecond.

**Important:** Your Elasticsearch index template must use `date_nanos` field type for `@timestamp` to preserve nanosecond precision. Default ES `date` type truncates to milliseconds.

## Multiline Log Support (Java Stack Traces)

The role automatically joins Java stack traces into single log entries. Lines starting with:
- `  at ...` (stack frames)
- `Caused by:` (chained exceptions)
- `... N more` (truncated frames)

Are merged into the preceding log line. This prevents stack trace lines from appearing as separate entries in Elasticsearch.

## Dynatrace Tag Removal

If Dynatrace is injecting tags like `{dt.trace_id=...}` into log messages, the role strips them automatically via a Lua filter before sending to Elasticsearch. This keeps logs clean and reduces storage.

## Troubleshooting

**No logs appearing in Elasticsearch:**
```bash
# Check Fluent Bit pods
kubectl get pods -n kube-system -l app.kubernetes.io/name=fluent-bit

# Check Fluent Bit logs for errors
kubectl logs -n kube-system -l app.kubernetes.io/name=fluent-bit --tail=50

# Verify log files exist on node
ls /var/log/containers/ | grep <pattern>
```

**High memory usage:**
- Reduce `logging_mem_buf_limit` (lower buffer per input)
- Reduce `logging_limits_memory` (Fluent Bit will backpressure)
- Check if Elasticsearch is slow (causes buffer buildup)

**Missing logs from specific pods:**
- Verify pattern matches: `ls /var/log/containers/ | grep <your-pattern>`
- Pattern must match part of the filename (pod_namespace_container format)

---

## Upgrade Process

1. Update `version.kubernetes.logging.fluent_bit` in `versions.yml`
2. Re-run the playbook — `kubectl apply` updates the DaemonSet image tag
3. Pods restart in rolling fashion (one per node at a time)
4. No data loss — Fluent Bit picks up from where it left off (file position tracked)

---

## Post-Deployment Verification

```bash
# 1. All Fluent Bit pods running (one per node)
kubectl get pods -n kube-system -l app.kubernetes.io/name=fluent-bit -o wide

# 2. Check pod logs for successful output
kubectl logs -n kube-system -l app.kubernetes.io/name=fluent-bit --tail=10

# 3. Verify logs arriving in Elasticsearch
curl -s "http://<es-host>:<es-port>/kubelogs-*/_count" | python3 -m json.tool
```

---

## Security Notes

- Fluent Bit runs as a privileged DaemonSet (requires access to host `/var/log` paths)
- ServiceAccount with RBAC for pod/namespace metadata lookups (read-only)
- No secrets in ConfigMap — Elasticsearch connection is plaintext (internal cluster traffic)
- If ES security is enabled, credentials should be added to ConfigMap or Secret
- Dynatrace tag stripping via Lua filter does not log or store removed tags

# Kubernetes Monitoring

Deploys in-cluster monitoring stack for Kubernetes: Prometheus (for K8s-native metric collection and federation), kube-state-metrics (cluster state), metrics-server (enables `kubectl top` and HPA), and optionally node-exporter (host-level OS metrics from all K8s nodes). The node-exporter is disabled by default — enable it when you want host metrics (CPU, memory, disk, network) collected within the K8s Prometheus without needing a separate bare-metal node-exporter deployment.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Prometheus** | https://github.com/prometheus/prometheus/releases | Defined in `version.kubernetes.monitoring.prometheus` |
| **kube-state-metrics** | https://github.com/kubernetes/kube-state-metrics/releases | Defined in `version.kubernetes.monitoring.kube_state_metrics` |
| **metrics-server** | https://github.com/kubernetes-sigs/metrics-server/releases | Defined in `version.kubernetes.monitoring.metrics_server` |
| **AlertManager** | https://github.com/prometheus/alertmanager/releases | Defined in `version.kubernetes.monitoring.alertmanager` |
| **Node Exporter** | https://github.com/prometheus/node_exporter/releases | Defined in `version.kubernetes.monitoring.node_exporter` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Kubernetes cluster | Must be running with kubectl access | `kubectl get nodes` |
| Longhorn (optional) | Required only if persistent storage enabled for Prometheus | `kubectl get sc longhorn` |
| ansible_user | Must have kubectl access on master node | `kubectl auth can-i create deployments` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kubernetes/kubernetes_monitoring.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kubernetes.monitoring.prometheus` | `v3.5.4` | Prometheus container image tag |
| `versions.yml` | `version.kubernetes.monitoring.kube_state_metrics` | `v2.19.1` | kube-state-metrics image tag |
| `versions.yml` | `version.kubernetes.monitoring.metrics_server` | `v0.8.1` | metrics-server image tag |
| `versions.yml` | `version.kubernetes.monitoring.alertmanager` | `v0.33.0` | AlertManager image tag |
| `versions.yml` | `version.kubernetes.monitoring.node_exporter` | `v1.9.1` | Node Exporter image tag (when enabled) |
| `networks.yml` | `ports.kubernetes.monitoring.prometheus` | `30092` | Prometheus NodePort |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config_k8s.monitoring.namespace` | `monitoring` | K8s namespace for Prometheus + KSM | All monitoring pods deployed here |
| `config_k8s.monitoring.prometheus_retention` | `30d` | How long Prometheus keeps data | Higher = more disk usage |
| `config_k8s.monitoring.prometheus_scrape_interval` | `30s` | How often targets are scraped | Lower = more CPU/memory/network |
| `config_k8s.monitoring.prometheus_storage.enabled` | `false` | Use Longhorn PVC for Prometheus data | `true` = data survives pod restarts |
| `config_k8s.monitoring.prometheus_storage.storage_class` | `longhorn` | StorageClass for PVC | Must exist in cluster |
| `config_k8s.monitoring.prometheus_storage.size` | `10Gi` | PVC size | Size based on retention + scrape targets |
| `config_k8s.monitoring.prometheus_resources.requests_cpu` | `250m` | Prometheus CPU request | |
| `config_k8s.monitoring.prometheus_resources.requests_memory` | `512Mi` | Prometheus memory request | |
| `config_k8s.monitoring.prometheus_resources.limits_cpu` | `2000m` | Prometheus CPU limit | |
| `config_k8s.monitoring.prometheus_resources.limits_memory` | `4Gi` | Prometheus memory limit | Increase for large clusters |
| `config_k8s.monitoring.kube_state_metrics.requests_cpu` | `100m` | KSM CPU request | |
| `config_k8s.monitoring.kube_state_metrics.limits_memory` | `512Mi` | KSM memory limit | Increase for 500+ pods |
| `config_k8s.monitoring.metrics_server.requests_cpu` | `100m` | Metrics server CPU request | |
| `config_k8s.monitoring.metrics_server.limits_memory` | `512Mi` | Metrics server memory limit | |
| `config_k8s.monitoring.wait_retries` | `10` | Readiness check retries | |
| `config_k8s.monitoring.wait_delay` | `15` | Seconds between retries | |
| `config_k8s.monitoring.alertmanager.enabled` | `true` | Deploy AlertManager | `false` = no alerting, just metrics |
| `config_k8s.monitoring.alertmanager.smtp_host` | `smtpb.intra.bt.com:25` | SMTP relay for emails | |
| `config_k8s.monitoring.alertmanager.from_email` | `noreply.martini@bt.com` | Sender address | |
| `config_k8s.monitoring.alertmanager.to_emails` | `[]` | TO recipients | |
| `config_k8s.monitoring.alertmanager.cc_emails` | `[]` | CC recipients | |
| `config_k8s.monitoring.alertmanager.group_wait` | `5m` | Wait before sending grouped alert | |
| `config_k8s.monitoring.alertmanager.resolve_timeout` | `48h` | Auto-resolve if no update | |
| `config_k8s.monitoring.alertmanager.p1_repeat_interval` | `2h` | P1 alert repeat interval | |
| `config_k8s.monitoring.alertmanager.p2_repeat_interval` | `6h` | P2 alert repeat interval | |
| `config_k8s.monitoring.alertmanager.p3_repeat_interval` | `24h` | P3 alert repeat interval | |
| `config_k8s.monitoring.alert_rules.enabled` | `true` | Deploy K8s alert rules | |
| `config_k8s.monitoring.env_label` | `k8s` | Environment label in alert emails | Identifies which cluster fired the alert |
| `config_k8s.monitoring.node_exporter.enabled` | `false` | Deploy node-exporter DaemonSet | `true` = host metrics from all K8s nodes |
| `config_k8s.monitoring.node_exporter.port` | `9100` | Node Exporter listen port (hostPort) | Must not conflict with existing services |
| `config_k8s.monitoring.node_exporter.max_requests` | `40` | Max concurrent scrape requests | |
| `config_k8s.monitoring.node_exporter.resources.requests_cpu` | `50m` | Node Exporter CPU request | |
| `config_k8s.monitoring.node_exporter.resources.requests_memory` | `64Mi` | Node Exporter memory request | |
| `config_k8s.monitoring.node_exporter.resources.limits_cpu` | `250m` | Node Exporter CPU limit | |
| `config_k8s.monitoring.node_exporter.resources.limits_memory` | `128Mi` | Node Exporter memory limit | Increase if high collector count causes OOM |

---

## What Gets Deployed

| Component | Namespace | Type | Purpose | Conditional |
|-----------|-----------|------|---------|-------------|
| Prometheus | `monitoring` | Deployment + Service (NodePort) | Scrapes K8s metrics, federates to external Prometheus | Always |
| AlertManager | `monitoring` | Deployment + Service | Routes alerts to email (P1/P2/P3 priorities) | `alertmanager.enabled: true` |
| kube-state-metrics | `monitoring` | Deployment + Service | Exports cluster state as Prometheus metrics | Always |
| metrics-server | `kube-system` | Deployment + Service + APIService | Enables `kubectl top` and HPA autoscaling | Always |
| Alert Rules | `monitoring` | ConfigMap | K8s-specific alert rules (pods, nodes, PVCs, deployments) | `alert_rules.enabled: true` |
| Node Exporter | `monitoring` | DaemonSet + Service (headless) | Host-level OS metrics (CPU, memory, disk, network) | `node_exporter.enabled: true` |

---

## Metrics Collected

| Source | Metrics | Job Name | Conditional |
|--------|---------|----------|-------------|
| **API Server** | Request latency, etcd health, admission webhooks | `kubernetes-apiservers` | Always |
| **Kubelet** | Pod lifecycle, volume operations, runtime stats | `kubernetes-nodes` | Always |
| **cAdvisor** | Container CPU, memory, network I/O, filesystem | `kubernetes-cadvisor` | Always |
| **kube-state-metrics** | Deployment replicas, pod status, PVC capacity, node conditions | `kube-state-metrics` | Always |
| **Annotated pods** | Any pod with `prometheus.io/scrape: "true"` | `kubernetes-pods` | Always |
| **Annotated services** | Any service with `prometheus.io/scrape: "true"` | `kubernetes-service-endpoints` | Always |
| **Node Exporter** | Host CPU, memory, disk, network, filesystem, systemd, processes | `node-exporter` | `node_exporter.enabled: true` |

### Node Exporter Collectors (when enabled)

Matches the on-prem node-exporter role collectors exactly (except `textfile` which requires host-level directories):

cpu, diskstats, filesystem, loadavg, meminfo, filefd, netdev, netclass, stat, netstat, systemd, uname, vmstat, time, mdadm, tcpstat, hwmon, arp, mountstats, ethtool, sysctl, bcache, btrfs, conntrack, cpufreq, edac, entropy, nfs, nfsd, os, selinux, sockstat, softnet, thermal_zone, interrupts, processes, pressure

**Not included:** `textfile` (requires a host directory for custom metrics; not applicable in a container context)

---

## Task Execution Flow

```
main.yaml
├── validate.yml    — Check versions defined, kubectl available, NodePort valid
├── install.yml     — Create namespace, apply RBAC, ConfigMap, deployments
│   ├── Prometheus (RBAC, ConfigMap, Deployment)
│   ├── Alert Rules ConfigMap (when alert_rules.enabled)
│   ├── kube-state-metrics
│   ├── metrics-server
│   ├── AlertManager (when alertmanager.enabled)
│   └── Node Exporter DaemonSet (when node_exporter.enabled)
└── verify.yml      — Wait for all pods Running, test kubectl top, status summary
```

---

## Post-Deployment Verification

```bash
# 1. Check pods
kubectl get pods -n monitoring
kubectl get pods -n kube-system -l k8s-app=metrics-server

# 2. Prometheus UI
curl http://<node-ip>:<nodeport>/api/v1/targets | python3 -m json.tool | head -30

# 3. kubectl top (needs ~60s after metrics-server starts)
kubectl top nodes
kubectl top pods -A

# 4. Check federation endpoint (for external Prometheus)
curl http://<node-ip>:<nodeport>/federate?match[]={job=~".+"}

# 5. Node Exporter (when enabled)
kubectl get ds node-exporter -n monitoring
curl http://<node-ip>:9100/metrics | head -20
# Verify scrape target in Prometheus
curl -s http://<node-ip>:<nodeport>/api/v1/targets | grep node-exporter
```

---

## Alert Rules (Default)

The role deploys these K8s-specific alert rules when `alert_rules.enabled: true`:

| Alert | Priority | Trigger |
|-------|----------|---------|
| PodCrashLooping | P1 | Pod restarting repeatedly (5m) |
| ContainerOOMKilled | P1 | Container terminated by OOM |
| NodeNotReady | P1 | Node not ready for 5m |
| PodNotReady | P2 | Pod not ready for 10m |
| NodeHighMemoryUsage | P2 | Memory >90% for 10m |
| NodeHighCPUUsage | P2 | CPU >90% for 10m |
| PVCAlmostFull | P2 | PVC >85% full for 5m |
| PVCCriticallyFull | P1 | PVC >95% full for 2m |
| DeploymentReplicasMismatch | P2 | Desired != available for 10m |
| StatefulSetReplicasMismatch | P2 | Desired != ready for 10m |
| DaemonSetNotFullyScheduled | P3 | DaemonSet pods not ready for 10m |

---

## Upgrade Process

1. Update versions in `versions.yml`:
   ```yaml
   version:
     kubernetes:
       monitoring:
         prometheus: "v3.6.0"
         kube_state_metrics: "v2.20.0"
         metrics_server: "v0.8.2"
         alertmanager: "v0.34.0"
         node_exporter: "v1.10.0"   # only needed if node_exporter.enabled
   ```
2. Re-run the playbook — `kubectl apply` updates the deployments with new images
3. Verify pods restart with new versions: `kubectl get pods -n monitoring`

---

## Troubleshooting

### Prometheus not scraping targets
```bash
# Check targets in Prometheus UI
curl http://<node-ip>:<nodeport>/api/v1/targets | grep -i "down"

# Check RBAC
kubectl auth can-i list pods --as=system:serviceaccount:monitoring:prometheus
```

### kubectl top shows "Metrics not available"
```bash
# metrics-server needs ~60s to collect first metrics
kubectl get pods -n kube-system -l k8s-app=metrics-server
kubectl logs -n kube-system deploy/metrics-server --tail=20

# Common: kubelet certificate issues — metrics-server uses --kubelet-insecure-tls
```

### Prometheus OOMKilled
```bash
# Increase memory limit in config
config_k8s:
  monitoring:
    prometheus_resources:
      limits_memory: "8Gi"
```

---

## Security Notes

- Prometheus and KSM run as non-root (UID 65534/nobody)
- metrics-server runs as UID 1000 with read-only root filesystem
- Node Exporter runs with `hostNetwork: true` and `hostPID: true` (required for real host metrics), read-only root filesystem, no privilege escalation
- Node Exporter uses `tolerations: [operator: Exists]` to schedule on all nodes (including tainted masters)
- RBAC follows least-privilege (only read access to cluster resources)
- `--kubelet-insecure-tls` is used for metrics-server (kubelet uses self-signed certs)
- Prometheus admin API enabled for lifecycle management (reload config)

---

## File Structure

```
roles/kubernetes/operations/monitoring/
├── defaults/main.yml
├── tasks/
│   ├── main.yaml          # Orchestrator
│   ├── validate.yml       # Pre-flight checks
│   ├── install.yml        # Deploy all components (conditional)
│   └── verify.yml         # Readiness checks
├── templates/
│   ├── prometheus-rbac.yaml.j2             # ServiceAccount + ClusterRole
│   ├── prometheus-config-map.yaml.j2       # Scrape config + alertmanager target + node-exporter job
│   ├── prometheus-deployment.yaml.j2       # Deployment + PVC + Service
│   ├── kube-state-metrics.yaml.j2          # Full KSM stack
│   ├── metrics-server.yaml.j2             # Full metrics-server stack
│   ├── alertmanager-config.yaml.j2         # AlertManager routing + email config
│   ├── alertmanager-deployment.yaml.j2     # AlertManager Deployment + Service
│   ├── alert-rules.yaml.j2                # K8s alert rules (pods, nodes, PVCs)
│   └── node-exporter.yaml.j2              # Node Exporter DaemonSet + headless Service
└── README.md
```

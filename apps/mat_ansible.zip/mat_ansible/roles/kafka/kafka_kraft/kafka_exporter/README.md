# Kafka Exporter Sub-Role

Installs and configures [kafka_exporter](https://github.com/danielqsj/kafka_exporter) — a Prometheus exporter for Apache Kafka that exposes consumer group lag, topic offsets, and broker metadata as metrics. Deployed on Kafka broker hosts with Prometheus scraping via HAProxy load-balancing.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **kafka_exporter** | https://github.com/danielqsj/kafka_exporter/releases | Check `version.kafka_kraft.kafka_exporter` in `versions.yml` |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kafka broker running** | Must be accessible on plaintext port | `telnet localhost <broker_port>` |
| **Base directory** | Must exist (e.g., `/apps`) | `ls -la /apps` |
| **Proxy** | For GitHub binary download | `all_secrets.yml` |

---

## How to Run

```bash
# Deploy to all Kafka broker hosts
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kafka_exporter.yaml \
  --vault-password-file .vault

# Deploy to specific host group
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/kafka_exporter.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=kafka_kraft_ssl"
```

### Playbook Example

```yaml
- hosts: "{{ target_host | default('kafka_kraft') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  roles:
    - { role: roles/kafka_kraft/kafka_exporter }
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kafka_kraft.kafka_exporter` | `1.7.0` | Binary version |
| `paths.yml` | `paths.kafka_exporter.base_dir` | `/apps` | Install directory (must exist) |
| `networks.yml` | `ports.kafka_kraft.exporter` | `61001` | Metrics HTTP port |
| `networks.yml` | `ports.kafka_kraft.broker` | `61000` | Kafka broker plaintext port (exporter connects here) |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.kafka_kraft.user` | `kafka` | Service user | Shared with Kafka broker |
| `config.kafka_kraft.group` | `kafka` | Service group | Shared with Kafka broker |
| `config.kafka_kraft.kafka_exporter_arch` | `linux-amd64` | Binary architecture | Change for ARM: `linux-arm64` |
| `config.kafka_kraft.kafka_exporter_memory_limit` | `256M` | Systemd `MemoryMax` | **Increase:** If many consumer groups/topics (monitoring >500 topics) |
| `config.kafka_kraft.kafka_exporter_nofile_limit` | `1024` | Systemd `LimitNOFILE` | Rarely needs change |
| `config.kafka_kraft.kafka_exporter_download_timeout` | `60` | Seconds for download | **Increase:** On slow proxy connections |

---

## Metrics Exposed

| Metric | Description | Alert Use |
|--------|-------------|-----------|
| `kafka_consumergroup_current_offset` | Current committed offset per group/topic/partition | — |
| `kafka_consumergroup_lag` | **Consumer lag** — difference between log end and committed offset | ⚠️ Primary alerting metric |
| `kafka_consumergroup_lag_seconds` | Estimated lag in seconds | Time-based SLA alerting |
| `kafka_topic_partition_current_offset` | Latest offset per topic/partition | — |
| `kafka_topic_partitions` | Number of partitions per topic | Capacity monitoring |
| `kafka_topic_partition_replicas` | Replica count per partition | — |
| `kafka_topic_partition_in_sync_replica` | ISR count per partition | ⚠️ ISR shrink alerting |
| `kafka_topic_partition_under_replicated_partition` | Under-replicated partitions (1=problem) | ⚠️ Critical alert |
| `kafka_brokers` | Number of brokers in cluster | ⚠️ Broker down alerting |

### Example Prometheus Alert Rules

```yaml
# Consumer lag too high
- alert: KafkaConsumerLagHigh
  expr: kafka_consumergroup_lag > 10000
  for: 5m
  labels:
    severity: P2

# Under-replicated partitions
- alert: KafkaUnderReplicatedPartitions
  expr: sum(kafka_topic_partition_under_replicated_partition) > 0
  for: 5m
  labels:
    severity: P1
```

---

## What Gets Installed

```
/apps/
├── kafka_exporter -> kafka_exporter-1.7.0.linux-amd64/    # symlink (current version)
├── kafka_exporter-1.7.0.linux-amd64/                       # extracted binary
│   └── kafka_exporter                                      # single Go binary
└── kafka_exporter-1.7.0.linux-amd64.tar.gz                # downloaded tarball (cleaned on upgrade)

/etc/systemd/system/kafka-exporter.service                  # Systemd unit (After=kafka.service)
```

---

## Task Execution Flow

```
main.yml
├── validate.yml         # Check: version defined, port valid, base_dir exists
├── create_user.yml      # Ensure kafka user/group exists (shared with broker)
├── pre_install.yml      # Version check from symlink → set ke_installed, ke_current_version,
│                        #   ke_upgrade_needed → stop service if upgrading
├── install.yml          # Download from GitHub → extract → set permissions → create symlink
├── cleanup.yml          # Remove old version directory + tarball (only if version differs)
├── service.yml          # Deploy systemd unit → daemon_reload → enable + start → conditional restart
└── verify.yml           # Service active + port listening + /metrics endpoint HTTP 200
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status kafka-exporter

# 2. Port listening
ss -tlnp | grep <exporter_port>

# 3. Metrics endpoint
curl -s http://localhost:<port>/metrics | head -20

# 4. Consumer lag for all groups
curl -s http://localhost:<port>/metrics | grep kafka_consumergroup_lag | head -10

# 5. Broker count (should match cluster size)
curl -s http://localhost:<port>/metrics | grep kafka_brokers

# 6. Under-replicated partitions (should be 0)
curl -s http://localhost:<port>/metrics | grep under_replicated
```

---

## Upgrade Process

1. Update `version.kafka_kraft.kafka_exporter` in `versions.yml`
2. Re-run the playbook:
   - Pre-install detects version mismatch via symlink target
   - Stops current service
   - Downloads new version from GitHub
   - Extracts and updates symlink
   - Cleans up old version directory and tarball
   - Restarts service
3. Verify: `curl http://localhost:<port>/metrics` returns data

**Zero-downtime note:** Since kafka_exporter is a monitoring tool (not in the data path), brief restarts during upgrade are acceptable. Prometheus will simply miss one scrape interval.

---

## Troubleshooting

### Checking Logs

Kafka Exporter does **not** write log files — all output goes to systemd journal:

```bash
# Recent logs (last 50 lines)
journalctl -u kafka-exporter --no-pager -n 50

# Follow live
journalctl -u kafka-exporter -f

# Errors only
journalctl -u kafka-exporter -p err

# Since last boot
journalctl -u kafka-exporter -b

# Specific time range
journalctl -u kafka-exporter --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Exporter won't start
```bash
journalctl -u kafka-exporter --no-pager -n 30
# Common: Kafka broker not reachable, port conflict, binary permissions
```

### No metrics / empty response
```bash
# Check if Kafka broker is reachable
telnet localhost <broker_port>

# Check exporter connects successfully
journalctl -u kafka-exporter --no-pager | grep -i "error\|fail\|connect"
# Common: broker SSL-only (exporter connects plaintext), wrong port
```

### High memory usage
```bash
# Check number of consumer groups/topics being scraped
curl -s http://localhost:<port>/metrics | grep -c kafka_consumergroup_lag
# If >10000 series, consider increasing memory_limit
```

### Metrics stale / not updating
```bash
# Restart the exporter (forces reconnect to broker)
systemctl restart kafka-exporter

# Check if broker is healthy
/apps/kafka/bin/kafka-broker-api-versions --bootstrap-server localhost:<broker_port>
```

### Version symlink extraction issue
```bash
# If pre_install fails to detect version correctly:
ls -la /apps/kafka_exporter   # should be symlink
readlink /apps/kafka_exporter  # shows target directory
```

---

## Systemd Service Features

| Feature | Value | Purpose |
|---------|-------|---------|
| `After` | `kafka.service` | Start after Kafka broker |
| `MemoryMax` | Configurable (256M) | Hard memory cap |
| `LimitNOFILE` | Configurable (1024) | File descriptor limit |
| `RestartSec` | `15s` | Delay before restart on failure |
| `Restart` | `on-failure` | Auto-restart on crash |
| Telemetry path | `/metrics` | Standard Prometheus endpoint |
| Listen address | `:{{ port }}` | Binds all interfaces |

---

## File Structure

```
roles/kafka_kraft/kafka_exporter/
├── defaults/main.yml                       # All variables (Core → User → Runtime → Limits → Network/Proxy)
├── handlers/main.yml                       # restart kafka-exporter (daemon_reload + restart)
├── tasks/
│   ├── main.yml                            # Orchestrator
│   ├── validate.yml                        # Pre-flight checks (version, port, base_dir)
│   ├── create_user.yml                     # Ensure kafka user/group exist
│   ├── pre_install.yml                     # Version detection from symlink + stop if upgrade
│   ├── install.yml                         # Download + extract + permissions + symlink
│   ├── cleanup.yml                         # Remove old version directory + tarball
│   ├── service.yml                         # Systemd deploy + daemon_reload + enable + start + restart
│   └── verify.yml                          # Service + port + /metrics HTTP 200 check
├── templates/
│   └── kafka-exporter.service.j2           # Systemd unit (connects to localhost:<broker_port>)
└── README.md                               # This file
```

---

### Service Account Access

The `kafka` user (shared with broker) is created with `/sbin/nologin` shell for security. To switch to this user from root:

```bash
# Get an interactive shell as kafka
su -s /bin/bash kafka

# Run a single command as kafka
su -s /bin/bash -c "whoami" kafka
```

---

## Security Notes

- Runs as `kafka` user (shared with broker — no separate service account)
- Connects only to `localhost:<broker_port>` — no external network access needed
- Metrics exposed without authentication (standard for Prometheus exporters)
- Rely on network-level access control (firewall/HAProxy) for metrics scraping
- `MemoryMax` prevents runaway memory from excessive metric cardinality
- Binary downloaded over HTTPS from GitHub (cert validation disabled for proxy compatibility)
- Single static Go binary — no runtime dependencies

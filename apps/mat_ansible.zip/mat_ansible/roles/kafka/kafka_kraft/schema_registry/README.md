# Schema Registry Sub-Role

Configures and manages Confluent Schema Registry as a systemd service on top of an existing Kafka KRaft cluster. Uses the binary already installed by the `kafka-broker` role — no separate download needed. Supports both plaintext and SSL connections to Kafka brokers.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Schema Registry** | https://docs.confluent.io/platform/current/schema-registry/index.html | Bundled with Confluent Community (follows `version.kafka_kraft.broker`) |
| **JMX Prometheus Agent** | https://github.com/prometheus/jmx_exporter/releases | Check `version.kafka_kraft.jmx_agent` (optional) |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **Kafka broker role** | Must be deployed first (provides the binary) | `ls /apps/kafka/bin/schema-registry-start` |
| **Kafka cluster running** | Brokers must be active and accepting connections | `/apps/kafka/bin/kafka-topics --bootstrap-server localhost:61000 --list` |
| **config.schema_registry.enabled** | Must be `true` in `app_configs.yml` | Check `app_configs.yml` |
| **SSL certs (if SSL)** | Deployed by kafka-broker role to `/apps/kafka/ssl/` | `ls -la /apps/kafka/ssl/` |

---

## How to Run

```bash
# Deploy to schema_registry hosts
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/schema_registry.yaml \
  --vault-password-file .vault
```

### Playbook Example

```yaml
- hosts: "{{ target_host | default('schema_registry') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
    sr_kafka_group_name: "{{ kafka_host_group_name | default('kafka_kraft') }}"
  roles:
    - { role: roles/kafka_kraft/schema_registry }
```

### Hosts File Example

```ini
[schema_registry]
blp20919878  ansible_host=10.6.121.153
blp20919880  ansible_host=10.6.121.155
blp20919887  ansible_host=10.6.121.157

# Schema Registry typically runs on a subset of Kafka broker nodes
# or on the same nodes that run kafka_kraft_ssl (for SSL clusters)
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `app_configs.yml` | `config.schema_registry.enabled` | `true` | Must be `true` or role skips |
| `networks.yml` | `ports.schema_registry.service` | `61033` | Schema Registry listener port |
| `paths.yml` | `paths.kafka_kraft.base_dir` | `/apps` | Shared with Kafka broker |
| `networks.yml` | `ports.kafka_kraft.broker` | `61000` | Kafka plaintext port (for bootstrap) |

### Optional (with defaults)

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `config.schema_registry.compatibility_level` | `BACKWARD` | Schema evolution rule | `BACKWARD` = new can read old. `FORWARD` = old can read new. `FULL` = both. `NONE` = no checks. |
| `config.schema_registry.replication_factor` | `1` | `_schemas` topic replicas | **Increase:** for HA. Must be ≤ number of brokers. |
| `config.schema_registry.heap_size` | `512M` | Min JVM heap (`-Xms`) | |
| `config.schema_registry.max_heap_size` | `1G` | Max JVM heap (`-Xmx`) | Must be ≤ `memory_limit`. |
| `config.schema_registry.memory_limit` | `2G` | Systemd `MemoryMax` | Must be > `max_heap_size`. |
| `config.schema_registry.nofile_limit` | `65536` | Systemd `LimitNOFILE` | Rarely needs change. |
| `config.schema_registry.listen_address` | `0.0.0.0` | Bind address for listener | |
| `config.schema_registry.ssl_config.enabled` | `false` | Connect to Kafka via SSL | Reuses keystore/truststore from `/apps/kafka/ssl/` (deployed by kafka-broker role). |
| `config.schema_registry.ssl_config.keystore_password` | `''` | JKS keystore password | Required when SSL enabled. |
| `config.schema_registry.ssl_config.truststore_password` | `''` | JKS truststore password | Required when SSL enabled. |
| `config.schema_registry.ssl_config.key_password` | `''` | Private key password | Required when SSL enabled. |
| `ports.schema_registry.jmx` | `''` (disabled) | JMX Prometheus agent port | Set a port to enable JMX metrics. |
| `ports.kafka_kraft.ssl_broker` | `61008` | Kafka SSL port | Used when `ssl_config.enabled` is true. |

### User/Group (shared with Kafka broker)

| Variable | Default | Description |
|----------|---------|-------------|
| `config.kafka_kraft.user` | `kafka` | Service user |
| `config.kafka_kraft.group` | `kafka` | Service group |

---

## SSL Configuration

Schema Registry **reuses** the SSL certificates deployed by the kafka-broker role. No additional SSL files need to be placed — just enable SSL and provide passwords:

```yaml
config:
  schema_registry:
    enabled: true
    ssl_config:
      enabled: true
      keystore_password: "{{ kafka_ssl_keystore_password_vault }}"
      truststore_password: "{{ kafka_ssl_truststore_password_vault }}"
      key_password: "{{ kafka_ssl_key_password_vault }}"
```

The validate step checks that `/apps/kafka/ssl/kafka.keystore.jks` and `/apps/kafka/ssl/kafka.truststore.jks` exist on the target host before proceeding.

---

## What Gets Deployed

```
/apps/kafka/
├── etc/schema-registry/
│   └── schema-registry.properties         # Templated config
├── logs/schema-registry/                   # Application logs (created by role)
└── bin/
    ├── schema-registry-start              # Startup script (from Confluent package)
    └── schema-registry-stop               # Stop script

/etc/systemd/system/schema-registry.service  # Systemd unit (After=kafka.service)
/etc/logrotate.d/schema-registry             # Daily rotation, 7 days
```

**Note:** No download or extraction happens — the binary comes from the Confluent Community package deployed by `kafka-broker`.

---

## Task Execution Flow

```
main.yml
├── validate.yml         # Check: enabled flag, port valid, binary exists,
│                        #   kafka brokers in host group, memory_limit > max_heap_size,
│                        #   SSL certs exist on target (if SSL), SSL passwords defined
├── config.yml           # Create log dir + template properties + systemd unit + logrotate
├── service.yml          # Reload daemon + enable + start + conditional restart
└── verify.yml           # Service active + port listening + API /subjects responding
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status schema-registry

# 2. Port listening
ss -tlnp | grep 61033

# 3. List subjects (should return [] on fresh install)
curl -s http://localhost:61033/subjects

# 4. Check compatibility config
curl -s http://localhost:61033/config
# Expected: {"compatibilityLevel":"BACKWARD"}

# 5. Register a test schema
curl -X POST -H "Content-Type: application/vnd.schemaregistry.v1+json" \
  --data '{"schema": "{\"type\": \"string\"}"}' \
  http://localhost:61033/subjects/test-topic-value/versions

# 6. Check schema (after registering)
curl -s http://localhost:61033/subjects/test-topic-value/versions/latest

# 7. JMX metrics (only if sr_jmx_port is set)
curl -s http://localhost:<jmx_port>/metrics | head -10
```

---

## Upgrade Process

Schema Registry follows the Kafka broker version since it's bundled in the Confluent Community package:

1. Upgrade Kafka brokers first (update `version.kafka_kraft.broker` and run kafka-broker role)
2. Re-run the schema_registry playbook — it will detect the new binary via the updated symlink
3. Config is re-templated and service restarted if anything changed

No separate version management or download needed.

---

## Troubleshooting

### Checking Logs

Schema Registry writes logs to **both** a log directory and systemd journal:

```bash
# Log files
ls -la /apps/kafka/logs/schema-registry/
tail -f /apps/kafka/logs/schema-registry/*.log

# Systemd journal — recent logs (last 50 lines)
journalctl -u schema-registry --no-pager -n 50

# Follow live
journalctl -u schema-registry -f

# Errors only
journalctl -u schema-registry -p err

# Since last boot
journalctl -u schema-registry -b

# Specific time range
journalctl -u schema-registry --since "2024-01-15 10:00" --until "2024-01-15 11:00"
```

### Schema Registry won't start
```bash
journalctl -u schema-registry --no-pager -n 50
# Common: Kafka brokers not reachable, SSL cert issues, port conflict
```

### Cannot connect to Kafka brokers
```bash
# Check if brokers are reachable from Schema Registry host
telnet <broker_ip> 61000  # plaintext
telnet <broker_ip> 61008  # SSL

# Verify broker list in properties
cat /apps/kafka/etc/schema-registry/schema-registry.properties | grep bootstrap
```

### SSL errors
```bash
# Verify certs exist (deployed by kafka-broker role)
ls -la /apps/kafka/ssl/
# Expected: kafka.keystore.jks, kafka.truststore.jks with mode 0600

# Check SSL config in properties
cat /apps/kafka/etc/schema-registry/schema-registry.properties | grep ssl
```

### _schemas topic issues
```bash
# Check topic exists and is healthy
/apps/kafka/bin/kafka-topics --bootstrap-server localhost:61000 --describe --topic _schemas
# Fix: if corrupt, delete topic (lose all schemas!) and restart SR to recreate
```

---

## Systemd Service Features

| Feature | Value | Purpose |
|---------|-------|---------|
| `After` | `kafka.service` | Start after Kafka broker |
| `MemoryMax` | Configurable (2G) | Hard memory cap |
| `LimitNOFILE` | Configurable (65536) | File descriptor limit |
| `RestartSec` | `15s` | Delay before restart on failure |
| `Restart` | `on-failure` | Auto-restart on crash |
| JMX Agent | Optional (port-based) | Prometheus metrics exposure |

---

## File Structure

```
roles/kafka_kraft/schema_registry/
├── defaults/main.yml                         # All variables (Core → User → Runtime → Limits → SSL → JMX → Network)
├── tasks/
│   ├── main.yml                              # Orchestrator
│   ├── validate.yml                          # Pre-flight checks (9 validations)
│   ├── config.yml                            # Properties + systemd + logrotate + log dir
│   ├── service.yml                           # Daemon reload + enable + start + conditional restart
│   └── verify.yml                            # Service + port + API health check
├── templates/
│   ├── schema-registry.properties.j2        # Kafka bootstrap (auto-generated from host group), SSL conditionals
│   ├── schema-registry.service.j2           # Systemd unit (JVM heap, optional JMX, MemoryMax)
│   └── schema-registry-logrotate.j2         # Daily rotation, 7 days, compress
└── README.md                                 # This file
```

---

## Security Notes

- Runs as `kafka` user (shared with broker — no additional user created)
- Config file restricted to `0640` (owner + group read)
- SSL keystore/truststore reused from broker with original `0600` permissions
- SSL passwords kept in vault-encrypted `all_secrets.yml`
- No authentication on the REST API by default (rely on network-level access control)
- `MemoryMax` prevents runaway memory usage
- Log directory created with `0755` (logs are not sensitive)

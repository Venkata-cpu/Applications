# Kafka KRaft Broker Role

Installs and configures Apache Kafka in KRaft mode (no ZooKeeper) using the Confluent Community distribution. Supports plaintext and SSL clusters via host-group-based configuration, auto-generates controller quorum from inventory, and uses persistent data directories that survive upgrades. Includes automatic data migration from old in-symlink layout to the new persistent directory layout.

## Latest Version

| Component | Check Latest | Current |
|-----------|-------------|---------|
| **Confluent Community (Kafka)** | https://www.confluent.io/previous-versions/ | 8.3.0 |
| **JMX Prometheus Agent** | https://github.com/prometheus/jmx_exporter/releases | 0.20.0 |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Java** | Java 17+ must be installed | `java -version` |
| **Base directory** | Must already exist (`/apps`) | `ls -la /apps` |
| **Network** | Broker port + controller port (9093) reachable between all nodes | `ss -tlnp \| grep 61000` |
| **Proxy** | For Confluent package download from packages.confluent.io | Verify `http_proxy` / `https_proxy` set |
| **Host vars** | Each host MUST have `nodeRole` and `nodeId` in hosts file | See hosts example below |
| **config_kafka.yml** | Must have a section matching the host group name | See config example below |
| **Vault secrets** | SSL passwords if SSL enabled | `kafka_ssl_keystore_password`, `kafka_ssl_key_password`, `kafka_ssl_truststore_password` |

---

## How to Run

```bash
# Plaintext cluster
ansible-playbook -f 4 --extra-vars="target_host=kafka_kraft" -D \
  --vault-password-file .vault \
  -e "ansible_user=$ANSIBLE_USER" \
  -i inventories/mat_fixed_network/prod/hosts \
  playbook/kafka/kafka_kraft.yaml

# SSL cluster
ansible-playbook -f 4 --extra-vars="target_host=kafka_kraft_ssl" -D \
  --vault-password-file .vault \
  -e "ansible_user=$ANSIBLE_USER" \
  -i inventories/mat_fixed_network/prod/hosts \
  playbook/kafka/kafka_kraft.yaml
```

### CI/CD (GitLab)
- **APP_INSTANCE:** `Fixed Network`
- **APP_GROUP:** `kafka`
- **APP:** `kafka_kraft`
- **TARGET_HOST:** `kafka_kraft` or `kafka_kraft_ssl`

### Hosts File Example

```ini
[kafka_kraft]
blp20919943 ansible_host=10.6.122.107 nodeRole=broker,controller nodeId=106122107
blp20919944 ansible_host=10.6.122.108 nodeRole=broker,controller nodeId=106122108
blp20919952 ansible_host=10.6.122.111 nodeRole=broker,controller nodeId=106122111

[kafka_kraft_ssl]
blp20919942 ansible_host=10.6.122.77  nodeRole=broker,controller nodeId=10612277
blp20919953 ansible_host=10.6.122.112 nodeRole=broker,controller nodeId=106122112
```

- `nodeRole`: Comma-separated roles (`broker`, `controller`, or `broker,controller`)
- `nodeId`: Unique numeric ID per node (typically derived from IP)
- Controller count MUST be odd (1, 3, or 5) for Raft quorum

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.kafka_kraft.broker` | `8.3.0` | Confluent Community version |
| `versions.yml` | `version.kafka_kraft.jmx_agent` | `0.20.0` | JMX Prometheus agent version |
| `paths.yml` | `paths.kafka_kraft.base_dir` | `/apps` | Install base directory |
| `networks.yml` | `ports.kafka_kraft.broker` | `61000` | Broker plaintext port |
| `networks.yml` | `ports.kafka_kraft.jmx_exporter` | `61002` | JMX metrics port |
| `config_kafka.yml` | `config_kafka[host_group].clusterId` | `matfn-xxx` | Unique cluster ID |
| `hosts` | `nodeRole` (per host) | `broker,controller` | KRaft process roles |
| `hosts` | `nodeId` (per host) | `106122107` | Unique numeric node ID |

### Config (`config_kafka.yml`) — Per Host Group

All config is read from `config_kafka[kafka_host_group].*`. Each cluster (host group) has its own self-contained section.

| Variable | Default | Description |
|----------|---------|-------------|
| `clusterId` | (required) | Unique cluster ID (never change after init) |
| `controller_port` | `9093` | Controller listener port |
| `user` / `group` | `kafka` | Service account |
| `default_replication_factor` | `3` | Default topic RF |
| `default_num_partitions` | `3` | Default topic partitions |
| `min_insync_replicas` | `2` | Min replicas for ack=all |
| `log_retention_hrs` | `6` | Data retention hours |
| `log_segment_bytes` | `1073741824` | Segment size (1GB) |
| `log_roll_hours` | `6` | Hours before new segment |
| `log_retention_check_interval_ms` | `300000` | Retention check interval |
| `config_memory_gb` | `4` | JVM heap (Xms=Xmx) in GB |
| `memory_limit` | `6G` | Systemd MemoryMax |
| `nofile_limit` | `65536` | Max file descriptors |
| `cpu_affinity` | `0-2` | CPU core pinning |
| `num_network_threads` | `3` | Network handler threads |
| `num_io_threads` | `8` | Disk I/O threads |
| `num_replica_fetchers` | `2` | Replica fetch threads |
| `num_recovery_threads` | `2` | Log recovery threads |
| `socket_send_buffer` | `102400` | Socket send buffer |
| `socket_receive_buffer` | `102400` | Socket receive buffer |
| `socket_request_max_bytes` | `104857600` | Max request size |
| `message_max_bytes` | `10485760` | Max message size |
| `fetch_max_bytes` | `52428800` | Max consumer fetch |
| `replica_fetch_max_bytes` | `10485760` | Max replica fetch |
| `replica_lag_time_max_ms` | `30000` | ISR lag tolerance |
| `replica_socket_timeout_ms` | `60000` | Replica socket timeout |
| `group_rebalance_delay_ms` | `3000` | Rebalance delay |
| `transaction_state_log_replication` | `1` | Transaction log RF |
| `transaction_state_log_min_isr` | `1` | Transaction log min ISR |
| `quorum_fetch_timeout_ms` | `5000` | Controller fetch timeout |
| `quorum_retry_backoff_ms` | `500` | Quorum retry backoff |
| `quorum_election_timeout_ms` | `5000` | Election timeout |
| `delete_topic_enable` | `true` | Allow topic deletion |
| `auto_create_topics` | `false` | Auto-create on produce |
| `unclean_leader_election` | `false` | Out-of-sync leader allowed |
| `log_message_timestamp_type` | `CreateTime` | Timestamp type |
| `offsets_topic_replication_factor` | `3` | __consumer_offsets RF |
| `reserved_broker_max_id` | `2147483647` | Max broker ID |
| `controller_socket_timeout_ms` | `30000` | Controller socket timeout |
| `download_timeout` | `300` | Download timeout (seconds) |
| `ssl.enabled` | `false` | Enable SSL listeners |
| `ssl.keystore_src` | `''` | Source path for keystore |
| `ssl.truststore_src` | `''` | Source path for truststore |
| `ssl.keystore_password` | `''` | Keystore password (vault) |
| `ssl.truststore_password` | `''` | Truststore password (vault) |
| `ssl.key_password` | `''` | Key password (vault) |

---

## What Gets Installed

```
/apps/
├── kafka -> confluent-8.3.0/             # symlink to current version
├── confluent-8.3.0/                      # extracted Confluent Community
│   ├── bin/                               # kafka-server-start, kafka-topics, etc.
│   ├── etc/kafka/
│   │   ├── server.properties             # main config (templated)
│   │   └── producer.properties           # CLI testing config (templated)
│   ├── jmx_agent/
│   │   └── jmx_prometheus_javaagent-0.20.0.jar
│   ├── kafka_metrics.yaml                # JMX exporter scrape config
│   ├── ssl/                               # (only when SSL enabled)
│   │   ├── kafka.keystore.jks
│   │   └── kafka.truststore.jks
│   └── logs/                              # Kafka application logs
├── kafka_data/                           # PERSISTENT — topic partition data
└── kafka_metadata/                       # PERSISTENT — KRaft raft metadata

/etc/systemd/system/kafka.service         # Systemd unit (priority tuned)
/etc/logrotate.d/kafka                    # Daily log rotation
```

---

## Task Execution Flow

```
main.yml
├── validate.yml         # Pre-flight: version, ports, cluster_id, nodeRole/nodeId,
│                        #   controllers odd, RF ≤ brokers, ISR < RF, message sizes, heap
├── create_user.yml      # kafka user/group (system, /sbin/nologin)
├── pre_verify.yml       # Verify prerequisites in place
├── pre_config.yml       # vm.swappiness=1, disable swap
├── pre_install.yml      # Version check via symlink + stop if upgrade
├── migrate_data.yml     # Move old kafka/data → kafka_data, kafka/metadata → kafka_metadata
├── install.yml          # Download + extract + symlink + persistent dirs + JMX agent
├── cleanup.yml          # Remove old version directory + tarball
├── config.yml           # server.properties + producer.properties + SSL + systemd + logrotate
├── initialise.yml       # kafka-storage format (ONLY if metadata dir empty)
├── service.yml          # Enable + start + conditional restart
└── verify.yml           # Service active check + quorum status
```

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status kafka

# 2. List topics
/apps/kafka/bin/kafka-topics --bootstrap-server localhost:61000 --list

# 3. Cluster quorum
/apps/kafka/bin/kafka-metadata quorum describe --status --bootstrap-server localhost:61000

# 4. Describe replication
/apps/kafka/bin/kafka-metadata quorum describe --replication --bootstrap-server localhost:61000

# 5. Under-replicated partitions (should be 0)
/apps/kafka/bin/kafka-topics --bootstrap-server localhost:61000 --describe --under-replicated-partitions

# 6. JMX metrics
curl -s http://localhost:61002/metrics | grep kafka_server | head -10
```

---

## Upgrade Process

1. Update `version.kafka_kraft.broker` in `versions.yml`
2. Run playbook — role detects version mismatch via symlink, stops broker, downloads new version, updates symlink, restarts
3. `kafka_data/` and `kafka_metadata/` are NEVER touched during upgrade
4. Old version directory and tarball cleaned up automatically

---

## Troubleshooting

### Checking Logs

```bash
# Application logs
tail -f /apps/kafka/logs/server.log

# Systemd journal
journalctl -u kafka --no-pager -n 50
journalctl -u kafka -f
journalctl -u kafka -p err
```

### Service Account Access

```bash
su -s /bin/bash kafka
su -s /bin/bash -c "/apps/kafka/bin/kafka-topics --bootstrap-server localhost:61000 --list" kafka
```

---

## Security Notes

- Runs as unprivileged `kafka` user (`/sbin/nologin`)
- Swap disabled (`vm.swappiness=1`, `swapoff -a`)
- SSL certificates stored with mode `0600`, directory `0700`
- `MemoryMax` enforces hard memory limit
- `unclean.leader.election.enable=false` — data integrity over availability
- `auto.create.topics.enable=false` — prevents accidental topics
- Config files mode `0640` (owner+group read)

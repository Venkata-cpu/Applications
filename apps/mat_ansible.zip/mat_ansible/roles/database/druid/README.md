# Apache Druid

Deploys Apache Druid as a clustered real-time analytics database using individual systemd services per daemon. Provides sub-second OLAP queries on streaming and batch data. Uses HDFS for deep storage, MySQL for metadata, and ZooKeeper for coordination.

---

## Latest Version

| Component | Version | Check Latest |
|-----------|---------|--------------|
| Apache Druid | 37.0.0 | [Apache Downloads](https://druid.apache.org/downloads/) |
| MySQL Connector/J | 9.2.0 | [Maven Central](https://central.sonatype.com/artifact/com.mysql/mysql-connector-j) |

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| Java 17+ | OpenJDK must be installed | `java -version` |
| Base directory | `/apps` must exist | `ls -la /apps` |
| ZooKeeper | Running ensemble | `echo ruok \| nc <zk_host> 2181` |
| HDFS | Running HA cluster (for deep storage) | `hdfs dfs -ls /` |
| MySQL | Running instance with Druid database | `mysql -h <host> -u druid -p -e "show databases"` |
| Inventory groups | Per-service host groups defined | Check `hosts` file |
| Inventory config | `config_database.druid` section | Check `group_vars/all/` |

---

## How to Run

```bash
# Deploy all Druid services
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/druid.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>"

# Deploy only historicals
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/druid.yaml \
  --vault-password-file .vault \
  -e "ansible_user=<user>" \
  --extra-vars="target_host=druid_historical"

# Via GitLab CI
APP_INSTANCE=<instance> ENV=<env> APP_GROUP=database APP=druid
```

---

## Host Groups

A node can be in **multiple groups** (e.g., test env: coordinator + overlord + broker + router on one node).

| Group | Service | Min Nodes |
|-------|---------|:---------:|
| `druid_coordinator` | Segment management, load rules | 1 |
| `druid_overlord` | Ingestion task management | 1 |
| `druid_broker` | Query routing and merging | 1 |
| `druid_router` | Web console, API gateway | 1 |
| `druid_historical` | Segment storage and queries | 1+ |
| `druid_middle_manager` | Ingestion task execution | 1+ |
| `druid` | Parent group (children: all above) | — |

### Host Vars (Historical tier support)

```ini
[druid_historical]
hot_node1  ansible_host=10.x.x.x druid_tier=hot druid_segment_cache_size=500g
cold_node1 ansible_host=10.x.x.x druid_tier=_default_tier druid_segment_cache_size=2t
```

### Host Vars (MiddleManager capacity)

```ini
[druid_middle_manager]
mm_node1 ansible_host=10.x.x.x druid_worker_capacity=10
mm_node2 ansible_host=10.x.x.x druid_worker_capacity=5
```

---

## Variable Reference

### Required Variables (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.druid` | `37.0.0` | Druid version |
| `paths.yml` | `paths.druid.base_dir` | `/apps` | Base install directory |
| `networks.yml` | `ports.druid.*` | Various | Service and metrics ports |
| `config_database.yml` | `config_database.druid.mysql.host` | `10.11.21.245` | MySQL metadata host |
| `config_database.yml` | `config_database.druid.hdfs.cluster_name` | `MartiniEERan` | HDFS nameservice |
| `all_secrets.yml` | `druid_mysql_password_vault` | (vault) | MySQL password |
| `all_secrets.yml` | `druid_admin_password_vault` | (vault) | Druid admin password |
| `all_secrets.yml` | `druid_internal_client_password_vault` | (vault) | Internal client password |

### Key Optional Variables (with defaults)

| Variable | Default | Description |
|----------|---------|-------------|
| `druid_coordinator_heap_min` / `_max` | `1g` / `2g` | Coordinator JVM heap |
| `druid_overlord_heap_min` / `_max` | `1g` / `2g` | Overlord JVM heap |
| `druid_broker_heap_min` / `_max` | `2g` / `4g` | Broker JVM heap |
| `druid_broker_direct_memory` | `4g` | Broker off-heap (must exceed processing formula) |
| `druid_router_heap_min` / `_max` | `512m` / `1g` | Router JVM heap |
| `druid_historical_heap_min` / `_max` | `2g` / `4g` | Historical JVM heap |
| `druid_historical_direct_memory` | `6g` | Historical off-heap |
| `druid_historical_segment_cache_size` | `100g` | Per-node segment cache (host var override) |
| `druid_historical_tier` | `_default_tier` | Tier name (host var override) |
| `druid_mm_worker_capacity` | `10` | Tasks per middlemanager (host var override) |
| `druid_mm_peon_heap` | `1g` | Peon JVM heap |
| `druid_mm_peon_direct_memory` | `2g` | Peon off-heap |
| `druid_query_timeout_ms` | `600000` | Query timeout (10 min) |
| `druid_mysql_connector_version` | `9.2.0` | MySQL JDBC driver version |
| `druid_prometheus_simpleclient_version` | `0.16.0` | Prometheus client library version |
| `druid_cacerts_path` | `/etc/pki/java/cacerts` | Java truststore path (for basic-security SSL) |
| `druid_housekeep_retention_days` | `30` | Days before old logs deleted |
| `druid_log_rotation_count` | `7` | Logrotate file count |
| `druid_auth_enabled` | `true` | Enable basic-security authentication |

### Direct Memory Formula

For services with processing buffers (Broker, Historical, MiddleManager peons):

```
DirectMemory >= (numMergeBuffers + numThreads + 1) × buffer_sizeBytes
```

---

## What Gets Installed

```
/apps/
├── apache-druid-37.0.0/               # Extracted distribution
│   ├── bin/                            # Scripts (run-druid)
│   ├── conf/druid/cluster/
│   │   ├── _common/                    # Shared config (Ansible-managed)
│   │   │   ├── common.runtime.properties
│   │   │   ├── core-site.xml
│   │   │   └── hdfs-site.xml
│   │   ├── master/coordinator/         # Coordinator config
│   │   ├── master/overlord/            # Overlord config
│   │   ├── query/broker/               # Broker config
│   │   ├── query/router/               # Router config
│   │   ├── data/historical/            # Historical config
│   │   └── data/middleManager/         # MiddleManager config
│   ├── extensions/                     # Core + contrib extensions
│   │   ├── mysql-metadata-storage/     # + MySQL Connector/J (downloaded)
│   │   └── prometheus-emitter/         # (downloaded from Maven Central)
│   ├── lib/                            # Java libraries
│   ├── log/                            # Request logs (non-persistent)
│   └── var/                            # Runtime data (non-persistent)
│       ├── tmp/                        # JVM temp directory
│       └── druid/
│           ├── processing/             # Query processing temp
│           └── indexing-logs/          # Ingestion task logs
├── druid -> apache-druid-37.0.0/       # Symlink (current version)
└── druid_data/                         # Persistent data — survives upgrades
    ├── segment-cache/                  # Historical segment files
    └── task/                           # MiddleManager in-progress tasks

/etc/systemd/system/druid-coordinator.service
/etc/systemd/system/druid-overlord.service
/etc/systemd/system/druid-broker.service
/etc/systemd/system/druid-router.service
/etc/systemd/system/druid-historical.service
/etc/systemd/system/druid-middlemanager.service
/etc/logrotate.d/druid
/apps/scripts/druid-housekeep.sh
```

---

## Task Execution Flow

```
main.yml
├── validate.yml        Check version, dirs, MySQL host, HDFS cluster name
├── create_user.yml     Create druid system user/group
├── pre_install.yml     Detect version, stop services if upgrading
├── migrate_data.yml    Stop legacy supervise, move segment-cache + task dir to persistent
├── install.yml         Download tarball, extract, symlink, MySQL connector, prometheus-emitter
├── cleanup.yml         Remove old version (no_log: true)
├── config.yml          Deploy configs, systemd units, logrotate, housekeep cron
├── service.yml         Remove legacy supervise, start individual services
└── verify.yml          Service active checks, port listening, status display
```

---

## Post-Deployment Verification

```bash
# Check all services
systemctl status druid-coordinator druid-overlord druid-broker druid-router druid-historical druid-middlemanager

# Druid web console (via router)
curl -s http://<router_ip>:<router_port>/status | python3 -m json.tool

# Check loaded datasources
curl -s http://<router_ip>:<router_port>/druid/coordinator/v1/datasources | python3 -m json.tool

# Check running tasks
curl -s http://<router_ip>:<router_port>/druid/indexer/v1/runningTasks | python3 -m json.tool

# Check metrics (Prometheus format)
curl -s http://<any_node>:<metrics_port>/metrics
```

---

## Upgrade Process

1. Update `version.druid` in `versions.yml`.
2. Run the playbook — it will:
   - Stop all services
   - Migrate segment-cache and task dirs to persistent locations (first upgrade only)
   - Download and extract new version
   - Update symlink
   - Download MySQL Connector/J and prometheus-emitter for new version
   - Clean up old version (no_log)
   - Apply config
   - Remove legacy supervise service
   - Start individual services
3. Verify via web console and `systemctl status`.

---

## Troubleshooting

### Checking Logs

```bash
# Journald (per service)
journalctl -u druid-coordinator --no-pager -n 50
journalctl -u druid-broker -f
journalctl -u druid-historical -p err

# Request logs
ls -lt /apps/druid/log/

# Indexing task logs (MiddleManager)
ls -lt /apps/druid/var/druid/indexing-logs/
```

### Common Issues

| Problem | Diagnostic | Solution |
|---------|-----------|----------|
| Service won't start | `journalctl -u druid-<service> -n 50` | Check JVM heap/direct memory, verify ZK/MySQL connectivity |
| No segments loading | Coordinator logs | Check HDFS connectivity, verify segment metadata in MySQL |
| Query timeout | Broker/Router logs | Increase `druid_query_timeout_ms`, check Historical health |
| OOM on Historical | `dmesg \| grep oom` | Increase `druid_historical_heap` and `direct_memory` |
| Extension not found | Startup logs | Verify extension in `loadList` and present in `extensions/` dir |
| MySQL connection refused | common.runtime.properties | Check host/port/user/password, verify MySQL is running |

### Service Account Access

```bash
su -s /bin/bash druid
su -s /bin/bash -c "/apps/druid/bin/run-java -classpath '/apps/druid/lib/*' org.apache.druid.cli.Main tools pull-deps --help" druid
```

---

## File Structure

```
roles/database/druid/
├── defaults/
│   └── main.yml
├── handlers/
│   └── main.yml
├── tasks/
│   ├── main.yml
│   ├── validate.yml
│   ├── create_user.yml
│   ├── pre_install.yml
│   ├── migrate_data.yml
│   ├── install.yml
│   ├── cleanup.yml
│   ├── config.yml
│   ├── service.yml
│   └── verify.yml
├── templates/
│   ├── common.runtime.properties.j2
│   ├── core-site.xml.j2
│   ├── hdfs-site.xml.j2
│   ├── logrotate.j2
│   ├── druid-housekeep.sh.j2
│   ├── coordinator/
│   │   ├── runtime.properties.j2
│   │   └── jvm.config.j2
│   ├── overlord/
│   │   ├── runtime.properties.j2
│   │   └── jvm.config.j2
│   ├── broker/
│   │   ├── runtime.properties.j2
│   │   └── jvm.config.j2
│   ├── router/
│   │   ├── runtime.properties.j2
│   │   └── jvm.config.j2
│   ├── historical/
│   │   ├── runtime.properties.j2
│   │   └── jvm.config.j2
│   ├── middlemanager/
│   │   ├── runtime.properties.j2
│   │   └── jvm.config.j2
│   └── systemd/
│       ├── druid-coordinator.service.j2
│       ├── druid-overlord.service.j2
│       ├── druid-broker.service.j2
│       ├── druid-router.service.j2
│       ├── druid-historical.service.j2
│       └── druid-middlemanager.service.j2
└── README.md
```

---

## Security Notes

- Druid runs as unprivileged system user (`druid`) with `/sbin/nologin` shell.
- `common.runtime.properties` is mode `0640` — contains MySQL password and auth credentials.
- Auth passwords sourced from Ansible vault (`druid_mysql_password_vault`, `druid_admin_password_vault`, `druid_internal_client_password_vault`).
- Basic metadata authentication enabled by default — all API access requires credentials.
- `simple-client-sslcontext` extension required for basic-security internal communication (provides SSL context pointing to Java's default cacerts truststore).
- Internal communication uses plaintext HTTP (`druid.enableTlsPort=false`) — SSL context is only needed to satisfy the Guice dependency injection.
- Download uses `validate_certs: false` due to corporate proxy MITM.
- MySQL Connector/J and Prometheus client JARs downloaded from Maven Central (trusted source).

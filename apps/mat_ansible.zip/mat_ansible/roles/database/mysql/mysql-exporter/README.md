# MySQL Exporter Role

Installs and configures [Prometheus mysqld_exporter](https://github.com/prometheus/mysqld_exporter) — exposes MySQL server metrics in Prometheus format. Collects InnoDB metrics, replication status, query performance, and table statistics.

---

## Latest Version

Check for updates: https://github.com/prometheus/mysqld_exporter/releases

Current deployed: `0.16.0`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (`/apps`) | `ls -la /apps` |
| **MySQL** | Running with exporter user created | `mysql -u exporter -p -e "SELECT 1"` |
| **Proxy** | For GitHub download | `all_secrets.yml` |
| **Vault** | `mysqld_exporter_user_password` | In `all_secrets.yml` |

### MySQL User Setup (pre-requisite)

Create a MySQL user for the exporter with minimal read-only privileges:

```sql
CREATE USER 'exporter'@'localhost' IDENTIFIED BY '<password>';
GRANT PROCESS, REPLICATION CLIENT, SELECT ON *.* TO 'exporter'@'localhost';
FLUSH PRIVILEGES;
```

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/mysql-exporter.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.mysql.exporter` | `0.16.0` | Exporter version |
| `networks.yml` | `ports.mysql.exporter` | `9104` | Metrics port |
| `networks.yml` | `ports.mysql.db` | `61010` | MySQL port to connect to |
| `all_secrets.yml` | `mysqld_exporter_user_password` | (vault) | MySQL exporter user password |

### Optional (from config_database.yml)

| Variable | Default | Description |
|----------|---------|-------------|
| `config_database.mysql_exporter.user` | `mysql-exporter` | Service user |
| `config_database.mysql_exporter.mysql_user` | `exporter` | MySQL DB username |
| `config_database.mysql_exporter.listen_address` | `0.0.0.0` | Bind address |
| `config_database.mysql_exporter.memory_limit` | `256M` | Systemd MemoryMax |
| `config_database.mysql_exporter.nofile_limit` | `1024` | Systemd LimitNOFILE |
| `config_database.mysql_exporter.collectors` | (see defaults) | List of `--collect.*` flags |
| `config_database.mysql_exporter.download_timeout` | `60` | Download timeout (seconds) |

---

## What Gets Installed

```
/apps/
├── mysqld_exporter -> mysqld_exporter-0.16.0.linux-amd64/   # symlink
├── mysqld_exporter-0.16.0.linux-amd64/                       # extracted
│   ├── mysqld_exporter                                        # binary
│   ├── LICENSE
│   └── NOTICE
└── mysqld_exporter-0.16.0.linux-amd64.tar.gz                # archive

/etc/systemd/system/mysqld_exporter.service                   # systemd unit
```

---

## Task Execution Flow

```
validate → create_user → pre_install → install → cleanup → service → verify
    │           │             │            │          │          │         │
    ├─ version  ├─ group      ├─ get ver   ├─ download├─ rm old  ├─ template├─ active
    ├─ base dir └─ user       ├─ set facts ├─ extract │  dir     ├─ daemon  ├─ port
    └─ port                   └─ stop(upg) ├─ perms   └─ rm old  ├─ enable  ├─ /metrics
                                           └─ symlink    tar     └─ restart └─ status
```

---

## Upgrade Process

1. Update `version.mysql.exporter` in `versions.yml`
2. Re-run the playbook
3. Role will: detect mismatch → stop → download new → symlink → remove old → start → verify

---

## Troubleshooting

### Checking Logs

```bash
journalctl -u mysqld_exporter --no-pager -n 50
journalctl -u mysqld_exporter -f
```

### Metrics endpoint returns errors

```bash
curl http://localhost:9104/metrics | grep mysql_up
# mysql_up 0 means MySQL connection failed

# Check MySQL user can connect
mysql -u exporter -p -h localhost -P <port> -e "SELECT 1"
```

---

## File Structure

```
roles/database/mysql/mysql-exporter/
├── defaults/main.yml              # All variables
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Pre-flight checks
│   ├── create_user.yml            # System user (nologin)
│   ├── pre_install.yml            # Version check, conditional stop
│   ├── install.yml                # Download, extract, symlink
│   ├── cleanup.yml                # Remove old version (exact, no globs)
│   ├── service.yml                # Systemd, enable, start, conditional restart
│   └── verify.yml                 # Service active, port, /metrics
├── templates/
│   └── mysqld_exporter.service.j2 # Systemd unit (MemoryMax, collectors loop)
└── README.md                      # This file
```

---

## Security Notes

- Runs as unprivileged `mysql-exporter` user (not root)
- MySQL password passed via `Environment=` in systemd unit (not on command line)
- `no_log: true` on password-related variables in defaults
- MySQL user has minimal grants (PROCESS, REPLICATION CLIENT, SELECT)
- `validate_certs: false` on download (corporate proxy)

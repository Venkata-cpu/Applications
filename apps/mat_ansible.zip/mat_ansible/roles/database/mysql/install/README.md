# MySQL Install Role

Installs and configures [MySQL Community Server](https://dev.mysql.com/downloads/mysql/) (8.4 LTS) via the official Oracle yum repository. Handles both fresh installs and version upgrades in a single role. Supports OEL 8 and OEL 9 (auto-detected).

---

## Latest Version

Check for updates: https://dev.mysql.com/downloads/mysql/

Current deployed: `8.4.8` (MySQL 8.4 LTS)

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8 or OEL 9 | `cat /etc/os-release` |
| **Base directory** | Must exist (mount point: `/apps`) | `ls -la /apps` |
| **Proxy** | `http_proxy`/`https_proxy` for dev.mysql.com | Defined in `all_secrets.yml` |
| **Vault** | `mysql_root_password_vault` for root password | In `all_secrets.yml` |

---

## How to Run

```bash
# Fresh install or upgrade
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/mysql_install.yaml \
  --vault-password-file .vault

# With backup enabled before upgrade
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/mysql_install.yaml \
  --vault-password-file .vault \
  --extra-vars="mysql_backup_enabled=true"
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Example | Description |
|--------|----------|---------|-------------|
| `versions.yml` | `version.mysql.db` | `8.4.8` | MySQL version to install |
| `paths.yml` | `paths.mysql.base_dir` | `/apps` | Base install directory |
| `networks.yml` | `ports.mysql.db` | `61010` | MySQL port |
| `all_secrets.yml` | `mysql_root_password_vault` | (vault) | Root user password |

### Optional (from config_database.yml)

```yaml
config_database:
  mysql:
    bind_address: "0.0.0.0"
    max_connections: 500
    innodb_buffer_pool_size: "24G"
    innodb_buffer_pool_instances: 24
    innodb_log_buffer_size: "128M"
    innodb_log_file_size: "1G"
    innodb_write_io_threads: 8
    innodb_read_io_threads: 8
    key_buffer_size: "256M"
    join_buffer_size: "256M"
    max_allowed_packet: "256M"
    thread_cache_size: 40
    max_connect_errors: 10000
    general_log: "OFF"
    slow_query_log: "ON"
    log_rotation_size: "100M"
    log_rotation_count: 5
    memory_limit: "32G"
    nofile_limit: 65536
    backup_enabled: false
    backup_dir: "/apps/mysql_data_bkp"
```

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `bind_address` | `0.0.0.0` | Listen address | `127.0.0.1` = local only |
| `max_connections` | `500` | Max client connections | Higher = more RAM per connection |
| `innodb_buffer_pool_size` | `4G` | InnoDB cache (most impactful setting) | Set to 60-70% of total RAM |
| `innodb_buffer_pool_instances` | `8` | Pool shards for concurrency | Set to pool_size_GB (1 instance per GB) |
| `memory_limit` | `32G` | Systemd MemoryMax | Prevents OOM of other services |
| `nofile_limit` | `65536` | Max open files | Increase for many tables |
| `backup_enabled` | `false` | Backup data before upgrade | Set `true` when upgrading |
| `backup_dir` | `/apps/mysql_data_bkp` | Where tar backup is stored | Ensure sufficient disk space |

---

## What Gets Installed

```
/usr/sbin/mysqld                               # Binary (from RPM)
/usr/bin/mysql                                  # Client

/etc/my.cnf                                    # Configuration (from role template)

/apps/mysql/                                   # Data directory
├── data/                                      # InnoDB tablespace + redo logs
├── logs/                                      # Error, general, slow query logs
│   ├── mysqld.log
│   ├── general_log.log
│   └── general-slow.log
└── temp/                                      # tmpdir for sorts/joins

/etc/systemd/system/mysqld.service.d/
└── override.conf                              # MemoryMax + LimitNOFILE

/etc/logrotate.d/mysql                         # Log rotation config
```

---

## Task Execution Flow

```
validate → create_user → pre_install → install → config → service → verify
    │           │             │            │         │         │         │
    ├─ version  ├─ group      ├─ version   ├─ repo   ├─ my.cnf ├─ start  ├─ active
    ├─ base dir └─ user       ├─ OS detect ├─ server ├─ systemd├─ root   ├─ port
    ├─ port                   ├─ backup*   ├─ client │  override│  passwd ├─ version
    └─ OS check               └─ stop(upg) └─ dirs   └─ logrot └─restart └─ summary
                                                                  (cond)
```

*backup only if `mysql_backup_enabled=true` AND upgrade needed

---

## Upgrade Process

1. Update `version.mysql.db` in `versions.yml` (e.g., `8.4.8` → `8.4.9`)
2. Optionally enable backup: set `config_database.mysql.backup_enabled: true`
3. Run the playbook
4. The role will:
   - Detect version mismatch
   - Backup data + my.cnf (if enabled)
   - Stop MySQL
   - Remove old packages
   - Install new version from 8.4 LTS repo
   - Deploy config
   - Start MySQL (auto-upgrade runs on first start for 8.4)
   - Verify

```bash
# Upgrade with backup
ansible-playbook ... --extra-vars="mysql_backup_enabled=true"
```

**Note:** MySQL 8.4 performs auto-upgrade on first start after a version change — no manual `mysql_upgrade` needed.

---

## Post-Deployment Verification

```bash
# 1. Service status
systemctl status mysqld

# 2. Version
mysql -u root -p -e "SELECT VERSION();"

# 3. Port listening
ss -tlnp | grep 3306

# 4. Connection test
mysqladmin -u root -p ping

# 5. InnoDB status
mysql -u root -p -e "SHOW ENGINE INNODB STATUS\G" | head -30
```

---

## Troubleshooting

### Checking Logs

```bash
# Error log
tail -100 /apps/mysql/logs/mysqld.log

# Slow query log
tail -50 /apps/mysql/logs/general-slow.log

# Systemd journal
journalctl -u mysqld --no-pager -n 50
```

### Service won't start

```bash
# Check error log
cat /apps/mysql/logs/mysqld.log | tail -30

# Common issues:
# - Port in use: ss -tlnp | grep <port>
# - Permission denied on datadir: ls -laZ /apps/mysql/data/
# - SELinux: audit2why < /var/log/audit/audit.log
```

### Root password lost

```bash
# Stop MySQL, start with skip-grant-tables
systemctl stop mysqld
mysqld --skip-grant-tables --user=mysql &
mysql -u root -e "ALTER USER 'root'@'localhost' IDENTIFIED BY 'new_password';"
kill $(pgrep mysqld)
systemctl start mysqld
```

### Upgrade failed — rollback

```bash
# If backup was taken:
systemctl stop mysqld
rm -rf /apps/mysql/data/*
tar -xzf /apps/mysql_data_bkp/mysql_data_backup_*.tar.gz -C /apps/mysql/data/
cp /apps/mysql_data_bkp/my.cnf.pre_upgrade /etc/my.cnf
# Reinstall old version from repo, then start
systemctl start mysqld
```

---

## File Structure

```
roles/database/mysql/install/
├── defaults/main.yml              # All variables (config_database.mysql.*)
├── handlers/main.yml              # restart mysql
├── tasks/
│   ├── main.yml                   # Orchestrator
│   ├── validate.yml               # Version, base dir, port, OS detection
│   ├── create_user.yml            # System user (nologin)
│   ├── pre_install.yml            # Version check, backup (if enabled), stop
│   ├── install.yml                # Repo + packages + directories (OEL 8/9)
│   ├── config.yml                 # my.cnf + systemd override + logrotate
│   ├── service.yml                # Start, root password, conditional restart
│   └── verify.yml                 # Service active, port, version
├── templates/
│   ├── my.cnf.j2                  # MySQL config (InnoDB tuning, paths, logging)
│   ├── mysqld-override.conf.j2   # Systemd MemoryMax + LimitNOFILE
│   └── logrotate.j2              # Log rotation
└── README.md                      # This file
```

---

### Service Account Access

The `mysql` user is created with `/sbin/nologin` shell:

```bash
su -s /bin/bash mysql
su -s /bin/bash -c "ls -la /apps/mysql/data/" mysql
```

---

## Security Notes

- Root password set from vault on first install (never plaintext in config)
- `mysql_native_password=ON` for backward compatibility with older clients
- `no_log: true` on all password-handling tasks
- Data directory with SELinux context `mysqld_db_t`
- Systemd MemoryMax prevents runaway memory consumption
- MySQL repo disabled after install (prevents surprise auto-upgrades via yum update)
- `validate_certs: false` on repo download (required behind corporate proxy)

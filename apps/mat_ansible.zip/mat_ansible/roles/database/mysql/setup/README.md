# MySQL User Setup Role

Provisions MySQL databases, users, and access grants. Run after `mysql/install` to create application-specific objects. All operations are idempotent (`CREATE IF NOT EXISTS`, `GRANT` is additive).

---

## Latest Version

No versioned binary — uses the installed `mysql` client.

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **MySQL** | Running (installed via `mysql/install` role) | `systemctl is-active mysqld` |
| **Root password** | `mysql_root_password_vault` in vault | `mysql -u root -p -e "SELECT 1"` |
| **Exporter password** | `mysqld_exporter_user_password` in vault | In `all_secrets.yml` |

---

## How to Run

```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/mysql_user_setup.yaml \
  --vault-password-file .vault
```

---

## Variable Reference

### Required (from inventory)

| Source | Variable | Description |
|--------|----------|-------------|
| `all_secrets.yml` | `mysql_root_password_vault` | Root password (for DDL operations) |
| `all_secrets.yml` | `mysqld_exporter_user_password` | Exporter user password |

### Config (from config_database.yml)

```yaml
config_database:
  mysql:
    databases:
      - mat_db
      - grafana_db

    users:
      - name: mat_app
        host: "10.6.%"
        password_vault_var: mysql_mat_app_password
      - name: grafana
        host: "localhost"
        password_vault_var: mysql_grafana_password

    user_access:
      - name: mat_app
        host: "10.6.%"
        database: mat_db
        tables: "*"
        access: "ALL PRIVILEGES"
      - name: grafana
        host: "localhost"
        database: grafana_db
        tables: "*"
        access: "ALL PRIVILEGES"
```

### Vault secrets for user passwords

```yaml
mysql_mat_app_password: "<password>"
mysql_grafana_password: "<password>"
```

---

## Task Execution Flow

```
validate → setup → verify
    │         │        │
    ├─ mysqld ├─ DBs   ├─ list DBs
    │  active ├─ users ├─ list users
    └─ root   ├─ export├─ exporter
       login  ├─ grants│  connect
              └─ flush └─ summary
```

---

## Post-Deployment Verification

```bash
# Check databases created
mysql -u root -p -e "SHOW DATABASES;"

# Check users
mysql -u root -p -e "SELECT User, Host FROM mysql.user;"

# Check grants for a user
mysql -u root -p -e "SHOW GRANTS FOR 'mat_app'@'10.6.%';"

# Test exporter connectivity
mysql -u exporter -p -e "SELECT 1;"
```

---

## File Structure

```
roles/database/mysql/setup/
├── defaults/main.yml      # Database/user/grant lists, passwords
├── tasks/
│   ├── main.yml           # Orchestrator (validate → setup → verify)
│   ├── validate.yml       # MySQL running, root can connect
│   ├── setup.yml          # Create DBs, users, exporter, grants, flush
│   └── verify.yml         # List DBs/users, test exporter
└── README.md              # This file
```

---

## Security Notes

- All password-handling tasks use `no_log: true`
- Root password never exposed in output
- Exporter user limited to `MAX_USER_CONNECTIONS 3` (prevents resource abuse)
- Exporter user has minimal grants: `PROCESS, REPLICATION CLIENT, SELECT`
- User passwords referenced via vault variable names (`password_vault_var`)
- `FLUSH PRIVILEGES` run at end to ensure grants take immediate effect

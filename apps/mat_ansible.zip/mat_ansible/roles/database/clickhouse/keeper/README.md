# ClickHouse Keeper Role

Installs and configures [ClickHouse Keeper](https://clickhouse.com/docs/en/guides/sre/keeper/clickhouse-keeper) — a ZooKeeper-compatible distributed coordination service built into ClickHouse. Used by ClickHouse Server for replicated tables, distributed DDL, and cluster coordination. Deployed as a Raft consensus cluster (3 or 5 nodes).

---

## Latest Version

Check for updates: https://github.com/ClickHouse/ClickHouse/releases

Current deployed: `26.5.2.39`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (mount point: `/apps`) | `ls -la /apps` |
| **Network** | All Keeper nodes reachable on TCP + Raft ports | `telnet <peer-ip> 9181` |
| **Proxy** | `http_proxy`/`https_proxy` for ClickHouse repo | Defined in `all_secrets.yml` |
| **Host var** | `zkId` must be set for each host in inventory | See Hosts File below |
| **Odd node count** | 3 or 5 nodes for Raft quorum | `ansible-inventory --list \| grep clickhouse_keeper` |

---

## How to Run

```bash
# Standard deployment (all keeper nodes)
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/clickhouse_keeper.yaml \
  --vault-password-file .vault

# Single node (for upgrade rolling restart)
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/database/clickhouse_keeper.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=clickhouse_keeper" \
  --limit <hostname>
```

**⚠️ Rolling upgrades:** Run one node at a time in production. The Raft cluster tolerates losing 1 node (in a 3-node) or 2 nodes (in a 5-node). Never upgrade all nodes simultaneously.

---

## Variable Reference

### Required Variables (from inventory)

| Source File | Variable | Example | Description |
|-------------|----------|---------|-------------|
| `versions.yml` | `version.clickhouse_keeper` | `25.8.2.29` | Package version |
| `paths.yml` | `paths.clickhouse_keeper.base_dir` | `/apps` | Base install directory |
| `networks.yml` | `ports.clickhouse.keeper.tcp` | `9181` | Client TCP port |
| `networks.yml` | `ports.clickhouse.keeper.raft` | `9234` | Inter-node Raft port |
| `networks.yml` | `ports.clickhouse.keeper.metrics` | `9363` | Prometheus metrics port |
| `hosts` | `zkId` (host var) | `1`, `2`, `3` | Unique Raft server ID per node |

### Hosts File Example

```ini
[clickhouse_keeper]
blp20919401  ansible_host=10.6.101.241  zkId=1
blp20919402  ansible_host=10.6.101.242  zkId=2
blp20919403  ansible_host=10.6.101.243  zkId=3
blp20919404  ansible_host=10.6.101.244  zkId=4
blp20919405  ansible_host=10.6.101.245  zkId=5
```

### Optional Variables (from app_configs.yml)

```yaml
config_database:
  clickhouse_keeper:
    user: clickhouse
    group: clickhouse
    host_group: clickhouse_keeper
    memory_limit: "4G"
    nofile_limit: 500000
    log_level: warning
    log_size: "500M"
    log_count: 10
    max_connections: 8192
    operation_timeout_ms: 10000
    session_timeout_ms: 100000
    min_session_timeout_ms: 10000
    wait_retries: 10
    wait_delay: 10
```

| Variable | Default | Description | Impact |
|----------|---------|-------------|--------|
| `user` | `clickhouse` | Service user | System user, nologin shell |
| `group` | `clickhouse` | Service group | |
| `host_group` | `clickhouse_keeper` | Inventory group for Raft peers | Template iterates this group for `raft_configuration` |
| `memory_limit` | `4G` | Systemd `MemoryMax` | **Increase** for large clusters with many znodes. Keeper memory grows with coordination state. |
| `nofile_limit` | `500000` | Systemd `LimitNOFILE` | Must be high — Keeper opens many files for Raft logs/snapshots. |
| `log_level` | `warning` | ClickHouse log level | `information` for troubleshooting, `warning` for production. |
| `log_size` | `500M` | Max log file size before rotation | Keeper rotates internally (not logrotate). |
| `log_count` | `10` | Rotated log files to keep | 10 × 500M = 5GB max log disk. |
| `max_connections` | `8192` | Max client connections | One per ClickHouse Server node + overhead. |
| `operation_timeout_ms` | `10000` | ZK operation timeout | **Increase** if network latency is high between nodes. |
| `session_timeout_ms` | `100000` | Client session timeout (100s) | If a ClickHouse Server doesn't heartbeat within this time, its ephemeral nodes are deleted. |
| `wait_retries` | `10` | Verify step retries | |
| `wait_delay` | `10` | Seconds between verify retries | |

---

## What Gets Installed

```
/usr/bin/clickhouse-keeper              # Binary (from RPM)

/etc/clickhouse-keeper/
└── keeper_config.xml                   # Keeper config (Raft cluster, logging, metrics)

/apps/clickhouse-keeper/                # Data directory (persistent, survives upgrades)
├── coordination/
│   ├── logs/                           # Raft transaction logs
│   └── snapshots/                      # Raft state snapshots
├── cores/                              # Core dumps (if any)
└── logs/                               # Keeper application logs
    ├── clickhouse-keeper.log
    └── clickhouse-keeper.err.log

/var/lib/clickhouse-keeper/             # Alternative data path (legacy compatibility)

/etc/systemd/system/clickhouse-keeper.service  # Systemd unit
```

---

## Task Execution Flow

```
validate.yml → create_user.yml → pre_install.yml → install.yml → config.yml → service.yml → verify.yml
      │               │               │                │              │              │              │
      ├─ version      ├─ group        ├─ rpm query     ├─ add repo    ├─ keeper_cfg  ├─ systemd     ├─ service active
      ├─ base dir     └─ user         ├─ set facts     ├─ install pkg │   .xml       ├─ daemon      ├─ TCP port
      ├─ ports                        └─ stop (upg)    ├─ disable repo              ├─ enable      ├─ Raft port
      ├─ zkId                                          └─ create dirs               └─ restart*    ├─ ruok check
      └─ memory fmt                                                                                └─ status
```

*restart only if config or binary changed

- **Idempotent:** If target version is already installed, skips repo add + package install.
- **Data preserved:** Coordination data (Raft logs, snapshots) is NEVER deleted during upgrades.
- **Conditional restart:** Only restarts when config.xml or systemd unit changes, or on upgrade.

---

## Post-Deployment Verification

### 1. Check service status

```bash
systemctl status clickhouse-keeper
```

### 2. Check ruok (are you okay)

```bash
echo ruok | nc localhost 9181
# Expected: imok
```

### 3. Check leader/follower state

```bash
echo mntr | nc localhost 9181 | grep zk_server_state
# Expected: zk_server_state  leader   (on one node)
# Expected: zk_server_state  follower (on other nodes)
```

### 4. Check cluster stats

```bash
echo mntr | nc localhost 9181
# Shows: zk_version, zk_num_alive_connections, zk_outstanding_requests, etc.
```

### 5. Check Prometheus metrics

```bash
curl -s http://localhost:9363/metrics | head -10
```

### 6. Test from ClickHouse Server

```sql
-- On any ClickHouse Server node:
SELECT * FROM system.zookeeper WHERE path = '/';
```

---

## Upgrade Process

1. Update `version.clickhouse_keeper` in `versions.yml`
2. Run the playbook **one node at a time** (use `--limit`):
   ```bash
   # Upgrade node 1
   ansible-playbook ... --limit blp20919401

   # Wait for it to rejoin Raft, then upgrade node 2
   ansible-playbook ... --limit blp20919402

   # Continue until all nodes done
   ```
3. The role will: detect version mismatch → stop keeper → install new version → start → verify
4. Raft cluster tolerates one missing node during each upgrade

**Never upgrade all nodes simultaneously** — this breaks quorum.

---

## Troubleshooting

### Checking Logs

ClickHouse Keeper writes its own log files (not journald):

```bash
# Application log
tail -100 /apps/clickhouse-keeper/logs/clickhouse-keeper.log

# Error log
tail -50 /apps/clickhouse-keeper/logs/clickhouse-keeper.err.log

# Follow live
tail -f /apps/clickhouse-keeper/logs/clickhouse-keeper.log

# Systemd journal (startup issues only)
journalctl -u clickhouse-keeper --no-pager -n 30
```

### Service won't start

```bash
# Check error log
cat /apps/clickhouse-keeper/logs/clickhouse-keeper.err.log

# Common issues:
# - Port already in use: ss -tlnp | grep 9181
# - Config XML syntax error: validate manually
# - Permission denied: check dir ownership (should be clickhouse:clickhouse)
```

### Keeper shows "no leader"

```bash
# Check all nodes
for ip in 10.6.101.241 10.6.101.242 10.6.101.243; do
  echo "=== $ip ===" && echo mntr | nc $ip 9181 | grep server_state
done

# If no leader: possible network partition or quorum lost
# Fix: ensure majority of nodes are running and can reach each other on Raft port
```

### ClickHouse Server can't connect

```bash
# Test TCP port from server node
echo ruok | nc <keeper-ip> 9181

# Check ClickHouse Server log for keeper errors
grep -i keeper /var/log/clickhouse-server/clickhouse-server.err.log

# Common: wrong port, firewall blocking, keeper not running
```

### Raft logs growing large

```bash
# Check coordination dir size
du -sh /apps/clickhouse-keeper/coordination/

# Keeper automatically snapshots and truncates old logs
# If growing: check if snapshots are failing
ls -la /apps/clickhouse-keeper/coordination/snapshots/
```

---

## File Structure

```
roles/database/clickhouse/keeper/
├── defaults/main.yml              # All variables (version, paths, ports, limits)
├── handlers/main.yml              # Restart handler
├── tasks/
│   ├── main.yml                   # Orchestrator (validate → ... → verify)
│   ├── validate.yml               # Pre-flight checks (version, base dir, ports, zkId)
│   ├── create_user.yml            # System user + group (nologin)
│   ├── pre_install.yml            # Version check, conditional stop for upgrade
│   ├── install.yml                # Repo + package + directories
│   ├── config.yml                 # Template keeper_config.xml
│   ├── service.yml                # Systemd unit, enable, start, conditional restart
│   └── verify.yml                 # Service active, TCP port, Raft port, ruok
├── templates/
│   ├── keeper_config.xml.j2       # Keeper config (Raft peers auto-discovered from inventory)
│   └── clickhouse-keeper.service.j2  # Systemd unit (memory/nofile limits, Nice -20)
└── README.md                       # This file
```

---

### Service Account Access

The `clickhouse` user is created with `/sbin/nologin` shell. To access as this user:

```bash
su -s /bin/bash clickhouse
su -s /bin/bash -c "ls -la /apps/clickhouse-keeper/coordination/" clickhouse
```

---

## Security Notes

- Runs as unprivileged `clickhouse` user (not root)
- `MemoryMax` prevents runaway memory consumption
- `Nice=-20` and `IOSchedulingClass=realtime` give Keeper priority (consensus must not be starved)
- `CapabilityBoundingSet` limits to network + IPC + nice only
- No authentication on TCP port by default — rely on network-level access control (firewall)
- Prometheus metrics endpoint unauthenticated — restrict via network
- `validate_certs: false` on repo (required behind corporate proxy)
- Data directory owned by service user, mode `0755`

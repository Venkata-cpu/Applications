# ClickHouse Server Role

Installs and configures [ClickHouse Server](https://clickhouse.com/) — a column-oriented OLAP database for real-time analytics. Deploys as a replicated sharded cluster with dynamic cluster topology from config, per-user thread limits, SHA256 password authentication, Kafka dead letter queue, and full Linux OS performance tuning.

---

## Latest Version

Check for updates: https://github.com/ClickHouse/ClickHouse/releases

Current deployed: `26.5.2.39`

---

## Prerequisites

| Requirement | Details | How to Check |
|-------------|---------|--------------|
| **OS** | OEL 8/9, RHEL 8/9 | `cat /etc/os-release` |
| **Base directory** | Must exist (mount point: `/apps`) | `ls -la /apps` |
| **RAM** | 32GB+ recommended | `free -h` |
| **Network** | All cluster nodes reachable on TCP + inter-server ports | `telnet <peer-ip> <tcp_port>` |
| **ClickHouse Keeper** | Running cluster (3 or 5 nodes) | `echo ruok \| nc <keeper-ip> 9181` |
| **Proxy** | `http_proxy`/`https_proxy` for ClickHouse repo | Defined in `all_secrets.yml` |
| **Host vars** | `shardId`, `replicaId`, `defaultMaximumThreads`, `appMaximumThreads`, `roMaximumThreads` per host | In `hosts` file |

---

## How to Run

```bash
# Deploy to all ClickHouse server nodes
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/database/clickhouse_server.yaml \
  --vault-password-file .vault

# Deploy to a specific sub-group (e.g., port shards only)
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/database/clickhouse_server.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=clickhouse_server_port"

# Single node (rolling upgrade)
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/database/clickhouse_server.yaml \
  --vault-password-file .vault \
  --limit blp20919401
```

---

## Variable Reference

### Required Variables (from inventory)

| Source File | Variable | Example | Description |
|-------------|----------|---------|-------------|
| `versions.yml` | `version.clickhouse_server` | `26.5.2.39` | Package version |
| `paths.yml` | `paths.clickhouse_server.base_dir` | `/apps` | Base install directory |
| `networks.yml` | `ports.clickhouse.server.tcp` | `61052` | Native TCP port |
| `networks.yml` | `ports.clickhouse.server.http` | `61051` | HTTP API port |
| `networks.yml` | `ports.clickhouse.server.mysql` | `9004` | MySQL compatibility port |
| `networks.yml` | `ports.clickhouse.server.postgres` | `9005` | PostgreSQL compatibility port |
| `networks.yml` | `ports.clickhouse.server.interServer` | `9009` | Inter-server replication port |
| `networks.yml` | `ports.clickhouse.server.metrics` | `9363` | Prometheus metrics port |
| `networks.yml` | `ports.clickhouse.keeper.tcp` | `9181` | Keeper TCP port (for ZK connection) |
| `hosts` | `shardId` (host var) | `1` | Shard assignment per node |
| `hosts` | `replicaId` (host var) | `1` or `2` | Replica within shard |
| `hosts` | `defaultMaximumThreads` (host var) | `8` | Max threads for admin profile |
| `hosts` | `appMaximumThreads` (host var) | `5` | Max threads for app profile |
| `hosts` | `roMaximumThreads` (host var) | `4` | Max threads for readonly profile |
| `all_secrets.yml` | Per-user vault passwords | (vault encrypted) | Referenced by `password_vault_var` in users config |

### Hosts File Example

```ini
[clickhouse_server:children]
clickhouse_server_port
clickhouse_server_vlan

[clickhouse_server_port]
blp20919401  ansible_host=10.6.102.21  shardId=1  replicaId=1  defaultMaximumThreads=8  appMaximumThreads=5  roMaximumThreads=4
blp20919402  ansible_host=10.6.102.22  shardId=1  replicaId=2  defaultMaximumThreads=8  appMaximumThreads=5  roMaximumThreads=4
blp20919403  ansible_host=10.6.102.92  shardId=2  replicaId=1  defaultMaximumThreads=8  appMaximumThreads=5  roMaximumThreads=4

[clickhouse_server_vlan]
blp20919410  ansible_host=10.6.102.1   shardId=6  replicaId=1  defaultMaximumThreads=8  appMaximumThreads=5  roMaximumThreads=4
blp20919411  ansible_host=10.6.102.2   shardId=6  replicaId=2  defaultMaximumThreads=8  appMaximumThreads=5  roMaximumThreads=4
```

### Config Structure (in `config_database.yml`)

```yaml
config_database:
  clickhouse_server:
    # --- Cluster Topology ---
    cluster_name: mat_fn
    keeper_host_group: clickhouse_keeper
    clusters:
      - name: mat_fn
        host_group: clickhouse_server
      - name: port
        host_group: clickhouse_server_port
      - name: vlan
        host_group: clickhouse_server_vlan
      - name: twamp
        host_group: clickhouse_server_twamp
      - name: system
        host_group: clickhouse_server_system
      - name: radius
        host_group: clickhouse_server_radius

    # --- Users (type: admin | app | readonly) ---
    users:
      - name: admin
        type: admin
        password_vault_var: clickhouse_admin_user_password
      - name: appUser
        type: app
        password_vault_var: clickhouse_app_user_password
      - name: readonly
        type: readonly
        password_vault_var: clickhouse_ro_user_password

    # --- Resource Limits ---
    memory_ratio: 0.60          # MemoryMax = total_RAM × this ratio
    nofile_limit: 500000

    # --- Service ---
    nice: -20
    io_scheduling_class: realtime
    io_scheduling_priority: 0
    log_level: warning
    log_size: "500M"
    log_count: 10

    # --- Server ---
    max_connections: 4096
    max_concurrent_queries: 200
    max_server_memory_usage_to_ram_ratio: 0.9
    max_thread_pool_size: 10000
    concurrent_threads_soft_limit_ratio: 0

    # --- Background Pools ---
    background_pool_size: 16
    background_merges_mutations_concurrency_ratio: 2
    background_move_pool_size: 8
    background_fetches_pool_size: 16
    background_common_pool_size: 8
    background_schedule_pool_size: 128
    background_message_broker_pool_size: 16
    background_distributed_pool_size: 16
    backup_threads: 16

    # --- MergeTree Tuning ---
    max_suspicious_broken_parts: 100
    max_parts_to_merge_at_once: 100
    number_of_free_entries_in_pool_to_execute_mutation: 20
    max_bytes_to_merge_at_max_space_in_pool: 161061273600
    parts_to_delay_insert: 150
    parts_to_throw_insert: 300
    merge_with_ttl_timeout: 14400
    max_replicated_merges_in_queue: 16
    max_replicated_mutations_in_queue: 8

    # --- Dead Letter Queue ---
    dead_letter_queue_ttl_days: 7

    # --- System Log TTL ---
    log_ttl_days: 7

    # --- Query Settings ---
    max_insert_block_size: 1048576
    max_block_size: 65536
    max_query_size: 262144
    max_partitions_per_insert_block: 100
    max_execution_time: 0
    max_parser_depth: 1000
    enable_lightweight_delete: 1
    skip_unavailable_shards: 0
    kafka_disable_num_consumers_limit: 0
```

### Vault Secrets (in `all_secrets.yml`)

```yaml
clickhouse_admin_user_password: "<strong-password>"
clickhouse_app_user_password: "<strong-password>"
clickhouse_ro_user_password: "<strong-password>"
```

---

## What Gets Installed

```
/usr/bin/clickhouse-server              # Binary (from RPM)
/usr/bin/clickhouse-client              # CLI client

/etc/clickhouse-server/
├── config.xml                          # Server config (from role template)
└── users.xml                           # User/profile config (from role template)

/apps/clickhouse/                       # Data directory (persistent)
├── data/                               # Table data (mode 0700)
├── logs/                               # Application logs
│   ├── clickhouse-server.log
│   └── clickhouse-server.err.log
├── tmp/                                # Temporary query data
├── caches/                             # Custom cached disks
├── access/                             # SQL-created users/roles/grants
├── user_files/                         # User-uploaded files (file() function)
├── format_schemas/                     # Protobuf/Cap'n Proto schemas
└── /apps/clickhouse_backups/           # BACKUP TO path

/etc/systemd/system/clickhouse-server.service      # Systemd unit
/etc/systemd/system/clickhouse-os-tuning.service   # THP + overcommit (persist across reboot)
```

---

## Task Execution Flow

```
validate → create_user → pre_install → install → os_tuning → config → service → verify
    │           │             │            │          │           │          │         │
    ├─ version  ├─ group      ├─ rpm query ├─ repo    ├─ THP      ├─ shard   ├─ systemd├─ active
    ├─ base dir └─ user       ├─ set facts ├─ server  ├─ sysctl   │  maps    ├─ daemon ├─ TCP port
    ├─ ports                  └─ stop(upg) ├─ client  ├─ swap off  ├─ passwd  ├─ enable ├─ HTTP port
    ├─ clusters                            ├─ disable ├─ CPU gov   │  hashes  └─ restart├─ query test
    ├─ users                               │  repo    └─ persist   ├─ config  │  (cond) └─ status
    ├─ shardId                             └─ dirs       service   │  .xml    │
    └─ replicaId                                                   └─ users
                                                                      .xml
```

- **Idempotent:** If target version is already installed, skips repo + install
- **Data preserved:** Data directory never touched during upgrades
- **Conditional restart:** Only on config/binary change
- **Dynamic clusters:** Shard maps built from inventory host groups at runtime
- **Password security:** SHA256 hashes generated at runtime, `no_log: true`
- **OS tuning persists:** `clickhouse-os-tuning.service` survives reboots

---

## OS Performance Tuning (Applied Automatically)

Based on official ClickHouse recommendations ([source](https://clickhouse.com/docs/en/operations/tips/)):

| Setting | Value | Why |
|---------|-------|-----|
| THP (Transparent Huge Pages) | `madvise` | Prevents kernel defragmentation stalls on 64GB+ RAM |
| THP defrag | `madvise` | Same reason |
| `vm.overcommit_memory` | `0` | ClickHouse needs overcommit enabled (official docs) |
| `vm.max_map_count` | `262144` | ClickHouse mmaps many files for data access |
| `vm.swappiness` | `1` | Prefer OOM-kill over swapping (swap destroys OLAP perf) |
| `vm.dirty_ratio` | `40` | Allow dirty pages to accumulate (better write throughput) |
| `vm.dirty_background_ratio` | `10` | Start flushing at 10% dirty |
| `fs.file-max` | `2097152` | Many open parts/files per server |
| `net.core.rmem_max` | `16MB` | Large socket buffers for replication traffic |
| `net.core.wmem_max` | `16MB` | Same |
| `net.core.somaxconn` | `4096` | High-concurrency client connections |
| CPU governor | `performance` | No CPU frequency scaling (consistent latency) |
| Swap | disabled | Prevents swap death on large queries |

All settings are applied via `sysctl` (persistent in `/etc/sysctl.d/`) and a systemd oneshot service for THP (survives reboot).

---

## Dead Letter Queue (Kafka Parse Failures)

Enabled by default. Failed Kafka messages are automatically captured in `system.dead_letter_queue`.

**How it works:**
1. `<dead_letter_queue>` section in `server_config.xml` creates the system table
2. `kafka_handle_error_mode=dead_letter_queue` in user profile applies to all Kafka engine tables
3. Parse failures are stored with topic, partition, offset, raw message, and error text
4. TTL auto-deletes old entries (default: 7 days, configurable via `dead_letter_queue_ttl_days`)

**Query failed messages:**
```sql
SELECT event_time, database, table, kafka_topic_name, kafka_partition, kafka_offset, error, raw_message
FROM system.dead_letter_queue
ORDER BY event_time DESC
LIMIT 20;
```

**Monitor DLQ size (for alerting):**
```sql
SELECT count() AS failed_messages, max(event_time) AS last_failure
FROM system.dead_letter_queue
WHERE event_date = today();
```

---

## User Profiles & Permissions

Three profiles are created, each with different capabilities:

| Profile | Type | max_threads | DDL | Insert | Delete | Grants |
|---------|------|:-----------:|:---:|:------:|:------:|--------|
| `default` | admin | `defaultMaximumThreads` | ✅ | ✅ | ✅ | Full access + `access_management` |
| `app` | app | `appMaximumThreads` | ❌ | ✅ | ✅ | SELECT, INSERT, UPDATE, DELETE, CLUSTER |
| `roProfile` | readonly | `roMaximumThreads` | ❌ | ❌ | ❌ | SELECT only (readonly=2) |

Thread limits are per-host (from inventory host vars) allowing different hardware to have different concurrency.

---

## Post-Deployment Verification

### 1. Check service status

```bash
systemctl status clickhouse-server
```

### 2. Check version

```bash
clickhouse-client --query "SELECT version()"
```

### 3. Check cluster connectivity

```bash
clickhouse-client --query "SELECT * FROM system.clusters WHERE cluster = 'mat_fn'"
```

### 4. Check Keeper connection

```bash
clickhouse-client --query "SELECT * FROM system.zookeeper WHERE path = '/'"
```

### 5. Check replication health

```bash
clickhouse-client --query "
  SELECT database, table, is_leader, total_replicas, active_replicas
  FROM system.replicas
  WHERE active_replicas < total_replicas"
```

### 6. Check Prometheus metrics

```bash
curl -s http://localhost:9363/metrics | head -10
```

### 7. Check DLQ for Kafka failures

```bash
clickhouse-client --query "SELECT count() FROM system.dead_letter_queue"
```

---

## Upgrade Process

1. Update `version.clickhouse_server` in `versions.yml`
2. Run the playbook **one shard at a time** — never all nodes simultaneously:
   ```bash
   # Upgrade replica 2 of each shard first (non-leader)
   ansible-playbook ... --limit 'clickhouse_server_port:&replicaId_2'

   # Then upgrade replica 1 (leaders will auto-failover)
   ansible-playbook ... --limit 'clickhouse_server_port:&replicaId_1'
   ```
3. The role will: detect version mismatch → stop → install new → start → verify
4. Data on disk is compatible across minor versions (check release notes for major upgrades)

**⚠️ Never upgrade all replicas of a shard simultaneously** — at least one replica must remain online for read availability.

---

## Troubleshooting

### Checking Logs

ClickHouse writes its own log files (not journald):

```bash
# Application log
tail -100 /apps/clickhouse/logs/clickhouse-server.log

# Error log
tail -50 /apps/clickhouse/logs/clickhouse-server.err.log

# Follow live
tail -f /apps/clickhouse/logs/clickhouse-server.log

# Systemd journal (startup issues only)
journalctl -u clickhouse-server --no-pager -n 30
```

### Service won't start

```bash
# Check error log
cat /apps/clickhouse/logs/clickhouse-server.err.log | tail -30

# Common issues:
# - Config XML syntax error
# - Port already in use: ss -tlnp | grep <port>
# - Permission denied on data dir: ls -la /apps/clickhouse/data/
# - Keeper unreachable: echo ruok | nc <keeper-ip> 9181
```

### Replication lag

```bash
clickhouse-client --query "
  SELECT database, table,
    absolute_delay,
    queue_size,
    inserts_in_queue,
    merges_in_queue
  FROM system.replicas
  WHERE absolute_delay > 0
  ORDER BY absolute_delay DESC"
```

### Too many parts (insert throttling)

```bash
clickhouse-client --query "
  SELECT database, table, partition, parts_to_check, parts_to_merge_now
  FROM system.replicas
  WHERE parts_to_check > 0"
```

### Mutation stuck

```bash
clickhouse-client --query "
  SELECT database, table, mutation_id, command, create_time, is_done
  FROM system.mutations
  WHERE is_done = 0"
```

### Distributed DDL stuck

```bash
clickhouse-client --query "
  SELECT * FROM system.distributed_ddl_queue
  WHERE status != 'Finished'
  ORDER BY initiator_host, query_start_time"
```

### Kafka DLQ filling up

```bash
# Check what's failing
clickhouse-client --query "
  SELECT kafka_topic_name, count() AS failures, max(event_time) AS last_fail
  FROM system.dead_letter_queue
  GROUP BY kafka_topic_name
  ORDER BY failures DESC"
```

---

## File Structure

```
roles/database/clickhouse/server/
├── defaults/main.yml              # All variables (config_database.clickhouse_server.*)
├── handlers/main.yml              # restart clickhouse-server
├── tasks/
│   ├── main.yml                   # Orchestrator (validate → ... → verify)
│   ├── validate.yml               # Pre-flight checks
│   ├── create_user.yml            # System user (nologin)
│   ├── pre_install.yml            # RPM version check, conditional stop
│   ├── install.yml                # Repo + packages + directories
│   ├── os_tuning.yml              # THP, sysctl, swap, CPU governor, persistent service
│   ├── config.yml                 # Build shard maps + password hashes + deploy templates
│   ├── build_shard_map.yml        # Helper: builds shard map for one cluster
│   ├── service.yml                # Systemd (dynamic MemoryMax), conditional restart
│   └── verify.yml                 # Service active, ports, HTTP query test, status
├── templates/
│   ├── server_config.xml.j2       # Full server config (clusters, ZK, logging, DLQ, MergeTree)
│   ├── users.xml.j2               # Profiles (default/app/roProfile) + dynamic users
│   └── clickhouse-server.service.j2  # Systemd unit (dynamic MemoryMax, Nice, IO priority)
└── README.md                       # This file
```

---

### Service Account Access

The `clickhouse` user is created with `/sbin/nologin` shell. To access:

```bash
# Interactive shell as clickhouse
su -s /bin/bash clickhouse

# Run a command as clickhouse
su -s /bin/bash -c "ls -la /apps/clickhouse/data/" clickhouse

# ClickHouse client (runs as any user)
clickhouse-client --host 127.0.0.1 --port 61052 --user admin --password '<pass>'
```

---

## Security Notes

- Service runs as unprivileged `clickhouse` user (not root)
- `OOMScoreAdjust=-1000` prevents OOM-kill (ClickHouse is the primary workload)
- `MemoryMax` dynamically calculated from RAM ratio (prevents runaway)
- Passwords stored as SHA256 hashes (never plaintext in config)
- `no_log: true` on all password generation tasks
- Data directory mode `0700` (only clickhouse user can read)
- `allow_no_password=1` kept for backward compatibility (existing `default` user) — new users always require passwords
- Prometheus metrics endpoint unauthenticated — rely on network ACL
- Crash reports disabled (`send_crash_reports.enabled=false`)
- `validate_certs: false` on repo (required behind corporate proxy)

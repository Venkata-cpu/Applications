---
inclusion: fileMatch
fileMatchPattern: "grafana_dashboards/**/*.json"
description: "Conventions for managing version-controlled Grafana dashboard JSON models"
---

# Grafana Dashboard Conventions

## Purpose

Grafana dashboards are version-controlled as JSON models in `grafana_dashboards/`. This ensures:
- Dashboards can be restored after Grafana reinstalls
- Changes are tracked via git history
- Dashboards can be deployed across environments (preprod, prod, DR)

## Directory Structure

```
grafana_dashboards/
├── data_dip_investigation/         # Pipeline health monitoring
│   ├── data_dip_investigation_prod.json
│   ├── data_dip_investigation_preprod.json
│   └── data_dip_investigation_dr.json
├── elasticsearch_monitoring/       # ES cluster health
│   ├── elasticsearch_monitoring_prod.json
│   └── elasticsearch_advanced_devops_prod.json
└── mysql_monitoring/               # MySQL overview + InnoDB
    ├── mysql_overview_prod.json
    └── mysql_innodb_advanced_prod.json
```

## Naming Convention

`<dashboard_name>_<environment>.json`

- Use snake_case for all names
- Always include the environment suffix
- Group related dashboards in a subdirectory

## Export Rules

When exporting a dashboard from Grafana:
1. Use **Share → Export → Save to file** (not clipboard)
2. Remove the `"id"` field (numeric, Grafana-instance-specific)
3. Keep the `"uid"` field (string, portable between instances)
4. Set `"version"` to `1` (avoids version conflicts on import)
5. Ensure `"editable": true` for team maintainability

## Environment-Specific Differences

Dashboards may differ between environments due to:
- Different datasource UIDs (Prometheus instances per env)
- Different host counts (prod has more shards than test)
- Different retention periods or alert thresholds

When creating env variants, duplicate and modify only the datasource references and host-specific panels.

## Data Dip Investigation Dashboard

The core pipeline health dashboard provides step-by-step investigation:

| Step | What It Checks |
|------|---------------|
| Pipeline Status | Overall health indicator |
| Data Dip Detection | PROD vs DR data comparison |
| Pod Status | K8s pod health and restarts |
| ATLAS | Collector/Parser consumer & producer metrics |
| HERCULES | Processor last push metrics |
| Kafka Broker | Status, errors, consumer lag |
| ClickHouse | Server health, per-node data, replication |
| Kubernetes | Node-level status |
| Decision Tree | Quick troubleshooting reference |

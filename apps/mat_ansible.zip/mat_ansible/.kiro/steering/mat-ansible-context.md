---
inclusion: always
---

# MAT Ansible — Project Context

## Overview

This is the **MAT (Martini Analytics Team) Ansible** project — an infrastructure automation platform for the Martini/MAT ecosystem at BT (British Telecom). It manages the full data pipeline stack from Kafka ingestion through ClickHouse storage to Grafana dashboards.

**Repository purpose:** Provision, configure, upgrade, and monitor all infrastructure components across multiple environments using Ansible playbooks triggered via GitLab CI.

---

## Data Pipeline Architecture

```
ATLAS (Collector/Parser) → Kafka Broker (KRaft) → HERCULES (Processor) → ClickHouse → HAProxy (LB) → Grafana Dashboards
```

All components are monitored via Prometheus exporters feeding into Grafana dashboards (including the "Data Dip Investigation" dashboard for pipeline health).

---

## Project Structure

```
mat_ansible/
├── .gitlab-ci.yml              # CI entrypoint — routes to pipeline/*.yml based on APP_INSTANCE
├── .vault                      # Vault password file (local runs)
├── inventories/                # Per-module, per-environment host definitions
│   ├── mat_fixed_network/      #   └── test / prod / dr
│   │   └── <env>/
│   │       ├── hosts           # INI inventory (host groups + host vars)
│   │       ├── group_vars/all/ # Variable files (versions, paths, networks, app_configs, secrets)
│   │       └── configs/        # Per-service config files (templates, properties, XML)
│   ├── mat_ran/                #   └── test / pre_prod / prod / dr / geo_prod
│   ├── mat_ran_fn/             #   └── pre_prod
│   ├── mat_common/             #   └── test / pre_prod
│   ├── martini/                #   └── test / prod / dr
│   ├── bhrigu/                 #   └── test / pre_prod / prod
│   ├── netrep/                 #   └── prod / dr
│   ├── eenpm/                  #   └── dr
│   ├── ran/                    #   └── test
│   └── monitoring/             #   └── hosts
├── playbook/                   # 70+ entrypoint YAML playbooks (one per service)
│   └── _global_vars/           # Shared vars loaded across playbooks (all.yml vault, common_config.yml)
├── roles/                      # 55+ reusable Ansible roles
├── pipeline/                   # GitLab CI stage definitions
│   ├── martini-ran-ci.yml      #   Jobs for RAN instance
│   ├── mat-fn-ci.yml           #   Jobs for Fixed Network instance
│   ├── mat-common-ci.yml       #   Jobs for MAT Common instance
│   ├── barista-ci.yml          #   Jobs for Barista instance
│   ├── bhrigu-ci.yml           #   Jobs for Bhrigu instance
│   ├── martini-ran-fn-ci.yml   #   Jobs for RAN-FN instance (uses APP_GROUP subfolder path)
│   └── default-ci.yml          #   Fallback jobs
├── grafana_dashboards/         # Version-controlled Grafana JSON models
│   ├── bhrigu_application_logs/ #  Bhrigu Pre-Prod application logs (Loki-based log viewer with namespace/pod/container filtering)
│   ├── clickhouse_monitoring/  #   ClickHouse cluster operations (query perf, merges, replication, Keeper health)
│   ├── data_dip_investigation/ #   Pipeline health dashboards (prod, preprod, dr)
│   ├── data_pipeline/          #   Data pipeline end-to-end health
│   ├── druid_monitoring/       #   Druid ingestion & query monitoring
│   ├── elasticsearch_monitoring/ # ES cluster health + advanced DevOps (prod)
│   ├── haproxy_monitoring/     #   HAProxy load balancer health (connections, latency, backends, errors, SSL & security)
│   ├── hdfs_monitoring/        #   HDFS cluster health
│   ├── infra_monitoring/       #   Infrastructure monitoring (Prometheus self-monitoring, GitLab Runner CI/CD, Harbor registry, LibreFS object storage, Schema Registry, Supabase platform)
│   ├── kafka_monitoring/       #   Kafka KRaft cluster health, OOM anomaly detection
│   ├── k8s_monitoring/         #   K8s Cluster Overview (nodes, CPU/memory per node, pods per namespace, PVC usage) + Pod Resources (CPU/memory/network per pod) + Kafka Strimzi Overview (brokers, partitions, replication, throughput, JVM) + Control Plane Health (API server request rate/latency/errors, etcd object counts, CoreDNS, workqueue depth, inflight requests) + Node Exporter Detail (per-node CPU by mode, memory breakdown, disk I/O throughput & IOPS, network traffic, load average, filesystem usage table) + Troubleshooting (cluster health indicators: nodes not ready, crash looping pods, OOMKilled, pending pods, failed jobs, PVC capacity; top restarting/not-ready pods; memory pressure nodes; top CPU/memory consumers; deployment replica mismatch)
│   ├── longhorn_monitoring/    #   Longhorn storage health
│   ├── mysql_monitoring/       #   MySQL overview, InnoDB advanced (prod), deep dive (test)
│   └── zookeeper_monitoring/   #   ZooKeeper ensemble health (latency, throughput, reliability, JVM — test)
├── config/                     # Shared configuration
└── templates/                  # Jinja2 templates
```

---

## Environments & Modules

| Module | Test | Pre-Prod | Prod | DR | Geo-Prod | CST |
|--------|:----:|:--------:|:----:|:--:|:--------:|:---:|
| MAT RAN | ✅ | ✅ | ✅ | ✅ | ✅ | — |
| MAT RAN FN | — | ✅ | — | — | — | — |
| MAT Common | ✅ | ✅ | — | — | — | — |
| Fixed Network | ✅ | — | ✅ | ✅ | — | — |
| Martini | ✅ | — | ✅ | ✅ | — | — |
| Barista | ✅ | ✅ | ✅ | — | — | ✅ |
| Bhrigu | ✅ | ✅ | ✅ | — | — | — |
| Netrep | — | — | ✅ | ✅ | — | — |
| EEnpm | — | — | — | ✅ | — | — |
| RAN | ✅ | — | — | — | — | — |

---

## Inventories Directory — Detailed Breakdown

### Directory Layout

```
inventories/
├── mat_fixed_network/
│   ├── test/
│   │   ├── hosts
│   │   ├── group_vars/all/  (versions.yml, paths.yml, networks.yml, app_configs.yml, config_kubernetes.yml, config_kafka.yml, all_secrets.yml, all_host_secrets.yml)
│   │   └── configs/         (clickhouse, copy_via_ssh, druid, elasticsearch, grafana, haproxy, haproxy_click, kafka, kafka_kraft, logstash, mysql, prometheus, zookeeper)
│   ├── prod/
│   │   ├── hosts
│   │   ├── group_vars/all/  (versions.yml, paths.yml, networks.yml, app_configs.yml, config_kubernetes.yml, config_elk.yml, all_secrets.yml, all_host_secrets.yml)
│   │   └── configs/         (clickhouse, copy_via_ssh, elasticsearch, grafana, haproxy, haproxy_click, kafka_kraft, logstash, mysql, prometheus)
│   └── dr/
│       ├── hosts
│       ├── group_vars/all/  (same 6 files)
│       └── configs/         (clickhouse, copy_via_ssh, druid, elasticsearch, grafana, haproxy, haproxy_click, kafka, kafka_kraft, logstash, mysql, prometheus, zookeeper)
├── mat_ran/
│   ├── test/
│   ├── pre_prod/
│   ├── prod/
│   ├── dr/
│   └── geo_prod/
├── mat_ran_fn/
│   └── pre_prod/
│       ├── hosts            # Uses kubernetes_master:children pattern (kubernetes_master_init)
│       ├── group_vars/all/  (versions.yml, paths.yml, networks.yml, config_kubernetes.yml, config_platform.yml, all_secrets.yml)
│       └── configs/         (Kubernetes: docker_less, longhorn, harbor, postgres, pgadmin, ingress-controller)
├── mat_common/
│   ├── automation_pre_prod/
│   ├── dev_test/
│   ├── pre_prod/
│   │   ├── hosts            # Kubernetes + data pipeline services (Kafka, Druid, HDFS, ClickHouse, MySQL, Grafana, Prometheus)
│   │   └── group_vars/all/  (versions.yml, paths.yml, networks.yml, config_kubernetes.yml, config_kafka.yml, config_elk.yml, app_configs.yml, all_secrets.yml, health_check.yml)
│   └── test/
│       ├── hosts            # Shared infrastructure with mat_fixed_network/test (same nodes)
│       ├── group_vars/all/  (versions.yml, paths.yml, networks.yml, config_kubernetes.yml, config_platform.yml, config_monitoring.yml, config_database.yml, config_elk.yml, config_kafka.yml, app_configs.yml, all_secrets.yml, all_host_secrets.yml)
│       └── configs/         (haproxy)
├── barista/
│   ├── cst/
│   │   ├── hosts            # Single-subnet: 10.11.39.x — 1 master + 4 workers
│   │   └── configs/
│   ├── test/
│   │   ├── hosts            # Dual-zone: zone1 (10.13.88.x) + zone2 (10.13.149.x) — zone-based master/worker groups
│   │   ├── group_vars/all/
│   │   └── configs/
│   ├── pre_prod/
│   │   ├── hosts            # Multi-DC: Reigate, Derby, St Albans — region-based master/worker groups
│   │   ├── group_vars/all/
│   │   └── configs/
│   └── prod/
│       ├── hosts
│       ├── group_vars/all/
│       └── configs/
├── martini/
├── bhrigu/
├── netrep/
├── eenpm/
├── ran/
└── monitoring/
```

### Config Templates Per Service

Each `configs/<service>/` directory contains Jinja2 templates (`.j2`) deployed to target hosts:

| Service | Config Files |
|---------|-------------|
| **clickhouse** | `server_config.xml.j2`, `users.xml.j2` |
| **kafka** | `server.properties.j2`, `producer.properties.j2` |
| **kafka_kraft** | `server.properties.j2`, `server_ssl.properties.j2` (prod/dr only), `producer.properties.j2`, `schema-registry.properties.j2`, `schema-registry-log4j.properties.j2` |
| **elasticsearch** | `elasticsearch.yml.j2`, `jvm.options.j2` |
| **haproxy** | `haproxy.cfg.j2`, `userlist.cfg.j2` |
| **haproxy_click** | `haproxy.cfg.j2` |
| **logstash** | `kube_filebeat.conf.j2`, `pipelines.yml.j2` |
| **mysql** | `my.cnf.j2` |
| **prometheus** | `prometheus.yml.j2`, `alertmanager.yml.j2`, `alert_rules/` (directory) |
| **grafana** | `monitor/`, `user/` (sub-directories) |
| **zookeeper** | `zoo.cfg.j2` |
| **druid** | `broker/`, `common/`, `coordinator/`, `historical/`, `middle-manager/`, `overlord/`, `router/` |
| **copy_via_ssh** | Per-host CSV templates (`blp*.csv.j2`) |

### Host Groups Per Environment (mat_fixed_network)

#### Test Environment
| Host Group | Nodes | IP Range |
|-----------|-------|----------|
| kubernetes_master_init | 1 | 10.11.21.30 |
| kubernetes_master_join | 1 | 10.11.21.250 |
| kubernetes_worker_set1 | 13 | 10.11.21.31–36, .150–153, .242–244 |
| haproxy | 1 | 10.6.97.10 |
| elasticsearch / prometheus | 1 (shared) | 10.11.21.37 |
| grafana_monitoring | 1 | 10.11.21.149 |
| mysql / grafana_user_mysql | 1 (shared) | 10.11.21.82 |
| kafka_kraft | 3 | 10.11.21.146–148 |
| kafdrop | 1 | 10.11.21.147 |
| schema_registry | 3 | 10.11.21.146–148 |
| clickhouse_keeper | 3 | 10.11.21.30, .37, .149 |
| clickhouse_server | 3 (3 shards × 1 replica) | 10.11.21.39, .76, .77 |
| pushgateway | 1 | 10.11.21.30 |

#### Prod Environment
| Host Group | Nodes | IP Range |
|-----------|-------|----------|
| kubernetes_master_init | 1 | 10.6.102.110 |
| kubernetes_master_join | 2 | 10.6.102.102, 10.6.101.244 |
| kubernetes_worker | 15 | 10.6.101.229–240, 10.6.121.158–160 |
| haproxy | 4 | 10.11.48.201–204 |
| haproxy_click | 1 | 10.6.101.243 |
| dr_haproxy_servers | 4 | 10.54.115.93–96 |
| prometheus | 1 | 10.6.102.112 |
| elasticsearch | 1 | 10.6.102.112 |
| grafana_monitoring | 1 | 10.6.122.109 |
| grafana_user | 1 | 10.6.122.110 |
| app_mysql | 1 | 10.6.101.255 |
| kafka_kraft | 5 | 10.6.122.107–111 |
| kafka_kraft_ssl | 3 | 10.6.122.77, .112, .113 |
| kafdrop_kraft | 1 | 10.6.122.111 |
| kafdrop_kraft_ssl | 1 | 10.6.122.113 |
| schema_registry_ssl | 1 | 10.6.122.112 |
| clickhouse_keeper | 5 | 10.6.101.241–245 |
| clickhouse_server_prod | 36 (18 shards × 2 replicas) | 10.6.102.x, 10.6.122.x |
| ├─ clickhouse_server_port | 10 (shards 1–5) | 10.6.102.21–22, .92–98, .111 |
| ├─ clickhouse_server_vlan | 10 (shards 6–10) | 10.6.102.1–2, .36–41, .113–114 |
| ├─ clickhouse_server_twamp | 2 (shard 11) | 10.6.102.11–12 |
| ├─ clickhouse_server_misc | 2 (shard 12) | 10.6.102.13–14 |
| ├─ clickhouse_server_system | 6 (shards 13–15) | 10.6.102.15–20 |
| └─ clickhouse_server_radius | 6 (shards 16–18) | 10.6.122.114–118, 10.6.101.246 |
| pushgateway | 1 | 10.6.101.229 |
| jupiter_nifi | 3 | 10.54.105.187–189 |
| saturn_nifi | 3 | 10.54.105.190–192 |
| broadband_capacity_dashboard | 1 | 10.54.106.103 |
| caf_knowledge_agent | 1 | 10.54.105.250 |

#### DR Environment
| Host Group | Nodes | IP Range |
|-----------|-------|----------|
| kubernetes_master | 2 | 10.54.105.175–176 |
| kubernetes_worker_set1 | 10 | 10.54.105.177–186 |
| haproxy | 4 | 10.54.115.93–96 |
| haproxy_click | 1 | 10.54.106.107 |
| prometheus / elasticsearch / logstash | 1 (shared) | 10.54.105.245 |
| grafana_monitoring | 1 | 10.54.105.241 |
| grafana_user | 1 | 10.54.105.243 |
| app_mysql | 1 | 10.54.105.201 |
| kafka_kraft | 5 | 10.54.105.240–244 |
| kafka_kraft_ssl | 3 | 10.54.105.246, .249, .250 |
| kafdrop_kraft | 1 | 10.54.105.240 |
| kafdrop_kraft_ssl | 1 | 10.54.105.249 |
| schema_registry_ssl | 1 | 10.54.105.250 |
| clickhouse_keeper | 5 | 10.54.105.188–189, 10.54.106.103, .106, .107 |
| clickhouse_server_dr | 36 (18 shards × 2 replicas) | 10.54.105.x, 10.54.106.x |
| ├─ clickhouse_server_radius | 6 (shards 1–3) | 10.54.105.193–198 |
| ├─ clickhouse_server_port | 10 (shards 4–8) | 10.54.105.251–253, 10.54.106.85–91 |
| ├─ clickhouse_server_vlan | 10 (shards 9–13) | 10.54.105.203–204, .254–255, 10.54.106.0–3, .104–105 |
| ├─ clickhouse_server_system | 6 (shards 14–16) | 10.54.105.234–239 |
| ├─ clickhouse_server_twamp | 2 (shard 17) | 10.54.105.232–233 |
| └─ clickhouse_server_misc | 2 (shard 18) | 10.54.105.230–231 |
| pushgateway | 1 | 10.54.105.175 |
| gitlab_runner | 1 | 10.54.106.160 |
| jupiter_nifi | 3 | 10.54.105.187–189 |
| saturn_nifi | 3 | 10.54.105.190–192 |

### Host Groups Per Environment (mat_ran_fn)

#### Pre-Prod Environment
| Host Group | Nodes | IP Range |
|-----------|-------|----------|
| kubernetes_master_init | 1 | 10.6.103.179 |
| kubernetes_worker | 5 | 10.6.103.180–184 |
| nvd_sync | 1 | 10.6.103.179 |
| gitlab_runner | 1 | 10.6.103.185 |

**Note:** Uses `kubernetes_master:children` → `kubernetes_master_init` pattern (dockerless/KRaft-style master setup for `kubeadm init` delegation). The `gitlab_runner` node also runs Gradle and nerdctl (rootless BuildKit) for CI/CD image builds. Configuration is split across two files with distinct root keys: `config_kubernetes.yml` uses the `config_k8s:` root key (flat hierarchy — roles access settings directly as `config_k8s.<role>.*`, e.g., `config_k8s.longhorn.*`, `config_k8s.postgres.*`, `config_k8s.headlamp.*`, `config_k8s.ansible_user`), while `config_platform.yml` uses the `config_platform:` root key (platform services: `nvd_sync`, `gitlab_runner`, `gradle`, `nerdctl`).

- **Pre-Prod Kubernetes config** (`config_kubernetes.yml`):
  - Longhorn: worker group `kubernetes_worker`, 2 replicas, storage reserved 55%, minimal available 10%, engine guaranteed CPU 500m
  - Harbor: external URL `https://martini.preprod.nat.bt.com:61140`, `db_auth` mode, Longhorn storage, no Trivy
  - PostgreSQL (CNPG): cluster `mat-pre-prod`, namespace `postgres`, 1 instance, db `preprod`, user `mat_user`, Longhorn 50Gi, max_connections 600
  - pgAdmin: email `admin@mat.bt.com`
  - Headlamp: namespace `headlamp`, port 4466, base path `/headlamp`, ingress enabled via HAProxy on `martini.preprod.nat.bt.com` (no TLS)
  - LibreFS: namespace `librefs`, distributed mode, 5 replicas, 1 volume per node, 225Gi hostPath (`/apps/librefs_data`), root user `libreadmin`, node label targeting (`storage=true`), buckets: `longhorn-backup`, ports: API 9000 (NodePort 61005), Console 9001 (NodePort 61006)
  - Monitoring: namespace `monitoring`, Prometheus retention 15d, scrape interval 30s, env label `mat-ran-fn-preprod`, persistent storage (Longhorn 30Gi), AlertManager enabled (SMTP `smtpb.intra.bt.com:25`, to: `martini.asg@bt.com` + `martini.ee.ran@bt.com`, cc: `martini-devops@bt.com`, P1/P2/P3 repeat intervals 2h/6h/24h, ingress enabled via HAProxy on `martini.preprod.nat.bt.com/alertmanager`), alert rules enabled
  - Grafana: namespace `grafana`, 1 replica, port 3000, base path `/grafana`, ingress enabled via HAProxy on `martini.preprod.nat.bt.com`, external PostgreSQL (`mat-pre-prod-rw.postgres.svc.cluster.local:5432`, db `grafana`, user `grafana`), SMTP enabled (`smtpb.intra.bt.com:25`, from `noreply.martini@bt.com`), LDAP enabled (`iuserldap.nat.bt.com:389`, sAMAccountName filter, search base `ou=employee,ou=btplc,dc=iuser,dc=iroot,dc=adidom,dc=com`, group mappings: `*` → Viewer, `mygrp-ddops-grafana-user-group` → Viewer org 2), plugins: `grafana-piechart-panel`, `grafana-polystat-panel`, `grafana-clock-panel`, `yesoreyeram-infinity-datasource`, `flant-statusmap-panel`, `marcusolsson-dynamictext-panel`

### Host Groups Per Environment (mat_common)

#### Test Environment

**Note:** MAT Common test shares the same physical infrastructure (nodes and IPs) as `mat_fixed_network/test` on the 10.11.21.x, 10.11.22.x, and 10.6.97.x subnets. The separation allows independent configuration (group_vars) while reusing the same hardware. MAT Common test is now scoped to **Kubernetes platform, CI/CD tooling, Kubernetes-deployed Elasticsearch, and data pipeline services (Druid, ZooKeeper, HDFS, Schema Registry)** — its `versions.yml` contains platform tools (GitLab Runner 19.0.1, Gradle 9.5.1, nerdctl 2.3.3), Kubernetes components (Helm, Harbor, Longhorn, PostgreSQL/CNPG, pgAdmin, LibreFS, monitoring stack, Grafana, Headlamp, docker_less cluster), and ELK versions (Elasticsearch 9.3.6, Elasticsearch Exporter 1.10.0). Its `config_database.yml` provides Druid OLAP cluster configuration (MySQL metadata store, HDFS deep storage, per-service heap/memory settings). Other legacy data pipeline services (ClickHouse, Kafka, Grafana standalone, HAProxy, MySQL, Prometheus standalone, exporters, etc.) are managed exclusively via the `mat_fixed_network/test` inventory. The pipeline uses the APP_GROUP subfolder pattern with path validation, FORKS=5, and runs on the `MAT-Ansible-TEST` runner tag.

**HAProxy groups:** MAT Common test splits HAProxy into two groups — `haproxy_fn` (Fixed Network LB, 10.6.97.10, port 50022) and `haproxy_ran` (RAN LB, 10.50.126.57, port 50022) — whereas `mat_fixed_network/test` uses a single `[haproxy]` group. Both HAProxy hosts use `ansible_port=50022` (SFTP-style SSH access via sshd_lock).

**HAProxy config template (`configs/haproxy/haproxy.cfg.j2`):** The MAT Common test HAProxy config is a dynamic Jinja2 template that uses inventory variables and host group loops to generate the configuration. All frontends use SSL termination with `{{ paths.ssl_certs.base_dir }}/certificate2023.pem` and disable SSLv3/TLSv1.0/TLSv1.1. It proxies the following services:
- **Stats interface** — binds `ports.haproxy.stats` with SSL, exposes Prometheus metrics at `/metrics` and stats UI at `/stats`
- **Kubernetes Worker Nodes** — binds `ports.haproxy.kube_worker` with SSL, HTTP mode with path rewriting rules (TWAMP service routing), backends loop over `groups['kubernetes_worker']` on port 80
- **Kubernetes Prometheus NodePort** — binds `ports.haproxy.kube_exporter` with SSL, TCP mode, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.monitoring.prometheus`
- **Prometheus (standalone)** — binds `ports.haproxy.prometheus` with SSL, TCP mode, backends loop over `groups['prometheus']` on `ports.prometheus.service`
- **Pushgateway** — binds `ports.haproxy.pushgateway` with SSL, TCP mode, backends loop over `groups['pushgateway']` on `ports.pushgateway.service`
- **Grafana Monitor** — binds `ports.haproxy.grafana_monitor` with SSL, TCP mode, backends loop over `groups['grafana_monitoring']` on `ports.grafana.service`
- **MySQL (app)** — binds `ports.haproxy.app_mysql` without SSL (plain TCP), TCP mode, maxconn 25, backends loop over `groups['app_mysql']` on `ports.mysql.db`
- **ClickHouse** — binds `ports.haproxy.clickhouse` with SSL, TCP mode, backends loop over `groups['clickhouse_server']` on `ports.clickhouse.server.http`
- **Kafdrop** — binds `ports.haproxy.kafdrop` with SSL, TCP mode, backends loop over `groups['kafdrop_kraft']` on `ports.kafdrop.service`
- **Druid** — binds `ports.haproxy.druid` with SSL, TCP mode, backends loop over `groups['druid_router']` on `ports.druid.router`
- **Harbor** — binds `ports.haproxy.harbor` with SSL, TCP mode, backends loop over `groups['kubernetes_worker']` on `ports.kubernetes.harbor.http`
- **pgAdmin** — binds `ports.haproxy.pgadmin` with SSL, HTTP mode with `X-Forwarded-Proto` and `X-Forwarded-Port` headers, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.pgadmin.nodeport`
- **Longhorn UI** — binds `ports.haproxy.longhorn` with SSL, HTTP mode with `X-Forwarded-Proto` header, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.longhorn.node_port`
- **Supabase (Kong API Gateway)** — binds `ports.haproxy.supabase` with SSL, HTTP mode with `X-Forwarded-Proto` and `X-Forwarded-Port` headers, backends loop over `groups['supabase_workers']` on `ports.kubernetes.supabase.kong`
- **libreFS Console** — binds `ports.haproxy.librefs_console` with SSL, HTTP mode with `X-Forwarded-Proto` header, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.librefs.console_nodeport`

**Note:** The template references `paths.ssl_certs.base_dir` (for certificate2023.pem path) and `groups['app_mysql']` — these must be defined in the MAT Common test inventory (`paths.yml` and `hosts` respectively) for the template to render correctly.

**Network configuration:** The MAT Common `networks.yml` contains the full set of service port definitions and host addresses — identical structure to `mat_fixed_network/test/group_vars/all/networks.yml`. This allows playbooks running under either inventory to resolve all `ports.*` and `hosts.*` variable references consistently. Both inventories share the same physical nodes and network topology.

**MAT Common test network ports (`networks.yml`) — key ports:**
- Prometheus (standalone): 61087
- AlertManager (standalone): 61089
- Pushgateway: 61001
- Node Exporter: 61088
- Process Exporter: 61077
- Blackbox Exporter: 61078
- Grafana: 61010 (legacy: 61010)
- Kafka KRaft broker: 61000, SSL: 61008, JMX exporter: 61002, exporter: 61001
- ClickHouse Keeper: TCP 9181, Raft 9234, metrics 61017
- ClickHouse Server: HTTP 61051, TCP 61052, metrics 61017
- Kafdrop: 61009
- MySQL: 61009
- HAProxy: kube_exporter 61000, kube_worker 61090, stats 61009, prometheus 61001, pushgateway 61002, app_mysql 61115, kafdrop 61005, grafana_monitor 61003, clickhouse 61004, druid 61006, harbor 61116, pgadmin 61007, longhorn 61008, librefs_console 61012, supabase 61011, supabase_api 61013
- Elasticsearch: 61003, exporter 61005, transport 9300
- Kubernetes API: 6443
- Monitoring Prometheus NodePort: 49400
- Monitoring AlertManager NodePort: 0 (disabled)
- Supabase: Kong 49410, Studio 3000, DB 5432, metrics 9542
- Longhorn NodePort: 49401
- PostgreSQL: internal 5432, NodePort 49402, metrics 9187
- pgAdmin NodePort: 49403
- LibreFS: API 9000, Console 9001, API NodePort 49405, Console NodePort 49406
- Grafana (K8s) NodePort: 0 (disabled, uses ingress)
- Harbor HTTP NodePort: 49404
- HAProxy DNS: `martini-test.nat.bt.com`

**Additional host groups (beyond mat_fixed_network/test):**
| Host Group | Nodes | IP Range |
|-----------|-------|----------|
| haproxy_fn | 1 | 10.6.97.10 (blt20919017, ansible_port=50022) |
| haproxy_ran | 1 | 10.50.126.57 (blt20919098, ansible_port=50022) |
| app_mysql | 1 | 10.11.21.82 (blt20919043) |
| longhorn_workers | 9 | 10.11.21.31–36, .242–244 (blt20919021–blt20919026, blt20919078–blt20919080) |
| librefs_workers | 6 | 10.11.21.31–36 (blt20919021–blt20919026) |
| supabase_workers | 3 | 10.11.21.34–36 (blt20919024–blt20919026) |
| elasticsearch | 1 | 10.11.21.37 (blt20919027) |
| prometheus | 1 | 10.11.21.37 (blt20919027) |
| zookeeper | 3 | 10.11.21.242–244 (blt20919078–blt20919080, zk_id=1–3) |
| hdfs (parent group) | 5 | (children: hdfs_name_node, hdfs_journal_node, hdfs_data_node) |
| hdfs_name_node1 | 1 | 10.11.21.242 (blt20919078) |
| hdfs_name_node2 | 1 | 10.11.21.243 (blt20919079) |
| hdfs_journal_node | 3 | 10.11.21.242–244 (blt20919078–blt20919080) |
| hdfs_data_node | 4 | 10.11.21.153, 10.11.21.242–244 (blt20919053, blt20919078–blt20919080) |
| druid (parent group) | 13 | (children: druid_coordinator, druid_overlord, druid_broker, druid_router, druid_historical, druid_middle_manager) |
| druid_coordinator | 2 | 10.11.21.245–246 (blt20919081–blt20919082) |
| druid_overlord | 2 | 10.11.21.245–246 (blt20919081–blt20919082) |
| druid_broker | 2 | 10.11.21.245–246 (blt20919081–blt20919082) |
| druid_router | 1 | 10.11.21.245 (blt20919081) |
| druid_historical | 4 | 10.11.21.249–250, 10.11.22.4–5 (blt20919085–blt20919086 druid_tier=hot druid_segment_cache_size=300g; blt20919088–blt20919089) |
| druid_middle_manager | 4 | 10.11.21.247–248, 10.11.22.6–7 (blt20919083–blt20919084 druid_worker_capacity=25; blt20919090–blt20919091 druid_worker_capacity=25) |
| druid_mysql | 1 | 10.11.21.245 (blt20919081) |
| grafana_monitoring | 1 | 10.11.21.149 (blt2019049) |
| kafka_kraft | 3 | 10.11.21.146–148 (blt20919046–blt20919048, nodeRole=broker,controller, nodeId=101121146–148) |
| kafdrop_kraft | 1 | 10.11.21.147 (blt20919047) |
| schema_registry | 3 | 10.11.21.146–148 (blt20919046–blt20919048) |
| exporter | 28 | 10.11.21.30–37, .39, .76–77, .146–153, .242–250 (blt20919020–blt20919027, blt20919029, blt20919036–blt20919037, blt20919046–blt20919053, blt20919078–blt20919086) |

The `app_mysql` group targets the MySQL database instance on blt20919043 at 10.11.21.82 (same node as mat_fixed_network/test `[app_mysql]` and `[grafana_user_mysql]`), enabling the MySQL role to run against the MAT Common test inventory. The `haproxy_fn` group targets the Fixed Network HAProxy load balancer (same node as mat_fixed_network/test `[haproxy]`). The `haproxy_ran` group targets the RAN HAProxy load balancer on the 10.50.x.x subnet. Both use `ansible_port=50022` for SSH access via the dedicated SFTP/SSH daemon. The `longhorn_workers` group is a subset of `kubernetes_worker_set1` — all 9 worker nodes used for Longhorn distributed storage prerequisites and disk management tasks. The `librefs_workers` group is a 6-node subset targeting nodes with `storage=true` label for libreFS distributed object storage. The `supabase_workers` group is a 3-node subset (blt20919024–blt20919026 at 10.11.21.34–36) targeting nodes with `app=mat_ai` label for Supabase pod scheduling, matching the Supabase topology configuration in `config_kubernetes.yml`. The `elasticsearch` group targets the Kubernetes-deployed Elasticsearch instance used for pod log storage (Fluent Bit → ES pipeline), versioned via `version.elk.elasticsearch` in the MAT Common test `versions.yml`. The `prometheus` group targets the same node (`blt20919027` at `10.11.21.37`) for standalone Prometheus deployment, enabling the Prometheus playbook to run against this inventory. The `grafana_monitoring` group targets the Grafana monitoring instance on blt2019049 at 10.11.21.149 (same node as the GitLab Runner), enabling the standalone Grafana monitoring playbook to run against the MAT Common test inventory. The `zookeeper` group targets a 3-node ZooKeeper ensemble on the same nodes as `kubernetes_worker_set1` (blt20919078–blt20919080), enabling the ZooKeeper coordination role to run against the MAT Common test inventory. The `hdfs` parent group enables the HDFS role to run against the MAT Common test inventory — it uses the same 3 worker nodes (blt20919078–blt20919080) as ZooKeeper for JournalNode roles, with NameNode1 on blt20919078 and NameNode2 on blt20919079 for HA failover. DataNode roles run on 4 nodes (blt20919067, blt20919078–blt20919080). The `druid` parent group enables the Druid OLAP analytics role to run against the MAT Common test inventory — it uses dedicated nodes (blt20919081–blt20919091) on the 10.11.21.245–250 and 10.11.22.4–7 subnets, with Coordinator/Overlord/Broker co-located on blt20919081–blt20919082, Historical nodes (blt20919085–blt20919086 with 300g segment cache, blt20919088–blt20919089 with 450g segment cache) on dedicated hosts with `hot` tier, Middle Manager nodes (blt20919083–blt20919084, blt20919090–blt20919091 with worker_capacity=25), and a co-located MySQL metadata store on blt20919081. The `druid_mysql` group identifies the MySQL instance used for Druid metadata storage. The `kafka_kraft` group targets a 3-node Kafka KRaft cluster (blt20919046–blt20919048 at 10.11.21.146–148) with all nodes serving as both broker and controller (nodeRole=broker,controller), enabling the Kafka KRaft role to run against the MAT Common test inventory. The `kafdrop_kraft` group targets a single Kafdrop instance on blt20919047 at 10.11.21.147 (one of the Kafka KRaft broker nodes), enabling the Kafdrop KRaft playbook to run against the MAT Common test inventory for Kafka topic browsing. The `schema_registry` group targets the same 3 Kafka KRaft nodes (blt20919046–blt20919048 at 10.11.21.146–148), enabling the Schema Registry role to run against the MAT Common test inventory for schema management alongside the Kafka brokers. The `exporter` group targets all 28 infrastructure nodes (including ZooKeeper, Druid, and Kubernetes nodes) for node/process exporter deployment.

**Monitoring configuration** (`config_monitoring.yml`): Standalone Prometheus and AlertManager settings for the test environment:
- Prometheus retention: 30d
- AlertManager: to `martini.asg@bt.com`, cc `suraj.tomar@bt.com` + `sujit.kumarsahu@bt.com` + `aniket.vijaykumarambi@bt.com` + `martini-devops@bt.com`, from `noreply.martini@bt.com`, SMTP `smtpb.intra.bt.com:25`, group_wait 5m, P1/P2/P3 repeat intervals 2h/6h/24h, resolve_timeout 48h

**Database configuration** (`config_database.yml`): Druid OLAP cluster settings for the test environment:
- Auth: enabled (`auth_enabled: true`)
- Extensions: `druid-kafka-indexing-service`, `druid-histogram`, `druid-datasketches`, `druid-lookups-cached-global`, `mysql-metadata-storage`, `druid-multi-stage-query`, `druid-hdfs-storage`, `prometheus-emitter`, `druid-basic-security`, `simple-client-sslcontext`
- MySQL metadata store: host `10.11.21.245`, port `61010`, db `druid`, user `druid`
- HDFS deep storage: cluster name `MartiniEERan`
- Coordinator: heap 2g, period PT300S, poll duration PT60S
- Overlord: heap 2g
- Broker: heap 2g, direct memory 2g, 60 HTTP threads, 25 connections, processing threads 8, buffer 100MiB, Avatica max connections 35
- Router: heap 1g, direct memory 256m, 50 HTTP connections/threads
- Historical: heap min 1g / max 3g, direct memory 3g, tier `hot`, segment cache 500g, 8 threads, buffer 100MiB, cache 250MiB
- Middle Manager: heap 1g, direct memory 512m, worker capacity 10, peon heap 1g, peon direct memory 2g

### Host Groups Per Environment (barista)

#### Test Environment — Host Groups

**Architecture:** Dual-zone Kubernetes cluster with masters and workers split into zone-based child groups (zone1 and zone2). Uses `kubernetes_master_zone2` as the init master (`ansible_connection=local`).

| Host Group | Nodes | IP Range | Zone |
|-----------|-------|----------|------|
| kubernetes_master_zone1 | 1 | 10.13.88.53 (blt25082008) | zone1 |
| kubernetes_master_zone2 (init) | 1 | 10.13.149.184 (blt25082005, ansible_connection=local) | zone2 |
| kubernetes_worker_zone1 | 3 | 10.13.88.47–49 (blt25082001–blt25082003) | zone1 |
| kubernetes_worker_zone2 | 4 | 10.13.149.183, .185–187 (blt25082004, blt25082009–blt25082011) | zone2 |
| librefs_workers | 1 | 10.13.149.183 (blt25082004) | zone2 |
| kubernetes_master_supabase | 1 | (children: kubernetes_master_zone2) | zone2 |
| kubernetes_master_falkordb | 1 | (children: kubernetes_master_zone2) | zone2 |

**Group hierarchy:**
- `kubernetes:children` → `kubernetes_master` + `kubernetes_worker`
- `kubernetes_master:children` → `kubernetes_master_zone1` + `kubernetes_master_zone2`
- `kubernetes_worker:children` → `kubernetes_worker_zone1` + `kubernetes_worker_zone2`
- `kubernetes_master_supabase:children` → `kubernetes_master_zone2`
- `kubernetes_master_falkordb:children` → `kubernetes_master_zone2`

**Network subnets:**
- Zone1: 10.13.88.x
- Zone2: 10.13.149.x

**Host naming:** `blt25082001–blt25082011` (prefix `blt`, test nodes)

**Note:** The `librefs_workers` group targets a single dedicated node (blt25082004 at 10.13.149.183) in zone2, which is also part of `kubernetes_worker_zone2`. This node hosts libreFS object storage for the test environment.

#### CST Environment — Host Groups

**Architecture:** Dual-zone Kubernetes cluster with 2 masters (one per zone) and workers split across both zones. Uses `kubernetes_master_zone1` (10.11.54.x) and `kubernetes_master_zone2` (10.11.39.x, `ansible_connection=local`) for control plane HA. Zone 1 has 10 worker nodes and zone 2 has 4 worker nodes. Application-specific worker groups for Kafka, MongoDB, Supabase, and libreFS workloads.

| Host Group | Nodes | IP Range | Purpose |
|-----------|-------|----------|---------|
| kubernetes_master_zone1 | 1 | 10.11.54.54 (bld25082013, ansible_connection=local) | K8s control plane (zone 1) |
| kubernetes_master_zone2 | 1 | 10.11.39.209 (bld25082002, ansible_connection=local) | K8s control plane (zone 2) |
| kubernetes_worker_zone1 | 10 | 10.11.54.45–57 (bld25082001, bld25082006–bld25082010, bld25082012, bld25082014–bld25082016) | General K8s workloads (zone 1) |
| kubernetes_worker_zone2 | 4 | 10.11.39.210–213 (bld25082003–bld25082005, bld25082011, ansible_connection=local) | General K8s workloads (zone 2) |
| kafka_workers | 3 | 10.11.39.210–212 (bld25082003–bld25082005) | Kafka (Strimzi) scheduling |
| mongodb_workers | 1 | 10.11.39.211 (bld25082004) | MongoDB (Percona) scheduling |
| supabase_workers | 4 | 10.11.39.210–213 (bld25082003–bld25082005, bld25082011) | Supabase application |
| librefs_workers | 1 | 10.11.39.213 (bld25082011) | LibreFS object storage |
| longhorn_workers | 4 | (children: kubernetes_worker_zone2) | Longhorn distributed storage |
| kubernetes_master_supabase | 1 | (children: kubernetes_master_zone2) | Supabase master access |
| kubernetes_master_falkordb | 1 | (children: kubernetes_master_zone2) | FalkorDB master access |

**Group hierarchy:**
- `kubernetes:children` → `kubernetes_master` + `kubernetes_worker`
- `kubernetes_master:children` → `kubernetes_master_zone1` + `kubernetes_master_zone2`
- `kubernetes_worker:children` → `kubernetes_worker_zone1` + `kubernetes_worker_zone2`
- `longhorn_workers:children` → `kubernetes_worker_zone2`
- `kubernetes_master_supabase:children` → `kubernetes_master_zone2`
- `kubernetes_master_falkordb:children` → `kubernetes_master_zone2`

**Network subnets:**
- Zone 1: 10.11.54.x (workers + master)
- Zone 2: 10.11.39.x (workers + master)

**Host naming:** `bld25082001–bld25082016` (prefix `bld`, CST nodes)

**Note:** The CST environment is a dual-zone cluster with masters and workers split across two subnets (10.11.54.x and 10.11.39.x) for zone-aware scheduling. Zone 1 hosts 10 worker nodes and zone 2 hosts 4 worker nodes. All zone 2 nodes (both masters and workers) use `ansible_connection=local` — the Ansible runner is co-located on the 10.11.39.x subnet. Zone 1 master (bld25082013) also uses `ansible_connection=local`. MongoDB uses a single replica (no HA), and libreFS runs in single-node mode. `barista_users` group lists all zone 2 nodes by IP for user management tasks. This layout mirrors the Barista test environment's dual-zone pattern (`kubernetes_master_zone1` + `kubernetes_master_zone2` + `kubernetes_worker_zone1` + `kubernetes_worker_zone2`).

#### CST Environment — Kubernetes Config (`config_kubernetes.yml`)
- Ansible user: `gitlab-runner`
- **Dockerless cluster:** pod CIDR `192.168.0.0/16`, service CIDR `10.96.0.0/12`, NodePort range `49400-49799`, control plane endpoint `barista.cst.nat.bt.com:61012`, max pods 150, cgroups v2, containerd sandbox `registry.k8s.io/pause:3.10`, cert renewal enabled (weekly Monday 03:07), no_proxy includes `10.11.39.0/24`
- **Ingress Controller (HAProxy):** timeouts client/server 5m, connect 10s, resources 100m–500m CPU / 256Mi–512Mi memory
- **Logging (Fluent Bit):** namespace `kube-system`, ES target `10.11.39.209:61003`, match `_barista-cst_`, log level warn
- **Longhorn:** worker group `kubernetes_worker`, 2 replicas, storage reserved 25%, minimal available 15%, engine guaranteed CPU 100m, backup to libreFS S3 (`http://librefs.librefs.svc.cluster.local:9000`, bucket `longhorn-backups`, daily cron `0 2 * * *`, retain 7, concurrency 2)
- **Kafka (Strimzi):** namespace `kafka`, cluster `barista-kafka-cluster`, 3 brokers + 3 controllers, Longhorn storage (broker 8Gi, controller 4Gi), replication factor 3, min ISR 2, 3 partitions, 6h retention, metrics enabled, topology spread on `node-role.kubernetes.io/kafka` by hostname (no rack awareness)
- **MongoDB (Percona):** namespace `mongodb`, cluster `mongodb-rs`, 1 replica (no HA for CST), Longhorn 30Gi, resources 500m–2000m CPU / 1Gi–4Gi memory, metrics enabled, backup disabled, topology spread on `node-role.kubernetes.io/mongodb`
- **Supabase:** namespace `supabase`, release `supabase`, built-in DB (Longhorn 20Gi), ingress on `barista.cst.nat.bt.com/supabase` (Kong class, no TLS), 1 replica for kong/auth/rest/studio/realtime, realtime enabled, metrics enabled, no node targeting (topology labels empty), analytics disabled, vector disabled
- **LibreFS:** namespace `librefs`, release `librefs`, single-node mode, 1 replica, root user `admin`, hostPath `/apps/librefs_data`, worker group `librefs_workers`, node label targeting (`node-role.kubernetes.io/librefs=true`), resources 250m–2000m CPU / 512Mi–2Gi memory
- **FalkorDB:** namespace `falkordb`, release `falkordb`, 3 replicas, auth enabled, NodePort service, persistence 8Gi (appendonly + RDB snapshots, save schedule: 900/1, 300/10, 60/10000), Sentinel HA (down_after 5000ms, failover timeout 60000ms), module params: THREAD_COUNT 4, CACHE_SIZE 25, RESULTSET_SIZE 10000, MAX_QUEUED_QUERIES 25, TIMEOUT 0, resources master/replica 1–2 CPU / 2Gi–4Gi memory, sentinel 100m–200m CPU / 128Mi–256Mi memory, no node targeting (topology labels empty), verification_timeout 300
- **Monitoring:** Prometheus retention 5m, min/max block duration 15m

#### Pre-Prod Environment — Host Groups

**Architecture:** Multi-DC (3 sites) Kubernetes cluster spanning Reigate, Derby, and St Albans data centres. Masters and workers are split into region-specific child groups for zone-aware scheduling and rack-aware replication.

| Host Group | Nodes | IP Range | Site |
|-----------|-------|----------|------|
| kubernetes_master_reigate (init) | 1 | 10.6.103.198 (ansible_connection=local) | Reigate |
| kubernetes_master_derby (join) | 1 | 10.55.4.226 | Derby |
| kubernetes_master_stalbans (join) | 1 | 10.13.92.108 | St Albans |
| kubernetes_worker_reigate | 3 | 10.6.103.199–201 | Reigate |
| kubernetes_worker_derby | 3 | 10.55.4.227–229 | Derby |
| kubernetes_worker_stalbans | 3 | 10.13.92.109–111 | St Albans |
| kafka_workers | 3 | 10.6.103.200, 10.55.4.228, 10.13.92.110 | 1 per site |
| mongodb_workers | 3 | 10.6.103.201, 10.55.4.229, 10.13.92.111 | 1 per site |
| postgres_workers | 3 | 10.6.103.199, 10.55.4.227, 10.13.92.109 | 1 per site |
| supabase_workers | 9 | all workers (10.6.103.199–201, 10.55.4.227–229, 10.13.92.109–111) | all sites |
| longhorn_workers | 12 | all workers + librefs (10.6.103.199–202, 10.55.4.227–230, 10.13.92.109–112) | all sites |
| minio_workers | 3 | 10.6.103.202, 10.55.4.230, 10.13.92.112 | 1 per site |
| librefs_workers | 3 | 10.6.103.202, 10.55.4.230, 10.13.92.112 | 1 per site (same as minio) |
| gitlab_runner | 1 | 10.6.103.198 (blp25082077, same as init master) | Reigate |
| buildkit_nerdctl_zone1 | 3 | 10.11.74.102, 10.54.124.65, 10.13.103.82 (blp25082065–blp25082067, ansible_connection=local) | 1 per site |

**Group hierarchy:**
- `kubernetes_master:children` → `kubernetes_master_init` + `kubernetes_master_join`
- `kubernetes_master_init:children` → `kubernetes_master_reigate`
- `kubernetes_master_join:children` → `kubernetes_master_derby` + `kubernetes_master_stalbans`
- `kubernetes_worker:children` → `kubernetes_worker_reigate` + `kubernetes_worker_derby` + `kubernetes_worker_stalbans`
- `longhorn_workers:children` → `kubernetes_worker_reigate` + `kubernetes_worker_derby` + `kubernetes_worker_stalbans` + `librefs_workers`

**Application worker distribution:** Each application-specific group (`kafka_workers`, `mongodb_workers`, `postgres_workers`) has exactly one node per site, enabling zone-aware topology spread. `supabase_workers` spans all 9 worker nodes. `longhorn_workers` spans all 9 worker nodes plus the 3 `librefs_workers` nodes (blp25082089–091), totalling 12 nodes. `minio_workers` and `librefs_workers` use 3 dedicated nodes (blp25082089–091) with one per site. The `gitlab_runner` runs on the Reigate init master node (blp25082077).

**Network subnets:**
- Reigate: 10.6.103.x
- Derby: 10.55.4.x
- St Albans: 10.13.92.x

**Host naming:** `blp25082065–blp25082067`, `blp25082077–blp25082091` (prefix `blp`, pre-prod nodes)

#### Prod Environment — Host Groups

**Architecture:** Multi-DC (3 sites) Kubernetes cluster spanning Derby, Reigate, and St Albans data centres. Masters and workers are split into region-specific child groups for zone-aware scheduling and rack-aware replication. Unlike pre-prod, the **init master is at Derby** (not Reigate). The init master (`blp25082025` at Derby) uses `ansible_connection=local`.

| Host Group | Nodes | IP Range | Site |
|-----------|-------|----------|------|
| Kubernetes_master_derby (init) | 1 | 10.6.103.192 (blp25082025, ansible_connection=local) | Derby |
| Kubernetes_master_reigate (join) | 1 | 10.55.4.220 (blp25082026) | Reigate |
| Kubernetes_master_stalbans (join) | 1 | 10.13.92.102 (blp25082027) | St Albans |
| kubernetes_worker_derby | 5 | 10.6.103.193–197 (blp25082028–031, blp25082044) | Derby |
| kubernetes_worker_reigate | 5 | 10.55.4.221–225 (blp25082032–035, blp25082045) | Reigate |
| kubernetes_worker_stalbans | 5 | 10.13.92.103–107 (blp25082036–039, blp25082046) | St Albans |
| kafka_workers | 3 | 10.6.103.193, 10.55.4.221, 10.13.92.103 | 1 per site |
| mongodb_workers | 3 | 10.6.103.194, 10.55.4.222, 10.13.92.105 | 1 per site |
| minio_workers | 3 | 10.6.103.196, 10.13.92.106, 10.55.4.225 | 1 per site |
| supabase_workers | 15 | all workers (10.6.103.193–197, 10.55.4.221–225, 10.13.92.103–107) | all sites |
| librefs_workers | 4 | 10.6.103.197, 10.55.4.225, 10.13.92.106–107 | Derby/Reigate + 2× St Albans |
| samba_check | 1 | 10.54.124.64 (blp25082055) | — |
| kubernetes_master_zone1 | 3 | 10.11.74.82, 10.54.124.56, 10.13.103.62 (blp25082004–006) | legacy zone1 (unused by hierarchy) |
| Kubernetes_workers_zone1 | 23 | 10.11.74.x, 10.54.124.x, 10.13.103.x (blp25082001–024) | legacy zone1 (unused by hierarchy) |

**Group hierarchy:**
- `kubernetes:children` → `kubernetes_master` + `kubernetes_worker`
- `kubernetes_master:children` → `kubernetes_master_init` + `kubernetes_master_join`
- `kubernetes_master_init:children` → `Kubernetes_master_derby`
- `kubernetes_master_join:children` → `Kubernetes_master_reigate` + `Kubernetes_master_stalbans`
- `kubernetes_worker:children` → `kubernetes_worker_derby` + `kubernetes_worker_reigate` + `kubernetes_worker_stalbans`

**Application worker distribution:** Each application-specific group (`kafka_workers`, `mongodb_workers`, `minio_workers`) has one node per site for zone-aware topology spread. `supabase_workers` spans all 15 worker nodes. `librefs_workers` uses 4 nodes (the storage nodes blp25082044–046 plus blp25082039 at St Albans).

**Network subnets:**
- Derby: 10.6.103.x
- Reigate: 10.55.4.x
- St Albans: 10.13.92.x
- Legacy zone1 (unused): 10.11.74.x, 10.54.124.x, 10.13.103.x

**Host naming:** `blp25082001–blp25082055` (prefix `blp`, prod nodes)

**Note:** The active multi-DC cluster uses the region-based master/worker groups (Derby init + Reigate/Stalbans join). The `kubernetes_master_zone1` and `Kubernetes_workers_zone1` groups (blp25082001–024 on the 10.11.74.x / 10.54.124.x / 10.13.103.x subnets) are legacy zone-based groups not wired into the `kubernetes` group hierarchy. The `samba_check` group (blp25082055) is a standalone node for Samba connectivity checks. Group name casing is inconsistent in the hosts file (`Kubernetes_master_derby`, `Kubernetes_workers_zone1`) — Ansible group names are case-sensitive, so playbook `target_host` references must match the exact casing.

#### Pre-Prod Environment — Kubernetes Config (`config_kubernetes.yml`)
- Ansible user: `app-manager`
- **Longhorn:** worker group `longhorn_workers`, 2 replicas, storage reserved 25%, minimal available 15%, engine guaranteed CPU 200m, backup to libreFS S3 (`http://librefs.librefs.svc.cluster.local:9000`, bucket `longhorn-backups`, daily cron `0 2 * * *`, retain 7, concurrency 2)
- **Kafka (Strimzi):** namespace `kafka`, cluster `barista-kafka-cluster`, 3 brokers + 3 controllers, Longhorn storage (broker 20Gi, controller 4Gi), replication factor 3, min ISR 2, 3 partitions, 24h retention, metrics enabled, topology spread on `node-role.kubernetes.io/kafka` by region (`topology.kubernetes.io/region`, max_skew 1) with rack awareness (`rack_topology_key: topology.kubernetes.io/region`)
- **MongoDB (Percona):** namespace `mongodb`, cluster `mongodb-rs`, 3 replicas, Longhorn 50Gi, resources 500m–2000m CPU / 1Gi–4Gi memory, metrics enabled, expose enabled (per-member NodePort for external replica set access, external hostname `barista.preprod.nat.bt.com`, split horizons: `barista.preprod.nat.bt.com:61017`, `barista.preprod.nat.bt.com:61018`, `barista.preprod.nat.bt.com:61019`), topology spread on `node-role.kubernetes.io/mongodb` by region (`topology.kubernetes.io/region`)
- **LibreFS:** namespace `librefs`, distributed mode, 4 replicas, root user `admin`, hostPath `/apps/librefs_data`, storage 250Gi, worker group `librefs_workers`, node label targeting (`node-role.kubernetes.io/librefs=true`), resources 250m–2000m CPU / 512Mi–2Gi memory
- **Kafka UI (Kafbat):** namespace `kafka`, release `kafka-ui`, cluster `barista-preprod` (bootstrap `barista-kafka-cluster-kafka-bootstrap.kafka.svc:9092`, readonly, topic delete/create disabled), LDAP auth (`iuserldap.nat.bt.com:389`, sAMAccountName filter, search base `ou=employee,ou=btplc,dc=iuser,dc=iroot,dc=adidom,dc=com`), RBAC with LDAP group mappings (admin: `mygrp-ddops-kafkaui-admin` → ALL on applicationconfig/clusterconfig/topic/consumer/schema/connect + VIEW ACL, developer: `mygrp-ddops-kafkaui-developer` → VIEW+MESSAGES_READ on topics/consumers/schemas + VIEW clusterconfig, viewer: `mygrp-ddops-kafkaui-viewer` → VIEW+MESSAGES_READ on topics/consumers + VIEW clusterconfig), resources 100m–500m CPU / 256Mi–512Mi memory

#### Prod Environment — Kubernetes Config (`config_kubernetes.yml`)
- Ansible user: `app-manager`
- **Dockerless cluster:** pod CIDR `192.168.0.0/16`, service CIDR `10.96.0.0/12`, NodePort range `49400-49799`, control plane endpoint `barista.nat.bt.com:61012`, max pods 150, cgroups v2, containerd sandbox `registry.k8s.io/pause:3.10`, cert renewal enabled (weekly Monday 03:07)
- **Ingress Controller (HAProxy):** timeouts client/server 5m, connect 10s, resources 100m–500m CPU / 256Mi–512Mi memory
- **Logging (Fluent Bit):** namespace `kube-system`, ES target `10.6.102.112:61003`, match `kube.*`, log level warn
- **Node labels:** `librefs_workers` → `node-role.kubernetes.io/librefs=true`, `tier=data`
- **Longhorn:** worker group `kubernetes_worker`, 2 replicas, storage reserved 25%, minimal available 15%, engine guaranteed CPU 200m
- **Kafka (Strimzi):** namespace `kafka`, cluster `barista-kafka-cluster`, 3 brokers + 3 controllers, Longhorn storage (broker 20Gi, controller 4Gi), replication factor 3, min ISR 2, 3 partitions, 24h retention, metrics enabled, topology spread on `node-role.kubernetes.io/kafka` with rack awareness
- **MongoDB (Percona):** namespace `mongodb`, cluster `mongodb-rs`, 3 replicas, Longhorn 50Gi, resources 500m–2000m CPU / 1Gi–4Gi memory, metrics enabled, expose enabled (per-member NodePort for external replica set access, configurable via `ports.kubernetes.mongodb.nodeports` list), topology spread on `node-role.kubernetes.io/mongodb`
- **Supabase:** namespace `supabase`, release `supabase`, endpoint `http://supabase.barista.prod.nat.bt.com`, built-in DB (Longhorn 20Gi), S3 storage enabled (LibreFS backend: `http://librefs.librefs.svc.cluster.local:9000`, bucket `supabase-storage`), ingress on `http://supabase.barista.prod.nat.bt.com/` (Kong class, no TLS), 3 replicas for kong/auth/rest/studio/realtime, realtime enabled, metrics enabled, node targeting `node-role.kubernetes.io/supabase`, pinned image tags: db `15.8.1.085`, kong `3.9.1`, studio `2026.06.03-sha-0bca601`, auth `v2.189.0`, rest `v14.12`, realtime `v2.105.1`, storage `v1.60.4`, meta `v0.96.6`, functions `v1.74.0`, imgproxy `v3.30.1`
- **LibreFS:** namespace `librefs`, release `librefs`, distributed mode, 4 replicas, root user `admin`, hostPath `/apps/librefs_data`, worker group `librefs_workers`, node label targeting (`node-role.kubernetes.io/librefs=true`), resources 250m–2000m CPU / 512Mi–2Gi memory
- **Kafka UI (Kafbat):** namespace `kafka`, release `kafka-ui`, cluster `barista-prod` (bootstrap `barista-kafka-cluster-kafka-bootstrap.kafka.svc:9092`, readonly), LOGIN_FORM auth with admin/developer/viewer users, RBAC (admin: ALL, dev-readwrite: VIEW_TOPIC+VIEW_CONSUMER on barista-prod, readonly: VIEW_TOPIC+VIEW_CONSUMER on all)
- **FalkorDB:** namespace `falkordb`, release `falkordb`, graph database deployed via Bitnami Redis Helm chart with FalkorDB module override, Sentinel HA topology (3 replicas + quorum 2), HAProxy master-only proxy with NodePort 61085, browser UI NodePort 61084, auth enabled, persistence 16Gi (appendonly + RDB snapshots, save schedule: 900/1, 300/10, 60/10000), module params: THREAD_COUNT 8, CACHE_SIZE 50, RESULTSET_SIZE 10000, MAX_QUEUED_QUERIES 50, TIMEOUT 0, resources master/replica 2–4 CPU / 4Gi–8Gi memory, sentinel 100m–250m CPU / 128Mi–256Mi memory, node targeting via `node-role.kubernetes.io/falkordb=true`, topology spread on `topology.kubernetes.io/region` (max_skew 1), rack-aware replication enabled (rack_topology_key: `topology.kubernetes.io/region`), verification_timeout 600
- **Monitoring:** Prometheus retention 30d, min/max block duration 15m

### Host Groups Per Environment (bhrigu)

#### Pre-Prod Environment — Host Groups

**Architecture:** Kubernetes cluster with dedicated application-specific worker groups for Kafka, Prometheus, MongoDB, LibreFS, and Supabase workloads. Uses `kubernetes_master_init` / `kubernetes_master_join` naming convention. The `kubernetes_worker_kafka` and `kubernetes_worker_prometheus` groups are children of `kubernetes_worker` — they participate in general Kubernetes worker operations (upgrades, prerequisites) as well as application-level topology scheduling.

| Host Group | Nodes | IP Range | Purpose |
|-----------|-------|----------|---------|
| kubernetes_master_init | 1 | 10.6.102.254 (blp20919338, ansible_connection=local) | K8s control plane init |
| kubernetes_master_join | 2 | 10.6.102.236–237 (blp20919320–blp20919321) | K8s control plane join |
| kubernetes_worker_set1 | 11 | 10.6.102.237–244, .246, .248–249 (blp20919321–blp20919328, blp20919330, blp20919332–blp20919333) | General K8s workloads |
| kubernetes_worker_kafka | 3 | 10.6.102.250–252 (blp20919334–blp20919336) | Kafka workloads |
| kubernetes_worker_prometheus | 1 | 10.6.102.253 (blp20919337) | Prometheus workloads |
| supabase_workers | 15 | 10.6.102.237–244, .246, .248–253 (blp20919321–blp20919328, blp20919330, blp20919332–blp20919337) | Supabase application |
| kafka_workers | 3 | 10.6.102.250–252 (blp20919334–blp20919336) | Kafka (Strimzi) scheduling |
| mongodb_workers | 3 | 10.6.102.246, .248–249 (blp20919330, blp20919332–blp20919333) | MongoDB (Percona) scheduling |
| librefs_workers | 4 | 10.6.102.241–244 (blp20919325–blp20919328) | LibreFS object storage |
| haproxy | 1 | 10.6.102.254 (blp20919338) | External LB for K8s services |
| prometheus | 1 | 10.6.102.253 (blp20919337) | Prometheus monitoring |

**Group hierarchy:**
- `kubernetes:children` → `kubernetes_master` + `kubernetes_worker`
- `kubernetes_master:children` → `kubernetes_master_init` + `kubernetes_master_join`
- `kubernetes_worker:children` → `kubernetes_worker_set1` + `kubernetes_worker_kafka` + `kubernetes_worker_prometheus`

**Network subnets:** 10.6.102.x (service tier)

**Note:** The inventory includes `kubernetes_worker_kafka` and `kubernetes_worker_prometheus` as children of `kubernetes_worker`, so they participate in general Kubernetes worker operations (upgrades, prerequisites, Longhorn storage) in addition to being used for application-level topology constraints (Kafka Strimzi scheduling, Prometheus workloads). Node `blp20919321` (10.6.102.237) serves a dual role — it is listed in both `kubernetes_master_join` and `kubernetes_worker_set1`, acting as both a control plane member and a general worker. The `haproxy` group targets the same node as `kubernetes_master_init` (blp20919338 at 10.6.102.254) — HAProxy is co-located on the init master and routes external traffic (`bhrigu-martini-preprod.nat.bt.com`) to K8s NodePorts via SSL termination. Legacy standalone MySQL, ZooKeeper, Kafka, Grafana, and observability groups are not present. All services run on Kubernetes with dedicated application-specific worker groups (`kafka_workers`, `mongodb_workers`, `librefs_workers`) for topology-aware scheduling.

#### Pre-Prod Environment — Kubernetes Config (`config_kubernetes.yml`)
- Ansible user: `app-manager`
- **Dockerless cluster:** Kubernetes 1.36 (full: 1.36.2), Calico 3.32.0, pod CIDR `192.168.0.0/16`, service CIDR `10.96.0.0/12`, NodePort range `49400-49799`, control plane endpoint `bhrigu-martini-preprod.nat.bt.com:61043`, max pods 150, cgroups v2, containerd sandbox `registry.k8s.io/pause:3.10`, cert renewal enabled (weekly Monday 03:07)
- **Ingress Controller (HAProxy):** timeouts client/server 5m, connect 10s, resources 100m–500m CPU / 256Mi–512Mi memory
- **Logging (Fluent Bit):** namespace `kube-system`, backend `loki` (Loki connection: `loki.loki.svc.cluster.local:3100`), match ALL pods (empty string pattern `""` — collects `/var/log/containers/*.log` from all containers), input path `/var/log/containers/*.log`, log level warn. Elasticsearch config kept for reference (switch `backend` to `elasticsearch` to use).
- **Loki (K8s StatefulSet):** namespace `loki`, release `loki`, Longhorn PVC 20Gi, HTTP port 3100, gRPC port 9096, retention 336h (14 days), ingestion rate 10MB/s burst 20MB/s, max streams 10000, resources 100m–1000m CPU / 256Mi–1Gi memory. Access: Grafana → Add data source → Loki → `http://loki.loki.svc.cluster.local:3100`
- **Node labels:** `librefs_workers` → `node-role.kubernetes.io/librefs=true`, `tier=data`
- **Longhorn:** worker group `kubernetes_worker`, 2 replicas, storage reserved 25%, minimal available 15%, engine guaranteed CPU 200m
- **Kafka (Strimzi):** namespace `kafka`, cluster `bhrigu-kafka-cluster`, 3 brokers + 3 controllers, Longhorn storage (broker 20Gi, controller 4Gi), replication factor 3, min ISR 2, 3 partitions, 24h retention, metrics enabled, topology spread on `node-role.kubernetes.io/kafka` by hostname (single-DC, no rack awareness)
- **MongoDB (Percona):** namespace `mongodb`, cluster `mongodb-rs`, 3 replicas, Longhorn 50Gi, resources 500m–2000m CPU / 1Gi–4Gi memory, metrics enabled, expose enabled (per-member NodePort for external replica set connections, external hostname `bhrigu-martini-preprod.nat.bt.com`, split horizons: `bhrigu-martini-preprod.nat.bt.com:49474`, `bhrigu-martini-preprod.nat.bt.com:49475`, `bhrigu-martini-preprod.nat.bt.com:49476`), topology spread on `node-role.kubernetes.io/mongodb`
- **Supabase:** namespace `supabase`, release `supabase`, endpoint `http://supabase.bhrigu-martini-preprod.nat.bt.com`, built-in DB (Longhorn 20Gi), S3 storage enabled (LibreFS backend: `http://librefs.librefs.svc.cluster.local:9000`, bucket `supabase-storage`), ingress on `supabase.bhrigu-martini-preprod.nat.bt.com/` (Kong class, no TLS), 3 replicas for kong/auth/rest/studio/realtime, realtime enabled, metrics enabled, node targeting `node-role.kubernetes.io/supabase`
- **LibreFS:** namespace `librefs`, release `librefs`, distributed mode, 4 replicas, root user `admin`, hostPath `/apps/librefs_data`, worker group `librefs_workers`, node label targeting (`node-role.kubernetes.io/librefs=true`), resources 250m–2000m CPU / 512Mi–2Gi memory
- **Kafka UI (Kafbat):** namespace `kafka`, release `kafka-ui`, cluster `bhrigu-preprod` (bootstrap `bhrigu-kafka-cluster-kafka-bootstrap.kafka.svc:9092`, readonly), LOGIN_FORM auth with admin/developer/viewer users, RBAC (admin: ALL, dev-readwrite: VIEW_TOPIC+VIEW_CONSUMER on bhrigu-preprod, readonly: VIEW_TOPIC+VIEW_CONSUMER on all)
- **FalkorDB:** namespace `falkordb`, release `falkordb`, 3 replicas, auth enabled, NodePort service, persistence 16Gi (appendonly + RDB snapshots, save schedule: 900/1, 300/10, 60/10000), Sentinel HA (down_after 5000ms, failover timeout 60000ms), module params: THREAD_COUNT 8, CACHE_SIZE 50, RESULTSET_SIZE 10000, MAX_QUEUED_QUERIES 50, TIMEOUT 0, resources master/replica 2–4 CPU / 4Gi–8Gi memory, sentinel 100m–250m CPU / 128Mi–256Mi memory, topology spread on `node-role.kubernetes.io/falkordb` with rack awareness (`topology.kubernetes.io/region`, max_skew 1), verification_timeout 600
- **Grafana:** namespace `grafana`, 2 replicas, port 3000, base path `/grafana`, ingress enabled via HAProxy on `bhrigu-martini-preprod.nat.bt.com`, external PostgreSQL (Supabase built-in DB: `supabase-supabase-db.supabase.svc.cluster.local:5432`, db `grafana`, user `grafana`, ssl_mode disable), SMTP enabled (`smtpb.intra.bt.com:25`, from `noreply.martini@bt.com`), LDAP enabled (`iuserldap.nat.bt.com:389`, bind DN `CN=SA989156,OU=functional,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com`, sAMAccountName filter, search base `ou=employee,ou=btplc,dc=iuser,dc=iroot,dc=adidom,dc=com`, group mappings: `mygrp-BhriguAdminGrafana` → Admin (grafana_admin) orgs 1–4, `mygrp-BhriguEditorGrafana` → Editor orgs 1–4, `mygrp-BhriguViewerGrafanaEECore` → Viewer org 2, `mygrp-BhriguViewerGrafanaFixed` → Viewer org 4), plugins: `grafana-piechart-panel`, `grafana-polystat-panel`, `grafana-clock-panel`, `yesoreyeram-infinity-datasource`, `flant-statusmap-panel`, `marcusolsson-dynamictext-panel`
- **Monitoring:** Prometheus retention 30d, min/max block duration 15m, AlertManager disabled

#### Pre-Prod Environment — HAProxy Config (`configs/haproxy/haproxy.cfg.j2`)

The Bhrigu pre-prod HAProxy config is a dynamic Jinja2 template that routes external traffic to Kubernetes NodePorts. All services run inside Kubernetes — HAProxy is the external entry point. DNS: `bhrigu-martini-preprod.nat.bt.com` → HAProxy.

**Global settings:** SSL DH param 2048, log to 127.0.0.1:514 local0
**Defaults:** log global, option dontlognull, timeout connect 10s, timeout client 2m, timeout server 2m

All frontends use SSL termination with `{{ paths.ssl_certs.base_dir }}/certificate2023.pem` and disable SSLv3/TLSv1.0/TLSv1.1. It proxies the following services:

- **Stats interface** — binds `ports.haproxy.stats` with SSL, exposes Prometheus metrics at `/metrics` and stats UI at `/stats`
- **Kubernetes API Server** — binds `ports.haproxy.kube_api`, TCP mode, backends loop over `groups['kubernetes_master']` on port 6443
- **Kubernetes Worker Nodes** — binds `ports.haproxy.kube_worker` with SSL, HTTP mode with `X-Forwarded-Proto` and `Host` headers (default `bhrigu-martini-preprod.nat.bt.com`), backends loop over `groups['kubernetes_worker']` on port 80 (Ingress Controller hostPort)
- **Prometheus** — binds `ports.haproxy.prometheus` with SSL, TCP mode, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.monitoring.prometheus`
- **AlertManager** — binds `ports.haproxy.alertmanager` with SSL, TCP mode, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.monitoring.alertmanager`
- **Grafana Monitor** — binds `ports.haproxy.grafana_monitor` with SSL, HTTP mode with `X-Forwarded-Proto`, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.grafana.nodeport`
- **Kafka UI (Kafbat)** — binds `ports.haproxy.kafdrop` with SSL, TCP mode, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.kafka_ui.nodeport`
- **Longhorn UI** — binds `ports.haproxy.longhorn` with SSL, HTTP mode with `X-Forwarded-Proto`, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.longhorn.node_port`
- **libreFS Console** — binds `ports.haproxy.librefs_console` with SSL, HTTP mode with `X-Forwarded-Proto`, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.librefs.console_nodeport`
- **Supabase (Kong API Gateway)** — binds `ports.haproxy.supabase` with SSL, HTTP mode with `X-Forwarded-Proto` and `X-Forwarded-Port`, backends loop over `groups['kubernetes_worker']` on `ports.kubernetes.supabase.kong_nodeport`
- **MongoDB** — binds `ports.haproxy.mongodb` with SSL, TCP mode, backends loop over `groups['mongodb_workers']` on `ports.kubernetes.mongodb.nodeports[loop.index0]` (per-member NodePort)
- **FalkorDB** — binds `ports.haproxy.falkordb` with SSL, TCP mode, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.falkordb.node_port`
- **FalkorDB Browser UI** — binds `ports.haproxy.falkordb_browser` with SSL, HTTP mode with `X-Forwarded-Proto`, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.falkordb.browser_ui`
- **Superset** — binds `ports.haproxy.superset` with SSL, HTTP mode with `X-Forwarded-Proto`, backends loop over `groups['kubernetes_master']` on `ports.kubernetes.superset_node`
- **Headlamp** — accessed via Ingress path routing on the `kube_worker` frontend (`/headlamp`)

**Note:** The template references `paths.ssl_certs.base_dir` (for certificate path) and `ports.*` variables — these must be defined in the Bhrigu pre-prod inventory (`paths.yml` and `networks.yml` respectively) for the template to render correctly. The Kubernetes API frontend does NOT use SSL termination (TCP passthrough to kube-apiserver's own TLS).

#### Prod Environment — Kubernetes Config (`config_kubernetes.yml`)
- Ansible user: `app-manager`
- **Headlamp:** namespace `headlamp`, port 4466, base path `/headlamp`, ingress enabled via HAProxy on `bhrigu.nat.bt.com` (no TLS)

### Host Naming Convention
- **Test:** `blt20919xxx` (prefix `blt`)
- **Prod/DR:** `blp20919xxx` (prefix `blp`)
- **Barista CST:** `bld25082xxx` (prefix `bld`)
- **Barista Pre-Prod:** `blp25082xxx` (prefix `blp`)
- **Bhrigu Pre-Prod:** `blp20919xxx` (prefix `blp`, range 319–338) for all nodes
- Host vars on inventory line: `ansible_host=<IP>` plus service-specific vars (`shardId`, `replicaId`, `nodeRole`, `nodeId`, `zkId`, thread limits)

### Network Subnets by Environment
| Environment | Subnets |
|-------------|---------|
| Test | 10.11.21.x, 10.11.22.x, 10.6.97.x, 10.50.126.x (MAT Common haproxy_ran) |
| Prod | 10.6.101.x, 10.6.102.x, 10.6.121.x, 10.6.122.x, 10.11.48.x, 10.54.105.x |
| DR | 10.54.105.x, 10.54.106.x, 10.54.115.x |
| MAT RAN Pre-Prod | 10.6.120.x, 10.6.103.x, 10.54.106.x, 10.54.107.x |
| MAT Common Pre-Prod | 10.6.120.x, 10.6.103.x, 10.54.106.x, 10.54.107.x |
| MAT RAN FN Pre-Prod | 10.6.103.x |
| Barista Pre-Prod | 10.6.103.x (Reigate), 10.55.4.x (Derby), 10.13.92.x (St Albans) |

---

## Shared Configuration (Global Vars)

The `playbook/_global_vars/` directory contains configuration shared across all environments and playbooks (loaded via `vars_files` in playbooks):

- **all.yml** — Vault-encrypted shared variables (secrets/credentials used across multiple roles)
- **common_config.yml** — Common non-secret configuration shared across all environments (top-level key: `common_config`)
  - `common_config.yum_repos_to_disable` — List of yum repos known to be unreachable within BT network (require external internet). These are disabled before any yum operation to prevent timeouts. Default list: `docker-ce-stable`, `docker-ce-stable-debuginfo`, `docker-ce-stable-source`, `docker-ce-test`, `docker-ce-nightly`, `Kubernetes`, `ol8_developer_EPEL`, `ol8_developer_EPEL_modular`, `ol8_baseos_latest`, `ol8_appstream`, `ol8_UEKR6`
  - **Reusable role:** `roles/_misc/disable_external_repos` — encapsulates the repo-disable logic as a reusable role. Must be included as the first role in any playbook that runs yum/dnf tasks. Uses `sed` to set `enabled=0` on matching repo sections (works on OEL 8/9 without yum-config-manager). Reports `changed` only when repos were actually disabled. For roles that delegate tasks to other nodes (e.g., Longhorn worker prerequisites), the same shell logic can be inlined with `delegate_to`.
  - **Reusable role:** `roles/_misc/falcon_memory_limit` — applies systemd `MemoryHigh`/`MemoryMax`/`CPUQuota` overrides to the CrowdStrike Falcon sensor (`falcon-sensor.service`) to prevent unbounded slab memory growth from kernel modules (`falcon_kal`, `falcon_lsm_serviceable`) and CPU saturation on high-I/O hosts. Targets high-I/O hosts where Falcon's per-syscall slab cache allocations can exhaust RAM. Deploys a systemd drop-in at `/etc/systemd/system/falcon-sensor.service.d/memory-limit.conf`. Gracefully skips if `falcon-sensor` is not installed. Restart uses shell-based `systemctl restart` with retries (3 attempts, 5s delay) for resilience against transient Falcon sensor restart failures. Variables: `falcon_memory_high` (default `1536M`, throttle threshold), `falcon_memory_max` (default `2G`, hard kill + auto-restart), `falcon_cpu_quota` (default `20%`, caps CPU usage). Sourced from `config.falcon.memory_high` / `config.falcon.memory_max` / `config.falcon.cpu_quota`.
  - **Reusable role:** `roles/_misc/k8s_cleanup` — Kubernetes cluster cleanup utility for decommissioning or resetting nodes. Uses a multi-play playbook pattern — `playbook/_misc/k8s_cleanup.yaml` is the primary entrypoint, using action-driven cleanup controlled by `K8S_CLEANUP_ACTION` environment variable (`worker` | `master`). The playbook imports individual task files directly in separate plays (each targeting the correct host group); the role's `main.yml` is documentation-only and NOT used via `roles:` directive. Since task files are imported directly (not via `roles:`), the playbook explicitly loads role defaults via `vars_files: ../../roles/_misc/k8s_cleanup/defaults/main.yml` to ensure all role default variables are available. Play 2 (worker cleanup) also loads `_global_vars/all.yml` and `_global_vars/common_config.yml`, and runs `roles/_misc/disable_external_repos` before worker cleanup tasks to prevent yum timeout failures from unreachable external repos during `kubeadm reset` or package removal. Play 3 (master cleanup) also loads `_global_vars/all.yml` and `_global_vars/common_config.yml`, runs `roles/_misc/disable_external_repos` before master cleanup, and runs `docker_remove.yml` on master nodes (when action is `master`) to ensure Docker packages are removed from masters as well. Task files: `remove_workers.yml` (drain + delete workers from K8s API, runs on master), `cleanup_worker.yml` (kubeadm reset + directory cleanup, runs on workers), `docker_remove.yml` (remove Docker packages keeping containerd, runs on workers and masters), `cleanup_master.yml` (full master node teardown, runs on masters). Additionally, dedicated per-action playbooks exist for running individual actions: `k8s_cleanup_remove_workers.yaml` (drain and delete worker nodes from cluster, runs on master, requires `WORKER_NODES` variable), `k8s_cleanup_worker.yaml` (kubeadm reset + directory cleanup, runs on worker nodes), `k8s_cleanup_docker.yaml` (remove Docker packages keeping containerd, runs on any k8s node), `k8s_cleanup_master.yaml` (full master node teardown, runs on master nodes). Configuration source: `config_k8s.cleanup.*` in `config_kubernetes.yml` (optional). Key variables: `k8s_cleanup_ansible_user` (from `config_k8s.ansible_user`, default `app-manager`), `k8s_cleanup_drain_timeout` (default `150`), `k8s_cleanup_drain_grace_period` (default `30`), `k8s_cleanup_data_dir` (default `<paths.kubernetes.base_dir>/kubernetes_data`), `k8s_cleanup_restart_containerd` (default `true`). Worker cleanup removes: `/etc/kubernetes`, `/etc/cni`, `/opt/cni`, `/var/lib/etcd`, `/var/lib/kubelet`, `~/.kube`. Master cleanup removes: `/etc/kubernetes`, `/var/lib/kubelet`, `/var/lib/etcd`, cert renewal cron/script. Docker removal targets Docker CE packages while preserving containerd. **WORKER_NODES filtering:** `WORKER_NODES` is required for the `worker` action. Both Play 1 (remote drain/delete from master) and Play 2 (local cleanup on workers) are filtered — only the listed nodes are drained from the cluster and cleaned locally.
  - **Reusable role:** `roles/_misc/static_route` — adds a persistent static network route on RHEL/OEL hosts via `/etc/sysconfig/network-scripts/route-<interface>`. Auto-detects the default network interface from the system's routing table (`ip route show default`). Useful for cross-subnet routing in multi-DC clusters (e.g., Barista pre-prod Reigate nodes routing to Derby 10.55.4.0/24 via local gateway). Default target host group: `kubernetes_worker` (overridable via `target_host`). Pipeline variables: `ROUTE_NETWORK` (CIDR network to route, e.g. `10.55.4.0/24`), `ROUTE_GATEWAY` (next-hop gateway IP, e.g. `10.6.103.254`) — read via `lookup('env', ...)` in the playbook and passed to the role as `route_network` / `route_gateway`. Role defaults reference these variables directly (`static_route_network: "{{ route_network }}"`, `static_route_gateway: "{{ route_gateway }}"`). Additional variable: `static_route_interface_fallback` (fallback NIC name if auto-detection fails, default `ens192`). Override via pipeline env vars or `--extra-vars` for local runs (no `config_misc` inventory lookup).

---

## Inventory Variable Hierarchy

Each environment's `group_vars/all/` contains these files (loaded in order):

1. **versions.yml** — All software version numbers
2. **paths.yml** — Base directory paths (all services install under `/apps`)
3. **networks.yml** — Port mappings, host addresses, DNS entries
4. **app_configs.yml** — Application-specific configuration (memory, retention, SSL, cluster settings)
5. **config_kubernetes.yml** — Kubernetes-specific configuration (top-level key: `config_k8s`, present in: mat_fixed_network/test, mat_fixed_network/prod, mat_ran_fn/pre_prod, mat_common/pre_prod, barista/pre_prod, barista/prod, bhrigu/pre_prod, bhrigu/prod)
6. **config_platform.yml** — Platform tools configuration (top-level key: `config_platform`, present in: mat_ran_fn/pre_prod — GitLab Runner, Gradle, nerdctl; mat_common/test — GitLab Runner, Gradle, nerdctl; barista/pre_prod — crypto_policy, java_folder; bhrigu/test — crypto_policy)
7. **config_monitoring.yml** — Monitoring-specific configuration: Prometheus scrape/retention, AlertManager email/SMTP, and exporter settings (top-level key: `config_monitoring`, present in: barista/pre_prod, mat_ran/dr, mat_common/test, mat_fixed_network/prod)
8. **config_kafka.yml** — Kafka-specific configuration (top-level key: `config_kafka`, one section per host group: `kafka_kraft`, `kafka_kraft_ssl`, `schema_registry`; present in: barista/pre_prod, mat_fixed_network/test, mat_fixed_network/prod, mat_common/test, mat_common/pre_prod, mat_ran/pre_prod)
9. **config_elk.yml** — ELK stack configuration (top-level key: `config_elk`, present in: barista/pre_prod, mat_fixed_network/prod, mat_common/test, mat_common/pre_prod)
10. **config_database.yml** — Database-specific configuration: Druid, ClickHouse, MySQL settings (top-level key: `config_database`, present in: mat_common/test — Druid OLAP cluster config + MySQL provisioning; mat_fixed_network/prod — ClickHouse Keeper config + ClickHouse Server config)
11. **all_secrets.yml** — Vault-encrypted secrets (passwords, tokens)
12. **all_host_secrets.yml** — Vault-encrypted per-host secrets
11. **all_host_secrets.yml** — Vault-encrypted per-host secrets

---

## Software Versions (Prod - Fixed Network)

| Component | Version |
|-----------|---------|
| Kafka KRaft | 8.3.0 |
| Kafka (ZooKeeper mode) | 7.5.3 |
| Schema Registry | 8.1.3 |
| Kafdrop (KRaft) | 4.2.0 |
| Kafka Exporter (KRaft) | 1.9.0 |
| ZooKeeper | 3.9.5 |
| ClickHouse Server/Keeper | 26.5.5.8 |
| Elasticsearch | 9.3.6 |
| Prometheus | 3.5.0 |
| Grafana | 12.1.1 |
| HAProxy (general) | 3.2.0 |
| HAProxy (ClickHouse) | 3.0.0 |
| Kubernetes | 1.36 (full: 1.36.2) |
| Calico | 3.32.0 |
| Helm | 4.2.1 |
| Harbor | 1.19.1 |
| Ingress Controller | 1.52.0 |
| Longhorn | 1.12.0 |
| PostgreSQL (CNPG helm chart) | 0.28.3 |
| PostgreSQL (server) | 18.4 |
| pgAdmin | 9.15 |
| Prometheus (K8s monitoring) | v3.5.4 |
| Kube State Metrics | v2.19.1 |
| Metrics Server | v0.8.1 |
| AlertManager (K8s monitoring) | v0.33.0 |
| Fluent Bit (logging) | 5.0.7 |
| Headlamp | v0.26.0 |
| MySQL | 8.0 |
| Node Exporter | 1.9.1 |
| Process Exporter | 0.8.5 |
| AlertManager | 0.27.0 |
| Pushgateway | 1.6.2 |
| Blackbox Exporter | 0.26.0 |
| Java | 17.0.2 |
| Hadoop HDFS | 3.4.3 |
| Druid | 37.0.0 |
| Gradle | 9.2.1 |
| nerdctl (full) | 2.1.2 |

## Software Versions (Pre-Prod - MAT RAN FN)

| Component | Version |
|-----------|---------|
| Kubernetes | 1.36 (full: 1.36.2) |
| Calico | 3.32.0 |
| Helm | 4.2.1 |
| Harbor | 1.19.1 |
| Ingress Controller | 1.52.0 |
| Longhorn | 1.12.0 |
| Headlamp | v0.43.0 |
| LibreFS | RELEASE.2026-05-04T00-42-47Z |
| PostgreSQL (CNPG helm chart) | 0.28.3 |
| PostgreSQL (server) | 18.4 |
| pgAdmin | 9.15 |
| Prometheus (K8s monitoring) | v3.5.4 |
| Kube State Metrics | v2.19.1 |
| Metrics Server | v0.8.1 |
| AlertManager (K8s monitoring) | v0.33.0 |
| Grafana (K8s) | 13.0.2 |
| OWASP Dependency-Check | 12.2.2 |
| PostgreSQL JDBC Driver | 42.7.11 |
| GitLab Runner | 19.0.1 |
| Gradle | 9.5.1 |
| nerdctl (full) | 2.1.2 |

## Software Versions (Test - MAT Common)

| Component | Version |
|-----------|---------|
| GitLab Runner | 19.0.1 |
| Gradle | 9.5.1 |
| nerdctl (full) | 2.3.3 |
| Kubernetes | 1.36 (full: 1.36.2) |
| Calico | 3.32.0 |
| Helm | 4.2.1 |
| Harbor | 1.19.1 |
| Ingress Controller | 1.52.0 |
| Longhorn | 1.12.0 |
| Headlamp | v0.43.0 |
| LibreFS | RELEASE.2026-05-04T00-42-47Z |
| PostgreSQL (CNPG helm chart) | 0.28.3 |
| PostgreSQL (server) | 18.4 |
| pgAdmin | 9.15 |
| Prometheus (K8s monitoring) | v3.5.4 |
| Kube State Metrics | v2.19.1 |
| Metrics Server | v0.8.1 |
| AlertManager (K8s monitoring) | v0.33.0 |
| Grafana (K8s) | 13.0.2 |
| Kafka (Strimzi) | 4.3.0 |
| Strimzi Operator | 1.1.0 |
| Supabase (Helm chart) | 0.5.6 |
| Supabase pg_exporter | 0.15.0 |
| Supabase DB | 15.8.1.085 |
| Supabase Kong | 3.9.1 |
| Supabase Studio | 2026.06.03-sha-0bca601 |
| Supabase Auth | (chart default) |
| Supabase REST | (chart default) |
| Supabase Realtime | (chart default) |
| Supabase Storage | (chart default) |
| Supabase Meta | v0.96.6 |
| Supabase Functions | (chart default) |
| Supabase imgproxy | v3.30.1 |
| Elasticsearch | 9.3.6 |
| Elasticsearch Exporter | 1.10.0 |
| Prometheus (standalone) | 3.12.0 |
| AlertManager (standalone) | 0.33.0 |
| HAProxy | 3.2.0 |

**Note:** MAT Common test no longer carries most data pipeline versions (ClickHouse, Kafka, MySQL, etc.). Those services are versioned and managed exclusively through the `mat_fixed_network/test` inventory. HAProxy is versioned here to support the `haproxy_fn` and `haproxy_ran` host groups defined in this inventory. ELK versions (Elasticsearch, Elasticsearch Exporter) are maintained here for the Kubernetes-deployed Elasticsearch instance used for pod log storage. The `[elasticsearch]` host group (`blt20919027` at `10.11.21.37`) enables running the Elasticsearch role against this inventory for the K8s log storage node. Druid OLAP cluster configuration is provided via `config_database.yml` (MySQL metadata store at `10.11.21.245:61010`, HDFS cluster `MartiniEERan`, per-service heap/memory tuning), enabling the Druid role to run against this inventory for the dedicated Druid nodes (blt20919081–blt20919086). Kafka KRaft cluster configuration is provided via `config_kafka.yml` (cluster ID `matfntest-ZE0dkDMXRLOmjkEU-BwyxQ`, 3-node cluster on blt20919046–blt20919048, advertised host DNS pattern `mat.modelb{{ ansible_host.split('.')[3] }}.nat.bt.com`, dual-listener PLAINTEXT + SSL with per-node JKS keystores, replication factor 2, min ISR 1, 10GB heap, `LogAppendTime` timestamps, Schema Registry enabled with BACKWARD compatibility and 1G/2G heap), enabling the Kafka KRaft and Schema Registry roles to run against this inventory for the shared Kafka nodes.

## Software Versions (Pre-Prod - MAT Common)

| Component | Version |
|-----------|---------|
| Druid | 29.0.1 |
| Grafana | 12.1.1 |
| HAProxy | 3.0.0 |
| Hadoop HDFS | 3.3.6 |
| Java | 17.0.2 |
| Kafka (ZooKeeper mode) | 7.5.3 |
| Kafka KRaft | 8.3.0 |
| Schema Registry | 8.1.3 |
| Kafdrop (KRaft) | 4.2.0 |
| Kafka Exporter (KRaft) | 1.9.0 |
| Elasticsearch | 9.3.6 |
| Kubernetes | 1.36 (full: 1.36.2) |
| Calico | 3.32.0 |
| Helm | 4.2.1 |
| Ingress Controller | 1.52.0 |
| Longhorn | 1.12.0 |
| Headlamp | v0.43.0 |
| Kafka UI | v1.5.0 |
| Prometheus (K8s monitoring) | v3.5.4 |
| Kube State Metrics | v2.19.1 |
| Metrics Server | v0.8.1 |
| Fluent Bit (logging) | 5.0.7 |
| MySQL | 8.0 |
| Node Exporter | 1.11.1 |
| Process Exporter | 0.8.7 |
| Prometheus (standalone) | 3.5.0 |
| AlertManager (standalone) | 0.28.1 |
| Pushgateway | 1.6.2 |
| ZooKeeper | 3.8.3 |
| ClickHouse Server/Keeper | 25.9.2.1 |

**Note:** MAT Common pre-prod is a full-stack environment carrying versions for the complete data pipeline (ClickHouse, Kafka, Druid, HDFS, HAProxy, MySQL, Prometheus, ZooKeeper) alongside Kubernetes platform components. It also includes Headlamp and Kafka UI for Kubernetes cluster management and Kafka topic visibility.

---

## Playbooks (70+)

Each playbook targets a host group via `target_host | default('group_name')` and applies one or more roles.

**Data Streaming:** `kafka_kraft.yaml`, `kafka.yaml`, `kafka_airborne.yaml`, `kafdrop.yaml`, `kafdrop_kraft.yaml`, `kafdrop_airborne.yaml`, `kafka_exporter.yaml`, `kafka_airborne_exporter.yaml`, `schema_registry.yaml`, `zookeeper.yaml`

**Data Storage:** `clickhouse_server.yaml`, `clickhouse_keeper.yaml`, `elasticsearch.yaml`, `mysql_install.yaml`, `mysql_upgrade.yaml`, `mysql_user_setup.yaml`, `postgres.yaml`, `hdfs.yaml`, `druid.yaml`, `nfs_mount.yaml`, `nfs_server.yaml`, `minio.yaml`

**Monitoring:** `prometheus.yaml`, `grafana_monitor.yaml`, `grafana_user.yaml`, `node_exporter.yaml`, `process_exporter.yaml`, `pushgateway.yaml`, `blackbox_exporter.yaml`, `jmx_server_exporter.yaml`, `jmx_agent_exporter.yaml`, `elasticsearch_exporter.yaml`, `mysql-exporter.yaml`, `daily_monitoring.yaml`, `auto_health_check.yaml`

**Load Balancing:** `haproxy.yaml`, `haproxy_click.yaml`

**Kubernetes:** `kubernetes_master_setup.yaml`, `kubernetes_master_setup_dockerless.yaml`, `kubernetes_worker_setup.yaml`, `kubernetes_upgrade.yaml`, `kubernetes_monitoring.yaml`, `kubernetes_logging.yaml`, `kubernetes_labels.yaml`, `kubernetes_headlamp.yaml`, `kubernetes_grafana.yaml`, `kubernetes_image_cleanup.yaml`, `kubernetes-ingress-controller.yaml`, `kubernetes_kafka_ui.yaml`, `kubernetes_kafdrop.yaml`, `kubernetes_strimzi_kafka.yaml`, `kubernetes_mongodb.yaml`, `kubernetes_elasticsearch.yaml`, `kubernetes_harbor.yaml`, `kubernetes/falkordb.yaml` (APP_GROUP subfolder, targets `kubernetes_master_zone2`, env var `FALKORDB_ACTION`), `longhorn.yaml`, `helm.yaml`

**ELK Stack:** `elasticsearch.yaml`, `logstash.yaml`, `kibana.yaml`, `loki.yaml`

**Platform/Utilities:** `java_folder.yaml`, `java.yaml` (platform/), `java8.yaml`, `python3.yaml`, `superset.yaml`, `pgadmin.yaml`, `add_user.yaml`, `sftp_setup.yaml`, `firewalld.yaml`, `crypto_policy.yaml`, `onepatch.yaml`, `nvd_sync.yaml`, `housekeep.yaml`, `cron_tab.yaml`, `copy_to_aws.yaml`, `copy_via_ssh.yaml`, `clean_service.yaml`, `realmd_sssd_restart.yaml`, `service_symlink_cleanup.yaml`, `zscaler_connectivity_test.yaml`, `check_patch_schedule.yaml`, `gitlab_runner.yaml`, `gradle.yaml`, `containerd_nerdctl.yaml`

**Maintenance/Misc (`_misc/`):** `librefs_wipe_data.yaml` — Wipes libreFS data on worker nodes and restarts the StatefulSet (destructive, for fresh installs or drive-ordering recovery only; targets `librefs_workers` then `kubernetes_master_init`), `falcon_memory_limit.yaml` — Applies systemd MemoryHigh/MemoryMax/CPUQuota overrides to CrowdStrike Falcon sensor (targets `falcon` host group by default), `k8s_cleanup.yaml` — Action-driven Kubernetes cluster cleanup (controlled by `K8S_CLEANUP_ACTION` env var: `worker` | `master`; requires `WORKER_NODES` for worker action; multi-play design importing task files directly from the role), `k8s_cleanup_remove_workers.yaml` — Drains and removes worker nodes from cluster (targets `kubernetes_master_init`, requires `WORKER_NODES` variable), `k8s_cleanup_worker.yaml` — Worker node local cleanup via kubeadm reset (targets `kubernetes_worker`), `k8s_cleanup_docker.yaml` — Removes Docker packages keeping containerd (targets `kubernetes_worker`), `k8s_cleanup_master.yaml` — Full master node teardown (targets `kubernetes_master` — all masters for complete cluster teardown), `clickhouse_cleanup_stale_data.yaml` — Removes stale files from `/apps/clickhouse/data/` created by a failed pipeline that deployed an incorrect `<path>` config (keeps `system/` and `default/` subdirectories; targets `clickhouse_server`; safe to run while ClickHouse is active since it validates the current config path before proceeding)

---

## Roles (55+)

Roles follow standard Ansible structure (`defaults/`, `tasks/`, `templates/`, `handlers/`, `files/`).

**Compound roles (with sub-roles):**
- `clickhouse/` → `server/`, `keeper/`
- `coordination/` → `zookeeper/`
- `kafka/kafka_kraft/` → `kafka-broker/`, `kafka_exporter/`
- `elk/` → `elasticsearch/` (sub-roles: `service/`, `exporter/`), `kibana/`, `loki/`
- `data_storage/` → `minio/`, `librefs/`, `nfs_mount/`, `nfs_server/`
- `kubernetes/` (categorized sub-directory structure):
  - `cluster/` → docker_less, helm, master_setup, upgrade, worker_setup
  - `database/` → elasticsearch, loki, mongo_express, mongodb, pgadmin, postgres, supabase
  - `falkordb/` → FalkorDB graph database (Redis Sentinel HA + FalkorDB module)
  - `frontend/` → grafana, headlamp
  - `networking/` → ingress-controller
  - `operations/` → image_cleanup, label_management, logging, monitoring
  - `platform/` → harbor
  - `storage/` → longhorn, minio, librefs
  - `streaming/` → kafka_ui, kafka (Strimzi), kafka_connect, kafdrop

**Task pattern:** Most roles follow: `stop → create_user → cleanup → install → config → start → monitor`

**Exporter roles** (e.g., `node-exporter`, `process-exporter`) follow: `create_user → pre_install → install → cleanup → service` where pre_install checks if an upgrade is needed and stops the service, install downloads and extracts the new version, cleanup removes old version directory and tarball (only if version differs from current, using the `*_current` version variable detected in pre_install via symlink target and binary `--version` output), and the service step includes systemd configuration, restart, and post-install health verification (port listening check, version confirmation, metrics endpoint validation).

- **process-exporter key defaults:**
  - `process_exporter_version` — from `version.process_exporter`
  - `process_exporter_base_dir` — from `paths.process_exporter.base_dir`
  - `process_exporter_port` — from `ports.process_exporter.service`
  - `process_exporter_user` / `process_exporter_group` — default `process-exporter`
  - `process_exporter_listen_address` — default `0.0.0.0`
  - `process_exporter_arch` — default `linux-amd64`
  - `process_exporter_http_proxy` / `process_exporter_https_proxy` — inherits global proxy vars
  - `process_exporter_download_timeout` — default `30` seconds
  - `process_exporter_memory_limit` — from `config.process_exporter.memory_limit` (default `512M`), used as systemd `MemoryMax`
  - `process_exporter_nofile_limit` — from `config.process_exporter.nofile_limit` (default `1024`), used as systemd `LimitNOFILE`
  - Proxy-aware (http_proxy, https_proxy for download)

- **node-exporter key defaults:**
  - `node_exporter_version` — from `version.node_exporter`
  - `node_exporter_base_dir` — from `paths.node_exporter.base_dir`
  - `node_exporter_port` — from `ports.node_exporter.service`
  - `node_exporter_user` / `node_exporter_group` — default `node-exporter`
  - `node_exporter_listen_address` — default `0.0.0.0`
  - `node_exporter_textfile_dir` — textfile collector directory
  - `node_exporter_max_requests` — max concurrent scrape requests
  - `node_exporter_memory_limit` — used as systemd `MemoryMax`
  - `node_exporter_nofile_limit` — used as systemd `LimitNOFILE`
  - Proxy-aware (http_proxy, https_proxy for download)

**Full role list:** `_misc`, `add_user`, `auto_health_check`, `blackbox_exporter`, `buildkit_nerdctl`, `clean_service`, `clean_tmp_dir`, `clickhouse`, `containerd_nerdctl`, `copy_to_aws`, `copy_via_ssh`, `cron_tab`, `crypto_policy`, `docker`, `download_monitor`, `Download_Report_Failure`, `druid`, `elasticsearch`, `email_reporter`, `ericsson_dq`, `firewalld`, `gitlab_runner`, `gradle`, `grafana`, `haproxy`, `haproxy_click`, `hdfs`, `helm`, `Herald_Jobs_Failure`, `housekeep`, `java_1_8`, `java`, `java_folder`, `jmx_agent_exporter`, `jmx_server_exporter`, `k8s_health`, `k8s_health_check`, `k8s_health_monitor`, `kafdrop`, `kafdrop_airborne`, `kafdrop_kraft`, `kafka`, `kafka_airborne`, `kafka_kraft`, `kibana`, `kubernetes`, `logstash`, `loki`, `minio`, `monitoring`, `mysql`, `nfs_mount`, `nfs_server`, `node-exporter`, `nvd_sync`, `onepatch`, `process-exporter`, `prometheus`, `pushgateway`, `python3`, `realmd_sssd_restart`, `scripts`, `service_symlink_cleanup`, `sftp_setup`, `status_report`, `superset`, `systemd_services`, `zookeeper`, `zscaler_connectivity_test`

---

## CI/CD Pipeline (GitLab CI)

**Trigger variables:**
- `APP_INSTANCE`: `RAN` | `Fixed Network` | `Barista` | `Bhrigu` | `RAN-FN` | `MAT Common`
- `ENV`: `Test` | `Pre-Prod` | `Dr` | `Prod` | `Geo-Prod`
- `ZONE`: `zone-1` (HAProxy/LB tier) | `zone-2` (service tier)
- `APP_GROUP`: Playbook subfolder (e.g., `kubernetes`, `monitoring`, `kafka`, `elk`, `database`, `data_storage`, `load_balancing`, `frontend`, `platform`)
- `APP`: Playbook name (without `.yaml` extension)
- `TARGET_HOST`: Optional host group override
- `ANSIBLE_USER`: SSH user for remote execution
- `WORKER_NODES`: Comma-separated list of worker hostnames to remove (used by `k8s_cleanup` playbook via `lookup('env', 'WORKER_NODES')`). Required for the `worker` action. Filters both Play 1 (remote drain/delete from master) and Play 2 (local cleanup on worker nodes) to only the listed hostnames. Not passed as `--extra-vars` by any pipeline — read directly as an environment variable within the playbook.
- `K8S_CLEANUP_ACTION`: Action for `k8s_cleanup.yaml` (`worker` | `master`). Required. Read as environment variable within the playbook via `lookup('env', 'K8S_CLEANUP_ACTION')`.
- `KAFKA_CONFIG_GROUP`: Legacy override for the Kafka configuration section used by the `kafka_kraft.yaml` playbook. When set, passed as `-e kafka_config_group=$KAFKA_CONFIG_GROUP` which takes highest precedence for `kafka_host_group_name`. In practice, this is no longer needed — the playbook now auto-resolves the config group from `target_host` (if `target_host` exists as a key in `config_kafka`, it is used automatically). The `kafka_config_group` override is retained for backward compatibility but not passed by any pipeline.

**Pipeline routing:**
- `APP_INSTANCE == "RAN"` → `pipeline/martini-ran-ci.yml`
- `APP_INSTANCE == "Fixed Network"` → `pipeline/mat-fn-ci.yml`
- `APP_INSTANCE == "Barista"` → `pipeline/barista-ci.yml`
- `APP_INSTANCE == "Bhrigu"` → `pipeline/bhrigu-ci.yml`
- `APP_INSTANCE == "RAN-FN"` → `pipeline/martini-ran-fn-ci.yml`
- `APP_INSTANCE == "MAT Common"` → `pipeline/mat-common-ci.yml`

**Runner tags:** `MAT-Ansible-TEST`, `MAT-Ansible-DRZ1` (zone-1), `MAT-Ansible-DRZ2` (zone-2), `barista-test-ansible-z1` (Barista test zone-1), `barista-test-ansible-z2` (Barista test zone-2), `barista-preprod-ansible-z2` (Barista pre-prod zone-2), `barista-preprod-apps-z1` (Barista pre-prod zone-1), `barista-prod-ansible-z2` (Barista prod zone-2)

**All jobs are manual** — no auto-deploy. Vault password injected via `$ansible_vault_pass` CI variable.

**Execution command pattern:**
```bash
# Standard (most pipelines):
ansible-playbook -f 4 --extra-vars="target_host=$TARGET_HOST" -D \
  --vault-password-file .vault \
  -e "ansible_user=$ANSIBLE_USER" \
  -i inventories/<module>/<env>/hosts \
  playbook/$APP.yaml

# All APP_GROUP pipelines (Fixed Network, RAN, RAN-FN, Barista, MAT Common) use the same pattern:
INVENTORY_PATH="inventories/<module>/${INVENTORY_ENV}/hosts"
PLAYBOOK_PATH="playbook/${APP_GROUP}/${APP}.yaml"
if [ ! -f "$INVENTORY_PATH" ]; then
  echo "ERROR: Inventory file not found: $INVENTORY_PATH"
  exit 1
fi
if [ ! -f "$PLAYBOOK_PATH" ]; then
  echo "ERROR: Playbook not found: $PLAYBOOK_PATH"
  exit 1
fi
EXTRA_VARS=""
if [ -n "$TARGET_HOST" ]; then
  EXTRA_VARS="--extra-vars=target_host=$TARGET_HOST"
fi
ansible-playbook -f ${FORKS:-4} $EXTRA_VARS -D \
  --vault-password-file .vault \
  -e "ansible_user=$ANSIBLE_USER" \
  -i "$INVENTORY_PATH" \
  "$PLAYBOOK_PATH"
```

---

## Key Configuration Details

### ClickHouse (Prod Fixed Network)
- 18 shards × 2 replicas = 36 server nodes
- 5 Keeper nodes (consensus cluster)
- Sub-groups by data type: port, vlan, twamp, misc, system, radius
- Host vars: `shardId`, `replicaId`, `defaultMaximumThreads`, `appMaximumThreads`, `roMaximumThreads`
- Cluster name: `mat_fn`
- **Server sub-role** (ClickHouse Server for data storage/query):
  - Role path: `roles/database/clickhouse/server/`
  - **Variable prefix:** `ck_server_*` (refactored from legacy `click_house_*` / `clickhouse_*` naming)
  - Config directory: `/etc/clickhouse-server`
  - **Configuration source:** `config_database.clickhouse_server.*`
  - **Key defaults variables:**
    - `ck_server_version` — from `version.clickhouse_server` (default `26.5.5.8`)
    - `ck_server_base_dir` — from `paths.clickhouse_server.base_dir` (default `/apps`)
    - `ck_server_parent_dir` — `<base_dir>/clickhouse`
    - `ck_server_data_dir` — `<parent_dir>/data`
    - `ck_server_logs_dir` — `<parent_dir>/logs`
    - `ck_server_tmp_dir` — `<parent_dir>/tmp`
    - `ck_server_cache_dir` — `<parent_dir>/caches`
    - `ck_server_access_dir` — `<parent_dir>/access`
    - `ck_server_user_files_dir` — `<parent_dir>/user_files`
    - `ck_server_format_schemas_dir` — `<parent_dir>/format_schemas`
    - `ck_server_backup_dir` — `<base_dir>/clickhouse_backups`
    - `ck_server_config_dir` — `/etc/clickhouse-server`
    - `ck_server_user` / `ck_server_group` — from `config_database.clickhouse_server.user`/`.group` (default `clickhouse`)
    - `ck_server_tcp_port` — from `ports.clickhouse.server.tcp` (default `9000`)
    - `ck_server_http_port` — from `ports.clickhouse.server.http` (default `8123`)
    - `ck_server_mysql_port` — from `ports.clickhouse.server.mysql` (default `9004`)
    - `ck_server_postgres_port` — from `ports.clickhouse.server.postgres` (default `9005`)
    - `ck_server_inter_server_port` — from `ports.clickhouse.server.interServer` (default `9009`)
    - `ck_server_metrics_port` — from `ports.clickhouse.server.metrics` (default `9363`)
    - `ck_server_keeper_port` — from `ports.clickhouse.keeper.tcp` (default `9181`)
    - `ck_server_keeper_host_group` — from `config_database.clickhouse_server.keeper_host_group` (default `clickhouse_keeper`)
    - `ck_server_cluster_name` — from `config_database.clickhouse_server.cluster_name` (default `default`)
    - `ck_server_clusters` — from `config_database.clickhouse_server.clusters` (default `[]`) — list of cluster definitions for remote_servers (each: `{ name, host_group }`)
    - `ck_server_users` — from `config_database.clickhouse_server.users` (default `[]`) — list of ClickHouse users (each: `{ name, type, password_vault_var }`)
    - `ck_server_memory_ratio` — from `config_database.clickhouse_server.memory_ratio` (default `0.60`)
    - `ck_server_nofile_limit` — from `config_database.clickhouse_server.nofile_limit` (default `500000`), used as systemd `LimitNOFILE`
    - `ck_server_nice` — from `config_database.clickhouse_server.nice` (default `-20`)
    - `ck_server_io_scheduling_class` — from `config_database.clickhouse_server.io_scheduling_class` (default `realtime`)
    - `ck_server_io_scheduling_priority` — from `config_database.clickhouse_server.io_scheduling_priority` (default `0`)
    - `ck_server_log_level` — from `config_database.clickhouse_server.log_level` (default `warning`)
    - `ck_server_log_size` — from `config_database.clickhouse_server.log_size` (default `500M`)
    - `ck_server_log_count` — from `config_database.clickhouse_server.log_count` (default `10`)
    - `ck_server_max_connections` — from `config_database.clickhouse_server.max_connections` (default `4096`)
    - `ck_server_max_concurrent_queries` — from `config_database.clickhouse_server.max_concurrent_queries` (default `200`)
    - `ck_server_max_server_memory_usage_to_ram_ratio` — from `config_database.clickhouse_server.max_server_memory_usage_to_ram_ratio` (default `0.9`)
    - `ck_server_max_thread_pool_size` — from `config_database.clickhouse_server.max_thread_pool_size` (default `10000`)
    - `ck_server_background_pool_size` — from `config_database.clickhouse_server.background_pool_size` (default `16`)
    - `ck_server_background_merges_mutations_concurrency_ratio` — from `config_database.clickhouse_server.background_merges_mutations_concurrency_ratio` (default `2`)
    - `ck_server_background_move_pool_size` — from `config_database.clickhouse_server.background_move_pool_size` (default `8`)
    - `ck_server_background_fetches_pool_size` — from `config_database.clickhouse_server.background_fetches_pool_size` (default `16`)
    - `ck_server_background_common_pool_size` — from `config_database.clickhouse_server.background_common_pool_size` (default `8`)
    - `ck_server_background_schedule_pool_size` — from `config_database.clickhouse_server.background_schedule_pool_size` (default `128`)
    - `ck_server_background_message_broker_pool_size` — from `config_database.clickhouse_server.background_message_broker_pool_size` (default `16`)
    - `ck_server_background_distributed_pool_size` — from `config_database.clickhouse_server.background_distributed_pool_size` (default `16`)
    - `ck_server_max_suspicious_broken_parts` — from `config_database.clickhouse_server.max_suspicious_broken_parts` (default `100`)
    - `ck_server_dead_letter_queue_ttl_days` — from `config_database.clickhouse_server.dead_letter_queue_ttl_days` (default `7`)
  - **Task flow:** validate → create_user → pre_install → install → os_tuning → config → service → verify
  - **OS tuning sub-steps:** THP set to madvise → THP defrag to madvise → disable swap (swapoff + fstab cleanup) → sysctl settings (vm.overcommit_memory=0, vm.max_map_count=262144, vm.swappiness=1, vm.dirty_ratio=40, vm.dirty_background_ratio=10, fs.file-max=2097152, network buffer/backlog tuning) → CPU governor set to performance (if cpufreq supported) → deploy `clickhouse-os-tuning.service` oneshot unit for persistence across reboots
- **Keeper sub-role** (ClickHouse Keeper for consensus/coordination):
  - Role path: `roles/database/clickhouse/keeper/`
  - **Variable prefix:** `ck_keeper_*` (refactored from legacy `click_house_keeper_*` naming)
  - Config directory: `/etc/clickhouse-keeper`
  - **Key defaults variables:**
    - `ck_keeper_version` — from `version.clickhouse_keeper` (default `26.5.5.8`)
    - `ck_keeper_base_dir` — from `paths.clickhouse_keeper.base_dir` (default `/apps`)
    - `ck_keeper_parent_dir` — `<base_dir>/clickhouse-keeper`
    - `ck_keeper_coordination_dir` — `<parent_dir>/coordination`
    - `ck_keeper_cores_dir` — `<parent_dir>/cores`
    - `ck_keeper_logs_dir` — `<parent_dir>/logs`
    - `ck_keeper_config_dir` — `/etc/clickhouse-keeper`
    - `ck_keeper_user` / `ck_keeper_group` — from `config_database.clickhouse_keeper.user`/`.group` (default `clickhouse`)
    - `ck_keeper_tcp_port` — from `ports.clickhouse.keeper.tcp` (default `9181`)
    - `ck_keeper_raft_port` — from `ports.clickhouse.keeper.raft` (default `9234`)
    - `ck_keeper_metrics_port` — from `ports.clickhouse.keeper.metrics` (default `9363`)
    - `ck_keeper_host_group` — from `config_database.clickhouse_keeper.host_group` (default `clickhouse_keeper`)
    - `ck_keeper_memory_limit` — from `config_database.clickhouse_keeper.memory_limit` (default `4G`), used as systemd `MemoryMax`
    - `ck_keeper_nofile_limit` — from `config_database.clickhouse_keeper.nofile_limit` (default `500000`), used as systemd `LimitNOFILE`
    - `ck_keeper_log_level` — from `config_database.clickhouse_keeper.log_level` (default `warning`)
    - `ck_keeper_log_size` — from `config_database.clickhouse_keeper.log_size` (default `500M`)
    - `ck_keeper_log_count` — from `config_database.clickhouse_keeper.log_count` (default `10`)
    - `ck_keeper_max_connections` — from `config_database.clickhouse_keeper.max_connections` (default `8192`)
    - `ck_keeper_operation_timeout_ms` — from `config_database.clickhouse_keeper.operation_timeout_ms` (default `10000`)
    - `ck_keeper_session_timeout_ms` — from `config_database.clickhouse_keeper.session_timeout_ms` (default `100000`)
    - `ck_keeper_min_session_timeout_ms` — from `config_database.clickhouse_keeper.min_session_timeout_ms` (default `10000`)
    - `ck_keeper_http_proxy` / `ck_keeper_https_proxy` — inherits global proxy vars
    - `ck_keeper_wait_retries` — from `config_database.clickhouse_keeper.wait_retries` (default `10`)
    - `ck_keeper_wait_delay` — from `config_database.clickhouse_keeper.wait_delay` (default `10` seconds)
  - Proxy-aware (http_proxy, https_proxy for download)
  - **Task flow:** validate → create_user → pre_install → install → config → service → verify
  - **Verify sub-steps:** service active check → TCP port listening (timeout 30s, retries) → Raft port listening → ruok health check (`echo ruok | nc` expects `imok`, retries 5, delay 5s) → version confirmation (rpm query) → deployment status summary (service state, version, server ID, TCP/Raft ports, metrics URL, health status)

### Kafka KRaft (Prod Fixed Network)
- 5 broker+controller nodes (plaintext)
- 3 broker+controller nodes (SSL)
- Host vars: `nodeRole` (broker,controller), `nodeId`
- SSL with JKS keystores, per-node certificate paths
- Cluster IDs: `matfn-ZE0dkDMXRLOmjkEU-BwyxQ` (plaintext), `matfn-ssl-ZE0dkDMXRLOmjkEU-Bwy` (SSL)
- **DR SSL cluster specifics (3-node):** replication factor 2, min ISR 1, `advertised_host_pattern: "martini{{ ansible_host.split('.')[3] }}.dr.nat.bt.com"`, `inter_broker_listener: PLAINTEXT`, replica_fetch_max_bytes 10485760 (10MB), num_replica_fetchers 3
- **Variable prefix:** `kafka_*` (refactored from legacy `kafka_config_*` / `kafka_install_*` naming)
- **Configuration source:** `config_kafka[kafka_host_group].*` in `config_kafka.yml` — the top-level key is `config_kafka` with one section per host group (`kafka_kraft`, `kafka_kraft_ssl`, `schema_registry`). The `kafka_host_group` variable (derived from `kafka_host_group_name`, default `kafka_kraft`) selects which section to read. The playbook auto-resolves config selection from `target_host` using inline Jinja2 logic: `kafka_host_group_name: "{{ kafka_config_group | default(target_host if (target_host is defined and target_host in config_kafka) else 'kafka_kraft') }}"`. If `kafka_config_group` is explicitly set, it takes precedence; otherwise, if `target_host` exists as a key in `config_kafka`, it is used as the config group; finally it falls back to `kafka_kraft`. This means setting `target_host=kafka_kraft_ssl` both targets the SSL hosts AND reads the `config_kafka.kafka_kraft_ssl` config section — no separate override variable is needed. This enables the same role to serve both plaintext and SSL clusters with a single `target_host` override.
- Sub-roles: `kafka-broker/`, `kafka_exporter/`, `schema_registry/` (under `roles/kafka/kafka_kraft/`)
- **Key defaults variables:**
  - `kafka_version` — from `version.kafka_kraft.broker`
  - `kafka_base_dir` — from `paths.kafka_kraft.base_dir`
  - `kafka_port` — from `ports.kafka_kraft.broker`
  - `kafka_controller_port` — from `config_kafka[kafka_host_group].controller_port` (default `9093`)
  - `kafka_cluster_id` — from `config_kafka[kafka_host_group].clusterId`
  - `kafka_host_group` — from `kafka_host_group_name` (default `kafka_kraft`)
  - `kafka_user` / `kafka_group` — from `config_kafka[kafka_host_group].user`/`.group` (default `kafka`)
  - `kafka_advertised_host` — from `config_kafka[kafka_host_group].advertised_host_pattern` (falls back to `ansible_host`) — allows overriding the advertised hostname pattern (e.g., for DNS-based advertisement instead of raw IP)
  - `kafka_node_role` — from host var `nodeRole`
  - `kafka_node_id` — from host var `nodeId`
  - `kafka_is_controller` — derived (`'controller' in kafka_node_role`)
  - `kafka_heap_gb` — from `config_kafka[kafka_host_group].config_memory_gb` (default `4`)
  - `kafka_quorum_voters` — from `config_kafka[kafka_host_group].quorum_voters` (default auto-generated via `quorum_voters_default.j2` template — builds `nodeId@host:controllerPort` string from all controller nodes in the host group)
  - `kafka_data_dir` — `<base_dir>/kafka_data` (persistent, survives upgrades)
  - `kafka_metadata_dir` — `<base_dir>/kafka_metadata` (persistent, survives upgrades)
  - `kafka_memory_limit` — from `config_kafka[kafka_host_group].memory_limit` (default `6G`), used as systemd `MemoryMax`
  - `kafka_nofile_limit` — from `config_kafka[kafka_host_group].nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `kafka_cpu_affinity` — from `config_kafka[kafka_host_group].cpu_affinity` (default `0-2`)
  - `kafka_http_proxy` / `kafka_https_proxy` — inherits global proxy vars
  - `kafka_download_timeout` — from `config_kafka[kafka_host_group].download_timeout` (default `300` seconds)
  - `kafka_replication_factor` — from `config_kafka[kafka_host_group].default_replication_factor` (default `3`)
  - `kafka_num_partitions` — from `config_kafka[kafka_host_group].default_num_partitions` (default `3`)
  - `kafka_log_retention_hrs` — from `config_kafka[kafka_host_group].log_retention_hrs` (default `6`)
  - `kafka_log_segment_bytes` — from `config_kafka[kafka_host_group].log_segment_bytes` (default `1073741824` / 1GB)
  - `kafka_log_roll_hours` — from `config_kafka[kafka_host_group].log_roll_hours` (default `6`)
  - `kafka_log_retention_check_interval_ms` — from `config_kafka[kafka_host_group].log_retention_check_interval_ms` (default `300000`)
  - `kafka_min_insync_replicas` — from `config_kafka[kafka_host_group].min_insync_replicas` (default `2`)
  - `kafka_num_network_threads` — from `config_kafka[kafka_host_group].num_network_threads` (default `3`)
  - `kafka_num_io_threads` — from `config_kafka[kafka_host_group].num_io_threads` (default `8`)
  - `kafka_num_replica_fetchers` — from `config_kafka[kafka_host_group].num_replica_fetchers` (default `2`)
  - `kafka_num_recovery_threads` — from `config_kafka[kafka_host_group].num_recovery_threads` (default `2`)
  - `kafka_socket_send_buffer` / `kafka_socket_receive_buffer` — from `config_kafka[kafka_host_group].socket_send_buffer`/`.socket_receive_buffer` (default `102400`)
  - `kafka_socket_request_max_bytes` — from `config_kafka[kafka_host_group].socket_request_max_bytes` (default `104857600`)
  - `kafka_message_max_bytes` — from `config_kafka[kafka_host_group].message_max_bytes` (default `10485760`)
  - `kafka_fetch_max_bytes` — from `config_kafka[kafka_host_group].fetch_max_bytes` (default `52428800`)
  - `kafka_replica_fetch_max_bytes` — from `config_kafka[kafka_host_group].replica_fetch_max_bytes` (default `157286400`)
  - `kafka_replica_lag_time_max_ms` — from `config_kafka[kafka_host_group].replica_lag_time_max_ms` (default `30000`)
  - `kafka_replica_socket_timeout_ms` — from `config_kafka[kafka_host_group].replica_socket_timeout_ms` (default `60000`)
  - `kafka_group_rebalance_delay_ms` — from `config_kafka[kafka_host_group].group_rebalance_delay_ms` (default `3000`)
  - `kafka_transaction_state_log_replication` — from `config_kafka[kafka_host_group].transaction_state_log_replication` (default `3`)
  - `kafka_transaction_state_log_min_isr` — from `config_kafka[kafka_host_group].transaction_state_log_min_isr` (default `2`)
  - `kafka_quorum_fetch_timeout_ms` — from `config_kafka[kafka_host_group].quorum_fetch_timeout_ms` (default `5000`)
  - `kafka_quorum_retry_backoff_ms` — from `config_kafka[kafka_host_group].quorum_retry_backoff_ms` (default `500`)
  - `kafka_quorum_election_timeout_ms` — from `config_kafka[kafka_host_group].quorum_election_timeout_ms` (default `5000`)
  - `kafka_delete_topic_enable` — from `config_kafka[kafka_host_group].delete_topic_enable` (default `true`)
  - `kafka_auto_create_topics` — from `config_kafka[kafka_host_group].auto_create_topics` (default `false`)
  - `kafka_unclean_leader_election` — from `config_kafka[kafka_host_group].unclean_leader_election` (default `false`)
  - `kafka_log_message_timestamp_type` — from `config_kafka[kafka_host_group].log_message_timestamp_type` (default `CreateTime`)
  - `kafka_offsets_topic_replication_factor` — from `config_kafka[kafka_host_group].offsets_topic_replication_factor` (default `3`)
  - `kafka_reserved_broker_max_id` — from `config_kafka[kafka_host_group].reserved_broker_max_id` (default `2147483647`)
  - `kafka_controller_socket_timeout_ms` — from `config_kafka[kafka_host_group].controller_socket_timeout_ms` (default `30000`)
  - `kafka_ssl_enabled` — from `config_kafka[kafka_host_group].ssl.enabled` (default `false`)
  - `kafka_ssl_port` — from `ports.kafka_kraft.ssl_broker` (default `61008`)
  - `kafka_inter_broker_listener` — from `config_kafka[kafka_host_group].ssl.inter_broker_listener` (default `SSL`) — listener name used for inter-broker communication when SSL is enabled
  - `kafka_ssl_dir` — `<base_dir>/kafka/ssl` (directory for SSL keystores)
  - `kafka_ssl_keystore_src` — from `config_kafka[kafka_host_group].ssl.keystore_src` (source path for keystore file)
  - `kafka_ssl_keystore_location` — `<ssl_dir>/kafka.keystore.jks` (fixed destination path)
  - `kafka_ssl_truststore_src` — from `config_kafka[kafka_host_group].ssl.truststore_src` (source path for truststore file)
  - `kafka_ssl_truststore_location` — `<ssl_dir>/kafka.truststore.jks` (fixed destination path)
  - `kafka_ssl_keystore_password` / `kafka_ssl_truststore_password` / `kafka_ssl_key_password` — from `config_kafka[kafka_host_group].ssl.*`
  - `kafka_ssl_enabled_protocols` — from `config_kafka[kafka_host_group].ssl.enabled_protocols` (default `TLSv1.2,TLSv1.3`)
  - `kafka_ssl_keystore_type` — from `config_kafka[kafka_host_group].ssl.keystore_type` (default `JKS`)
  - `kafka_ssl_truststore_type` — from `config_kafka[kafka_host_group].ssl.truststore_type` (default `JKS`)
  - `kafka_jmx_port` — from `ports.kafka_kraft.jmx_exporter`
  - `jmx_exporter_version` — from `version.kafka_kraft.jmx_agent`
  - `kafka_wait_retries` — from `config_kafka[kafka_host_group].wait_retries` (default `10`)
  - `kafka_wait_delay` — from `config_kafka[kafka_host_group].wait_delay` (default `15` seconds)
- **JMX agent install:** The broker install task downloads the JMX Prometheus Java agent JAR from Maven Central (`https://repo1.maven.org/maven2/io/prometheus/jmx/jmx_prometheus_javaagent/<version>/jmx_prometheus_javaagent-<version>.jar`) directly into `<base_dir>/kafka/jmx_agent/` (idempotent via `creates:` arg). This is separate from the standalone `jmx_agent_exporter` role — the broker role self-contains its JMX agent dependency.
- **Task flow (broker):** validate → create_user → pre_verify → pre_config → pre_install → migrate_data → install → cleanup → config → initialise → service → verify
- **Pre-install download-before-stop pattern:** The pre_install step downloads the Confluent Community tarball while the Kafka service is still running (download can take minutes over proxy), then stops the service only after download completes. This minimises downtime during upgrades.
- **Migrate data step:** Moves old data/metadata directories from inside the symlinked version directory (`<base_dir>/kafka/data`, `<base_dir>/kafka/metadata`) to the new persistent locations (`kafka_data_dir`, `kafka_metadata_dir`) that survive upgrades. Only runs if old dirs exist and new dirs are empty. Runs after pre_install (service stopped) and before install (new dirs created).
- Proxy-aware (http_proxy, https_proxy for download)
- **Schema Registry sub-role defaults** (variable prefix `sr_*`):
  - `sr_enabled` — from `config_kafka.schema_registry.enabled` (default `false`)
  - `sr_port` — from `ports.schema_registry.service`
  - `sr_base_dir` — from `paths.kafka_kraft.base_dir` (shares Kafka base directory)
  - `sr_kafka_host_group` — from `sr_kafka_group_name` (default `kafka_kraft`)
  - `sr_install_mode` — from `config_kafka.schema_registry.install_mode` (default `shared`) — `shared` uses `/apps/kafka/` (deployed by kafka-broker role), `standalone` uses `/apps/schema_registry/` (own install directory)
  - `sr_standalone_dir` — `<base_dir>/schema_registry`
  - `sr_install_dir` — `<standalone_dir>` if standalone mode, else `<base_dir>/kafka`
  - `sr_config_dir` — `<install_dir>/etc/schema-registry`
  - `sr_bin_dir` — `<install_dir>/bin`
  - `sr_log_dir` — `<install_dir>/logs/schema-registry`
  - `sr_user` / `sr_group` — from `config_kafka.schema_registry.user`/`.group` (falls back to `config_kafka[sr_kafka_host_group].user`/`.group`, default `kafka`)
  - `sr_heap_size` — from `config_kafka.schema_registry.heap_size` (default `512M`)
  - `sr_max_heap_size` — from `config_kafka.schema_registry.max_heap_size` (default `1G`)
  - `sr_compatibility_level` — from `config_kafka.schema_registry.compatibility_level` (default `BACKWARD`)
  - `sr_replication_factor` — from `config_kafka.schema_registry.replication_factor` (default `1`)
  - `sr_listen_address` — from `config_kafka.schema_registry.listen_address` (default `0.0.0.0`)
  - `sr_advertised_host` — from `config_kafka.schema_registry.advertised_host_pattern` (falls back to `ansible_host`) — DNS pattern for listeners/host.name
  - `sr_https_enabled` — from `config_kafka.schema_registry.https.enabled` (default `false`) — enables dual HTTP + HTTPS listeners
  - `sr_https_port` — from `ports.schema_registry.ssl_service` (default `61034`)
  - `sr_inter_instance_protocol` — from `config_kafka.schema_registry.inter_instance_protocol` (default `http`) — protocol for inter-instance communication
  - `sr_master_eligibility` — from `config_kafka.schema_registry.master_eligibility` (default `true`)
  - `sr_cors_enabled` — from `config_kafka.schema_registry.cors.enabled` (default `false`)
  - `sr_cors_allow_origin` — from `config_kafka.schema_registry.cors.allow_origin` (default `*`)
  - `sr_cors_allow_methods` — from `config_kafka.schema_registry.cors.allow_methods` (default `GET,POST,PUT,DELETE,OPTIONS`)
  - `sr_cors_allow_headers` — from `config_kafka.schema_registry.cors.allow_headers` (default `origin,content-type,accept,authorization`)
  - `sr_response_mediatype` — from `config_kafka.schema_registry.response_mediatype` (default `''`)
  - `sr_metrics_enabled` — from `config_kafka.schema_registry.metrics.enabled` (default `false`) — Confluent Metrics Reporter
  - `sr_metrics_topic` — from `config_kafka.schema_registry.metrics.topic` (default `_confluent-metrics`)
  - `sr_memory_limit` — from `config_kafka.schema_registry.memory_limit` (default `3G`), used as systemd `MemoryMax`
  - `sr_nofile_limit` — from `config_kafka.schema_registry.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `sr_ssl_enabled` — from `config_kafka.schema_registry.ssl_config.enabled` (default `false`)
  - `sr_ssl_keystore_location` — from `config_kafka.schema_registry.ssl_config.keystore_location` (default `<base_dir>/kafka/ssl/kafka.keystore.jks`)
  - `sr_ssl_keystore_password` / `sr_ssl_truststore_password` / `sr_ssl_key_password` — from `config_kafka.schema_registry.ssl_config.*`
  - `sr_ssl_truststore_location` — from `config_kafka.schema_registry.ssl_config.truststore_location` (default `<base_dir>/kafka/ssl/kafka.truststore.jks`)
  - `sr_ssl_client_auth` — from `config_kafka.schema_registry.ssl_config.client_auth` (default `false`)
  - `sr_ssl_enabled_protocols` — from `config_kafka.schema_registry.ssl_config.enabled_protocols` (default `TLSv1.2,TLSv1.3`)
  - `sr_ssl_keystore_type` — from `config_kafka.schema_registry.ssl_config.keystore_type` (default `JKS`)
  - `sr_ssl_truststore_type` — from `config_kafka.schema_registry.ssl_config.truststore_type` (default `JKS`)
  - `sr_kafkastore_ssl_endpoint_id_algo` — from `config_kafka.schema_registry.ssl_config.endpoint_identification_algorithm` (default `''`) — Kafkastore SSL endpoint identification for connection to Kafka brokers
  - `sr_jmx_port` — from `ports.schema_registry.jmx` (default `''`)
  - `jmx_exporter_version` — from `version.kafka_kraft.jmx_agent`
  - `sr_kafka_port` — from `ports.kafka_kraft.broker`
  - `sr_kafka_ssl_port` — from `ports.kafka_kraft.ssl_broker` (default `61008`)
  - `sr_kafka_advertised_host_pattern` — from `config_kafka[sr_kafka_host_group].advertised_host_pattern` (default `''`) — DNS pattern for bootstrap servers
  - `sr_wait_retries` — from `config_kafka.schema_registry.wait_retries` (default `6`)
  - `sr_wait_delay` — from `config_kafka.schema_registry.wait_delay` (default `10` seconds)
  - **JMX metrics config:** When `sr_jmx_port` is set, the config task deploys a JMX Prometheus exporter metrics config at `<base_dir>/kafka/schema_registry_monitor.yaml` (catch-all pattern `.*`, `force: false` to preserve manual customisations)
- **Kafka Exporter sub-role defaults** (variable prefix `kafka_exporter_*`):
  - `kafka_exporter_version` — from `version.kafka_kraft.kafka_exporter`
  - `kafka_exporter_base_dir` — from `paths.kafka_exporter.base_dir`
  - `kafka_exporter_port` — from `ports.kafka_kraft.exporter`
  - `kafka_exporter_broker_port` — from `ports.kafka_kraft.broker`
  - `kafka_exporter_user` / `kafka_exporter_group` — from `config_kafka[kafka_host_group].user`/`.group` (default `kafka`)
  - `kafka_exporter_arch` — from `config_kafka[kafka_host_group].kafka_exporter_arch` (default `linux-amd64`)
  - `kafka_exporter_memory_limit` — from `config_kafka[kafka_host_group].kafka_exporter_memory_limit` (default `256M`), used as systemd `MemoryMax`
  - `kafka_exporter_nofile_limit` — from `config_kafka[kafka_host_group].kafka_exporter_nofile_limit` (default `1024`), used as systemd `LimitNOFILE`
  - `kafka_exporter_http_proxy` / `kafka_exporter_https_proxy` — inherits global proxy vars
  - `kafka_exporter_download_timeout` — from `config_kafka[kafka_host_group].kafka_exporter_download_timeout` (default `60` seconds)
  - **Pre-install download-before-stop pattern:** The pre_install step downloads the kafka_exporter tarball while the service is still running, then stops the service only after download completes. Install step only extracts and symlinks. Same pattern as Kafka KRaft broker, Elasticsearch, Grafana, and ZooKeeper.

### ZooKeeper (Coordination)
- Deploys Apache ZooKeeper as a systemd service for distributed coordination (used by legacy Kafka clusters and Druid)
- **Variable prefix:** `zk_*` (refactored from legacy `zookeeper_*` naming)
- **Role path:** `roles/coordination/zookeeper/`
- **Configuration source:** `config_coordination.zookeeper.*` in `app_configs.yml`
- **Install method:** Apache archive download
- **Key defaults variables:**
  - `zk_version` — from `version.zookeeper` (default `3.9.5`)
  - `zk_base_dir` — from `paths.zookeeper.base_dir` (default `/apps`)
  - `zk_parent_dir` — `<base_dir>/zookeeper`
  - `zk_data_dir` — `<base_dir>/zookeeper_data`
  - `zk_logs_dir` — `<parent_dir>/logs`
  - `zk_user` / `zk_group` — from `config_coordination.zookeeper.user`/`.group` (default `zookeeper`)
  - `zk_client_port` — from `ports.zookeeper.client` (default `2181`)
  - `zk_peer_port` — from `ports.zookeeper.peer` (default `2888`)
  - `zk_election_port` — from `ports.zookeeper.election` (default `3888`)
  - `zk_metrics_port` — from `ports.zookeeper.metrics` (default `61007`)
  - `zk_admin_port` — from `config_coordination.zookeeper.admin_port` (default `8080`)
  - `zk_host_group` — from `config_coordination.zookeeper.host_group` (default `zookeeper`)
  - `zk_tick_time` — from `config_coordination.zookeeper.tick_time` (default `2000`)
  - `zk_init_limit` — from `config_coordination.zookeeper.init_limit` (default `10`)
  - `zk_sync_limit` — from `config_coordination.zookeeper.sync_limit` (default `5`)
  - `zk_max_client_connections` — from `config_coordination.zookeeper.max_client_connections` (default `100`)
  - `zk_autopurge_snap_retain_count` — from `config_coordination.zookeeper.autopurge_snap_retain_count` (default `3`)
  - `zk_autopurge_purge_interval` — from `config_coordination.zookeeper.autopurge_purge_interval` (default `1`)
  - `zk_num_selector_threads` — from `config_coordination.zookeeper.num_selector_threads` (default `3`)
  - `zk_num_worker_threads` — from `config_coordination.zookeeper.num_worker_threads` (default `8`)
  - `zk_4lw_commands_whitelist` — from `config_coordination.zookeeper.four_letter_whitelist` (default `*`)
  - `zk_admin_enable_server` — from `config_coordination.zookeeper.admin_enable_server` (default `true`)
  - `zk_pre_alloc_size` — from `config_coordination.zookeeper.pre_alloc_size` (default `65536`)
  - `zk_snap_count` — from `config_coordination.zookeeper.snap_count` (default `100000`)
  - `zk_global_outstanding_limit` — from `config_coordination.zookeeper.global_outstanding_limit` (default `1000`)
  - `zk_heap_min_mb` — from `config_coordination.zookeeper.heap.min_mb` (default `1000`)
  - `zk_heap_max_mb` — from `config_coordination.zookeeper.heap.max_mb` (default `4000`)
  - `zk_gc_type` — from `config_coordination.zookeeper.gc_type` (default `G1GC`)
  - `zk_metrics_enabled` — from `config_coordination.zookeeper.metrics_enabled` (default `true`)
  - `zk_memory_limit` — from `config_coordination.zookeeper.memory_limit` (default `6G`), used as systemd `MemoryMax`
  - `zk_nofile_limit` — from `config_coordination.zookeeper.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `zk_http_proxy` / `zk_https_proxy` — inherits global proxy vars
  - `zk_download_timeout` — from `config_coordination.zookeeper.download_timeout` (default `300` seconds)
  - `zk_wait_retries` — from `config_coordination.zookeeper.wait_retries` (default `10`)
  - `zk_wait_delay` — from `config_coordination.zookeeper.wait_delay` (default `10` seconds)
  - `zk_log_rotation_size` — from `config_coordination.zookeeper.log_rotation_size` (default `100M`)
  - `zk_log_rotation_count` — from `config_coordination.zookeeper.log_rotation_count` (default `5`)
- Proxy-aware (http_proxy, https_proxy for download)
- **Task flow:** validate → create_user → pre_install → migrate_data → install → cleanup → config → service → verify
- **Pre-install download-before-stop pattern:** The pre_install step downloads the Apache ZooKeeper tarball while the service is still running (download can take minutes over proxy), then stops the service only after download completes. This minimises downtime during upgrades. Same pattern as Kafka KRaft broker and Elasticsearch.
- **Migrate data step:** Moves old data directory from inside the symlinked version directory (`<parent_dir>/data`) to the new persistent location (`zk_data_dir`) that survives upgrades. Only runs if old dir exists and new dir is empty. Uses `mv` for atomic relocation. Runs after pre_install (service stopped) and before install (new dirs created).
- Configuration hierarchy: all settings sourced from `config_coordination.zookeeper.*` with sensible defaults

### Elasticsearch
- **Variable prefix:** `es_*` (refactored from legacy `elasticsearch_*` naming)
- Sub-roles: `service/`, `exporter/`
- **Templates:** Role-local (under `roles/elasticsearch/service/templates/`) — not sourced from `inventory_dir/configs/`
- **Config task flow:** template elasticsearch.yml → template jvm.options → set log4j max size (file limits managed directly in `elasticsearch.service.j2` template via `LimitNOFILE`)
- Core settings sourced from `config.elk.elasticsearch.*`, `ports.elk.elasticSearch.*`, `paths.elasticsearch.*`, `version.elk.elasticsearch`
- **Pre-install download-before-stop pattern:** The pre_install step downloads the Elasticsearch tarball while the service is still running (download can take minutes over proxy), then stops the service only after download completes. This minimises downtime during upgrades. Same pattern as Kafka KRaft broker.
- **Key defaults variables:**
  - `es_version` — from `version.elk.elasticsearch`
  - `es_base_dir` — from `paths.elasticsearch.base_dir`
  - `es_cluster_name` — from `config.elk.elasticsearch.cluster_name`
  - `es_arch` — default `linux-x86_64`
  - `es_port` / `es_transport_port` — service and transport ports (transport default 9300)
  - `es_bind_address` — default `0.0.0.0`
  - `es_nodes` — auto-derived from `elasticsearch` host group IPs
  - `es_node_name` — uses `inventory_hostname`
  - `es_initial_master_nodes` / `es_discovery_seed_hosts` — default to `es_nodes`
  - `es_indices_retention_days` / `es_logs_retention_days` — ILM retention settings
  - `es_heap_size` — default `4g`
  - `es_log_max_size` — default `300MB`
  - `es_max_open_files` — default `65536`
  - `es_memory_limit` — from `config.elk.elasticsearch.memory_limit` (default `8G`), used as systemd `MemoryMax`
  - `es_user` / `es_group` — default `elasticsearch`
  - `es_http_proxy` / `es_https_proxy` — inherits global proxy vars
  - `es_download_timeout` — default `120` seconds
  - `es_date_nanos_enabled` — nanosecond timestamp support (default `true`)
  - `es_date_nanos_index_pattern` — default `kubelogs*`
  - `es_wait_retries` / `es_wait_delay` — readiness check settings (defaults: 10 retries, 15s delay)
- **Exporter sub-role defaults** (variable prefix `es_exporter_*`, refactored from legacy `elastic_search_exporter_*`):
  - `es_exporter_version` — from `version.elk.elasticsearch_exporter`
  - `es_exporter_base_dir` — from `paths.elasticsearch_exporter.base_dir`
  - `es_exporter_port` — from `ports.elk.elasticSearch.exporter`
  - `es_exporter_es_port` — from `ports.elk.elasticSearch.service`
  - `es_exporter_user` / `es_exporter_group` — default `elastic-exporter`
  - `es_exporter_listen_address` — default `0.0.0.0`
  - `es_exporter_arch` — default `linux-amd64`
  - `es_exporter_http_proxy` / `es_exporter_https_proxy` — inherits global proxy vars
  - `es_exporter_download_timeout` — default `30` seconds

### Loki (Log Aggregation)
- Deploys Grafana Loki as a systemd service for log aggregation (push-based, pairs with Promtail/Fluent Bit)
- **Variable prefix:** `loki_*`
- **Role path:** `roles/elk/loki/`
- **Configuration source:** `config_elk.loki.*` in `config_elk.yml`
- **Install method:** GitHub release binary download
- **Key defaults variables:**
  - `loki_version` — from `version.loki` (default `3.7.0`)
  - `loki_base_dir` — from `paths.loki.base_dir` (default `/apps`)
  - `loki_port` — from `ports.loki.service` (default `3100`)
  - `loki_arch` — default `linux-amd64`
  - `loki_user` / `loki_group` — from `config_elk.loki.user`/`.group` (default `loki`)
  - `loki_data_dir` — from `config_elk.loki.data_dir` (default `<base_dir>/loki_data`)
  - `loki_retention_period` — from `config_elk.loki.retention_period` (default `168h`)
  - `loki_retention_enabled` — from `config_elk.loki.retention_enabled` (default `true`)
  - `loki_listen_address` — from `config_elk.loki.listen_address` (default `0.0.0.0`)
  - `loki_log_level` — from `config_elk.loki.log_level` (default `warn`)
  - `loki_grpc_port` — from `config_elk.loki.grpc_port` (default `9096`)
  - `loki_memory_limit` — from `config_elk.loki.memory_limit` (default `2G`), used as systemd `MemoryMax`
  - `loki_nofile_limit` — from `config_elk.loki.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `loki_ingestion_rate_mb` — from `config_elk.loki.ingestion_rate_mb` (default `10`)
  - `loki_ingestion_burst_mb` — from `config_elk.loki.ingestion_burst_mb` (default `20`)
  - `loki_max_streams_per_user` — from `config_elk.loki.max_streams_per_user` (default `10000`)
  - `loki_http_proxy` / `loki_https_proxy` — inherits global proxy vars
  - `loki_download_timeout` — from `config_elk.loki.download_timeout` (default `120` seconds)
- Proxy-aware (http_proxy, https_proxy for download)
- **Task flow:** validate → create_user → pre_verify → pre_install → install → cleanup → config → service → verify
- **Pre-verify sub-steps:** base directory exists → user exists → group exists → port status (informational)
- **Verify sub-steps:** service active check → port listening (timeout 30s) → `/ready` endpoint HTTP 200 (retries 5, delay 5s) → version confirmation → deployment status summary

### Kibana (ELK Dashboard)
- Deploys Kibana as a systemd service for Elasticsearch visualisation and dashboarding
- **Variable prefix:** `kibana_*` (refactored from legacy `kibana_install_version` / `kibana_server_host` naming)
- **Role path:** `roles/elk/kibana/`
- **Configuration source:** `config_elk.kibana.*` in `config_elk.yml`
- **Install method:** RPM download from artifacts.elastic.co
- **Key defaults variables:**
  - `kibana_version` — from `version.elk.kibana` (default `9.0.3`)
  - `kibana_base_dir` — from `paths.kibana.base_dir` (default `/apps`)
  - `kibana_port` — from `ports.elk.kibana.service` (default `5601`)
  - `kibana_host` — from `config_elk.kibana.server_host` (default `0.0.0.0`)
  - `kibana_base_path` — from `config_elk.kibana.base_path` (default `''`)
  - `kibana_user` / `kibana_group` — from `config_elk.kibana.user`/`.group` (default `kibana`)
  - `kibana_elasticsearch_hosts` — from `config_elk.kibana.elasticsearch_hosts` (default `['http://localhost:9200']`)
  - `kibana_elasticsearch_ssl_verification` — from `config_elk.kibana.elasticsearch_ssl_verification_mode` (default `none`)
  - `kibana_elasticsearch_username` — from `config_elk.kibana.elasticsearch_username` (default `''`)
  - `kibana_elasticsearch_password` — from `config_elk.kibana.elasticsearch_password` (default `''`)
  - `kibana_log_level` — from `config_elk.kibana.log_level` (default `warn`)
  - `kibana_memory_limit` — from `config_elk.kibana.memory_limit` (default `1G`), used as systemd `MemoryMax`
  - `kibana_nofile_limit` — from `config_elk.kibana.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `kibana_node_options` — from `config_elk.kibana.node_options` (default `--max-old-space-size=768`)
  - `kibana_http_proxy` / `kibana_https_proxy` — inherits global proxy vars
  - `kibana_download_timeout` — from `config_elk.kibana.download_timeout` (default `120` seconds)
  - `kibana_wait_retries` / `kibana_wait_delay` — readiness check settings (defaults: 10 retries, 15s delay)
- Proxy-aware (http_proxy, https_proxy for download)
- **Task flow:** validate → pre_install → install → config → service → verify
- **Verify sub-steps:** service active check → port listening (timeout 60s, retries) → status API (`/api/status` HTTP 200, retries 5, delay 15s) → version confirmation (rpm query) → deployment status summary (service state, version, port, host, ES hosts, status, URL)

### Kubernetes (Test Fixed Network)
- 2 master nodes (1 init + 1 join), 13 worker nodes
- Pod network CIDR: 192.168.0.0/16
- Service CIDR: 10.96.0.0/12
- NodePort range: 49400-49799
- Control Plane Endpoint: `martini.ee.test.nat.bt.com:61000`
- Ansible user: `app-manager`
- Max pods per node: 150
- Container log rotation: max 50Mi, 5 files
- **Test Kubernetes config** (`config_kubernetes.yml`):
  - Longhorn: worker group `kubernetes_worker`, 2 replicas, storage reserved 50%, minimal available 10%, engine guaranteed CPU 500m, manager limits 1 CPU / 2Gi memory
  - Ingress controller: timeouts 5m/5m/10s, resources 100m–500m CPU / 256Mi–512Mi memory
  - Logging (Fluent Bit): ES target `10.11.21.37:61003`, match `_mat-test_`, namespace `kube-system`
  - Monitoring: Prometheus retention 15m, min/max block duration 5m, AlertManager disabled
  - Harbor: external URL `https://martini-test.nat.bt.com:61116`, `db_auth` mode, Longhorn storage, no Trivy
  - PostgreSQL (CNPG): cluster `mat-test`, namespace `postgres`, 1 instance, db `test`, user `mat_user`, Longhorn 30Gi, superuser enabled, bootstrap initdb, extensions (pg_stat_statements, pgcrypto, uuid-ossp, pg_trgm, btree_gist), max_connections 600, resources 500m–3000m CPU / 1Gi–5Gi memory
  - pgAdmin: email `admin@mat.bt.com`
  - Headlamp: namespace `headlamp`, port 4466, base path `/headlamp`, ingress enabled via HAProxy on `martini-test.nat.bt.com` (no TLS)
  - Grafana: namespace `grafana`, 1 replica, port 3000, base path `/grafana`, ingress enabled via HAProxy on `martini-test.nat.bt.com`, external PostgreSQL (`mat-test-rw.postgres.svc.cluster.local:5432`, db `grafana`, user `grafana`), SMTP enabled (`smtpb.intra.bt.com:25`, from `noreply.martini@bt.com`), LDAP enabled (`iuserldap.nat.bt.com:389`, bind DN `CN=MAT2023,OU=functional,OU=btplc,DC=iuser,DC=iroot,DC=adidom,DC=com`, sAMAccountName filter, search base `ou=employee,ou=btplc,dc=iuser,dc=iroot,dc=adidom,dc=com`, group mappings: `mygrp-mat-monitoring-grafana-SuperAdmin` → Admin (grafana_admin) orgs 1–3, `mygrp-mat-monitoring-grafana-Admin` → Admin orgs 1–3, `mygrp-mat-monitoring-grafana-Editor` → Editor orgs 1–3, `mygrp-mat-monitoring-grafana-Viewer` → Viewer orgs 1–3), plugins: `grafana-piechart-panel`, `grafana-polystat-panel`, `grafana-clock-panel`, `yesoreyeram-infinity-datasource`, `flant-statusmap-panel`, `marcusolsson-dynamictext-panel`, `grafana-elasticsearch-datasource`, resources 100m–1500m CPU / 256Mi–4Gi memory
  - LibreFS: namespace `librefs`, distributed mode, 5 replicas, hostPath `/apps/librefs_data`, root user `admin`, resources 250m–2000m CPU / 512Mi–2Gi memory, node label targeting (`storage=true`)
  - Supabase: namespace `supabase`, release `supabase`, endpoint `http://martini-test.nat.bt.com`, built-in DB (Longhorn 20Gi), S3 storage enabled (LibreFS backend: `http://librefs.librefs.svc.cluster.local:9000`, bucket `supabase-storage`), ingress on `martini-test.nat.bt.com/` (Kong class, no TLS), 1 replica for kong/auth/rest/studio/realtime, realtime disabled, metrics enabled, node targeting `app=mat_ai`
  - Node labels: `role=worker` on all 13 worker nodes; `storage=true` on blt20919021–026; `app=mat_fn` on blt20919021–023; `app=mat_ai` on blt20919024–026; `app=mat_ee` + `type=nat_ip` on blt20919078–080; `app=mat_mix` on blt20919050–053

### Kubernetes (Prod Fixed Network)
- 3 master nodes, 15 worker nodes
- Pod network CIDR: 192.168.0.0/16
- Service CIDR: 10.96.0.0/12
- NodePort range: 49400-49799
- Control Plane Endpoint: `martini-analytics.nat.bt.com:61012` (load-balanced DNS for multi-master HA)
- Ansible user: `app-manager`
- Max pods per node: 150
- Container log rotation: max 50Mi, 5 files
- Ingress controller version: 0.14.5
- **Prod Kubernetes config** (`config_kubernetes.yml`):
  - Node labels: tier-based scheme — `tier=collection` (blp20919025–029, 5 nodes), `tier=processing` (blp20919030–034, 5 nodes), `tier=interface` (blp20919035, blp20919036, blp20919888, 3 nodes), `tier=internal` (blp20919889, blp20919890, 2 nodes). All nodes also labelled `role=worker`.
  - Longhorn: worker group `longhorn_worker` (6 nodes: blp20919027, 030, 031, 034, 035, 036), 2 replicas, storage reserved 50%, minimal available 10%
  - Ingress controller: timeouts 5m/5m/10s, resources 100m–500m CPU / 256Mi–512Mi memory
  - Harbor: external URL `https://martini-analytics.nat.bt.com:61140`, `db_auth` mode, Longhorn storage, no Trivy
  - PostgreSQL (CNPG): cluster `mat-fn-prod`, namespace `postgres`, 3 instances, db `matfnprod`, user `mat_user`, Longhorn 100Gi, PgBouncer enabled (transaction mode, pool 25, max conn 200), max_connections 600, shared_buffers 512MB
  - pgAdmin: email `admin@mat.bt.com`
  - Logging (Fluent Bit): ES target `10.6.102.112:61003`, pattern `kube.*`, namespace `kube-system`
  - Monitoring: Prometheus retention 15m, min/max block duration 5m, AlertManager disabled
- **ingress-controller sub-role** (HAProxy Ingress via Helm):
  - Helm chart: `haproxytech/kubernetes-ingress` from `https://haproxytech.github.io/helm-charts`
  - Default version: 1.52.0 (configurable via `version.kubernetes.ingress_controller`)
  - Deployment: DaemonSet with hostPort enabled
  - Namespace: `ingress-controller`
  - Configurable timeouts: client (5m), server (5m), connect (10s)
  - Resource requests/limits: CPU 100m–500m, Memory 256Mi–512Mi
  - Proxy-aware (http_proxy, https_proxy, no_proxy)
  - All parameters sourced from `config.kubernetes.ingress_controller.*` with sensible defaults
  - ConfigMap naming: `<release_name>-kubernetes-ingress` (e.g., `haproxy-ingress-kubernetes-ingress`)
  - Task flow: add helm repo → helm upgrade --install → copy patch-timeouts.yaml → patch configmap → verify (wait for pods ready + status display)
- **helm sub-role** (Helm package manager for Kubernetes):
  - Installs and manages the Helm CLI binary on the init master node (playbook targets `kubernetes_master_init`)
  - Role path: `roles/kubernetes/cluster/helm/`
  - **Variable prefix:** `helm_*`
  - **Key defaults variables:**
    - `helm_version` — from `version.kubernetes.helm` (default `4.2.1`)
    - `helm_base_dir` — from `paths.helm.base_dir` (falls back to `paths.kubernetes.base_dir`)
    - `helm_install_dir` — `/usr/local/bin` (binary install location)
    - `helm_arch` — default `linux-amd64`
    - `helm_ansible_user` — from `config.kubernetes.ansible_user` (falls back to `ansible_user`)
    - `helm_additional_users` — from `config.kubernetes.docker_less.additional_users` (default `[]`)
    - `helm_http_proxy` / `helm_https_proxy` — inherits global proxy vars
    - `helm_download_timeout` — from `config.kubernetes.helm.download_timeout` (default `120` seconds)
  - Proxy-aware (http_proxy, https_proxy for download)
- **docker_less sub-role** (containerd-based, no Docker dependency):
  - Kubernetes: 1.36.1, Calico CNI: 3.32.0
  - Container runtime: containerd with cgroups v2 (SystemdCgroup enabled)
  - Service CIDR: 10.96.0.0/12
  - Custom data directories (under `paths.kubernetes.base_dir`):
    - Containerd root: `<base_dir>/kubernetes_data/containerd`
    - Kubelet root: `<base_dir>/kubernetes_data/kubelet`
    - Logs: `<base_dir>/kubernetes_data/logs` (variable: `k8s_log_dir`)
    - Etcd data: `<base_dir>/kubernetes_data/etcd`
  - **Kubelet configuration:**
    - Max pods per node: default 110 (configurable via `config.kubernetes.docker_less.max_pods`)
    - Eviction thresholds (hard): memory.available < 200Mi, nodefs.available < 10%, imagefs.available < 15%, pid.available < 5%
  - **Container log rotation:** max size 50Mi, max 3 files per container
  - **API Server:** NodePort range 49400-49799 (configurable via `config.kubernetes.docker_less.nodeport_range`)
  - **Control Plane Endpoint:** `martini-analytics.nat.bt.com:61012` (configurable via `config.kubernetes.docker_less.control_plane_endpoint`, used for multi-master HA with load-balanced DNS)
  - **Certificate renewal:** enabled by default, scheduled weekly (cron: `7 3 * * 1` — every Monday at 03:07). Cron minute is staggered per master node (`base_minute + index * 10`) to avoid simultaneous renewal across multi-master clusters.
  - Repos: pkgs.k8s.io (Kubernetes), download.docker.com (containerd)
  - Proxy-aware (http_proxy, https_proxy, no_proxy configured via systemd drop-in)
  - **Task flow (prerequisites):** cgroups → system_packages → kernel_modules → sysctl → disable_swap → clean_environment_proxy → containerd → kubernetes_packages (includes log directory setup) → verify
  - **Clean environment proxy step:** Removes HTTP_PROXY/HTTPS_PROXY/NO_PROXY variables (both upper and lower case) from `/etc/environment`. BT base images sometimes set these; `kubeadm init` reads `/etc/environment` and bakes proxy vars into the kube-apiserver static pod manifest, causing webhook calls to route through the corporate proxy which does TLS interception and breaks certificate verification. This task MUST run BEFORE `kubeadm init` so the apiserver manifest is generated clean. Proxy for K8s components is managed explicitly via containerd systemd drop-in and Ansible task-level environment.
  - **Log directory management (kubernetes_packages step):** Creates `<base_dir>/kubernetes_data/logs/pods` and `<base_dir>/kubernetes_data/logs/containers`, migrates existing logs from `/var/log/pods` and `/var/log/containers`, then symlinks those system paths to the `/apps` location. This keeps pod/container logs on the data volume rather than the root filesystem.
  - **Verify step checks:** cgroups v2 active, overlay + br_netfilter modules loaded, ip_forward + bridge-nf-call sysctl enabled, swap disabled, containerd running + CRI responding, kubelet + kubeadm installed, firewalld inactive
  - **Containerd setup:** Docker CE repo (inline content with sslverify=0 for proxy compatibility) → install containerd.io → generate default config → enable SystemdCgroup → set sandbox image → configure proxy → enable/start service
  - **Master host groups:** Uses `kubernetes_master_init` (the single node that runs `kubeadm init`) and `kubernetes_master_join` (additional masters that join the control plane). Tasks delegate cert-key generation and join-command creation to the init master.
  - **Master playbook structure:** `kubernetes_master_setup_dockerless.yaml` uses two separate plays (no `serial: 1`): Play 1 targets `kubernetes_master_init` to complete `kubeadm init` first; Play 2 targets `kubernetes_master_join` to join remaining masters in parallel after init is ready. Both plays load `_global_vars/all.yml` and `_global_vars/common_config.yml`, and apply `roles/_misc/disable_external_repos` before the `docker_less` role to prevent yum timeout failures from unreachable external repos.
  - **Task flow (master):** init (creates etcd data dir with mode 0700, deploys `kubeadm-config.yaml.j2` template to `/tmp/kubeadm-config.yaml`, runs `kubeadm init --config /tmp/kubeadm-config.yaml --upload-certs` on `kubernetes_master_init` group, removes config file after init, generates join command and joins on `kubernetes_master_join` group) → kubeconfig → calico → cert_renewal → verify
  - **Certificate renewal task:** Deploys `/usr/local/bin/k8s-cert-renew.sh` script (runs `kubeadm certs renew all` + restarts control plane by cycling manifests + re-copies `admin.conf` to kubeconfig locations for root, `k8s_ansible_user`, and all `k8s_additional_users`) and schedules it via cron. Controlled by `k8s_cert_renewal_enabled` (bool) and `k8s_cert_renewal_schedule` (cron expression, default `0 3 1 * *`). Includes a cert expiry check for visibility. Certificate renewal variables are sourced from `config_k8s.docker_less.cert_renewal.*` with hardcoded defaults (requires inventories to use the `config_k8s:` root key). Additional cert renewal variables:
    - `k8s_cert_renewal_threshold_days` — from `config_k8s.docker_less.cert_renewal.threshold_days` (default `45`) — days before expiry to trigger renewal
    - `k8s_cert_renewal_smtp_host` — from `config_k8s.docker_less.cert_renewal.smtp_host` (default `smtpb.intra.bt.com`)
    - `k8s_cert_renewal_smtp_port` — from `config_k8s.docker_less.cert_renewal.smtp_port` (default `25`)
    - `k8s_cert_renewal_from_email` — from `config_k8s.docker_less.cert_renewal.from_email` (default `noreply.martini@bt.com`)
    - `k8s_cert_renewal_to_emails` — from `config_k8s.docker_less.cert_renewal.to_emails` (default `[]`) — recipients for renewal notifications
    - `k8s_cert_renewal_cc_emails` — from `config_k8s.docker_less.cert_renewal.cc_emails` (default `[]`) — CC recipients for renewal notifications
    - `k8s_cert_renewal_log_file` — from `config_k8s.docker_less.cert_renewal.log_file` (default `/var/log/k8s-cert-renewal.log`)
  - **Task flow (worker):** join → verify
- **label_management sub-role** (Kubernetes node label management):
  - Adds or removes labels from K8s worker nodes via `kubectl label nodes`
  - Configuration via `config.kubernetes.node_labels.add` (list) and `config.kubernetes.node_labels.remove` (list)
  - Runs from a master node (`kubernetes_master_1` group)
  - Supports batch operations: processes node groups with multiple labels per group
  - **Inventory group resolution:** `label_group.nodes` entries can be either direct node names or inventory host group names. If a name matches an inventory group, it is automatically expanded to the hostnames in that group. This allows labelling entire host groups (e.g., `kubernetes_worker`) without listing individual nodes.
  - Task flow: resolve node names (expand inventory groups) → add labels (if any) → remove labels (if any) → verify (show labels on affected nodes)
- **logging sub-role** (Kubernetes log collection via Fluent Bit → Elasticsearch or Loki):
  - Deploys Fluent Bit as a DaemonSet for container log collection
  - Default image: `cr.fluentbit.io/fluent/fluent-bit` (version from `version.kubernetes.logging.fluent_bit`, default `5.0.7`)
  - Namespace: configurable via `config.kubernetes.logging.namespace` (default `kube-system`)
  - **Output backend:** configurable via `config_k8s.logging.backend` (default `elasticsearch`) — supports `elasticsearch` or `loki`
  - **Elasticsearch output:** host/port from `config.kubernetes.logging.elasticsearch.host`/`.port`, index prefix `kubelogs`, date format `%d.%m.%Y`, optional TLS
  - **Loki output:** host from `config_k8s.logging.loki.host` (default `loki.loki.svc.cluster.local`), port from `config_k8s.logging.loki.port` (default `3100`), optional tenant ID from `config_k8s.logging.loki.tenant_id` (default empty)
  - **Log collection:** match patterns from `config.kubernetes.logging.match_patterns`, log level default `warn`
  - **Resources:** requests 100m CPU / 200Mi memory, limits 1000m CPU / 1536Mi memory
  - **Buffer:** mem_buf_limit 100MB, backlog_mem_limit 800M, ES workers 1, ES buffer size 2M
  - **Users:** inherits `config.kubernetes.ansible_user` (falls back to `ansible_user`)
  - **Wait settings:** retries 10, delay 15s (for readiness checks)
  - Configuration hierarchy: all settings sourced from `config.kubernetes.logging.*` with sensible defaults
- **monitoring sub-role** (Kubernetes cluster monitoring via Prometheus, Kube State Metrics, and Metrics Server):
  - Deploys in-cluster Prometheus, Kube State Metrics, and Metrics Server for Kubernetes observability
  - Role path: `roles/kubernetes/operations/monitoring/`
  - Namespace: configurable via `config_k8s.monitoring.namespace` (default `monitoring`)
  - **Variable prefix:** `k8s_mon_*`
  - **Components:**
    - Prometheus: in-cluster scraper with NodePort exposure, configurable retention and persistent storage
    - Kube State Metrics: exports K8s object state as Prometheus metrics
    - Metrics Server: provides resource usage metrics for HPA and `kubectl top`
    - AlertManager: in-cluster alert routing and notification (email via SMTP), priority-based repeat intervals (P1/P2/P3)
    - Node Exporter: optional DaemonSet for host-level hardware/OS metrics (CPU, memory, disk, network)
  - **Versions:**
    - Prometheus: from `version.kubernetes.monitoring.prometheus` (default `v3.5.0`)
    - Kube State Metrics: from `version.kubernetes.monitoring.kube_state_metrics` (default `v2.14.0`)
    - Metrics Server: from `version.kubernetes.monitoring.metrics_server` (default `v0.8.1`)
    - AlertManager: from `version.kubernetes.monitoring.alertmanager` (default `v0.27.0`)
    - Node Exporter: from `version.kubernetes.monitoring.node_exporter` (default `v1.11.1`)
  - **Prometheus config:**
    - NodePort: from `ports.kubernetes.monitoring.prometheus` (default `30092`)
    - Retention: from `config_k8s.monitoring.prometheus_retention` (default `30d`)
    - Scrape interval: from `config_k8s.monitoring.prometheus_scrape_interval` (default `30s`)
    - Persistent storage: optional, storage class (default `longhorn`), size (default `10Gi`)
  - **Resources (Prometheus):** requests 250m CPU / 512Mi memory, limits 2000m CPU / 4Gi memory
  - **Resources (Kube State Metrics):** requests 100m CPU / 128Mi memory, limits 500m CPU / 512Mi memory
  - **Resources (Metrics Server):** requests 100m CPU / 200Mi memory, limits 500m CPU / 512Mi memory
  - **Resources (AlertManager):** requests 50m CPU / 128Mi memory, limits 200m CPU / 256Mi memory
  - **Resources (Node Exporter):** requests 50m CPU / 64Mi memory, limits 250m CPU / 128Mi memory
  - **AlertManager config:**
    - Enabled: from `config_k8s.monitoring.alertmanager.enabled` (default `true`)
    - NodePort: from `ports.kubernetes.monitoring.alertmanager` (default `0` — disabled unless set)
    - Ingress: optional (default disabled), configurable host/path/class via `config_k8s.monitoring.alertmanager.ingress.*`
    - SMTP relay: `smtpb.intra.bt.com:25`, from email `noreply.martini@bt.com`
    - Priority-based routing: P1 (2h repeat), P2 (6h repeat), P3 (24h repeat)
    - Group wait: 5m, resolve timeout: 48h
    - Alert rules: enabled by default, environment label `k8s`
  - **Key defaults variables:**
    - `k8s_mon_namespace` — from `config_k8s.monitoring.namespace` (default `monitoring`)
    - `k8s_mon_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `k8s_mon_prometheus_version` — from `version.kubernetes.monitoring.prometheus` (default `v3.5.0`)
    - `k8s_mon_kube_state_metrics_version` — from `version.kubernetes.monitoring.kube_state_metrics` (default `v2.14.0`)
    - `k8s_mon_metrics_server_version` — from `version.kubernetes.monitoring.metrics_server` (default `v0.8.1`)
    - `k8s_mon_prometheus_nodeport` — from `ports.kubernetes.monitoring.prometheus` (default `30092`)
    - `k8s_mon_prometheus_retention` — from `config_k8s.monitoring.prometheus_retention` (default `30d`)
    - `k8s_mon_prometheus_scrape_interval` — from `config_k8s.monitoring.prometheus_scrape_interval` (default `30s`)
    - `k8s_mon_prometheus_storage_enabled` — from `config_k8s.monitoring.prometheus_storage.enabled` (default `false`)
    - `k8s_mon_prometheus_storage_class` — from `config_k8s.monitoring.prometheus_storage.storage_class` (default `longhorn`)
    - `k8s_mon_prometheus_storage_size` — from `config_k8s.monitoring.prometheus_storage.size` (default `10Gi`)
    - `k8s_mon_prometheus_requests_cpu` / `k8s_mon_prometheus_requests_memory` — resource requests (defaults: `250m` / `512Mi`)
    - `k8s_mon_prometheus_limits_cpu` / `k8s_mon_prometheus_limits_memory` — resource limits (defaults: `2000m` / `4Gi`)
    - `k8s_mon_ksm_requests_cpu` / `k8s_mon_ksm_requests_memory` — KSM resource requests (defaults: `100m` / `128Mi`)
    - `k8s_mon_ksm_limits_cpu` / `k8s_mon_ksm_limits_memory` — KSM resource limits (defaults: `500m` / `512Mi`)
    - `k8s_mon_ms_requests_cpu` / `k8s_mon_ms_requests_memory` — Metrics Server resource requests (defaults: `100m` / `200Mi`)
    - `k8s_mon_ms_limits_cpu` / `k8s_mon_ms_limits_memory` — Metrics Server resource limits (defaults: `500m` / `512Mi`)
    - `k8s_mon_wait_retries` / `k8s_mon_wait_delay` — readiness check settings (defaults: 10 retries, 15s delay)
    - `k8s_mon_alertmanager_enabled` — from `config_k8s.monitoring.alertmanager.enabled` (default `true`)
    - `k8s_mon_alertmanager_version` — from `version.kubernetes.monitoring.alertmanager` (default `v0.27.0`)
    - `k8s_mon_alertmanager_nodeport` — from `ports.kubernetes.monitoring.alertmanager` (default `0`)
    - `k8s_mon_alertmanager_smtp_host` — from `config_k8s.monitoring.alertmanager.smtp_host` (default `smtpb.intra.bt.com:25`)
    - `k8s_mon_alertmanager_from_email` — from `config_k8s.monitoring.alertmanager.from_email` (default `noreply.martini@bt.com`)
    - `k8s_mon_alertmanager_to_emails` / `k8s_mon_alertmanager_cc_emails` — from `config_k8s.monitoring.alertmanager.to_emails`/`.cc_emails` (default `[]`)
    - `k8s_mon_alertmanager_group_wait` — from `config_k8s.monitoring.alertmanager.group_wait` (default `5m`)
    - `k8s_mon_alertmanager_resolve_timeout` — from `config_k8s.monitoring.alertmanager.resolve_timeout` (default `48h`)
    - `k8s_mon_alertmanager_p1/p2/p3_repeat_interval` — from `config_k8s.monitoring.alertmanager.p*_repeat_interval` (defaults: `2h` / `6h` / `24h`)
    - `k8s_mon_alertmanager_ingress_enabled` — from `config_k8s.monitoring.alertmanager.ingress.enabled` (default `false`)
    - `k8s_mon_alertmanager_ingress_host` — from `config_k8s.monitoring.alertmanager.ingress.host` (default `''`)
    - `k8s_mon_alertmanager_ingress_path` — from `config_k8s.monitoring.alertmanager.ingress.path` (default `/alertmanager`)
    - `k8s_mon_alertmanager_ingress_class` — from `config_k8s.monitoring.alertmanager.ingress.class` (default `haproxy`)
    - `k8s_mon_alertmanager_requests_cpu` / `k8s_mon_alertmanager_requests_memory` — AlertManager resource requests (defaults: `50m` / `128Mi`)
    - `k8s_mon_alertmanager_limits_cpu` / `k8s_mon_alertmanager_limits_memory` — AlertManager resource limits (defaults: `200m` / `256Mi`)
    - `k8s_mon_alert_rules_enabled` — from `config_k8s.monitoring.alert_rules.enabled` (default `true`)
    - `k8s_mon_env_label` — from `config_k8s.monitoring.env_label` (default `k8s`)
    - `k8s_mon_node_exporter_enabled` — from `config_k8s.monitoring.node_exporter.enabled` (default `false`)
    - `k8s_mon_node_exporter_version` — from `version.kubernetes.monitoring.node_exporter` (default `v1.11.1`)
    - `k8s_mon_node_exporter_port` — from `config_k8s.monitoring.node_exporter.port` (default `9100`)
    - `k8s_mon_node_exporter_max_requests` — from `config_k8s.monitoring.node_exporter.max_requests` (default `40`) — max concurrent scrape requests for Node Exporter
    - `k8s_mon_node_exporter_requests_cpu` / `k8s_mon_node_exporter_requests_memory` — Node Exporter resource requests (defaults: `50m` / `64Mi`)
    - `k8s_mon_node_exporter_limits_cpu` / `k8s_mon_node_exporter_limits_memory` — Node Exporter resource limits (defaults: `250m` / `128Mi`)
  - Proxy-aware (http_proxy, https_proxy)
  - Configuration hierarchy: all settings sourced from `config_k8s.monitoring.*` with sensible defaults
  - Task flow: install → verify
  - **Install sub-steps:** namespace → Prometheus ConfigMap (scrape config) → alert rules ConfigMap (when `k8s_mon_alert_rules_enabled`) → Prometheus Deployment (mounts both ConfigMaps) → Prometheus Service → Kube State Metrics → Metrics Server → AlertManager (when `k8s_mon_alertmanager_enabled`) → Node Exporter DaemonSet (when `k8s_mon_node_exporter_enabled`)
  - **Verify sub-steps:** wait for Prometheus pod ready → wait for kube-state-metrics pod ready → wait for metrics-server pod ready (in `kube-system` namespace) → validate `kubectl top nodes` → display deployment status summary
- **kafka sub-role** (Strimzi Kafka cluster on Kubernetes):
  - Deploys Apache Kafka via Strimzi operator (KafkaNodePool CRDs for brokers and controllers)
  - Role path: `roles/kubernetes/streaming/kafka/`
  - Namespace: configurable via `config_k8s.kafka.namespace`
  - Cluster name: configurable via `config_k8s.kafka.cluster_name`
  - **Variable prefix:** `kafka_*` (core cluster)
  - **Configuration source:** `config_k8s.kafka.*` in `config_kubernetes.yml`
  - Configuration hierarchy: all settings sourced from `config_k8s.kafka.*` with sensible defaults
- **kafka_connect role** (Strimzi Kafka Connect on Kubernetes — standalone role):
  - Deploys a Strimzi `KafkaConnect` CR and optional `KafkaConnector` CRDs for data integration pipelines
  - Role path: `roles/kubernetes/streaming/kafka_connect/`
  - Namespace: inherits from Kafka cluster (configurable via `config_k8s.kafka_connect.namespace`, falls back to `config_k8s.kafka.namespace`)
  - Cluster name: configurable via `config_k8s.kafka_connect.cluster_name` (default `<kafka_cluster_name>-connect`)
  - **Variable prefix:** `kafka_connect_*`
  - **Configuration source:** `config_k8s.kafka_connect.*` in `config_kubernetes.yml` (top-level section, separate from `config_k8s.kafka`)
  - **Environment variable:** `kafka_connect_action` — controls behaviour: `install` (default, deploy KafkaConnect cluster CR) or `deploy_connector` (deploy KafkaConnector CRDs from `config_k8s.kafka_connect.connectors` list)
  - **Bootstrap:** auto-derived from Kafka cluster (`<cluster>-kafka-bootstrap.<namespace>.svc:9092`), configurable via `config_k8s.kafka_connect.bootstrap_servers`
  - **Resources:** requests 250m CPU / 1Gi memory, limits 1000m CPU / 2Gi memory (configurable via `config_k8s.kafka_connect.resources.*`)
  - **Internal topics:** offset (`connect-cluster-offsets`), config (`connect-cluster-configs`), status (`connect-cluster-status`) — all with configurable replication factor (defaults to `config_k8s.kafka.default_replication_factor`)
  - **Converters:** key/value converters default to `org.apache.kafka.connect.json.JsonConverter` with schemas enabled
  - **Custom connector image:** Two modes — build (Strimzi builds image from plugin list, requires `output_image` + `plugins` config) or pre-built image (`config_k8s.kafka_connect.image`)
  - **Topology:** Inherits Kafka cluster topology settings (node labels, topology spread, rack awareness) with per-component overrides via `config_k8s.kafka_connect.topology.*`
  - **Metrics:** inherits Kafka cluster metrics setting by default (configurable via `config_k8s.kafka_connect.metrics.enabled`)
  - **Connector resources:** `use-connector-resources` annotation enabled by default (allows managing connectors as `KafkaConnector` CRDs)
  - **Connectors list:** Configurable via `config_k8s.kafka_connect.connectors` (default `[]`) — list of connector definitions deployed via the `deploy_connector` action
  - **Timeouts:** ready timeout 300s, retries 5, delay 30s (configurable via `config_k8s.kafka_connect.timeouts.*`)
  - **Key defaults variables:**
    - `kafka_connect_cluster_name` — from `config_k8s.kafka_connect.cluster_name` (default `<kafka_cluster_name>-connect`)
    - `kafka_connect_namespace` — from `config_k8s.kafka_connect.namespace` (falls back to `config_k8s.kafka.namespace`)
    - `kafka_connect_replicas` — from `config_k8s.kafka_connect.replicas` (falls back to `config_k8s.kafka.broker_replicas`)
    - `kafka_connect_version` — from `version.kubernetes.kafka.version`
    - `kafka_connect_bootstrap_servers` — from `config_k8s.kafka_connect.bootstrap_servers` (default auto-derived from Kafka cluster)
    - `kafka_connect_requests_cpu` / `kafka_connect_requests_memory` — resource requests (defaults: `250m` / `1Gi`)
    - `kafka_connect_limits_cpu` / `kafka_connect_limits_memory` — resource limits (defaults: `1000m` / `2Gi`)
    - `kafka_connect_group_id` — from `config_k8s.kafka_connect.group_id` (default matches cluster name)
    - `kafka_connect_offset_topic` / `kafka_connect_config_topic` / `kafka_connect_status_topic` — internal topic names
    - `kafka_connect_offset_replication_factor` / `kafka_connect_config_replication_factor` / `kafka_connect_status_replication_factor` — internal topic replication (defaults to `config_k8s.kafka.default_replication_factor`)
    - `kafka_connect_key_converter` / `kafka_connect_value_converter` — converter classes (default `JsonConverter`)
    - `kafka_connect_key_converter_schemas_enable` / `kafka_connect_value_converter_schemas_enable` — schema support (default `true`)
    - `kafka_connect_build_enabled` — from `config_k8s.kafka_connect.build.enabled` (default `false`)
    - `kafka_connect_build_output_image` — from `config_k8s.kafka_connect.build.output_image` (default `''`)
    - `kafka_connect_build_output_type` — from `config_k8s.kafka_connect.build.output_type` (default `docker`)
    - `kafka_connect_build_plugins` — from `config_k8s.kafka_connect.build.plugins` (default `[]`)
    - `kafka_connect_image` — from `config_k8s.kafka_connect.image` (default `''`) — pre-built image alternative to build
    - `kafka_connect_node_label_key` / `kafka_connect_node_label_value` — from `config_k8s.kafka_connect.topology.*` (falls back to Kafka cluster topology)
    - `kafka_connect_topology_key` — from `config_k8s.kafka_connect.topology.topology_key` (falls back to Kafka cluster)
    - `kafka_connect_topology_max_skew` — from `config_k8s.kafka_connect.topology.max_skew` (default `1`)
    - `kafka_connect_rack_enabled` — from `config_k8s.kafka_connect.topology.rack_enabled` (falls back to Kafka cluster, default `false`)
    - `kafka_connect_rack_topology_key` — from `config_k8s.kafka_connect.topology.rack_topology_key` (default `topology.kubernetes.io/zone`)
    - `kafka_connect_metrics_enabled` — from `config_k8s.kafka_connect.metrics.enabled` (falls back to `config_k8s.kafka.metrics.enabled`, default `true`)
    - `kafka_connect_use_connector_resources` — from `config_k8s.kafka_connect.use_connector_resources` (default `true`)
    - `kafka_connect_connectors` — from `config_k8s.kafka_connect.connectors` (default `[]`) — list of connector definitions
    - `kafka_connect_ready_timeout` — from `config_k8s.kafka_connect.timeouts.ready_timeout` (default `300s`)
    - `kafka_connect_retries` / `kafka_connect_delay` — from `config_k8s.kafka_connect.timeouts.*` (defaults: 5 retries, 30s delay)
    - `kafka_connect_http_proxy` / `kafka_connect_https_proxy` / `kafka_connect_no_proxy` — inherits global proxy vars
  - Proxy-aware (http_proxy, https_proxy, no_proxy)
  - Task flow: validate → install (when action=`install`) → deploy_connector (when action=`deploy_connector`) → verify
  - **Validate sub-steps:** assert bootstrap_servers defined → assert replicas >= 1 → assert replication factors <= broker count → assert node_label_key not empty → assert build output_image when build enabled → assert connectors defined (deploy_connector action only) → check Kafka cluster is Ready → display configuration summary
  - Configuration hierarchy: all settings sourced from `config_k8s.kafka_connect.*` with fallback to `config_k8s.kafka.*` for inherited settings
- **kafka_ui sub-role** (Kafbat UI for Kafka cluster management on Kubernetes):
  - Deploys Kafbat Kafka UI (`kafbat/kafka-ui`) as a Kubernetes service
  - Default version: v1.5.0 (configurable via `version.kubernetes.kafka_ui`)
  - Namespace: configurable via `config.kubernetes.kafka_ui.namespace` (default `kafka`)
  - Release name: configurable via `config.kubernetes.kafka_ui.release_name` (default `kafka-ui`)
  - **Ports:** NodePort default 61070 (service port no longer a role-level default)
  - **Multi-cluster support:** `config.kubernetes.kafka_ui.clusters` defines connected Kafka clusters
  - **Authentication:** LOGIN_FORM or LDAP auth (configurable via `config.kubernetes.kafka_ui.auth.*`), user list from `config.kubernetes.kafka_ui.users`, RBAC from `config.kubernetes.kafka_ui.rbac`
  - **LDAP (when auth.type = LDAP):** configurable via `config_k8s.kafka_ui.ldap.*` — urls (default `ldap://localhost:389`), base, admin_user, admin_password, user_filter_search_base, user_filter_search_filter (default `(sAMAccountName={0})`), group_filter_search_base, active_directory (default `false`), ad_domain
  - **Resources:** requests 100m CPU / 256Mi memory, limits 500m CPU / 512Mi memory
  - **Users:** inherits `config.kubernetes.ansible_user` (falls back to `ansible_user`)
  - **Wait settings:** retries 10, delay 15s (for readiness checks)
  - Configuration hierarchy: all settings sourced from `config.kubernetes.kafka_ui.*` with sensible defaults
- **kafdrop sub-role** (Kafdrop Kafka topic browser on Kubernetes):
  - Deploys Kafdrop (`obsidiandynamics/kafdrop`) on Kubernetes with HAProxy Ingress basic auth
  - Role path: `roles/kubernetes/streaming/kafdrop/`
  - Default version: 4.2.0 (configurable via `version.kubernetes.kafdrop`)
  - Namespace: configurable via `config_k8s.kafdrop.namespace` (default `kafka`)
  - **Variable prefix:** `kafdrop_*`
  - **Configuration source:** `config_k8s.kafdrop.*` in `config_kubernetes.yml`
  - **Kafka connection:** `config_k8s.kafdrop.bootstrap_servers` (required)
  - **Feature flags:** topic create (default `true`), topic delete (default `false`)
  - **Ingress:** HAProxy class, configurable host/path (`/kafdrop`), basic auth via htpasswd secret
  - **Authentication:** HAProxy Ingress basic auth — htpasswd-generated secret with configurable username (default `kafdrop`)
  - **Resources:** requests 100m CPU / 256Mi memory, limits 500m CPU / 512Mi memory (configurable via `config_k8s.kafdrop.resources.*`)
  - **JVM:** configurable opts (default `-Xms128M -Xmx256M`)
  - **Key defaults variables:**
    - `kafdrop_version` — from `version.kubernetes.kafdrop` (default `4.2.0`)
    - `kafdrop_image` — from `config_k8s.kafdrop.image` (default `obsidiandynamics/kafdrop`)
    - `kafdrop_namespace` — from `config_k8s.kafdrop.namespace` (default `kafka`)
    - `kafdrop_bootstrap_servers` — from `config_k8s.kafdrop.bootstrap_servers` (required)
    - `kafdrop_topic_create_enabled` — from `config_k8s.kafdrop.topic_create_enabled` (default `true`)
    - `kafdrop_topic_delete_enabled` — from `config_k8s.kafdrop.topic_delete_enabled` (default `false`)
    - `kafdrop_ingress_enabled` — from `config_k8s.kafdrop.ingress.enabled` (default `true`)
    - `kafdrop_ingress_host` — from `config_k8s.kafdrop.ingress.host` (default `''`)
    - `kafdrop_ingress_path` — from `config_k8s.kafdrop.ingress.path` (default `/kafdrop`)
    - `kafdrop_ingress_class` — from `config_k8s.kafdrop.ingress.class` (default `haproxy`)
    - `kafdrop_auth_enabled` — from `config_k8s.kafdrop.auth.enabled` (default `true`)
    - `kafdrop_auth_username` — from `config_k8s.kafdrop.auth.username` (default `kafdrop`)
    - `kafdrop_auth_password` — from vault (`kafdrop_auth_password_vault`)
    - `kafdrop_requests_cpu` / `kafdrop_requests_memory` — resource requests (defaults: `100m` / `256Mi`)
    - `kafdrop_limits_cpu` / `kafdrop_limits_memory` — resource limits (defaults: `500m` / `512Mi`)
    - `kafdrop_jvm_opts` — from `config_k8s.kafdrop.jvm_opts` (default `-Xms128M -Xmx256M`)
    - `kafdrop_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `kafdrop_wait_retries` / `kafdrop_wait_delay` — readiness check settings (defaults: 10 retries, 15s delay)
  - Secrets sourced from vault: `kafdrop_auth_password_vault`
  - **Deploy method:** Raw K8s manifests (no Helm dependency) — uses `kafdrop.yaml.j2` template applied via `kubectl apply`
  - Task flow: deploy (namespace → htpasswd secret → template manifest → kubectl apply → cleanup temp file) → verify
  - Configuration hierarchy: all settings sourced from `config_k8s.kafdrop.*` with sensible defaults
- **headlamp sub-role** (Headlamp Kubernetes web UI):
  - Deploys Headlamp as a Kubernetes web dashboard for cluster management
  - Role path: `roles/kubernetes/frontend/headlamp/`
  - Default version: v0.26.0 (configurable via `version.kubernetes.headlamp`)
  - Namespace: configurable via `config_k8s.headlamp.namespace` (default `headlamp`)
  - **Variable prefix:** `headlamp_*`
  - **Networking:**
    - Container port: configurable via `config_k8s.headlamp.port` (default `4466`)
    - Base path: configurable via `config_k8s.headlamp.base_path` (default `/headlamp`)
    - Ingress: enabled by default, class `haproxy`, configurable host/TLS via `config_k8s.headlamp.ingress.*`
    - NodePort: configurable via `ports.kubernetes.headlamp.nodeport` (default `0`, used when ingress disabled)
  - **Resources:** requests 50m CPU / 128Mi memory, limits 500m CPU / 256Mi memory (configurable via `config_k8s.headlamp.resources.*`)
  - **Key defaults variables:**
    - `headlamp_version` — from `version.kubernetes.headlamp` (default `v0.26.0`)
    - `headlamp_namespace` — from `config_k8s.headlamp.namespace` (default `headlamp`)
    - `headlamp_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `headlamp_ansible_user_home` — auto-derived (`/home/<user>` or `/root`)
    - `headlamp_port` — from `config_k8s.headlamp.port` (default `4466`)
    - `headlamp_base_path` — from `config_k8s.headlamp.base_path` (default `/headlamp`)
    - `headlamp_ingress_enabled` — from `config_k8s.headlamp.ingress.enabled` (default `true`)
    - `headlamp_ingress_host` — from `config_k8s.headlamp.ingress.host` (default `''`)
    - `headlamp_ingress_class` — from `config_k8s.headlamp.ingress.class` (default `haproxy`)
    - `headlamp_ingress_tls` — from `config_k8s.headlamp.ingress.tls` (default `false`)
    - `headlamp_nodeport` — from `ports.kubernetes.headlamp.nodeport` (default `0`)
    - `headlamp_requests_cpu` / `headlamp_requests_memory` — resource requests (defaults: `50m` / `128Mi`)
    - `headlamp_limits_cpu` / `headlamp_limits_memory` — resource limits (defaults: `500m` / `256Mi`)
    - `headlamp_wait_retries` / `headlamp_wait_delay` — readiness check settings (defaults: 10 retries, 15s delay)
    - `headlamp_http_proxy` / `headlamp_https_proxy` — inherits global proxy vars
  - Proxy-aware (http_proxy, https_proxy)
  - Configuration hierarchy: all settings sourced from `config_k8s.headlamp.*` with sensible defaults

- **grafana sub-role** (Grafana dashboarding on Kubernetes):
  - Deploys Grafana as a Kubernetes service for data visualisation and dashboarding
  - Role path: `roles/kubernetes/frontend/grafana/`
  - Default version: 12.1.1 (configurable via `version.kubernetes.grafana`)
  - Namespace: configurable via `config_k8s.grafana.namespace` (default `grafana`)
  - **Variable prefix:** `k8s_grafana_*`
  - **Networking:**
    - Container port: configurable via `config_k8s.grafana.port` (default `3000`)
    - Base path: configurable via `config_k8s.grafana.base_path` (default `/grafana`)
    - Ingress: enabled by default, class `haproxy`, configurable host via `config_k8s.grafana.ingress.*`
    - NodePort: configurable via `ports.kubernetes.grafana.nodeport` (default `0`, used when ingress disabled)
  - **Replicas:** configurable via `config_k8s.grafana.replicas` (default `1`)
  - **Admin:** user configurable (default `admin`), password from vault (`k8s_grafana_admin_password_vault`)
  - **External Database:** PostgreSQL by default (`config_k8s.grafana.database.*`), configurable type/host/port/name/user/ssl_mode, password from vault (`k8s_grafana_db_password_vault`)
  - **LDAP:** optional (default disabled), host `iuserldap.nat.bt.com`, port 389, sAMAccountName filter, configurable search_base_dns and group_mappings, bind password from vault (`k8s_grafana_ldap_bind_password_vault`)
  - **SMTP:** optional (default disabled), host `smtpb.intra.bt.com:25`, from `noreply.martini@bt.com`
  - **Plugins:** configurable list via `config_k8s.grafana.plugins` (default `[]`)
  - **Resources:** requests 100m CPU / 256Mi memory, limits 1000m CPU / 512Mi memory (configurable via `config_k8s.grafana.resources.*`)
  - **Key defaults variables:**
    - `k8s_grafana_version` — from `version.kubernetes.grafana` (default `12.1.1`)
    - `k8s_grafana_namespace` — from `config_k8s.grafana.namespace` (default `grafana`)
    - `k8s_grafana_release_name` — from `config_k8s.grafana.release_name` (default `grafana`)
    - `k8s_grafana_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `k8s_grafana_replicas` — from `config_k8s.grafana.replicas` (default `1`)
    - `k8s_grafana_port` — from `config_k8s.grafana.port` (default `3000`)
    - `k8s_grafana_base_path` — from `config_k8s.grafana.base_path` (default `/grafana`)
    - `k8s_grafana_ingress_enabled` — from `config_k8s.grafana.ingress.enabled` (default `true`)
    - `k8s_grafana_ingress_host` — from `config_k8s.grafana.ingress.host` (default `''`)
    - `k8s_grafana_ingress_class` — from `config_k8s.grafana.ingress.class` (default `haproxy`)
    - `k8s_grafana_nodeport` — from `ports.kubernetes.grafana.nodeport` (default `0`)
    - `k8s_grafana_admin_user` — from `config_k8s.grafana.admin_user` (default `admin`)
    - `k8s_grafana_admin_password` — from vault (`k8s_grafana_admin_password_vault`)
    - `k8s_grafana_db_type` — from `config_k8s.grafana.database.type` (default `postgres`)
    - `k8s_grafana_db_host` — from `config_k8s.grafana.database.host`
    - `k8s_grafana_db_port` — from `config_k8s.grafana.database.port` (default `5432`)
    - `k8s_grafana_db_name` — from `config_k8s.grafana.database.name` (default `grafana`)
    - `k8s_grafana_db_user` — from `config_k8s.grafana.database.user` (default `grafana`)
    - `k8s_grafana_db_password` — from vault (`k8s_grafana_db_password_vault`)
    - `k8s_grafana_db_ssl_mode` — from `config_k8s.grafana.database.ssl_mode` (default `disable`)
    - `k8s_grafana_ldap_enabled` — from `config_k8s.grafana.ldap.enabled` (default `false`)
    - `k8s_grafana_ldap_host` — from `config_k8s.grafana.ldap.host` (default `iuserldap.nat.bt.com`)
    - `k8s_grafana_ldap_port` — from `config_k8s.grafana.ldap.port` (default `389`)
    - `k8s_grafana_ldap_bind_dn` — from `config_k8s.grafana.ldap.bind_dn` (default `''`)
    - `k8s_grafana_ldap_bind_password` — from vault (`k8s_grafana_ldap_bind_password_vault`)
    - `k8s_grafana_ldap_search_filter` — from `config_k8s.grafana.ldap.search_filter` (default `(sAMAccountName=%s)`)
    - `k8s_grafana_ldap_search_base_dns` — from `config_k8s.grafana.ldap.search_base_dns` (default `[]`)
    - `k8s_grafana_ldap_group_mappings` — from `config_k8s.grafana.ldap.group_mappings` (default `[]`)
    - `k8s_grafana_smtp_enabled` — from `config_k8s.grafana.smtp.enabled` (default `false`)
    - `k8s_grafana_smtp_host` — from `config_k8s.grafana.smtp.host` (default `smtpb.intra.bt.com:25`)
    - `k8s_grafana_smtp_from_address` — from `config_k8s.grafana.smtp.from_address` (default `noreply.martini@bt.com`)
    - `k8s_grafana_plugins` — from `config_k8s.grafana.plugins` (default `[]`)
    - `k8s_grafana_requests_cpu` / `k8s_grafana_requests_memory` — resource requests (defaults: `100m` / `256Mi`)
    - `k8s_grafana_limits_cpu` / `k8s_grafana_limits_memory` — resource limits (defaults: `1000m` / `512Mi`)
    - `k8s_grafana_http_proxy` / `k8s_grafana_https_proxy` — inherits global proxy vars (default `''`)
    - `k8s_grafana_no_proxy` — from `config_k8s.grafana.no_proxy` (default `localhost,127.0.0.1,.svc,.cluster.local,10.96.0.0/12,192.168.0.0/16,.bt.com,.nat.bt.com,10.6.0.0/16,10.11.0.0/16,10.54.0.0/16`)
    - `k8s_grafana_wait_retries` / `k8s_grafana_wait_delay` — readiness check settings (defaults: 10 retries, 15s delay)
  - Proxy-aware (http_proxy, https_proxy, no_proxy — used for plugin downloads via `GF_INSTALL_PLUGINS` with proxy env vars in the deployment)
  - Secrets sourced from vault: `k8s_grafana_admin_password_vault`, `k8s_grafana_db_password_vault`, `k8s_grafana_ldap_bind_password_vault`
  - Configuration hierarchy: all settings sourced from `config_k8s.grafana.*` with sensible defaults

- **postgres sub-role** (CloudNativePG operator for PostgreSQL on Kubernetes):
  - Deploys PostgreSQL via the CloudNativePG (CNPG) operator using Helm
  - Helm chart version: configurable via `version.kubernetes.postgres.helm_chart`
  - PostgreSQL server version: configurable via `version.kubernetes.postgres.server` (default `18.4`)
  - Image: `ghcr.io/cloudnative-pg/postgresql` (configurable via `config.kubernetes.postgres.image.name`)
  - Helm chart: `cnpg/cloudnative-pg` from `https://cloudnative-pg.github.io/charts`
  - Namespace: configurable via `config.kubernetes.postgres.namespace`
  - Cluster name: configurable via `config.kubernetes.postgres.cluster_name`
  - Instances: configurable via `config.kubernetes.postgres.instances` (default 3)
  - **Variable prefix:** `cnpg_*` (refactored from legacy `postgres_*` naming)
  - **Storage:** `config.kubernetes.postgres.storage_class`, `config.kubernetes.postgres.storage_size`, optional separate WAL storage
  - **Resources:** requests/limits for CPU and memory via `config.kubernetes.postgres.resources.*`
  - **PostgreSQL parameters:** max_connections (200), shared_buffers (256MB), effective_cache_size (1GB), work_mem (4MB), maintenance_work_mem (128MB), wal_level (replica), synchronous_commit (remote_write), shared_preload_libraries (empty by default, configurable)
  - **PgBouncer (connection pooler):** optional, pool_mode transaction, default_pool_size 25, max_client_conn 100
  - **Backup (Longhorn snapshots):** optional, schedule `0 3 * * *`, retain 7
  - **Extensions:** configurable list via `config.kubernetes.postgres.extensions` (e.g., pgjwt, pgcrypto, uuid-ossp, pg_stat_statements)
  - **Topology & Affinity:** node label targeting, topology spread via `kubernetes.io/hostname`, configurable pod anti-affinity type (`required` = hard, `preferred` = soft/best-effort) via `config_k8s.postgres.topology.pod_anti_affinity_type` (default `required`). Use `preferred` when instances > number of zones (e.g., 3 instances across 2 DCs)
  - **Migration:** supports bootstrap modes `initdb` (fresh) and external source replication
  - **Maintenance:** reuse PVC (true), primary update strategy `unsupervised` with `switchover` method
  - **Ports:** internal 5432, metrics 9187, PgBouncer 5432 (configurable via `ports.kubernetes.postgres.*`)
  - **Security:** superuser enabled by default
  - **Timeouts:** operator retries 30 (10s delay), cluster retries 90 (20s delay)
  - Proxy-aware (http_proxy, https_proxy, no_proxy)
  - Secrets sourced from vault: `postgres_db_password_vault`, `postgres_replication_password_vault`
  - Configuration hierarchy: all settings sourced from `config.kubernetes.postgres.*` with sensible defaults

- **pgadmin sub-role** (pgAdmin web UI for PostgreSQL management on Kubernetes):
  - Deploys pgAdmin as a Kubernetes Deployment with PVC-backed storage
  - Namespace: configurable via `config.kubernetes.pgadmin.namespace` (falls back to `config.kubernetes.postgres.namespace`)
  - Version: configurable via `version.kubernetes.pgadmin`
  - Image: configurable via `config.kubernetes.pgadmin.image` (default `dpage/pgadmin4`)
  - **Variable prefix:** `pgadmin_*`
  - **PostgreSQL connection:** Auto-derived from postgres role config (cluster-name-rw service DNS, port, db, user, password) — no duplication of connection details
  - **Storage:** PVC with configurable storage class (defaults to postgres storage class) and size (default `2Gi`)
  - **Resources:** requests 100m CPU / 256Mi memory, limits 1500m CPU / 2Gi memory (configurable via `config.kubernetes.pgadmin.resources.*`)
  - **Ports:** NodePort from `ports.kubernetes.pgadmin.nodeport`, container port 80
  - **Node targeting:** Optional label-based node affinity via `config.kubernetes.pgadmin.topology.node_label_key` / `.node_label_value`
  - **Proxy:** no_proxy configurable via `config.kubernetes.pgadmin.no_proxy` (default `localhost,127.0.0.1,.svc,.cluster.local`)
  - **K8s resources deployed:** Secret (credentials), Secret (pgpass), PVC, Deployment, Service, RBAC
  - **Key defaults variables:**
    - `pgadmin_namespace` — from `config.kubernetes.pgadmin.namespace` (falls back to postgres namespace)
    - `pgadmin_email` — from `config.kubernetes.pgadmin.email`
    - `pgadmin_password` — from vault (`pgadmin_password_vault`)
    - `pgadmin_version` — from `version.kubernetes.pgadmin`
    - `pgadmin_image` — from `config.kubernetes.pgadmin.image` (default `dpage/pgadmin4`)
    - `pgadmin_pg_host` — auto-derived: `<cluster_name>-rw.<namespace>.svc.cluster.local`
    - `pgadmin_pg_port` — from `ports.kubernetes.postgres.internal` (default 5432)
    - `pgadmin_pg_db` — from `config.kubernetes.postgres.db_name`
    - `pgadmin_pg_user` — from `config.kubernetes.postgres.db_user`
    - `pgadmin_pg_password` — from vault (`postgres_db_password_vault`)
    - `pgadmin_storage_class` — from `config.kubernetes.pgadmin.storage_class` (falls back to postgres storage class)
    - `pgadmin_storage_size` — from `config.kubernetes.pgadmin.storage_size` (default `2Gi`)
    - `pgadmin_requests_cpu` / `pgadmin_requests_memory` — resource requests (defaults: `100m` / `256Mi`)
    - `pgadmin_limits_cpu` / `pgadmin_limits_memory` — resource limits (defaults: `1500m` / `2Gi`)
    - `pgadmin_nodeport` — from `ports.kubernetes.pgadmin.nodeport`
    - `pgadmin_container_port` — default `80`
    - `pgadmin_node_label_key` / `pgadmin_node_label_value` — optional node affinity labels
    - `pgadmin_no_proxy` — proxy exclusion list (default `localhost,127.0.0.1,.svc,.cluster.local`)
  - Task flow: install (apply secret, create pgpass secret, PVC, deployment, service, RBAC)
  - Secrets sourced from vault: `pgadmin_password_vault`, `postgres_db_password_vault`

- **mongo_express sub-role** (Mongo Express web-based MongoDB management on Kubernetes):
  - Deploys Mongo Express as a Kubernetes service for web-based MongoDB administration
  - Role path: `roles/kubernetes/database/mongo_express/`
  - Namespace: defaults to MongoDB namespace (configurable via `config_k8s.mongo_express.namespace`)
  - Version: configurable via `version.kubernetes.mongo_express` (default `1.0.2-20`)
  - Image: configurable via `config_k8s.mongo_express.image` (default `mongo-express`)
  - **Variable prefix:** `mongo_express_*`
  - **Configuration source:** `config_k8s.mongo_express.*` in `config_kubernetes.yml`
  - **MongoDB Connection:** Auto-derived from MongoDB role config (`config_k8s.mongodb.cluster_name`, `.namespace`, `.admin_user`) — no duplication of connection details
  - **Ports:** Container port 8081, NodePort from `ports.kubernetes.mongo_express.nodeport`
  - **Authentication:** Built-in basic auth (enabled by default), configurable user/password
  - **Resources:** requests 50m CPU / 128Mi memory, limits 500m CPU / 256Mi memory (configurable via `config_k8s.mongo_express.resources.*`)
  - **Node targeting:** Optional label-based node affinity via `config_k8s.mongo_express.topology.node_label_key` / `.node_label_value`
  - **Key defaults variables:**
    - `mongo_express_namespace` — from `config_k8s.mongo_express.namespace` (falls back to `config_k8s.mongodb.namespace`)
    - `mongo_express_admin_user` — from `config_k8s.mongo_express.admin_user` (default `admin`)
    - `mongo_express_admin_password` — from vault (`mongo_express_admin_password_vault`)
    - `mongo_express_version` — from `version.kubernetes.mongo_express` (default `1.0.2-20`)
    - `mongo_express_image` — from `config_k8s.mongo_express.image` (default `mongo-express`)
    - `mongo_express_mongodb_host` — auto-derived from `config_k8s.mongodb.cluster_name` and `.namespace` (K8s service DNS)
    - `mongo_express_mongodb_port` — from `config_k8s.mongo_express.mongodb_port` (falls back to `ports.kubernetes.mongodb.internal`, default `27017`)
    - `mongo_express_mongodb_admin_user` — from `config_k8s.mongo_express.mongodb_admin_user` (falls back to `config_k8s.mongodb.admin_user`, default `admin`)
    - `mongo_express_mongodb_admin_password` — from vault (`mongodb_admin_password_secret`) — MongoDB admin password passed directly as environment variable
    - `mongo_express_requests_cpu` / `mongo_express_requests_memory` — resource requests (defaults: `50m` / `128Mi`)
    - `mongo_express_limits_cpu` / `mongo_express_limits_memory` — resource limits (defaults: `500m` / `256Mi`)
    - `mongo_express_nodeport` — from `ports.kubernetes.mongo_express.nodeport`
    - `mongo_express_container_port` — default `8081`
    - `mongo_express_node_label_key` / `mongo_express_node_label_value` — optional node affinity labels
    - `mongo_express_basic_auth_enabled` — from `config_k8s.mongo_express.basic_auth_enabled` (default `true`)
    - `mongo_express_basic_auth_user` — from `config_k8s.mongo_express.basic_auth_user` (default `admin`)
    - `mongo_express_basic_auth_password` — from vault (`mongo_express_admin_password_vault`)
    - `mongo_express_site_baseurl` — from `config_k8s.mongo_express.site_baseurl` (default `/`)
  - Secrets sourced from vault: `mongo_express_admin_password_vault`, `mongodb_admin_password_secret`
  - Configuration hierarchy: all settings sourced from `config_k8s.mongo_express.*` with sensible defaults

- **supabase sub-role** (Supabase Backend-as-a-Service on Kubernetes):
  - Deploys Supabase (PostgreSQL + Auth + REST + Realtime + Storage + Studio) via Helm
  - Role path: `roles/kubernetes/database/supabase/`
  - Namespace: configurable via `config_k8s.supabase.namespace`
  - Chart version: configurable via `version.kubernetes.supabase.chart`
  - Helm chart: `supabase/supabase` from `https://supabase-community.github.io/supabase-kubernetes`
  - **Variable prefix:** `supabase_*`
  - **Storage:** storage class from `config_k8s.supabase.storage_class`, DB size from `config_k8s.supabase.db_storage_size`, file storage size (default `10Gi`)
  - **Database mode:** Built-in DB enabled by default (`config_k8s.supabase.db.enabled`), supports external PostgreSQL (host/port/name)
  - **Ports:** Kong (API gateway) from `ports.kubernetes.supabase.kong`, Studio from `ports.kubernetes.supabase.studio`, DB (default 5432)
  - **Ingress:** enabled by default, configurable host/path/class/TLS via `config_k8s.supabase.ingress.*`
  - **S3/MinIO Storage:** optional external object storage for Supabase Storage service (uses PVC when disabled)
    - `supabase_s3_enabled` — from `config_k8s.supabase.s3.enabled` (default `false`)
    - `supabase_s3_endpoint` — from `config_k8s.supabase.s3.endpoint` (default `''`)
    - `supabase_s3_region` — from `config_k8s.supabase.s3.region` (default `us-east-1`)
    - `supabase_s3_bucket` — from `config_k8s.supabase.s3.bucket` (default `supabase-storage`)
    - `supabase_s3_force_path_style` — from `config_k8s.supabase.s3.force_path_style` (default `true`)
    - `supabase_s3_access_key` / `supabase_s3_secret_key` — from vault (`supabase_s3_access_key_vault`, `supabase_s3_secret_key_vault`)
  - **Resources (DB):** requests/limits for CPU and memory via `config_k8s.supabase.resources.db.*`
  - **Resources (Kong):** requests 100m CPU / 256Mi memory, limits 500m CPU / 512Mi memory (configurable via `config_k8s.supabase.resources.kong.*`)
  - **Replicas:** kong (1), auth (1), rest (1), studio (1), realtime (1) — all configurable via `config_k8s.supabase.replicas.*`
  - **Optional components:** analytics (default disabled), vector (default disabled), realtime (default enabled)
  - **Metrics:** enabled by default, port 9542, pg_exporter version from `version.kubernetes.supabase.pg_exporter` (default `0.15.0`)
  - **Image tag overrides:** Per-component version pinning via `version.kubernetes.supabase.<component>` (e.g., `version.kubernetes.supabase.realtime: v2.105.1`). Supported components: `db`, `kong`, `studio`, `auth`, `rest`, `realtime`, `storage`, `meta`, `functions`, `imgproxy`. Set to `''` (empty) to use chart defaults. Allows upgrading individual Supabase services without changing the Helm chart version.
  - **Node targeting:** Optional label-based node affinity via `config_k8s.supabase.topology.node_label_key` / `.node_label_value`
  - **Key defaults variables:**
    - `supabase_namespace` — from `config_k8s.supabase.namespace`
    - `supabase_release_name` — from `config_k8s.supabase.release_name`
    - `supabase_chart_version` — from `version.kubernetes.supabase.chart`
    - `supabase_helm_repo_name` — from `config_k8s.supabase.helm.repo_name` (default `supabase`)
    - `supabase_helm_repo_url` — from `config_k8s.supabase.helm.repo_url` (default `https://supabase-community.github.io/supabase-kubernetes`)
    - `supabase_helm_chart_name` — from `config_k8s.supabase.helm.chart_name` (default `supabase/supabase`)
    - `supabase_storage_class` — from `config_k8s.supabase.storage_class`
    - `supabase_db_storage_size` — from `config_k8s.supabase.db_storage_size`
    - `supabase_file_storage_size` — from `config_k8s.supabase.file_storage_size` (default `10Gi`)
    - `supabase_db_enabled` — from `config_k8s.supabase.db.enabled` (default `true`)
    - `supabase_kong_port` — from `ports.kubernetes.supabase.kong` (internal container port)
    - `supabase_kong_nodeport` — from `ports.kubernetes.supabase.kong_nodeport` (default `0` — disabled; when > 0, patches Kong service to use this explicit NodePort)
    - `supabase_studio_port` — from `ports.kubernetes.supabase.studio`
    - `supabase_ingress_enabled` — from `config_k8s.supabase.ingress.enabled` (default `true`)
    - `supabase_ingress_host` — from `config_k8s.supabase.ingress.host`
    - `supabase_helm_timeout` — from `config_k8s.supabase.timeouts.helm_timeout` (default `600s`)
    - `supabase_operator_retries` / `supabase_operator_delay` — readiness check settings (defaults: 10 retries, 20s delay)
    - `supabase_metrics_enabled` — from `config_k8s.supabase.metrics.enabled` (default `true`)
    - `supabase_metrics_port` — from `ports.kubernetes.supabase.metrics` (default `9542`)
    - `supabase_image_tag_db` — from `version.kubernetes.supabase.db` (default `''`) — pin DB image version
    - `supabase_image_tag_kong` — from `version.kubernetes.supabase.kong` (default `''`) — pin Kong image version
    - `supabase_image_tag_studio` — from `version.kubernetes.supabase.studio` (default `''`) — pin Studio image version
    - `supabase_image_tag_auth` — from `version.kubernetes.supabase.auth` (default `''`) — pin Auth image version
    - `supabase_image_tag_rest` — from `version.kubernetes.supabase.rest` (default `''`) — pin REST (PostgREST) image version
    - `supabase_image_tag_realtime` — from `version.kubernetes.supabase.realtime` (default `''`) — pin Realtime image version
    - `supabase_image_tag_storage` — from `version.kubernetes.supabase.storage` (default `''`) — pin Storage image version
    - `supabase_image_tag_meta` — from `version.kubernetes.supabase.meta` (default `''`) — pin Meta image version
    - `supabase_image_tag_functions` — from `version.kubernetes.supabase.functions` (default `''`) — pin Functions image version
    - `supabase_image_tag_imgproxy` — from `version.kubernetes.supabase.imgproxy` (default `''`) — pin imgproxy image version
  - Proxy-aware (http_proxy, https_proxy, no_proxy — inherits from `config_k8s.docker_less.no_proxy`)
  - Task flow: validate → pre_deploy (create S3 bucket in libreFS if `supabase_s3_enabled`, using `mc` CLI — non-fatal, deployment continues if bucket exists or mc unavailable) → deploy (create S3 credentials secret `supabase-storage-s3-credentials` if `supabase_s3_enabled`, then helm install/upgrade, then post-helm patches: Recreate strategy for PVC-backed deployments, explicit Kong NodePort patch to `supabase_kong_nodeport` (conditional, skipped when nodeport is 0), Realtime IPv6 disable patch for IPv4-only nodes, S3 credentials env injection) → verify
  - Secrets sourced from vault: `supabase_jwt_secret_vault`, `supabase_anon_key_vault`, `supabase_service_role_key_vault`, `supabase_dashboard_password_vault`, `supabase_db_password_vault`, `supabase_s3_access_key_vault`, `supabase_s3_secret_key_vault`
  - Configuration hierarchy: all settings sourced from `config_k8s.supabase.*` with sensible defaults

- **falkordb sub-role** (FalkorDB graph database on Kubernetes):
  - Deploys FalkorDB (Redis-compatible graph database with Cypher query support) via Bitnami Redis Helm chart with FalkorDB module override
  - Role path: `roles/kubernetes/falkordb/`
  - Namespace: configurable via `config_k8s.falkordb.namespace` (default `falkordb`)
  - Chart: `oci://registry-1.docker.io/bitnamicharts/redis` (Bitnami Redis chart with FalkorDB image override)
  - Chart version: configurable via `version.kubernetes.falkordb_chart` (default `21.1.5`)
  - Image: `falkordb/falkordb` (version from `version.kubernetes.falkordb_image`, default `4.4.1`)
  - **Variable prefix:** `falkordb_*`
  - **Configuration source:** `config_k8s.falkordb.*` in `config_kubernetes.yml`
  - **Architecture:** Redis Sentinel HA topology — 1 master + N replicas + 3 Sentinel nodes for automatic failover
  - **HAProxy proxy:** Custom HAProxy Deployment routes client connections to the current master only (not replicas), exposed via NodePort
  - **Browser UI:** FalkorDB browser UI exposed via separate NodePort service (port 3000 internally, NodePort configurable)
  - **Ports:** Redis NodePort from `ports.kubernetes.falkordb.node_port` (default `61085`), Sentinel `ports.kubernetes.falkordb.sentinel` (default `61086`), Browser UI `ports.kubernetes.falkordb.browser_ui` (default `61084`)
  - **Persistence:** Longhorn PVC-backed, configurable size (default `8Gi`), RDB snapshots + AOF (appendonly yes, appendfsync everysec)
  - **FalkorDB module params:** THREAD_COUNT, CACHE_SIZE, RESULTSET_SIZE, MAX_QUEUED_QUERIES, TIMEOUT — all configurable via `config_k8s.falkordb.module.*`
  - **Resources (Master):** requests 1 CPU / 2Gi memory, limits 2 CPU / 4Gi memory (configurable via `config_k8s.falkordb.resources.master.*`)
  - **Resources (Replica):** requests 1 CPU / 2Gi memory, limits 2 CPU / 4Gi memory (configurable via `config_k8s.falkordb.resources.replica.*`)
  - **Resources (Sentinel):** requests 100m CPU / 128Mi memory, limits 200m CPU / 256Mi memory (configurable via `config_k8s.falkordb.resources.sentinel.*`)
  - **Topology & Affinity:** Node label targeting via `config_k8s.falkordb.topology.node_label_key` / `.node_label_value`, topology spread constraints via `topology_key` (default `kubernetes.io/hostname`) with configurable `max_skew` (default `1`), optional rack/zone-aware replica placement via `rack_enabled` (default `false`) using `rack_topology_key` (default `topology.kubernetes.io/zone`) for multi-DC fault tolerance
  - **Key defaults variables:**
    - `falkordb_chart_version` — from `version.kubernetes.falkordb_chart`
    - `falkordb_image_tag` — from `version.kubernetes.falkordb_image`
    - `falkordb_image_repo` — default `falkordb/falkordb`
    - `falkordb_namespace` — from `config_k8s.falkordb.namespace`
    - `falkordb_release_name` — from `config_k8s.falkordb.release_name`
    - `falkordb_base_dir` — from `paths.falkordb.base_dir`
    - `falkordb_replica_count` — from `config_k8s.falkordb.replica_count` (default `3`)
    - `falkordb_node_label_key` — from `config_k8s.falkordb.topology.node_label_key` — node affinity label key for FalkorDB pod scheduling
    - `falkordb_node_label_value` — from `config_k8s.falkordb.topology.node_label_value` — node affinity label value for FalkorDB pod scheduling
    - `falkordb_topology_key` — from `config_k8s.falkordb.topology.topology_key` (default `kubernetes.io/hostname`) — topology spread constraint key
    - `falkordb_topology_max_skew` — from `config_k8s.falkordb.topology.max_skew` (default `1`) — maximum pod distribution skew across topology domains
    - `falkordb_rack_enabled` — from `config_k8s.falkordb.topology.rack_enabled` (default `false`) — enables rack/zone-aware replica placement
    - `falkordb_rack_topology_key` — from `config_k8s.falkordb.topology.rack_topology_key` (default `topology.kubernetes.io/zone`) — node label key for rack/zone identification
    - `falkordb_redis_port` — from `ports.kubernetes.falkordb.redis`
    - `falkordb_sentinel_port` — from `ports.kubernetes.falkordb.sentinel`
    - `falkordb_browser_ui_port` — from `ports.kubernetes.falkordb.browser_ui`
    - `falkordb_node_port` — from `ports.kubernetes.falkordb.node_port` (default `61085`)
    - `falkordb_auth_enabled` — from `config_k8s.falkordb.auth_enabled`
    - `falkordb_service_type` — from `config_k8s.falkordb.service_type` (default `NodePort`)
    - `falkordb_persistence_size` — from `config_k8s.falkordb.persistence.size`
    - `falkordb_appendonly` — from `config_k8s.falkordb.persistence.appendonly`
    - `falkordb_appendfsync` — from `config_k8s.falkordb.persistence.appendfsync`
    - `falkordb_sentinel_down_after_ms` — from `config_k8s.falkordb.sentinel.down_after_ms`
    - `falkordb_sentinel_failover_timeout` — from `config_k8s.falkordb.sentinel.failover_timeout`
    - `falkordb_thread_count` — from `config_k8s.falkordb.module.thread_count`
    - `falkordb_cache_size` — from `config_k8s.falkordb.module.cache_size`
    - `falkordb_resultset_size` — from `config_k8s.falkordb.module.resultset_size`
    - `falkordb_max_queued_queries` — from `config_k8s.falkordb.module.max_queued_queries`
    - `falkordb_timeout` — from `config_k8s.falkordb.module.timeout`
    - `falkordb_verification_timeout` — from `config_k8s.falkordb.verification_timeout` (default `300`)
    - `falkordb_delete_namespace` — from `config_k8s.falkordb.delete_namespace` (default `false`)
  - **Environment variable:** `FALKORDB_ACTION` — controls behaviour: `install` (default, full deploy) or `uninstall` (remove all K8s resources)
  - Proxy-aware (http_proxy, https_proxy, no_proxy)
  - Task flow: validate → install (namespace, render Helm values, helm upgrade --install, deploy HAProxy proxy + browser UI service, cleanup temp files) → verify
  - Uninstall task flow: helm uninstall → delete HAProxy resources → delete namespace (if `falkordb_delete_namespace`)
  - Secrets sourced from vault: `falkordb_password` (Redis AUTH password)
  - Configuration hierarchy: all settings sourced from `config_k8s.falkordb.*` with sensible defaults

- **elasticsearch sub-role** (Elasticsearch on Kubernetes for pod log storage):
  - Deploys Elasticsearch as a StatefulSet on Kubernetes for pod log ingestion (Fluent Bit → ES)
  - Role path: `roles/kubernetes/database/elasticsearch/`
  - Namespace: configurable via `config_k8s.elasticsearch.namespace` (default `elasticsearch`)
  - Version: configurable via `version.kubernetes.elasticsearch` (default `8.19.16`)
  - **Variable prefix:** `k8s_es_*`
  - **Deploy method:** Raw K8s manifests (no Helm dependency) — uses `elasticsearch-statefulset.yaml.j2` template applied via `kubectl apply`
  - **Cluster config:** replicas must be 1 (single-node) or 3+ (cluster), cluster name configurable (default `k8s-logs`)
  - **Storage:** Longhorn PVC-backed, configurable storage class (default `longhorn`) and size (default `30Gi`)
  - **Networking:** HTTP port 9200, transport port 9300, optional NodePort (default `0` — disabled)
  - **JVM:** heap size configurable (default `1g`), memory limit must be ≥ 2× heap size
  - **Retention:** ILM-based, configurable retention days (default `7`)
  - **Security:** optional, disabled by default (`config_k8s.elasticsearch.security_enabled`)
  - **Resources:** requests 500m CPU / 2Gi memory, limits 2000m CPU / 4Gi memory (configurable via `config_k8s.elasticsearch.resources.*`)
  - **Node targeting:** Optional label-based node affinity via `config_k8s.elasticsearch.topology.node_label_key` / `.node_label_value`
  - **Key defaults variables:**
    - `k8s_es_version` — from `version.kubernetes.elasticsearch` (default `8.19.16`)
    - `k8s_es_namespace` — from `config_k8s.elasticsearch.namespace` (default `elasticsearch`)
    - `k8s_es_release_name` — from `config_k8s.elasticsearch.release_name` (default `elasticsearch`)
    - `k8s_es_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `k8s_es_replicas` — from `config_k8s.elasticsearch.replicas` (default `1`)
    - `k8s_es_cluster_name` — from `config_k8s.elasticsearch.cluster_name` (default `k8s-logs`)
    - `k8s_es_storage_class` — from `config_k8s.elasticsearch.storage_class` (default `longhorn`)
    - `k8s_es_storage_size` — from `config_k8s.elasticsearch.storage_size` (default `30Gi`)
    - `k8s_es_http_port` — from `config_k8s.elasticsearch.http_port` (default `9200`)
    - `k8s_es_transport_port` — from `config_k8s.elasticsearch.transport_port` (default `9300`)
    - `k8s_es_nodeport` — from `ports.kubernetes.elasticsearch.nodeport` (default `0`)
    - `k8s_es_heap_size` — from `config_k8s.elasticsearch.heap_size` (default `1g`)
    - `k8s_es_requests_cpu` / `k8s_es_requests_memory` — resource requests (defaults: `500m` / `2Gi`)
    - `k8s_es_limits_cpu` / `k8s_es_limits_memory` — resource limits (defaults: `2000m` / `4Gi`)
    - `k8s_es_retention_days` — from `config_k8s.elasticsearch.retention_days` (default `7`)
    - `k8s_es_security_enabled` — from `config_k8s.elasticsearch.security_enabled` (default `false`)
    - `k8s_es_node_label_key` / `k8s_es_node_label_value` — optional node affinity labels
    - `k8s_es_wait_retries` / `k8s_es_wait_delay` — readiness check settings (defaults: 20 retries, 15s delay)
  - Configuration hierarchy: all settings sourced from `config_k8s.elasticsearch.*` with sensible defaults
  - Task flow: validate → install → verify

- **loki sub-role** (Loki log aggregation on Kubernetes):
  - Deploys Grafana Loki as a StatefulSet on Kubernetes for log aggregation (Fluent Bit → Loki → Grafana)
  - Role path: `roles/kubernetes/database/loki/`
  - Namespace: configurable via `config_k8s.loki.namespace` (default `loki`)
  - Version: configurable via `version.kubernetes.loki` (default `3.7.0`)
  - **Variable prefix:** `k8s_loki_*`
  - **Deploy method:** Raw K8s manifests (no Helm dependency) — uses `loki-statefulset.yaml.j2` template applied via `kubectl apply`
  - **Storage:** Longhorn PVC-backed, configurable storage class (default `longhorn`) and size (default `20Gi`)
  - **Networking:** HTTP port 3100, gRPC port 9096, optional NodePort (default `0` — disabled)
  - **Retention:** configurable period (default `168h`), enabled by default
  - **Ingestion limits:** rate MB (default `10`), burst MB (default `20`), max streams (default `10000`)
  - **Resources:** requests 100m CPU / 256Mi memory, limits 1000m CPU / 1Gi memory (configurable via `config_k8s.loki.resources.*`)
  - **Key defaults variables:**
    - `k8s_loki_version` — from `version.kubernetes.loki` (default `3.7.0`)
    - `k8s_loki_namespace` — from `config_k8s.loki.namespace` (default `loki`)
    - `k8s_loki_release_name` — from `config_k8s.loki.release_name` (default `loki`)
    - `k8s_loki_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `k8s_loki_storage_class` — from `config_k8s.loki.storage_class` (default `longhorn`)
    - `k8s_loki_storage_size` — from `config_k8s.loki.storage_size` (default `20Gi`)
    - `k8s_loki_http_port` — from `config_k8s.loki.http_port` (default `3100`)
    - `k8s_loki_grpc_port` — from `config_k8s.loki.grpc_port` (default `9096`)
    - `k8s_loki_nodeport` — from `ports.kubernetes.loki.nodeport` (default `0`)
    - `k8s_loki_retention_period` — from `config_k8s.loki.retention_period` (default `168h`)
    - `k8s_loki_retention_enabled` — from `config_k8s.loki.retention_enabled` (default `true`)
    - `k8s_loki_ingestion_rate_mb` — from `config_k8s.loki.ingestion_rate_mb` (default `10`)
    - `k8s_loki_ingestion_burst_mb` — from `config_k8s.loki.ingestion_burst_mb` (default `20`)
    - `k8s_loki_max_streams` — from `config_k8s.loki.max_streams` (default `10000`)
    - `k8s_loki_requests_cpu` / `k8s_loki_requests_memory` — resource requests (defaults: `100m` / `256Mi`)
    - `k8s_loki_limits_cpu` / `k8s_loki_limits_memory` — resource limits (defaults: `1000m` / `1Gi`)
    - `k8s_loki_wait_retries` / `k8s_loki_wait_delay` — readiness check settings (defaults: 15 retries, 10s delay)
  - Configuration hierarchy: all settings sourced from `config_k8s.loki.*` with sensible defaults
  - Task flow: validate → install → verify

- **minio sub-role** (MinIO object storage on Kubernetes):
  - Deploys MinIO as a Kubernetes StatefulSet for S3-compatible object storage
  - Role path: `roles/kubernetes/storage/minio/`
  - Namespace: configurable via `config.kubernetes.minio.namespace` (default `minio`)
  - Version: configurable via `version.kubernetes.minio.server`
  - Images: `minio/minio` (server), `minio/mc` (client)
  - **Variable prefix:** `k8s_minio_*`
  - **Cluster config:** Mode `distributed` or `single-node` (default `distributed`), replicas (default 4), volumes per node (default 1)
  - **Storage:** hostPath-based with configurable size (default `100Gi`), path default `/apps/minio_data`
  - **Resources:** requests 250m CPU / 512Mi memory, limits 2000m CPU / 2Gi memory (configurable via `config.kubernetes.minio.resources.*`)
  - **Ports:** API 9000, Console 9001, API NodePort 61060, Console NodePort 61061 (configurable via `ports.kubernetes.minio.*`)
  - **Node targeting:** Optional label-based node affinity via `config.kubernetes.minio.topology.node_label_key` / `.node_label_value`
  - **Buckets:** Auto-created bucket list (default `['longhorn-backup']`)
  - **Key defaults variables:**
    - `k8s_minio_version` — from `version.kubernetes.minio.server` (default `RELEASE.2025-09-07T16-13-09Z`)
    - `k8s_minio_namespace` — from `config.kubernetes.minio.namespace` (default `minio`)
    - `k8s_minio_release_name` — from `config.kubernetes.minio.release_name` (default `minio`)
    - `k8s_minio_image` — from `config.kubernetes.minio.image` (default `minio/minio`)
    - `k8s_minio_mc_image` — from `config.kubernetes.minio.mc_image` (default `minio/mc`)
    - `k8s_minio_root_user` — from `config.kubernetes.minio.root_user` (default `minioadmin`)
    - `k8s_minio_root_password` — from vault (`k8s_minio_root_password_vault`)
    - `k8s_minio_mode` — from `config.kubernetes.minio.mode` (default `distributed`)
    - `k8s_minio_replicas` — from `config.kubernetes.minio.replicas` (default `4`)
    - `k8s_minio_volumes_per_node` — from `config.kubernetes.minio.volumes_per_node` (default `1`)
    - `k8s_minio_storage_size` — from `config.kubernetes.minio.storage_size` (default `100Gi`)
    - `k8s_minio_host_path` — from `config.kubernetes.minio.host_path` (default `/apps/minio_data`)
    - `k8s_minio_api_port` — from `ports.kubernetes.minio.api` (default `9000`)
    - `k8s_minio_console_port` — from `ports.kubernetes.minio.console` (default `9001`)
    - `k8s_minio_api_nodeport` — from `ports.kubernetes.minio.api_nodeport` (default `61060`)
    - `k8s_minio_console_nodeport` — from `ports.kubernetes.minio.console_nodeport` (default `61061`)
    - `k8s_minio_node_label_key` / `k8s_minio_node_label_value` — optional node affinity labels
    - `k8s_minio_requests_cpu` / `k8s_minio_requests_memory` — resource requests (defaults: `250m` / `512Mi`)
    - `k8s_minio_limits_cpu` / `k8s_minio_limits_memory` — resource limits (defaults: `2000m` / `2Gi`)
    - `k8s_minio_buckets` — from `config.kubernetes.minio.buckets` (default `['longhorn-backup']`)
    - `k8s_minio_ansible_user` — from `config.kubernetes.ansible_user` (falls back to `ansible_user`)
    - `k8s_minio_wait_retries` / `k8s_minio_wait_delay` — readiness check settings (defaults: 30 retries, 10s delay)
    - `k8s_minio_http_proxy` / `k8s_minio_https_proxy` — inherits global proxy vars
    - `k8s_minio_no_proxy` — from `config_k8s.minio.no_proxy` (default `localhost,127.0.0.1,.svc,.cluster.local`)
  - Secrets sourced from vault: `k8s_minio_root_password_vault`
  - Proxy-aware (http_proxy, https_proxy, no_proxy)
  - Configuration hierarchy: all settings sourced from `config.kubernetes.minio.*` with sensible defaults

- **librefs sub-role** (libreFS S3-compatible object storage on Kubernetes):
  - Deploys libreFS (community fork of MinIO) as a StatefulSet for S3-compatible object storage on Kubernetes
  - Role path: `roles/kubernetes/storage/librefs/`
  - Namespace: configurable via `config_k8s.librefs.namespace` (default `librefs`)
  - Version: configurable via `version.kubernetes.librefs.server`
  - Images: `ghcr.io/librefs/librefs` (server), `ghcr.io/librefs/lc` (CLI)
  - **Variable prefix:** `k8s_librefs_*`
  - **Cluster config:** Mode `distributed` or `single-node` (default `distributed`), replicas (default 4)
  - **Storage:** hostPath-based, path default `/apps/librefs_data`
  - **Resources:** requests 250m CPU / 512Mi memory, limits 2000m CPU / 2Gi memory (configurable via `config_k8s.librefs.resources.*`)
  - **Ports:** API 9000, Console 9001, API NodePort 61074, Console NodePort 61075 (configurable via `ports.kubernetes.librefs.*`)
  - **Node targeting:** Optional label-based node affinity via `config_k8s.librefs.topology.node_label_key` / `.node_label_value`
  - **Zone topology (optional):** Spreads libreFS pods across zones/racks for fault tolerance using `topologySpreadConstraints`. Requires nodes to be pre-labelled with the zone label (e.g., via `label_management` role or Longhorn zone config). Prevents single rack/DC failure from taking out enough erasure-coded shards to cause data loss. Configurable via `config_k8s.librefs.topology.zone_spread_enabled` (default `false`), `config_k8s.librefs.topology.zone_label_key` (default `topology.kubernetes.io/zone`), `config_k8s.librefs.topology.zone_max_skew` (default `1`).
  - **Buckets:** Auto-created bucket list (default `['longhorn-backup']`)
  - **Key defaults variables:**
    - `k8s_librefs_version` — from `version.kubernetes.librefs.server`
    - `k8s_librefs_namespace` — from `config_k8s.librefs.namespace` (default `librefs`)
    - `k8s_librefs_release_name` — from `config_k8s.librefs.release_name` (default `librefs`)
    - `k8s_librefs_image` — from `config_k8s.librefs.image` (default `ghcr.io/librefs/librefs`)
    - `k8s_librefs_cli_image` — from `config_k8s.librefs.cli_image` (default `ghcr.io/librefs/lc`)
    - `k8s_librefs_root_user` — from `config_k8s.librefs.root_user` (default `eadmin`)
    - `k8s_librefs_root_password` — from vault (`k8s_librefs_root_password_vault`)
    - `k8s_librefs_mode` — from `config_k8s.librefs.mode` (default `distributed`)
    - `k8s_librefs_replicas` — from `config_k8s.librefs.replicas` (default `4`)
    - `k8s_librefs_host_path` — from `config_k8s.librefs.host_path` (default `/apps/librefs_data`)
    - `k8s_librefs_storage_size` — from `config_k8s.librefs.storage_size` (default `250Gi`)
    - `k8s_librefs_api_port` — from `ports.kubernetes.librefs.api` (default `9000`)
    - `k8s_librefs_console_port` — from `ports.kubernetes.librefs.console` (default `9001`)
    - `k8s_librefs_api_nodeport` — from `ports.kubernetes.librefs.api_nodeport` (default `61074`)
    - `k8s_librefs_console_nodeport` — from `ports.kubernetes.librefs.console_nodeport` (default `61075`)
    - `k8s_librefs_node_label_key` / `k8s_librefs_node_label_value` — optional node affinity labels
    - `k8s_librefs_zone_spread_enabled` — from `config_k8s.librefs.topology.zone_spread_enabled` (default `false`) — enables topologySpreadConstraints for zone-aware pod distribution
    - `k8s_librefs_zone_label_key` — from `config_k8s.librefs.topology.zone_label_key` (default `topology.kubernetes.io/zone`) — node label key used to identify zones
    - `k8s_librefs_zone_max_skew` — from `config_k8s.librefs.topology.zone_max_skew` (default `1`) — maximum allowed difference in pod count between zones
    - `k8s_librefs_requests_cpu` / `k8s_librefs_requests_memory` — resource requests (defaults: `250m` / `512Mi`)
    - `k8s_librefs_limits_cpu` / `k8s_librefs_limits_memory` — resource limits (defaults: `2000m` / `2Gi`)
    - `k8s_librefs_buckets` — from `config_k8s.librefs.buckets` (default `['longhorn-backup']`)
    - `k8s_librefs_ansible_user` — from `config_k8s.ansible_user` (falls back to `ansible_user`)
    - `k8s_librefs_wait_retries` / `k8s_librefs_wait_delay` — readiness check settings (defaults: 30 retries, 10s delay)
  - Secrets sourced from vault: `k8s_librefs_root_password_vault`
  - Configuration hierarchy: all settings sourced from `config_k8s.librefs.*` with sensible defaults
  - **Environment variable:** `LIBREFS_ACTION` — controls behaviour: `install` (full deploy: prerequisites, validate, install, verify) or `uninstall` (remove all K8s resources and wipe data on disk). **Default: `uninstall`** (safety measure — requires explicit `LIBREFS_ACTION=install` to deploy)
  - Task flow: prerequisites (create hostPath data directories on worker nodes) → validate → install (namespace, secret, local StorageClass + PersistentVolumes for hostPath, template and apply StatefulSet manifest directly via kubectl, wait for rollout) → verify
  - **Uninstall task flow:** scale down StatefulSet → wait for pods to terminate → delete StatefulSet → delete Services (headless + ClusterIP) → delete PVCs (label-based) → wait for PVCs removal → delete PVs (label-based) → delete credentials Secret → delete StorageClass → delete namespace → wipe data on worker nodes (`k8s_librefs_host_path` removed and recreated empty via `delegate_to` loop over `k8s_librefs_worker_hosts` group) → summary
  - **Uninstall note:** Data on disk (`k8s_librefs_host_path`) IS automatically wiped during uninstall (directory removed and recreated empty with owner 1000:1000, mode 0755 on all worker nodes).
  - **Bucket creation:** Manual — buckets are created via the libreFS Console UI after deployment (not automated by Ansible)
  - **Deploy method:** Raw K8s manifests (no Helm dependency) — uses `librefs-statefulset.yaml.j2` template applied via `kubectl apply`

- **longhorn sub-role** (Longhorn distributed block storage on Kubernetes):
  - Deploys Longhorn as the default StorageClass for persistent volumes on Kubernetes
  - Role path: `roles/kubernetes/storage/longhorn/`
  - Namespace: configurable via `config.kubernetes.longhorn.namespace` (default `longhorn-system`)
  - Version: configurable via `version.kubernetes.longhorn_version` (default `1.12.0`)
  - **Variable prefix:** `longhorn_*`
  - **Data path:** configurable via `paths.longhorn.base_dir` (default `/apps/longhorn`)
  - **Worker nodes:** derived from host group `config.kubernetes.longhorn.worker_node_hosts` (default `kubernetes_worker`)
  - **Ports:** NodePort from `ports.kubernetes.longhorn.node_port` (default `61066`)
  - **Node restriction:** Label-based scheduling — only nodes with the `longhorn-node=true` label will run Longhorn components and host volumes. New nodes require playbook re-run to receive the label. Label key/value are hardcoded (all K8s roles using Longhorn PVCs use this same label as nodeSelector).
  - **Storage settings:** replica count (default 3), reserved percentage (default 15%), minimal available percentage (default 10%)
  - **Zone-aware replication (optional):** For multi-rack/multi-DC clusters on the same network. Labels nodes with their zone and configures Longhorn to spread replicas across zones for fault tolerance. Requires `config_k8s.longhorn.zone.enabled: true` and `config_k8s.longhorn.zone.nodes` list defined in inventory. Each node entry: `{ node: <hostname>, zone: <zone_name> }`. Uses `topology.kubernetes.io/zone` label by default. Supports soft anti-affinity (default `true`) and auto-balance (default `best-effort`).
  - **Resources (manager):** requests 100m CPU / 128Mi memory, limits 500m CPU / 512Mi memory (configurable via `config.kubernetes.longhorn.resources.manager.*`)
  - **Engine:** guaranteed CPU 100m (configurable via `config.kubernetes.longhorn.resources.engine.guaranteed_cpu`)
  - **UI Authentication:** basic auth with configurable username (default `admin`) and vault-sourced password
  - **Engine-image DaemonSet:** Deploy waits for engine-image pods to be ready on all worker nodes (no manual probe patching — relies on Longhorn's default probe configuration)
  - **Backup (MinIO S3):** configured via Longhorn UI, not managed by Ansible automation
  - **Key defaults variables:**
    - `longhorn_version` — from `version.kubernetes.longhorn_version` (default `1.12.0`)
    - `longhorn_namespace` — from `config.kubernetes.longhorn.namespace` (default `longhorn-system`)
    - `longhorn_data_path` — from `paths.longhorn.base_dir` (default `/apps/longhorn`)
    - `longhorn_worker_nodes` — from host group `config.kubernetes.longhorn.worker_node_hosts` (default `kubernetes_worker`)
    - `longhorn_node_port` — from `ports.kubernetes.longhorn.node_port` (default `61066`)
    - `longhorn_node_label_key` — hardcoded `longhorn-node` (all K8s roles using Longhorn PVCs use this same label as nodeSelector)
    - `longhorn_node_label_value` — hardcoded `true`
    - `longhorn_replica_count` — from `config.kubernetes.longhorn.replica_count` (default `3`)
    - `longhorn_storage_reserved_percentage` — from `config.kubernetes.longhorn.storage_reserved_percentage` (default `15`)
    - `longhorn_storage_minimal_available_percentage` — from `config.kubernetes.longhorn.storage_minimal_available_percentage` (default `10`)
    - `longhorn_manager_requests_cpu` / `longhorn_manager_requests_memory` — manager resource requests (defaults: `100m` / `128Mi`)
    - `longhorn_manager_limits_cpu` / `longhorn_manager_limits_memory` — manager resource limits (defaults: `500m` / `512Mi`)
    - `longhorn_engine_guaranteed_cpu` — engine guaranteed CPU (default `100m`)
    - `longhorn_zone_enabled` — from `config_k8s.longhorn.zone.enabled` (default `false`) — enables zone-aware replica placement
    - `longhorn_zone_label_key` — from `config_k8s.longhorn.zone.label_key` (default `topology.kubernetes.io/zone`) — K8s node label key for zone identification
    - `longhorn_zone_nodes` — from `config_k8s.longhorn.zone.nodes` (default `[]`) — list of `{ node, zone }` mappings
    - `longhorn_replica_zone_soft_anti_affinity` — from `config_k8s.longhorn.zone.soft_anti_affinity` (default `true`) — allows replicas in same zone if not enough zones
    - `longhorn_replica_auto_balance` — from `config_k8s.longhorn.zone.auto_balance` (default `best-effort`) — automatic replica rebalancing across zones
    - `longhorn_ui_auth_user` — from `config.kubernetes.longhorn.ui_auth.username` (default `admin`)
    - `longhorn_ui_auth_password` — from vault (`longhorn_ui_password`)

    - `longhorn_ansible_user` — from `config.kubernetes.ansible_user` (falls back to `ansible_user`)
    - `longhorn_ansible_user_home` — auto-derived (`/home/<user>` or `/root`)
    - `longhorn_http_proxy` / `longhorn_https_proxy` — inherits global proxy vars
    - `longhorn_wait_retries` / `longhorn_wait_delay` — readiness check settings (defaults: 60 retries, 15s delay)
  - Secrets sourced from vault: `longhorn_ui_password`
  - Proxy-aware (http_proxy, https_proxy)
  - Configuration hierarchy: all settings sourced from `config.kubernetes.longhorn.*` with sensible defaults
  - **Playbook structure** (`playbook/kubernetes/longhorn.yaml`): Single-play design:
    - Targets `kubernetes_master_init` (overridable via `target_host`), `become: true`, `gather_facts: true`
    - Sets `longhorn_action` from `LONGHORN_ACTION` env var (default `install`) — controls behaviour within the role (e.g., `install` for full deploy including prerequisites, other values for partial operations)
    - Loads shared vars from `../_global_vars/all.yml`
    - Applies the `roles/kubernetes/storage/longhorn` role from the master node (kubectl/helm operations + any worker-node tasks delegated internally by the role)
    - **Environment variable:** `LONGHORN_ACTION` — controls behaviour: `install` (default, full install) or other values for targeted operations
    - **Extra vars:** `target_host` overrides the target host group

- **harbor sub-role** (Harbor container registry on Kubernetes):
  - Deploys Harbor container registry via Helm for private Docker image hosting
  - Role path: `roles/kubernetes/platform/harbor/`
  - Namespace: configurable via `config.kubernetes.harbor.namespace` (default `harbor`)
  - Version: configurable via `version.kubernetes.harbor` (default `1.19.1`)
  - Release name: configurable via `config.kubernetes.harbor.release_name` (default `harbor`)
  - **Variable prefix:** `harbor_*`
  - **Expose type:** NodePort — HTTP `61064`, Notary `61065` (configurable via `ports.kubernetes.harbor.*`)
  - **External URL:** configurable via `config.kubernetes.harbor.external_url` (default `https://harbor.local`)
  - **Storage:** registry 200Gi, database 10Gi, Redis 5Gi, jobservice 5Gi, Trivy 10Gi (all configurable via `config.kubernetes.harbor.*_size`)
  - **Storage class:** configurable via `config.kubernetes.harbor.storage_class` (default `longhorn`)
  - **Authentication:** LDAP auth by default (`ldap_auth`), configurable mode via `config.kubernetes.harbor.auth.mode`
  - **LDAP config:** url, base_dn, search_dn, uid (default `sAMAccountName`), scope, filter, group settings, verify_cert
  - **Trivy (vulnerability scanning):** optional, disabled by default (`config.kubernetes.harbor.trivy.enabled`)
  - **Garbage Collection:** enabled by default, daily schedule, deletes untagged images
  - **Resources (core):** requests 100m CPU / 256Mi memory, limits 1000m CPU / 512Mi memory
  - **Resources (registry):** requests 100m CPU / 256Mi memory, limits 2000m CPU / 2Gi memory
  - **Node targeting:** Optional label-based node affinity via `config.kubernetes.harbor.topology.node_label_key` / `.node_label_value`
  - **Key defaults variables:**
    - `harbor_version` — from `version.kubernetes.harbor` (default `1.19.1`)
    - `harbor_namespace` — from `config.kubernetes.harbor.namespace` (default `harbor`)
    - `harbor_release_name` — from `config.kubernetes.harbor.release_name` (default `harbor`)
    - `harbor_admin_password` — from vault (`harbor_admin_password_vault`)
    - `harbor_external_url` — from `config.kubernetes.harbor.external_url` (default `https://harbor.local`)
    - `harbor_http_nodeport` — from `ports.kubernetes.harbor.http` (default `61064`)
    - `harbor_notary_nodeport` — from `ports.kubernetes.harbor.notary` (default `61065`)
    - `harbor_storage_class` — from `config.kubernetes.harbor.storage_class` (default `longhorn`)
    - `harbor_registry_size` — from `config.kubernetes.harbor.registry_size` (default `200Gi`)
    - `harbor_database_size` — from `config.kubernetes.harbor.database_size` (default `10Gi`)
    - `harbor_redis_size` — from `config.kubernetes.harbor.redis_size` (default `5Gi`)
    - `harbor_jobservice_size` — from `config.kubernetes.harbor.jobservice_size` (default `5Gi`)
    - `harbor_trivy_size` — from `config.kubernetes.harbor.trivy_size` (default `10Gi`)
    - `harbor_node_label_key` / `harbor_node_label_value` — optional node affinity labels
    - `harbor_core_requests_cpu` / `harbor_core_requests_memory` — core resource requests (defaults: `100m` / `256Mi`)
    - `harbor_core_limits_cpu` / `harbor_core_limits_memory` — core resource limits (defaults: `1000m` / `512Mi`)
    - `harbor_registry_requests_cpu` / `harbor_registry_requests_memory` — registry resource requests (defaults: `100m` / `256Mi`)
    - `harbor_registry_limits_cpu` / `harbor_registry_limits_memory` — registry resource limits (defaults: `2000m` / `2Gi`)
    - `harbor_auth_mode` — from `config.kubernetes.harbor.auth.mode` (default `ldap_auth`)
    - `harbor_ldap_url` / `harbor_ldap_base_dn` / `harbor_ldap_search_dn` — LDAP connection settings
    - `harbor_ldap_search_password` — from vault (`harbor_ldap_search_password_vault`)
    - `harbor_ldap_uid` — from `config.kubernetes.harbor.ldap.uid` (default `sAMAccountName`)
    - `harbor_trivy_enabled` — from `config.kubernetes.harbor.trivy.enabled` (default `false`)
    - `harbor_gc_enabled` — from `config.kubernetes.harbor.gc.enabled` (default `true`)
    - `harbor_gc_schedule` — from `config.kubernetes.harbor.gc.schedule` (default `Daily`)
    - `harbor_gc_delete_untagged` — from `config.kubernetes.harbor.gc.delete_untagged` (default `true`)
    - `harbor_ansible_user` — from `config.kubernetes.ansible_user` (falls back to `ansible_user`)
    - `harbor_wait_retries` / `harbor_wait_delay` — readiness check settings (defaults: 30 retries, 10s delay)
    - `harbor_http_proxy` / `harbor_https_proxy` — inherits global proxy vars
    - `harbor_no_proxy` — from `config.kubernetes.harbor.no_proxy` (default `127.0.0.1,localhost,.local,.svc,.cluster.local,10.96.0.0/12`)
  - Task flow: validate → install (helm, includes pre-upgrade field manager conflict resolution for jobservice/registry annotations and strategy fields, then Recreate strategy patch post-helm to avoid Multi-Attach PVC errors) → configure → verify
  - Secrets sourced from vault: `harbor_admin_password_vault`, `harbor_ldap_search_password_vault`
  - Configuration hierarchy: all settings sourced from `config.kubernetes.harbor.*` with sensible defaults

### HAProxy (Load Balancing)
- Deploys HAProxy as a systemd service for TCP/HTTP load balancing across backend services
- **Variable prefix:** `haproxy_*`
- **Configuration source:** `config_load_balancing.haproxy.*` in `app_configs.yml`
- **Role path:** `roles/load_balancing/haproxy/`
- **Config files:** Sourced from inventory `configs/haproxy/` directory (per-environment `haproxy.cfg.j2`, `userlist.cfg.j2`)
- **Install method:** Source compilation from haproxy.org with `USE_PROMEX=1` (Prometheus metrics exporter built-in). Compiled binary installed to `<base_dir>/haproxy-<version>-bin/` with symlink `<base_dir>/haproxy` pointing to current version.
- **Task flow:** validate → pre_verify → pre_install → install → cleanup → config → service → cert_check → verify
- **Install sub-steps:** install build deps (openssl-devel, pcre-devel, zlib-devel, gcc, make, socat) → download source tarball → extract → compile (`make TARGET=linux-glibc USE_OPENSSL=1 USE_PCRE=1 USE_ZLIB=1 USE_PROMEX=1`) → `make install PREFIX=<base_dir>/haproxy-<version>-bin` → symlink to current. Install/compile steps are conditional on `haproxy_upgrade_needed` or `not haproxy_installed`.
- **Verify sub-steps:** service active check → version confirmation → stats port listening (timeout 15s) → deployment status summary (service state, version, config path, stats URL, cert check status)
- **Key defaults variables:**
  - `haproxy_version` — from `version.haproxy.patch` (full patch version, e.g., `3.2.0`)
  - `haproxy_minor_version` — from `version.haproxy.minor` (minor version for download path)
  - `haproxy_base_dir` — from `paths.haproxy.base_dir`
  - `haproxy_stats_port` — from `ports.haproxy.stats` (default `61009`)
  - `haproxy_config_dir` — from `config_load_balancing.haproxy.config_dir` (default `haproxy`) — inventory subfolder for config templates (allows multiple HAProxy instances)
  - `haproxy_memory_limit` — from `config_load_balancing.haproxy.memory_limit` (default `1G`), used as systemd `MemoryMax`
  - `haproxy_nofile_limit` — from `config_load_balancing.haproxy.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `haproxy_http_proxy` / `haproxy_https_proxy` — inherits global proxy vars
  - `haproxy_download_timeout` — from `config_load_balancing.haproxy.download_timeout` (default `120` seconds)
- **SSL Certificate Expiry Check:**
  - `haproxy_cert_check_enabled` — from `config_load_balancing.haproxy.cert_check.enabled` (default `false`)
  - `haproxy_cert_check_paths` — from `config_load_balancing.haproxy.cert_check.cert_paths` (default `[]`) — list of certificate file paths to monitor
  - `haproxy_cert_check_threshold_days` — from `config_load_balancing.haproxy.cert_check.threshold_days` (default `30`)
  - `haproxy_cert_check_schedule` — from `config_load_balancing.haproxy.cert_check.schedule` (default `0 6 * * 1` — weekly Monday 06:00)
  - `haproxy_cert_check_smtp_host` — from `config_load_balancing.haproxy.cert_check.smtp_host` (default `smtpb.intra.bt.com`)
  - `haproxy_cert_check_smtp_port` — from `config_load_balancing.haproxy.cert_check.smtp_port` (default `25`)
  - `haproxy_cert_check_from_email` — from `config_load_balancing.haproxy.cert_check.from_email` (default `noreply.martini@bt.com`)
  - `haproxy_cert_check_to_emails` — from `config_load_balancing.haproxy.cert_check.to_emails` (default `[]`)
  - `haproxy_cert_check_cc_emails` — from `config_load_balancing.haproxy.cert_check.cc_emails` (default `[]`)
- Proxy-aware (http_proxy, https_proxy for download)
- Configuration hierarchy: all settings sourced from `config_load_balancing.haproxy.*` with sensible defaults

### Prometheus & Alerting
- Scrape interval: 15s, Retention: 30d
- Alert priorities: P1 (2h repeat), P2 (6h repeat), P3 (24h repeat)
- SMTP relay: smtpb.intra.bt.com:25
- **Variable prefix:** `prometheus_*` (core), `alert_manager_*` (alerting)
- **Configuration source:** `config.prometheus.*`, `config.alert_manager.*` in `app_configs.yml`
- **Install method:** GitHub release tarball download with symlink to current version
- **Task flow (main.yml):** validate → create_user → prometheus (pre_install → install → config → service → verify) → alertmanager (install → config → cleanup → service → verify) → config_dns (optional, when nameservers defined)
- **Pre-install sub-steps (prometheus):** check if binary exists → get current version → set version facts (prometheus_installed, prometheus_current, prometheus_upgrade_needed) → stop service if upgrading
- **Key defaults variables:**
  - `prometheus_version` — from `version.prometheus`
  - `prometheus_base_dir` — from `paths.prometheus.base_dir`
  - `prometheus_port` — from `ports.prometheus.service`
  - `prometheus_retention_time` — from `config.prometheus.retention`
  - `prometheus_data_dir` — from `config.prometheus.data_dir` (default `<base_dir>/prometheus_data`)
  - `prometheus_user` / `prometheus_group` — default `prometheus`
  - `prometheus_listen_address` — default `0.0.0.0`
  - `prometheus_arch` — default `linux-amd64`
  - `prometheus_http_proxy` / `prometheus_https_proxy` — inherits global proxy vars
  - `prometheus_download_timeout` — default `120` seconds
  - `prometheus_memory_limit` — from `config.prometheus.memory_limit` (default `4G`), used as systemd `MemoryMax`
  - `prometheus_nofile_limit` — from `config.prometheus.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `prometheus_nameservers` — from `config.prometheus.nameservers` (default `[]`)
  - `prometheus_resolv_conf` — from `paths.resolv_conf` (default `/etc/resolv.conf`)
  - `prometheus_host` — auto-derived from `prometheus` host group IP
  - `prometheus_webhook_enabled` — from `config.alert_manager.webhook.enabled` (default `false`)
  - `prometheus_webhook_url` — from `config.alert_manager.webhook.url` (default `''`)
  - `prometheus_webhook_priorities` — from `config.alert_manager.webhook.priorities` (default `['P1']`)
  - `prometheus_webhook_send_resolved` — from `config.alert_manager.webhook.send_resolved` (default `true`)
  - `alert_manager_version` — from `version.alert_manager`
  - `alert_manager_port` — from `ports.alert_manager.service`
  - `alert_manager_to_email` / `alert_manager_cc_email` — from `config.alert_manager.toMail` / `.ccMail`
  - `alert_manager_smtp_host` / `alert_manager_from_email` — from `config.alert_manager.smtpHost` / `.fromMail`
  - `alert_manager_p1/p2/p3_repeat_interval` — from `config.alert_manager.p*_repeat_interval`
  - `alert_manager_resolve_timeout` — from `config.alert_manager.resolve_timeout`
  - `alert_manager_memory_limit` — from `config.alert_manager.memory_limit` (default `1G`), used as systemd `MemoryMax`
- Proxy-aware (http_proxy, https_proxy for download)

### Pushgateway
- Deploys Prometheus Pushgateway as a systemd service for batch job metric collection
- **Variable prefix:** `pushgateway_*`
- **Configuration source:** `config.pushgateway.*` in `app_configs.yml`
- **Service:** `pushgateway.service` (systemd unit)
- **Task flow:** `create_user → pre_install → install → cleanup → service → verify`
- **Install method:** GitHub release tarball download with symlink to current version
- **Pre-install sub-steps:** verify base dir → check if binary exists → get current version → set version facts (pushgateway_installed, pushgateway_current, pushgateway_upgrade_needed) → stop service if upgrading
- **Install sub-steps:** download → extract → set permissions → symlink to current
- **Cleanup sub-steps:** detect old version via symlink target and binary `--version` output → remove old version directory and tarball (only if version differs from current)
- **Key defaults variables:**
  - `pushgateway_version` — from `version.pushgateway`
  - `pushgateway_port` — from `ports.pushgateway.service`
  - `pushgateway_base_dir` — from `paths.pushgateway.base_dir`
  - `pushgateway_user` / `pushgateway_group` — default `pushgateway`
  - `pushgateway_log_level` — default `warn`
  - `pushgateway_listen_address` — default `0.0.0.0`
  - `pushgateway_enable_admin_api` — default `false`
  - `pushgateway_memory_limit` — from `config.pushgateway.memory_limit` (default `512M`)
  - `pushgateway_arch` — default `linux-amd64`
  - `pushgateway_download_timeout` — default `120` seconds
  - `pushgateway_http_proxy` / `pushgateway_https_proxy` — inherits global proxy vars
- **Systemd service features:** Restart on failure (5s delay), LimitNOFILE 65536, optional admin API
- Proxy-aware (http_proxy, https_proxy for download)

### Blackbox Exporter
- Deploys Prometheus Blackbox Exporter as a systemd service for HTTP/TCP/ICMP/DNS endpoint probing
- **Variable prefix:** `blackbox_exporter_*`
- **Configuration source:** `config_monitoring.blackbox_exporter.*` in `config_monitoring.yml`
- **Role path:** `roles/monitoring/blackbox_exporter/`
- **Install method:** GitHub release binary download
- **Task flow:** validate → create_user → pre_install → install → cleanup → config → service → verify
- **Key defaults variables:**
  - `blackbox_exporter_version` — from `version.blackbox_exporter` (default `0.26.0`)
  - `blackbox_exporter_base_dir` — from `paths.blackbox_exporter.base_dir` (default `/apps`)
  - `blackbox_exporter_port` — from `ports.blackbox_exporter.service` (default `9115`)
  - `blackbox_exporter_user` / `blackbox_exporter_group` — from `config_monitoring.blackbox_exporter.user`/`.group` (default `blackbox-exporter`)
  - `blackbox_exporter_listen_address` — from `config_monitoring.blackbox_exporter.listen_address` (default `0.0.0.0`)
  - `blackbox_exporter_arch` — from `config_monitoring.blackbox_exporter.arch` (default `linux-amd64`)
  - `blackbox_exporter_memory_limit` — from `config_monitoring.blackbox_exporter.memory_limit` (default `256M`), used as systemd `MemoryMax`
  - `blackbox_exporter_nofile_limit` — from `config_monitoring.blackbox_exporter.nofile_limit` (default `1024`), used as systemd `LimitNOFILE`
  - `blackbox_exporter_http_proxy` / `blackbox_exporter_https_proxy` — inherits global proxy vars
  - `blackbox_exporter_download_timeout` — from `config_monitoring.blackbox_exporter.download_timeout` (default `60` seconds)
- Proxy-aware (http_proxy, https_proxy for download)

### Grafana (Standalone/Systemd)
- Deploys Grafana as a systemd service for dashboarding and monitoring visualisation
- **Variable prefix:** `grafana_*`
- **Configuration source:** `config_frontend.grafana[grafana_instance].*` in `app_configs.yml`
- **Role path:** `roles/frontend/grafana/`
- **Multi-instance support:** Uses `grafana_instance` variable (default `monitor`) to support multiple Grafana instances (e.g., `monitor`, `user`) on the same or different hosts. All config lookups use `config_frontend.grafana[grafana_instance].*` pattern, allowing per-instance configuration in inventory.
- **Instance selection:** Set via `grafana_instance_name` variable (passed from playbook or extra-vars), defaults to `monitor`
- **Key defaults variables:**
  - `grafana_instance` — from `grafana_instance_name` (default `monitor`) — determines which config block to read
  - `grafana_version` — from `version.grafana[grafana_instance]` (default `12.1.1`)
  - `grafana_base_dir` — from `paths.grafana.base_dir` (default `/apps`)
  - `grafana_user` / `grafana_group` — from `config_frontend.grafana[grafana_instance].user`/`.group` (default `grafana`)
  - `grafana_port` — from `config_frontend.grafana[grafana_instance].port` (falls back to `ports.grafana.service`, default `3000`)
  - `grafana_memory_limit` — from `config_frontend.grafana[grafana_instance].memory_limit` (default `2G`), used as systemd `MemoryMax`
  - `grafana_nofile_limit` — from `config_frontend.grafana[grafana_instance].nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `grafana_log_rotation_size` — from `config_frontend.grafana[grafana_instance].log_rotation_size` (default `100M`)
  - `grafana_log_rotation_count` — from `config_frontend.grafana[grafana_instance].log_rotation_count` (default `5`)
  - `grafana_plugins` — from `config_frontend.grafana[grafana_instance].plugins` (default `[]`)
  - `grafana_http_proxy` / `grafana_https_proxy` — inherits global proxy vars
  - `grafana_no_proxy` — from `config_frontend.grafana[grafana_instance].no_proxy` (default `localhost,127.0.0.1`)
  - `grafana_proxy_enabled` — from `config_frontend.grafana[grafana_instance].proxy_enabled` (default `false`) — controls whether proxy environment variables are set in the systemd service
  - `grafana_download_timeout` — from `config_frontend.grafana[grafana_instance].download_timeout` (default `120` seconds)
  - `grafana_wait_retries` / `grafana_wait_delay` — readiness check settings (defaults: 10 retries, 10s delay)
- Proxy-aware (http_proxy, https_proxy for download)
- Configuration hierarchy: all settings sourced from `config_frontend.grafana[grafana_instance].*` with sensible defaults

### SFTP Setup (sshd_lock)
- Deploys a dedicated SFTP-only SSH daemon (`sshd_lock`) running on a custom port alongside the system SSH
- **Variable prefix:** `sftp_*`
- **Configuration source:** `config.sftp.*` in `app_configs.yml`
- **Service:** `sshd_lock.service` (separate systemd unit using `/etc/ssh/sshd_lock_config`)
- **Default port:** 50022 (configurable via `config.sftp.port`)
- **Multi-user support:** Users defined in `config.sftp.users` list, each with:
  - `name` — username (required)
  - `shell` — default `/sbin/nologin`
  - `home` — default `/home/<name>`
  - `auth` — `password` | `key` | `both` (default `password`)
  - `public_key` — required if auth is `key` or `both`
- **Passwords:** Stored in `all_secrets.yml` as `sftp_password_<username>_vault`
- **Security hardening (configurable via `config.sftp.*`, defaults are hardened):**
  - Root login disabled, empty passwords disabled
  - TCP/X11/agent forwarding disabled, tunnelling disabled
  - Password authentication enabled, pubkey authentication enabled
  - MaxAuthTries: 4, LoginGraceTime: 60s
  - ClientAliveInterval: 300s, ClientAliveCountMax: 3
- **Crypto controls (configurable via `config.sftp.*`, defaults are hardened):**
  - Ciphers: chacha20-poly1305, aes256-ctr, aes256-gcm
  - MACs: hmac-sha2-512-etm, hmac-sha2-256-etm, hmac-sha2-512
  - KexAlgorithms: curve25519-sha256, diffie-hellman-group14/16/18
  - HostKeyAlgorithms: ssh-ed25519, rsa-sha2-512/256, ecdsa-sha2-nistp256/384/521
- **Key defaults variables:**
  - `sftp_port` — from `config.sftp.port` (default `50022`)
  - `sftp_users` — from `config.sftp.users` (default `[]`)
  - `sftp_max_sessions_per_connection` — from `config.sftp.max_sessions` (default `10`)
  - `sftp_max_startup` — from `config.sftp.max_startup` (default `80:30:200`)
  - `sftp_client_alive_interval` — from `config.sftp.client_alive_interval` (default `300`)
  - `sftp_client_alive_count_max` — from `config.sftp.client_alive_count_max` (default `3`)
  - `sftp_login_grace_time` — from `config.sftp.login_grace_time` (default `60`)
  - `sftp_max_auth_tries` — from `config.sftp.max_auth_tries` (default `4`)
  - `sftp_permit_root_login` — from `config.sftp.permit_root_login` (default `no`)
  - `sftp_allow_tcp_forwarding` — from `config.sftp.allow_tcp_forwarding` (default `no`)
  - `sftp_x11_forwarding` — from `config.sftp.x11_forwarding` (default `no`)
  - `sftp_permit_empty_passwords` — from `config.sftp.permit_empty_passwords` (default `no`)
  - `sftp_password_authentication` — from `config.sftp.password_authentication` (default `yes`)
  - `sftp_pubkey_authentication` — from `config.sftp.pubkey_authentication` (default `yes`)
  - `sftp_ciphers` — from `config.sftp.ciphers` (default `chacha20-poly1305@openssh.com,aes256-ctr,aes256-gcm@openssh.com`)
  - `sftp_macs` — from `config.sftp.macs` (default `hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512`)
  - `sftp_kex_algorithms` — from `config.sftp.kex_algorithms` (default `curve25519-sha256,curve25519-sha256@libssh.org,diffie-hellman-group14-sha256,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512`)
  - `sftp_host_key_algorithms` — from `config.sftp.host_key_algorithms` (default `ssh-ed25519,rsa-sha2-512,rsa-sha2-256,ecdsa-sha2-nistp256,ecdsa-sha2-nistp384,ecdsa-sha2-nistp521`)
- **Task flow:** install openssh-server → SELinux port config → firewall port → template sshd_lock_config → deploy sshd_lock.service → systemd reload → enable/start service → restart if config changed
- SELinux-aware (automatically configures `ssh_port_t` if SELinux enforcing)
- Firewall-aware (opens port via `firewalld`)

### GitLab Runner
- Deploys a GitLab Runner as a shell executor for CI/CD pipeline job execution
- **Variable prefix:** `gitlab_runner_*`
- **Configuration source:** `config_platform.gitlab_runner.*` in `config_platform.yml`
- **Role path:** `roles/platform/gitlab_runner/`
- **Executor type:** Shell (default), configurable via `config_platform.gitlab_runner.executor`
- **GitLab server:** `https://gitlab.prod.ec.devops.nat.bt.com/` (BT internal GitLab)
- **Binary:** Downloaded directly from GitLab S3 (`gitlab-runner-linux-amd64`)
- **Key defaults variables:**
  - `gitlab_runner_version` — from `version.gitlab_runner` (default `19.0.1`)
  - `gitlab_runner_base_dir` — from `paths.gitlab_runner.base_dir` (default `/apps`)
  - `gitlab_runner_builds_dir` — from `config_platform.gitlab_runner.builds_dir` (default `<base_dir>/gitlab-runner/build`)
  - `gitlab_runner_binary_url` — S3 download URL for `gitlab-runner-linux-amd64`
  - `gitlab_runner_user` — from `config_platform.gitlab_runner.user` (default `gitlab-runner`)
  - `gitlab_runner_shell` — from `config_platform.gitlab_runner.shell` (default `/bin/bash`)
  - `gitlab_runner_url` — from `config_platform.gitlab_runner.url` (default `https://gitlab.prod.ec.devops.nat.bt.com/`)
  - `gitlab_runner_name` — from `config_platform.gitlab_runner.name` (default `MAT-Ansible-Runner`)
  - `gitlab_runner_executor` — from `config_platform.gitlab_runner.executor` (default `shell`)
  - `gitlab_runner_concurrent` — from `config_platform.gitlab_runner.concurrent` (default `5`)
  - `gitlab_runner_check_interval` — from `config_platform.gitlab_runner.check_interval` (default `0`)
  - `gitlab_runner_connection_max_age` — from `config_platform.gitlab_runner.connection_max_age` (default `15m0s`)
  - `gitlab_runner_session_timeout` — from `config_platform.gitlab_runner.session_timeout` (default `1800`)
  - `gitlab_runner_git_ssl_no_verify` — from `config_platform.gitlab_runner.git_ssl_no_verify` (default `true`)
  - `gitlab_runner_http_proxy` / `gitlab_runner_https_proxy` — inherits global proxy vars
  - `gitlab_runner_download_timeout` — from `config_platform.gitlab_runner.download_timeout` (default `120` seconds)
- **Environment variable:** `RUNNER_ACTION` — controls behaviour (default `install`):
  - `INSTALL` — full install + register (validate → create_user → install → config → service → register → verify)
  - `REGISTER` — only register a new runner (skips install steps, expects runner already installed; runs register → verify only)
- **Task flow (INSTALL action):** validate → create_user → install → config → service → register → verify
- **Task flow (REGISTER action):** register → verify
- **Config template:** `config.toml.j2` (GitLab Runner TOML configuration)
- **Registration task** (`register.yml`): Registers a new runner with GitLab using a token. Skipped if no token is provided. Variables:
  - `runner_token` — GitLab runner authentication token (pass via `-e runner_token=glrt-xxxxx` or `RUNNER_TOKEN` env var). Required for registration to execute.
  - `runner_tags` — runner description/identifier (pass via `-e runner_tags=MAT-Ansible-DRZ2` or `RUNNER_TAGS` env var). Used as the `--description` flag. Tags are managed server-side in GitLab Runner 19.x (no `--tag-list` CLI flag).
  - Registration uses `gitlab-runner register --non-interactive` with token security
  - Post-registration: injects `GIT_SSL_NO_VERIFY=true` into `/etc/gitlab-runner/config.toml` via `lineinfile` (when `gitlab_runner_git_ssl_no_verify` is true)
  - Restarts `gitlab-runner` service after successful registration
- Proxy-aware (http_proxy, https_proxy for download)

### Gradle
- Installs Gradle build tool for CI/CD build automation (used by GitLab Runner)
- **Variable prefix:** `gradle_*`
- **Configuration source:** `config.gradle.*` in `app_configs.yml`
- **Role path:** `roles/platform/gradle/`
- **Key defaults variables:**
  - `gradle_version` — from `version.gradle` (default `9.2.1`)
  - `gradle_base_dir` — from `paths.gradle.base_dir` (default `/apps/Software`)
  - `gradle_download_type` — from `config.gradle.download_type` (default `all`) — controls distribution type (`all` includes sources+docs, `bin` is binary-only)
  - `gradle_user` — from `config_platform.gradle.user` (default `gitlab-runner`)
  - `gradle_user_home` — auto-derived from `gradle_user` (`/home/<user>` or `/root`)
  - `gradle_cache_dir` — from `config_platform.gradle.cache_dir` (default `<base_dir>/gradle_cache`) — Gradle cache directory, set to /apps path to avoid /home bloat
  - `gradle_http_proxy` / `gradle_https_proxy` — inherits global proxy vars
  - `gradle_download_timeout` — from `config.gradle.download_timeout` (default `120` seconds)
- **Task flow:** validate → install → verify
- **Validate sub-steps:** assert gradle_version defined → create base directory (`gradle_base_dir`) with owner/group `gradle_user` and mode 0755 → verify `gradle_user` exists
- Proxy-aware (http_proxy, https_proxy for download)

### Docker
- Installs Docker CE for CI/CD image build and push workflows (used by GitLab Runner)
- **Variable prefix:** `docker_*`
- **Configuration source:** `config.docker.*` in `app_configs.yml`
- **Role path:** `roles/platform/docker/`
- **Key defaults variables:**
  - `docker_data_root` — from `config.docker.data_root` (default `/apps/docker`)
  - `docker_containerd_root` — from `config.docker.containerd_root` (default `/apps/containerd`)
  - `docker_containerd_state` — from `config.docker.containerd_state` (default `/apps/containerd/state`)
  - `docker_scripts_dir` — from `config.docker.scripts_dir` (default `/apps/script`)
  - `docker_group_user` — from `config.docker.group_user` (default `gitlab-runner`) — user added to docker group for passwordless access
  - `docker_http_proxy` / `docker_https_proxy` — inherits global proxy vars
  - `docker_prune_enabled` — from `config.docker.prune.enabled` (default `true`)
  - `docker_prune_schedule` — from `config.docker.prune.schedule` (default `6 0 * * *`) — cron for daily image prune
  - `docker_prune_log` — from `config.docker.prune.log` (default `/apps/script/docker-prune.log`)
- **Task flow:** validate → install → config → service → verify
- Proxy-aware (http_proxy, https_proxy for Docker daemon)

### Containerd + nerdctl (Rootless)
- Installs nerdctl (Docker-compatible CLI for containerd) with rootless BuildKit for building and pushing container images without a Docker daemon
- **Variable prefix:** `nerdctl_*`
- **Configuration source:** `config.nerdctl.*` in `app_configs.yml`
- **Role path:** `roles/platform/containerd_nerdctl/`
- **Package:** `nerdctl-full` bundle includes: nerdctl, containerd, BuildKit, runc, CNI plugins, RootlessKit, slirp4netns
- **Execution mode:** Entirely rootless — runs as user-level systemd services (no root daemon)
- **Key defaults variables:**
  - `nerdctl_version` — from `version.nerdctl` (default `2.1.2`)
  - `nerdctl_base_dir` — from `paths.nerdctl.base_dir` (default `/apps`)
  - `nerdctl_arch` — from `config.nerdctl.arch` (default `linux-amd64`)
  - `nerdctl_package_type` — from `config.nerdctl.package_type` (default `full`)
  - `nerdctl_user` — from `config.nerdctl.user` (default `gitlab-runner`) — user who runs builds in rootless mode
  - `nerdctl_user_home` — auto-derived from `nerdctl_user` (`/home/<user>` or `/root`)
  - `nerdctl_data_root` — from `config.nerdctl.data_root` (default `<base_dir>/containerd`)
  - `nerdctl_buildkit_root` — from `config.nerdctl.buildkit_root` (default `<base_dir>/buildkit`)
  - `nerdctl_http_proxy` / `nerdctl_https_proxy` — inherits global proxy vars
  - `nerdctl_no_proxy` — from `config.nerdctl.no_proxy` (default `localhost,127.0.0.1,10.0.0.0/8`)
  - `nerdctl_download_timeout` — from `config.nerdctl.download_timeout` (default `120` seconds)
  - `nerdctl_prune_enabled` — from `config.nerdctl.prune.enabled` (default `true`)
  - `nerdctl_prune_schedule` — from `config.nerdctl.prune.schedule` (default `6 0 * * *`) — cron for daily image prune
  - `nerdctl_prune_log` — from `config.nerdctl.prune.log` (default `<base_dir>/script/nerdctl-prune.log`)
  - `nerdctl_registries` — from `config.nerdctl.registries` (default `[]`) — list of private registries to configure (HTTPS with skip_verify for self-signed certs)
- **Task flow:** validate → install → config → verify
- **User-level systemd services:** `containerd.service` and `buildkit.service` (under `~/.config/systemd/user/`)
- **Config-before-start pattern:** The config step follows a strict ordering: (1) create data directories → (2) deploy `config.toml` → (3) deploy systemd overrides → (4) install rootless containerd/buildkit → (5) restart if config changed → (6) verify services. This ensures containerd reads the correct `config.toml` with `/apps` paths on first start rather than using defaults and requiring a restart.
- **Containerd config.toml:** Config step creates `~/.config/containerd/config.toml` with `version = 2`, `root` (set to `nerdctl_data_root`), `state` (set to `/run/user/<uid>/containerd-rootless`), and `grpc.address` (socket path). This is the primary mechanism for configuring the containerd data root directory.
- **Systemd override drop-ins:** Config step deploys override files at `~/.config/systemd/user/containerd.service.d/override.conf` (sets `HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`, and `CONTAINERD_CONFIG` pointing to the config.toml path) and `~/.config/systemd/user/buildkit.service.d/override.conf` (sets proxy env vars + overrides `ExecStart` to pass `--root {{ nerdctl_buildkit_root }}`). Services are reloaded and restarted via `machinectl shell` when config changes (including `config.toml` changes).
- **Post-start verification:** After services are started/restarted, the config step waits for the containerd socket at `/run/user/<uid>/containerd-rootless/containerd.sock` (retries 10, delay 3s) and verifies that containerd is using the correct root directory by checking for `io.containerd.content.v1.content` under `nerdctl_data_root`.
- **BuildKit registry config:** When `nerdctl_registries` is defined, deploys `~/.config/buildkit/buildkitd.toml` with `[registry."<host>"]` sections (HTTPS with `insecure = true` for self-signed certs). BuildKit is restarted via `machinectl shell` if the config changes. This ensures `nerdctl build --push` works with private registries that use self-signed certificates.
- Proxy-aware (http_proxy, https_proxy for download and systemd service-level proxy for image operations)

### BuildKit + nerdctl (Root Mode)
- Installs BuildKit and nerdctl CLI in root mode (requires containerd already installed and running). Unlike the rootless `containerd_nerdctl` role, this runs BuildKit as a system-level systemd service.
- **Variable prefix:** `buildkit_*` / `nerdctl_*`
- **Configuration source:** `version.buildkit_nerdctl.*` in `versions.yml`
- **Role path:** `roles/platform/buildkit_nerdctl/`
- **Prerequisites:** containerd must be installed and running (validated at `/usr/local/bin/containerd` or `/usr/bin/containerd`)
- **Install method:** GitHub release tarball download (BuildKit from moby/buildkit, nerdctl from containerd/nerdctl)
- **Execution mode:** Root — BuildKit runs as a system-level systemd service (`buildkit.service`)
- **Key defaults variables:**
  - `buildkit_version` — from `version.buildkit_nerdctl.buildkit` (default `0.32.0`)
  - `nerdctl_version` — from `version.buildkit_nerdctl.nerdctl` (default `2.3.5`)
  - `buildkit_install_dir` — `/usr/local/bin` (binaries: buildctl, buildkitd, nerdctl)
  - `buildkit_nerdctl_download_dir` — `/tmp/buildkit_nerdctl_install` (temporary download/extract location)
  - `buildkit_arch` — default `linux-amd64`
  - `buildkit_http_proxy` / `buildkit_https_proxy` — inherits global proxy vars
  - `buildkit_download_timeout` — default `120` seconds
  - `buildkit_nerdctl_secure_path` — `/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/bin` (sudoers secure_path)
- **Task flow:** validate → install_buildkit → install_nerdctl → config → verify
- **BuildKit config:** Deploys `/etc/buildkit/buildkitd.toml` with both OCI and containerd workers enabled (rootless=false)
- **Systemd service:** `buildkit.service` — Type=simple, Restart=always, RestartSec=5, LimitNOFILE=infinity, Delegate=yes, KillMode=mixed
- **Config step:** Ensures `/usr/local/bin` is in sudoers `secure_path` (validated via `visudo -cf`)
- **Verify sub-steps:** buildctl version check → nerdctl version check → buildkit service active check → containerd service active check → deployment summary
- Proxy-aware (http_proxy, https_proxy for download)

### Java 17 (OpenJDK)
- Installs Java OpenJDK via yum and sets it as the system default using alternatives
- **Variable prefix:** `java_*`
- **Configuration source:** `version.java` in `versions.yml`, `config.java.*` in `app_configs.yml`
- **Role path:** `roles/platform/java/`
- **Install method:** yum package (`java-<version>-openjdk` + optional `-devel`)
- **Key defaults variables:**
  - `java_version` — from `version.java` (default `17`)
  - `java_package` — derived: `java-<version>-openjdk`
  - `java_devel` — from `config.java.install_devel` (default `true`) — installs `-devel` package (includes `javac`)
  - `java_http_proxy` / `java_https_proxy` — inherits global proxy vars
- **Task flow:** validate → install → verify
- **Install sub-steps:** install OpenJDK package → install devel package (if enabled) → find java binary path via filesystem search (`find /usr/lib/jvm`) → register and set as default via alternatives (install with priority 9999999 + set) → find javac binary path via filesystem search → register and set javac as default via alternatives (install with priority 9999999 + set) → set JAVA_HOME in `/etc/profile.d/java.sh`
- Proxy-aware (http_proxy, https_proxy for yum package install)

### NVD Sync (Vulnerability Database Synchronisation)
- Downloads NVD (National Vulnerability Database) CVE data via OWASP Dependency-Check CLI into PostgreSQL for vulnerability scanning
- **Variable prefix:** `nvd_sync_*`
- **Configuration source:** `config.nvd_sync.*` in `app_configs.yml`
- **Role path:** `roles/platform/nvd_sync/`
- **Sync behaviour:** The playbook deploys the sync script but does NOT execute it — actual NVD data sync runs via cron at the scheduled time. First run pulls all data and initialises the schema; subsequent runs pull only deltas (handled internally by the Dependency-Check CLI)
- **Key defaults variables:**
  - `nvd_sync_version` — from `version.nvd_sync.dependency_check`
  - `nvd_sync_base_dir` — from `paths.nvd_sync.base_dir`
  - `nvd_sync_pg_driver_version` — from `version.nvd_sync.pg_driver`
  - `nvd_sync_user` / `nvd_sync_group` — from `config.nvd_sync.user`/`.group` (default `nvd-sync`)
  - `nvd_sync_db_host` — from `config.nvd_sync.db_host`
  - `nvd_sync_db_port` — from `config.nvd_sync.db_port` (default `5432`)
  - `nvd_sync_db_name` — hardcoded `dependencycheck` (required by Dependency-Check schema SQL `initialize_postgres.sql`)
  - `nvd_sync_db_user` — hardcoded `dcuser` (required by Dependency-Check schema SQL `initialize_postgres.sql`)
  - `nvd_sync_db_password` — from vault (`nvd_sync_db_password_vault`)
  - `nvd_sync_api_key` — from vault (`nvd_sync_api_key_vault`)
  - `nvd_sync_api_delay` — from `config.nvd_sync.api_delay` (default `2000` ms)
  - `nvd_sync_api_max_retries` — from `config.nvd_sync.api_max_retries` (default `15`)
  - `nvd_sync_java_home` — from `config.nvd_sync.java_home` (default `/apps/java`)
  - `nvd_sync_connection_timeout` — from `config.nvd_sync.connection_timeout` (default `5000` ms)
  - `nvd_sync_read_timeout` — from `config.nvd_sync.read_timeout` (default `10000` ms)
  - `nvd_sync_cron_enabled` — from `config.nvd_sync.cron_enabled` (default `true`)
  - `nvd_sync_cron_schedule_minute` / `nvd_sync_cron_schedule_hour` — from `config.nvd_sync.cron_minute`/`.cron_hour` (default `0` / `2` — runs daily at 02:00)
  - `nvd_sync_log_dir` — `<base_dir>/nvd_sync/logs`
  - `nvd_sync_log_retention_days` — from `config.nvd_sync.log_retention_days` (default `30`)
  - `nvd_sync_http_proxy` / `nvd_sync_https_proxy` — inherits global proxy vars
  - `nvd_sync_download_timeout` — from `config.nvd_sync.download_timeout` (default `120` seconds)
- **Task flow:** validate → create_user → pre_verify → install → sync (deploy sync script only) → cron → verify
- Proxy-aware (http_proxy, https_proxy for download)
- Secrets sourced from vault: `nvd_sync_db_password_vault`, `nvd_sync_api_key_vault`

### OnePatch (OS Patching)
- BT OS patching automation — enables addon repos and optionally runs the OnePatch patching script with optional reboot, supports optional cron-based scheduled monthly patching
- **Variable prefix:** `onepatch_*`
- **Configuration source:** `config_platform.onepatch.*` in `config_platform.yml`
- **Role path:** `roles/platform/onepatch/`
- **Key defaults variables:**
  - `onepatch_mode` — from `config_platform.onepatch.mode` (default `monthly`)
  - `onepatch_url` — from `config_platform.onepatch.url` (default `https://patch.linux.nat.bt.com/onepatch`)
  - `onepatch_run_patch` — from `config_platform.onepatch.run_patch` (default `false`) — controls whether the patch script actually runs (false = only enable repos)
  - `onepatch_reboot` — from `config_platform.onepatch.reboot` (default `false`) — whether to reboot after patching
  - `onepatch_timeout` — from `config_platform.onepatch.timeout` (default `1800`) — async timeout in seconds (patching can take 10-30 minutes)
  - `onepatch_cron_enabled` — from `config_platform.onepatch.cron.enabled` (default `false`) — whether to set up a cron job for automated monthly patching (reboot always enabled for cron)
  - `onepatch_cron_weekday` — from `config_platform.onepatch.cron.weekday` (default `0` — Sunday)
  - `onepatch_cron_day` — from `config_platform.onepatch.cron.day` (default `8-14` — 2nd week of month)
  - `onepatch_cron_hour` — from `config_platform.onepatch.cron.hour` (default `2`)
  - `onepatch_cron_minute` — from `config_platform.onepatch.cron.minute` (default `0`)
  - `onepatch_cron_log` — from `config_platform.onepatch.cron.log` (default `/var/log/onepatch-cron.log`)
- **Task flow:** validate → setup → patch (conditional on `onepatch_run_patch`) → cron (conditional on `onepatch_cron_enabled`) → status
- **Validate sub-steps:** assert `onepatch_url` defined and non-empty → assert `onepatch_mode` is `monthly` or `full` → assert cron schedule variables defined (when `onepatch_cron_enabled`) → display configuration summary
- **Setup sub-steps:** Check if BT-OL9.repo / BT-OL8.repo exist → enable `[addons]` section in the appropriate repo file
- **Cron sub-steps:** Deploy addons repo persistence cron (ensures `[addons]` section stays enabled after OS updates reset it — weekly Monday 02:00, targets whichever repo file exists OL8/OL9, uses `sed` to flip `enabled=0` → `enabled=1`) → Deploy OnePatch patching cron (or remove if disabled) → Display cron status
- **Cron schedule:** Default patching targets the 2nd Sunday of each month at 02:00 (day 8-14, weekday 0); addons repo persistence runs weekly on 1st Monday at 02:00 (day 1-7, weekday 1)

### MinIO (Object Storage)
- Deploys MinIO server and `mc` (MinIO Client) as a systemd service for S3-compatible object storage
- **Variable prefix:** `minio_*`
- **Configuration source:** `config.minio.*` in `app_configs.yml`
- **Role path:** `roles/data_storage/minio/`
- **Deployment modes:** `single-node` (one server, one or more local dirs) or `distributed` (multi-node erasure coding, requires 4+ nodes)
- **Key defaults variables:**
  - `minio_version` — from `version.minio.server`
  - `minio_mc_version` — from `version.minio.mc`
  - `minio_base_dir` — from `paths.minio.base_dir`
  - `minio_api_port` — from `ports.minio.api` (default `61060`)
  - `minio_console_port` — from `ports.minio.console` (default `61061`)
  - `minio_user` / `minio_group` — from `config.minio.user`/`.group` (default `minio`)
  - `minio_root_user` — from `config.minio.root_user` (default `minioadmin`)
  - `minio_root_password` — from vault (`minio_root_password_vault`)
  - `minio_data_dir` — from `config.minio.data_dir` (default `<base_dir>/minio_data`)
  - `minio_data_dirs` — from `config.minio.data_dirs` (default `[minio_data_dir]`)
  - `minio_mode` — from `config.minio.mode` (default `single-node`)
  - `minio_host_group` — from `minio_host_group_name` (default `minio`)
  - `minio_listen_address` — from `config.minio.listen_address` (default `0.0.0.0`)
  - `minio_console_enabled` — from `config.minio.console_enabled` (default `true`)
  - `minio_arch` — from `config.minio.arch` (default `linux-amd64`)
  - `minio_memory_limit` — from `config.minio.memory_limit` (default `2G`), used as systemd `MemoryMax`
  - `minio_nofile_limit` — from `config.minio.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `minio_http_proxy` / `minio_https_proxy` — inherits global proxy vars
  - `minio_download_timeout` — from `config.minio.download_timeout` (default `120` seconds)
  - `minio_buckets` — from `config.minio.buckets` (default `['longhorn-backup']`)
  - `minio_wait_retries` — from `config.minio.wait_retries` (default `10`)
  - `minio_wait_delay` — from `config.minio.wait_delay` (default `10` seconds)
- Proxy-aware (http_proxy, https_proxy for download)
- Secrets sourced from vault: `minio_root_password_vault`

### HDFS (Hadoop Distributed File System)
- Deploys Apache Hadoop HDFS as systemd services for distributed file storage with High Availability (dual NameNode failover via ZooKeeper + JournalNode quorum)
- **Variable prefix:** `hdfs_*`
- **Configuration source:** `config_data_storage.hdfs.*` in `app_configs.yml`
- **Role path:** `roles/data_storage/hdfs/`
- **Install method:** Apache Hadoop archive download
- **Architecture:** HA cluster with 2 NameNodes (active/standby), 3+ JournalNodes (edit log quorum), N DataNodes, ZooKeeper for automatic failover
- **Key defaults variables:**
  - `hdfs_version` — from `version.hadoop` (default `3.4.3`)
  - `hdfs_base_dir` — from `paths.hadoop.base_dir` (default `/apps`)
  - `hdfs_parent_dir` — `<base_dir>/hdfs`
  - `hdfs_data_dir` — `<base_dir>/hdfs_data`
  - `hdfs_namenode_dir` — `<data_dir>/namenode`
  - `hdfs_datanode_dir` — `<data_dir>/datanode`
  - `hdfs_journalnode_dir` — `<data_dir>/journalnode`
  - `hdfs_logs_dir` — `<parent_dir>/logs`
  - `hdfs_pid_dir` — `<parent_dir>/pids`
  - `hdfs_tmp_dir` — `<data_dir>/tmp`
  - `hdfs_user` / `hdfs_group` — from `config_data_storage.hdfs.user`/`.group` (default `hadoop`)
  - `hdfs_cluster_name` — from `config_data_storage.hdfs.cluster_name` (default `hdfscluster`)
  - `hdfs_replication` — from `config_data_storage.hdfs.replication` (default `2`)
  - `hdfs_namenode1_group` — from `config_data_storage.hdfs.namenode1_group` (default `hdfs_name_node1`)
  - `hdfs_namenode2_group` — from `config_data_storage.hdfs.namenode2_group` (default `hdfs_name_node2`)
  - `hdfs_journalnode_group` — from `config_data_storage.hdfs.journalnode_group` (default `hdfs_journal_node`)
  - `hdfs_datanode_group` — from `config_data_storage.hdfs.datanode_group` (default `hdfs_data_node`)
  - `hdfs_zookeeper_group` — from `config_data_storage.hdfs.zookeeper_group` (default `zookeeper`)
  - `hdfs_rpc_port` — from `ports.hadoop.rpc` (default `9000`)
  - `hdfs_http_port` — from `ports.hadoop.http` (default `61002`)
  - `hdfs_journalnode_rpc_port` — from `config_data_storage.hdfs.journalnode_rpc_port` (default `8485`)
  - `hdfs_zookeeper_port` — from `config_data_storage.hdfs.zookeeper_port` (default `2181`)
  - `hdfs_namenode_heap_mb` — from `config_data_storage.hdfs.namenode_heap_mb` (default `2048`)
  - `hdfs_datanode_heap_mb` — from `config_data_storage.hdfs.datanode_heap_mb` (default `2048`)
  - `hdfs_journalnode_heap_mb` — from `config_data_storage.hdfs.journalnode_heap_mb` (default `1024`)
  - `hdfs_java_home` — from `config_data_storage.hdfs.java_home` (default `/usr`)
  - `hdfs_namenode_memory_limit` — from `config_data_storage.hdfs.namenode_memory_limit` (default `4G`), used as systemd `MemoryMax`
  - `hdfs_datanode_memory_limit` — from `config_data_storage.hdfs.datanode_memory_limit` (default `4G`), used as systemd `MemoryMax`
  - `hdfs_journalnode_memory_limit` — from `config_data_storage.hdfs.journalnode_memory_limit` (default `2G`), used as systemd `MemoryMax`
  - `hdfs_nofile_limit` — from `config_data_storage.hdfs.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `hdfs_http_proxy` / `hdfs_https_proxy` — inherits global proxy vars
  - `hdfs_download_timeout` — from `config_data_storage.hdfs.download_timeout` (default `600` seconds)
  - `hdfs_wait_retries` — from `config_data_storage.hdfs.wait_retries` (default `15`)
  - `hdfs_wait_delay` — from `config_data_storage.hdfs.wait_delay` (default `10` seconds)
  - `hdfs_ha_fencing_method` — from `config_data_storage.hdfs.ha_fencing_method` (default `shell(/bin/true)`)
  - `hdfs_ha_fencing_ssh_timeout` — from `config_data_storage.hdfs.ha_fencing_ssh_timeout` (default `30000` ms)
  - `hdfs_trash_interval` — from `config_data_storage.hdfs.trash_interval` (default `4320` minutes / 3 days)
  - `hdfs_trash_checkpoint_interval` — from `config_data_storage.hdfs.trash_checkpoint_interval` (default `2880` minutes / 2 days)
  - `hdfs_acls_enabled` — from `config_data_storage.hdfs.acls_enabled` (default `true`)
  - `hdfs_log_rotation_size` — from `config_data_storage.hdfs.log_rotation_size` (default `100M`)
  - `hdfs_log_rotation_count` — from `config_data_storage.hdfs.log_rotation_count` (default `5`)
  - `hdfs_housekeep_enabled` — from `config_data_storage.hdfs.housekeep.enabled` (default `false`) — enables cron-based HDFS path cleanup
  - `hdfs_housekeep_paths` — from `config_data_storage.hdfs.housekeep.paths` (default `['/druid/segments']`) — list of HDFS paths to purge old data from
  - `hdfs_housekeep_retention_days` — from `config_data_storage.hdfs.housekeep.retention_days` (default `90`) — files older than this are removed
  - `hdfs_housekeep_schedule_hour` — from `config_data_storage.hdfs.housekeep.schedule_hour` (default `2`)
  - `hdfs_housekeep_schedule_minute` — from `config_data_storage.hdfs.housekeep.schedule_minute` (default `0`)
  - `hdfs_housekeep_log` — from `config_data_storage.hdfs.housekeep.log` (default `<parent_dir>/logs/housekeep.log`)
  - `hdfs_namenode_status_enabled` — from `config_data_storage.hdfs.namenode_status.enabled` (default `true`) — enables cron-based NameNode HA state exporter for node_exporter textfile collector
  - `hdfs_namenode_textfile_dir` — from `config_data_storage.hdfs.namenode_status.textfile_dir` (default `<node_exporter_base_dir>/node_exporter/textfile_collector`, derived from `paths.node_exporter.base_dir`) — directory where Prometheus `.prom` metric files are written for node_exporter textfile collector
- **NameNode Status Exporter:** Deploys a cron script (every minute) on NameNode hosts that writes HA state (active=1, standby=0, unknown=-1) as Prometheus metrics (`hdfs_namenode_active`, `hdfs_namenode_state_info`) to the node_exporter textfile collector directory. Enables Prometheus/Grafana alerting on NameNode failover events without requiring a dedicated HDFS exporter.
- Proxy-aware (http_proxy, https_proxy for download)
- Configuration hierarchy: all settings sourced from `config_data_storage.hdfs.*` with sensible defaults
- **Environment variable:** `HDFS_ACTION` — controls behaviour: `install` (default, full deploy) or other values for targeted operations
- **Playbook structure** (`playbook/data_storage/hdfs.yaml`): Single-play design:
  - Targets `hdfs` host group (overridable via `target_host`), `become: true`, `gather_facts: true`
  - Sets `hdfs_action` from `HDFS_ACTION` env var (default `install`) — controls behaviour within the role
  - Loads shared vars from `../_global_vars/all.yml` and `../_global_vars/common_config.yml`
  - Applies `roles/_misc/disable_external_repos` before the `roles/data_storage/hdfs` role
- **Service sub-steps:** deploy JournalNode systemd unit → enable/start JournalNode (restart if config/upgrade changed) → upgrade NameNode filesystem layout on NN1 (`hdfs namenode -upgrade`, blocking foreground command, conditional on `hdfs_upgrade_needed`) → bootstrap standby NN2 (`hdfs namenode -bootstrapStandby -force`, conditional on `hdfs_upgrade_needed`) → deploy NameNode systemd unit → enable/start NameNode → deploy ZKFC systemd unit → enable/start ZKFC → deploy DataNode systemd unit → enable/start DataNode
- **Verify sub-steps:** JournalNode service active check (retries 3) → NameNode service active check (retries 3) → ZKFC service active check (retries 3) → DataNode service active check (retries 3) → RPC port listening (NameNode, timeout 30s, retries) → HTTP port listening (NameNode, timeout 30s) → JournalNode RPC port listening (timeout 30s) → NameNode HA state check (`hdfs haadmin -getServiceState nn1`) → deployment status summary (version, cluster name, replication, host roles, service states, HA state, ports, data dir)

### Druid (OLAP Analytics)
- Deploys Apache Druid as a multi-service cluster for real-time OLAP analytics with HDFS deep storage and MySQL metadata
- **Variable prefix:** `druid_*`
- **Configuration source:** `config_database.druid.*` in `config_database.yml`
- **Role path:** `roles/database/druid/`
- **Architecture:** Multi-process cluster — Coordinator, Overlord, Broker, Router, Historical, Middle Manager (each as separate systemd service, separate config directories)
- **Config directory layout:** `conf/druid/cluster/_common/` (shared), `conf/druid/cluster/master/coordinator/` (Coordinator), `conf/druid/cluster/master/overlord/` (Overlord), `conf/druid/cluster/query/broker/` (Broker), `conf/druid/cluster/query/router/` (Router), `conf/druid/cluster/data/historical/` (Historical), `conf/druid/cluster/data/middleManager/` (Middle Manager)
- **Deep storage:** HDFS (HA NameNode cluster) — segments stored at configurable path (default `/druid/segments`)
- **Metadata storage:** MySQL
- **Coordination:** ZooKeeper (shared with HDFS/legacy Kafka)
- **Key defaults variables:**
  - `druid_version` — from `version.druid` (default `37.0.0`)
  - `druid_base_dir` — from `paths.druid.base_dir` (default `/apps`)
  - `druid_parent_dir` — `<base_dir>/druid`
  - `druid_data_dir` — `<base_dir>/druid_data`
  - `druid_segment_cache_dir` — `<data_dir>/segment-cache`
  - `druid_task_dir` — `<data_dir>/task`
  - `druid_logs_dir` — `<parent_dir>/var/sv`
  - `druid_indexing_logs_dir` — `<parent_dir>/var/druid/indexing-logs`
  - `druid_user` / `druid_group` — from `config_database.druid.user`/`.group` (default `druid`)
  - `druid_java_home` — from `config_database.druid.java_home` (default `/usr`)
  - `druid_zookeeper_group` — from `config_database.druid.zookeeper_group` (default `zookeeper`)
  - `druid_zookeeper_port` — from `config_database.druid.zookeeper_port` (default `2181`)
  - `druid_zk_base_path` — from `config_database.druid.zk_base_path` (default `/druid`)
  - `druid_mysql_host` — from `config_database.druid.mysql.host`
  - `druid_mysql_port` — from `config_database.druid.mysql.port` (default `3306`)
  - `druid_mysql_db` — from `config_database.druid.mysql.db` (default `druid`)
  - `druid_mysql_user` — from `config_database.druid.mysql.user` (default `druid`)
  - `druid_mysql_password` — from vault (`druid_mysql_password_vault`)
  - `druid_mysql_connector_version` — from `config_database.druid.mysql.connector_version` (default `9.2.0`)
  - `druid_hdfs_cluster_name` — from `config_database.druid.hdfs.cluster_name`
  - `druid_hdfs_namenode1_host` / `druid_hdfs_namenode2_host` — auto-derived from inventory host groups
  - `druid_hdfs_rpc_port` — from `ports.hadoop.rpc` (default `9000`)
  - `druid_hdfs_http_port` — from `ports.hadoop.http` (default `61002`)
  - `druid_hdfs_storage_dir` — from `config_database.druid.hdfs.storage_dir` (default `/druid/segments`)
  - `druid_coordinator_port` — from `ports.druid.coordinator` (default `8081`)
  - `druid_overlord_port` — from `ports.druid.overlord` (default `8090`)
  - `druid_broker_port` — from `ports.druid.broker` (default `8082`)
  - `druid_router_port` — from `ports.druid.router` (default `8888`)
  - `druid_historical_port` — from `ports.druid.historical` (default `8083`)
  - `druid_middle_manager_port` — from `ports.druid.middleManager` (default `8091`)
  - `druid_coordinator_metrics_port` — from `ports.druid.coordinator_metrics` (default `9601`)
  - `druid_overlord_metrics_port` — from `ports.druid.overlord_metrics` (default `9602`)
  - `druid_broker_metrics_port` — from `ports.druid.broker_metrics` (default `9603`)
  - `druid_router_metrics_port` — from `ports.druid.router_metrics` (default `9604`)
  - `druid_historical_metrics_port` — from `ports.druid.historical_metrics` (default `9605`)
  - `druid_middle_manager_metrics_port` — from `ports.druid.middleManager_metrics` (default `9606`)
  - `druid_coordinator_heap_min` / `druid_coordinator_heap_max` — from `config_database.druid.coordinator.heap_min`/`.heap_max` (defaults `1g` / `2g`)
  - `druid_coordinator_period` — from `config_database.druid.coordinator.period` (default `PT300S`) — how often the Coordinator runs its coordination cycle
  - `druid_coordinator_poll_duration` — from `config_database.druid.coordinator.poll_duration` (default `PT60S`) — how often the Coordinator polls for segment changes
  - `druid_overlord_heap_min` / `druid_overlord_heap_max` — from `config_database.druid.overlord.heap_min`/`.heap_max` (defaults `1g` / `2g`)
  - `druid_broker_heap_min` / `druid_broker_heap_max` — from `config_database.druid.broker.heap_min`/`.heap_max` (defaults `2g` / `4g`)
  - `druid_broker_direct_memory` — from `config_database.druid.broker.direct_memory` (default `4g`)
  - `druid_router_heap_min` / `druid_router_heap_max` — from `config_database.druid.router.heap_min`/`.heap_max` (defaults `512m` / `1g`)
  - `druid_router_direct_memory` — from `config_database.druid.router.direct_memory` (default `256m`)
  - `druid_historical_heap_min` / `druid_historical_heap_max` — from `config_database.druid.historical.heap_min`/`.heap_max` (defaults `2g` / `4g`)
  - `druid_historical_direct_memory` — from `config_database.druid.historical.direct_memory` (default `6g`)
  - `druid_middle_manager_heap_min` / `druid_middle_manager_heap_max` — from `config_database.druid.middle_manager.heap_min`/`.heap_max` (defaults `512m` / `1g`)
  - `druid_middle_manager_direct_memory` — from `config_database.druid.middle_manager.direct_memory` (default `512m`)
  - `druid_historical_tier` — from `hostvars[inventory_hostname].druid_tier` (host-level override), falling back to `config_database.druid.historical.tier` (default `_default_tier`)
  - `druid_historical_segment_cache_size` — from `hostvars[inventory_hostname].druid_segment_cache_size` (host-level override), falling back to `config_database.druid.historical.segment_cache_size` (default `100g`)
  - `druid_historical_num_threads` — from `config_database.druid.historical.num_threads` (default `8`)
  - `druid_historical_buffer_size` — from `config_database.druid.historical.buffer_size` (default `100MiB`)
  - `druid_historical_num_merge_buffers` — from `config_database.druid.historical.num_merge_buffers` (default `2`)
  - `druid_mm_worker_capacity` — from `hostvars[inventory_hostname].druid_worker_capacity` (host-level override), falling back to `config_database.druid.middle_manager.worker_capacity` (default `10`)
  - `druid_mm_http_threads` — from `config_database.druid.middle_manager.http_threads` (default `60`)
  - `druid_mm_peon_heap` / `druid_mm_peon_direct_memory` — from `config_database.druid.middle_manager.peon_heap`/`.peon_direct_memory` (defaults `1g` / `2g`)
  - `druid_mm_peon_processing_buffer` — from `config_database.druid.middle_manager.peon_processing_buffer` (default `104857600`)
  - `druid_mm_peon_processing_threads` — from `config_database.druid.middle_manager.peon_processing_threads` (default `3`)
  - `druid_mm_peon_merge_buffers` — from `config_database.druid.middle_manager.peon_merge_buffers` (default `2`)
  - `druid_mm_peon_http_threads` — from `config_database.druid.middle_manager.peon_http_threads` (default `50`)
  - `druid_broker_http_threads` — from `config_database.druid.broker.http_threads` (default `60`)
  - `druid_broker_http_connections` — from `config_database.druid.broker.http_connections` (default `25`)
  - `druid_broker_http_max_queued_bytes` — from `config_database.druid.broker.http_max_queued_bytes` (default `10MiB`)
  - `druid_broker_http_read_timeout` — from `config_database.druid.broker.http_read_timeout` (default `PT10M`)
  - `druid_broker_processing_threads` — from `config_database.druid.broker.processing_threads` (default `8`)
  - `druid_broker_processing_buffer` — from `config_database.druid.broker.processing_buffer` (default `100MiB`)
  - `druid_broker_num_merge_buffers` — from `config_database.druid.broker.num_merge_buffers` (default `2`)
  - `druid_broker_groupby_max_merging_dict` — from `config_database.druid.broker.groupby_max_merging_dict` (default `5368709`)
  - `druid_broker_groupby_max_on_disk` — from `config_database.druid.broker.groupby_max_on_disk` (default `128849018`)
  - `druid_broker_groupby_max_results` — from `config_database.druid.broker.groupby_max_results` (default `1500000`)
  - `druid_broker_avatica_max_connections` — from `config_database.druid.broker.avatica_max_connections` (default `35`)
  - `druid_broker_avatica_max_rows_per_frame` — from `config_database.druid.broker.avatica_max_rows_per_frame` (default `10000`)
  - `druid_broker_avatica_max_statements` — from `config_database.druid.broker.avatica_max_statements` (default `5`)
  - `druid_broker_avatica_fetch_timeout_ms` — from `config_database.druid.broker.avatica_fetch_timeout_ms` (default `10000`)
  - `druid_auth_enabled` — from `config_database.druid.auth_enabled` (default `true`)
  - `druid_nofile_limit` — from `config_database.druid.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `druid_http_proxy` / `druid_https_proxy` — inherits global proxy vars
  - `druid_download_timeout` — from `config_database.druid.download_timeout` (default `600` seconds)
  - `druid_wait_retries` / `druid_wait_delay` — readiness check settings (defaults: 15 retries, 10s delay)
  - `druid_unused_extensions` — from `config_database.druid.unused_extensions` (default list: `druid-avro-extensions`, `druid-aws-rds-extensions`, `druid-azure-extensions`, `druid-bloom-filter`, `druid-catalog`, `druid-ec2-extensions`, `druid-google-extensions`, `druid-kafka-extraction-namespace`, `druid-kerberos`, `druid-kinesis-indexing-service`, `druid-kubernetes-extensions`, `druid-kubernetes-overlord-extensions`, `druid-lookups-cached-single`, `druid-orc-extensions`, `druid-pac4j`, `druid-parquet-extensions`, `druid-protobuf-extensions`, `druid-s3-extensions`, `druid-stats`, `druid-testing-tools`, `postgresql-metadata-storage`) — extensions explicitly excluded from the Druid load list
  - `druid_extensions` — from `config_database.druid.extensions` (default list includes: `druid-kafka-indexing-service`, `druid-histogram`, `druid-datasketches`, `druid-lookups-cached-global`, `mysql-metadata-storage`, `druid-multi-stage-query`, `druid-hdfs-storage`, `prometheus-emitter`, `druid-basic-security`, `simple-client-sslcontext`)
  - `druid_housekeep_enabled` — from `config_database.druid.housekeep.enabled` (default `true`) — enables cron-based log/segment cleanup
  - `druid_housekeep_retention_days` — from `config_database.druid.housekeep.retention_days` (default `30`) — days to retain old logs/data before removal
  - `druid_housekeep_schedule_hour` — from `config_database.druid.housekeep.schedule_hour` (default `3`)
  - `druid_housekeep_schedule_minute` — from `config_database.druid.housekeep.schedule_minute` (default `0`)
  - `druid_log_rotation_size` — from `config_database.druid.log_rotation_size` (default `100M`)
  - `druid_log_rotation_count` — from `config_database.druid.log_rotation_count` (default `7`)
- Proxy-aware (http_proxy, https_proxy for download)
- Secrets sourced from vault: `druid_mysql_password_vault`, `druid_admin_password_vault`, `druid_internal_client_password_vault`
- Configuration hierarchy: all settings sourced from `config_database.druid.*` with sensible defaults
- **Task flow:** validate → create_user → pre_install → migrate_data → install → cleanup → config → service → verify
- **Migrate data step:** Moves old segment cache from inside the symlinked version directory (`<parent_dir>/var/druid/segment-cache`) to the new persistent location (`druid_segment_cache_dir` = `<data_dir>/segment-cache`) that survives upgrades. Only runs on historical nodes where old data exists and new dir is empty. Uses `mv` for atomic relocation. Runs after pre_install (service stopped) and before install (new dirs created).

### NFS Server
- Deploys and configures an NFS server with one or more export directories via `/etc/exports`
- **Variable prefix:** `nfs_server_*` (proxy), `nfs_exports` (export list)
- **Configuration source:** `config_data_storage.nfs_server.*` in `app_configs.yml`
- **Role path:** `roles/data_storage/nfs_server/`
- **Design:** List-based — supports any number of NFS exports via a single `nfs_exports` list (refactored from legacy single-export variables)
- **Key defaults variables:**
  - `nfs_exports` — from `config_data_storage.nfs_server.exports` (default `[]`) — list of export definitions, each with: `path`, `clients`, optional `owner`, optional `group`, optional `mode`
  - `nfs_server_http_proxy` / `nfs_server_https_proxy` — inherits global proxy vars
- **Export list item schema:**
  - `path` — local directory to export (required)
  - `clients` — NFS client specification with options, e.g., `10.6.97.0/24(rw,sync,no_subtree_check,no_root_squash)` (required)
  - `owner` — directory owner (optional, default `root`)
  - `group` — directory group (optional, default `root`)
  - `mode` — directory permissions (optional, default `0755`)
- **Task flow:** validate → install (nfs-utils, rpcbind) → config (create dirs, template /etc/exports) → service (enable rpcbind + nfs-server) → verify
- **Handlers:** `reload nfs exports` (exportfs -ra), `restart nfs-server` (systemd restart)
- Proxy-aware (http_proxy, https_proxy for package install)

### NFS Mount
- Mounts remote NFS shares on local hosts as a systemd service dependency (uses `mount` module for fstab persistence)
- **Variable prefix:** `nfs_mount_*` (mount config), `nfs_mounts` (list of mounts)
- **Configuration source:** `config_data_storage.nfs_mount.*` in `app_configs.yml`
- **Role path:** `roles/data_storage/nfs_mount/`
- **Design:** List-based — supports any number of NFS mounts via a single `nfs_mounts` list (refactored from legacy hardcoded primary/secondary/tertiary/etc. variables)
- **Key defaults variables:**
  - `nfs_mounts` — from `config_data_storage.nfs_mount.mounts` (default `[]`) — list of mount definitions, each with: `server`, `remote_path`, `local_path`, optional `fstype`, optional `opts`
  - `nfs_mount_default_opts` — from `config_data_storage.nfs_mount.default_opts` (default `rw,soft,timeo=30,retrans=3,intr,bg,_netdev,noatime,rsize=1048576,wsize=1048576`)
  - `nfs_mount_default_fstype` — from `config_data_storage.nfs_mount.default_fstype` (default `nfs4`)
  - `nfs_mount_http_proxy` / `nfs_mount_https_proxy` — inherits global proxy vars
- **Mount list item schema:**
  - `server` — NFS server IP or hostname (required)
  - `remote_path` — export path on the NFS server (required)
  - `local_path` — mount point on the local host (required)
  - `fstype` — optional, overrides `nfs_mount_default_fstype` (default `nfs4`)
  - `opts` — optional, overrides `nfs_mount_default_opts`
- **Task flow:** install (nfs-utils) → config (create dirs, mount, persist in fstab)
- Proxy-aware (http_proxy, https_proxy for package install)

### MySQL (Database)
- Deploys MySQL Community Server as a systemd service for relational data storage
- **Variable prefix:** `mysql_*`
- **Configuration source:** `config_database.mysql.*` in `app_configs.yml`
- **Role path:** `roles/database/mysql/install/` (install), `roles/database/mysql/upgrade/` (upgrade), `roles/database/mysql/setup/` (user/database provisioning)
- **Service name:** `mysqld`
- **Key defaults variables:**
  - `mysql_version` — from `version.mysql.db` (default `8.4.8`)
  - `mysql_base_dir` — from `paths.mysql.base_dir` (default `/apps`)
  - `mysql_dir` — `<base_dir>/mysql`
  - `mysql_data_dir` — `<dir>/data`
  - `mysql_logs_dir` — `<dir>/logs`
  - `mysql_tmp_dir` — `<dir>/temp`
  - `mysql_backup_dir` — from `config_database.mysql.backup_dir` (default `<base_dir>/mysql_data_bkp`)
  - `mysql_backup_enabled` — from `config_database.mysql.backup_enabled` (default `false`) — controls whether pre-upgrade backup is performed
  - `mysql_user` / `mysql_group` — from `config_database.mysql.user`/`.group` (default `mysql`)
  - `mysql_port` — from `ports.mysql.db` (default `3306`)
  - `mysql_bind_address` — from `config_database.mysql.bind_address` (default `0.0.0.0`)
  - `mysql_max_connections` — from `config_database.mysql.max_connections` (default `500`)
  - `mysql_innodb_buffer_pool_size` — from `config_database.mysql.innodb_buffer_pool_size` (default `4G`)
  - `mysql_innodb_buffer_pool_instances` — from `config_database.mysql.innodb_buffer_pool_instances` (default `8`)
  - `mysql_innodb_log_buffer_size` — from `config_database.mysql.innodb_log_buffer_size` (default `128M`)
  - `mysql_innodb_log_file_size` — from `config_database.mysql.innodb_log_file_size` (default `1G`)
  - `mysql_innodb_write_io_threads` / `mysql_innodb_read_io_threads` — from `config_database.mysql.innodb_*_io_threads` (default `8`)
  - `mysql_key_buffer_size` — from `config_database.mysql.key_buffer_size` (default `256M`)
  - `mysql_join_buffer_size` — from `config_database.mysql.join_buffer_size` (default `256M`)
  - `mysql_max_allowed_packet` — from `config_database.mysql.max_allowed_packet` (default `256M`)
  - `mysql_thread_cache_size` — from `config_database.mysql.thread_cache_size` (default `40`)
  - `mysql_max_connect_errors` — from `config_database.mysql.max_connect_errors` (default `10000`)
  - `mysql_general_log` — from `config_database.mysql.general_log` (default `OFF`)
  - `mysql_slow_query_log` — from `config_database.mysql.slow_query_log` (default `ON`)
  - `mysql_log_rotation_size` — from `config_database.mysql.log_rotation_size` (default `100M`)
  - `mysql_log_rotation_count` — from `config_database.mysql.log_rotation_count` (default `5`)
  - `mysql_memory_limit` — from `config_database.mysql.memory_limit` (default `32G`), used as systemd `MemoryMax`
  - `mysql_nofile_limit` — from `config_database.mysql.nofile_limit` (default `65536`), used as systemd `LimitNOFILE`
  - `mysql_http_proxy` / `mysql_https_proxy` — inherits global proxy vars
  - `mysql_wait_retries` / `mysql_wait_delay` — readiness check settings (defaults: 10 retries, 10s delay)
- Proxy-aware (http_proxy, https_proxy for download)
- **Install role task flow:** validate → create_user → create_dirs → pre_install (includes backup before upgrade) → install → config → service → monitor → verify
- **Pre-install sub-steps:** check if MySQL binary exists → get current version → determine OS version (OEL8/9) → set version facts (mysql_installed, mysql_current, mysql_upgrade_needed, mysql_repo_package) → create backup directory (if upgrading) → backup data directory as tar.gz (if upgrading) → backup my.cnf (if upgrading) → stop service (if upgrading)
- **Service sub-steps:** systemd daemon reload (if override changed) → enable and start MySQL → wait for port ready (fresh install/upgrade) → get temporary root password from mysqld.log (fresh install) → set root password using temp password (fresh install) → restart if config changed
- **Fresh install password handling:** MySQL 8.4 generates a temporary root password in `mysqld.log` on first initialisation. The `service.yml` task extracts it and immediately resets it to the vault-sourced `mysql_root_password_vault`.
- Secrets sourced from vault: `mysql_root_password_vault`
- Configuration hierarchy: all settings sourced from `config_database.mysql.*` with sensible defaults

- **MySQL Exporter sub-role** (Prometheus exporter for MySQL metrics):
  - Deploys mysqld_exporter as a systemd service for MySQL metrics collection
  - Role path: `roles/database/mysql/mysql-exporter/`
  - **Variable prefix:** `mysql_exporter_*` (refactored from legacy `mysqld_exporter_*` / `mysql_port` naming)
  - **Configuration source:** `config_database.mysql_exporter.*` in `app_configs.yml`
  - **Key defaults variables:**
    - `mysql_exporter_version` — from `version.mysql.exporter` (default `0.16.0`)
    - `mysql_exporter_base_dir` — from `paths.mysql.base_dir` (default `/apps`)
    - `mysql_exporter_port` — from `ports.mysql.exporter` (default `9104`)
    - `mysql_exporter_user` / `mysql_exporter_group` — from `config_database.mysql_exporter.user`/`.group` (default `mysql-exporter`)
    - `mysql_exporter_listen_address` — from `config_database.mysql_exporter.listen_address` (default `0.0.0.0`)
    - `mysql_exporter_arch` — from `config_database.mysql_exporter.arch` (default `linux-amd64`)
    - `mysql_exporter_mysql_port` — from `ports.mysql.db` (default `3306`)
    - `mysql_exporter_mysql_user` — from `config_database.mysql_exporter.mysql_user` (default `exporter`)
    - `mysql_exporter_mysql_password` — from vault (`mysqld_exporter_user_password`)
    - Collectors are hardcoded in the systemd template (all useful collectors enabled: InnoDB, replication, perf_schema, query stats). No `mysql_exporter_collectors` variable in defaults.
    - `mysql_exporter_memory_limit` — from `config_database.mysql_exporter.memory_limit` (default `256M`), used as systemd `MemoryMax`
    - `mysql_exporter_nofile_limit` — from `config_database.mysql_exporter.nofile_limit` (default `1024`), used as systemd `LimitNOFILE`
    - `mysql_exporter_http_proxy` / `mysql_exporter_https_proxy` — inherits global proxy vars
    - `mysql_exporter_download_timeout` — from `config_database.mysql_exporter.download_timeout` (default `60` seconds)
    - `mysql_exporter_wait_retries` / `mysql_exporter_wait_delay` — readiness check settings (defaults: 5 retries, 5s delay)
  - Proxy-aware (http_proxy, https_proxy for download)
  - Secrets sourced from vault: `mysqld_exporter_user_password`
  - Configuration hierarchy: all settings sourced from `config_database.mysql_exporter.*` with sensible defaults
  - **Task flow:** validate → create_user → pre_install → install → cleanup → config → service → verify
  - **Verify sub-steps:** service active check → port listening (timeout 15s, retries) → metrics endpoint HTTP 200 (`/metrics`, retries 3, delay 5s) → deployment status summary (service state, version, port, MySQL user/port, metrics status)

- **MySQL Setup sub-role** (Database/user/grant provisioning):
  - Creates MySQL databases, users, and grants post-install
  - Role path: `roles/database/mysql/setup/`
  - Called by: `playbook/database/mysql_user_setup.yaml`
  - **Variable prefix:** `mysql_setup_*`
  - **Configuration source:** `config_database.mysql.*` (databases, users, user_access lists)
  - **Key defaults variables:**
    - `mysql_setup_databases` — from `config_database.mysql.databases` (default `[]`) — list of database names to create
    - `mysql_setup_users` — from `config_database.mysql.users` (default `[]`) — list of user definitions (each: `{ name, host, password_vault_var }`)
    - `mysql_setup_grants` — from `config_database.mysql.user_access` (default `[]`) — list of access grants (each: `{ name, host, database, tables, access }`)
    - `mysql_setup_root_password` — from vault (`mysql_root_password_vault`) — used to authenticate setup commands
    - `mysql_setup_exporter_password` — from vault (`mysqld_exporter_user_password`) — password for the metrics exporter user
    - `mysql_setup_exporter_user` — from `config_database.mysql_exporter.mysql_user` (default `exporter`)
  - Secrets sourced from vault: `mysql_root_password_vault`, `mysqld_exporter_user_password`
  - **Task flow:** validate → setup (databases → users → exporter user → grants → exporter grants) → verify

### Network Ports (key services)
- Kubernetes API: 61012
- Kafka broker: 61000, SSL: 61008
- Kafka UI (NodePort): 61070 (default, Barista pre-prod + prod); 49483 (Bhrigu pre-prod)
- ClickHouse HTTP: 61051, TCP: 61052, Keeper: 9181
- Prometheus: 61087, Node Exporter: 61088
- Kubernetes Monitoring Prometheus (NodePort): 49400 (Fixed Network prod + test, MAT Common test); 49470 (Bhrigu pre-prod)
- Kubernetes Monitoring AlertManager (NodePort): 49402 (Fixed Network test); 0/disabled (Fixed Network prod); 49410 (MAT Common test)
- Grafana monitor: 61011, HAProxy stats: 61009
- Elasticsearch: 61003, Logstash: 61006, Kibana: 5601
- Loki: 3100 (HTTP API), 9096 (gRPC), NodePort 49490 (Bhrigu pre-prod)
- MySQL: 61010, Exporter: 9104
- PostgreSQL (CNPG): 5432 (internal), NodePort: 61067, metrics: 9187; MAT Common test: NodePort 49402, metrics 9187
- pgAdmin (NodePort): 61068; MAT Common test: 49403
- MinIO API: 61060, Console: 61061
- MinIO K8s (NodePort): API 61060, Console 61061 (internal 9000/9001)
- LibreFS (MAT RAN FN pre-prod): API 9000, Console 9001, API NodePort 61005, Console NodePort 61006
- LibreFS (MAT Common test): API 9000, Console 9001, API NodePort 49405, Console NodePort 49406
- LibreFS (Barista pre-prod): API 9000, Console 9001, API NodePort 61074, Console NodePort 61075
- LibreFS (Barista prod): API 9000, Console 9001, API NodePort 61074, Console NodePort 61075
- LibreFS (Bhrigu pre-prod): API 9000, Console 9001, API NodePort 49472, Console NodePort 49473
- Harbor (NodePort): HTTP 61064, Notary 61065, HTTPS 61140 (Fixed Network prod); HTTPS 61116 (Fixed Network test); HTTP 49404 (MAT Common test); HTTPS 61140 (MAT RAN FN pre-prod, via `martini.preprod.nat.bt.com`)
- Supabase (Bhrigu pre-prod): Kong 8000, Kong NodePort 49485, Studio 3000, DB 5432, metrics 9542
- MongoDB Expose (Barista pre-prod): NodePorts 61017, 61018, 61019 (per-member replica set access via `barista.preprod.nat.bt.com`)
- MongoDB Expose (Barista prod): NodePorts 61017, 61018, 61019 (per-member replica set access via `barista.nat.bt.com`)
- MongoDB Expose (Bhrigu pre-prod): NodePorts 49474, 49475, 49476 (per-member replica set access via `bhrigu-martini-preprod.nat.bt.com`)
- Mongo Express (Bhrigu pre-prod): NodePort 49489
- FalkorDB (Barista prod): Redis NodePort 61085, Sentinel 61086, Browser UI 61084
- FalkorDB (Bhrigu pre-prod): Redis NodePort 49477, Sentinel 49478, Browser UI 49479
- Longhorn (NodePort): 61066 (default); 49401 (Fixed Network prod + test, MAT Common test); 61001 (MAT RAN FN pre-prod); 49471 (Bhrigu pre-prod)
- Superset (Bhrigu pre-prod): NodePort 49484
- SFTP (sshd_lock): 50022 (configurable via `config.sftp.port`)
- Blackbox Exporter: 9115

### Base Paths
All services install under `/apps` (e.g., `/apps/kafka_kraft`, `/apps/clickhouse_server`, `/apps/prometheus`).

---

## Conventions & Best Practices

1. **One playbook per service** — keeps blast radius small
2. **target_host override** — all playbooks accept `--extra-vars="target_host=<group>"` for targeted runs
3. **Environment isolation** — each env has its own inventory, configs, and secrets
4. **Vault for secrets** — all passwords/tokens encrypted with ansible-vault
5. **Manual CI triggers** — no auto-deploy to any environment
6. **Zone separation** — zone-1 for load balancers, zone-2 for backend services
7. **Modular task files** — roles split tasks into importable files (stop, install, config, start)
8. **Version pinning** — all software versions defined in `versions.yml`
9. **Config files in inventory** — service configs (XML, properties, YAML) stored per-environment under `configs/`
10. **Grafana dashboards as code** — JSON models version-controlled in `grafana_dashboards/`
11. **Log checking commands in README** — every role's README must include a "Checking Logs" section under Troubleshooting with the appropriate commands:
    - For services **without** log files (systemd-only): include `journalctl -u <service_name>` commands (recent, follow, errors, time-range)
    - For services **with** log files (e.g., Kafka, Elasticsearch): include both the log file path and `journalctl` commands
    - Standard commands: `journalctl -u <service> --no-pager -n 50` (recent), `journalctl -u <service> -f` (follow), `journalctl -u <service> -p err` (errors only)
12. **Use latest stable versions** — all new roles and role refactors must target the latest stable version of the software. Check the official release page before implementation. Role code must be written for the latest version's install method, config format, and CLI. If a version change breaks backward compatibility, document it in the README.
13. **Task file comments** — all task files (main.yml, sub-task files) must include a YAML comment block at the top explaining:
    - **What** the file does (one-line purpose)
    - **How** it is called (which playbook or parent file triggers it)
    - **Execution order** (where it fits in the overall flow, especially for roles with split task files like prerequisites + setup)
    - This is especially important for roles where `main.yml` runs via `roles:` and additional tasks run via the playbook's `tasks:` section
14. **Pre-verify step** — all roles must include a `pre_verify.yml` task file that runs AFTER prerequisite/setup tasks (like `create_user.yml`) and BEFORE install tasks (`pre_install.yml` or `install.yml`). This step validates that all prerequisites are correctly in place (directories exist, users created, services running, sysctl values applied, etc.) and fails fast with a clear message if anything is missing. Prevents wasted time debugging failures deep in the install phase.
15. **Dynamic task names** — task `name:` fields must use variables when referencing paths, versions, ports, or any configurable value. Hardcoded paths in task names become incorrect when inventory values differ. Example:
    - Bad: `- name: Move pod logs to /apps`
    - Good: `- name: Move pod logs to {{ k8s_log_dir }}`
    - Bad: `- name: Download kafka 8.0.0`
    - Good: `- name: Download kafka {{ kafka_version }}`

---

## How to Add a New Service

1. Create a role under `roles/<service_name>/` with standard structure
2. Create a playbook `playbook/<service_name>.yaml` targeting the appropriate host group
3. Add the host group to each environment's `hosts` file
4. Add version to `versions.yml`, paths to `paths.yml`, ports to `networks.yml`
5. Add any app-specific config to `app_configs.yml`
6. Add the playbook name to `.gitlab-ci.yml` APP variable options
7. If needed, add config files under `inventories/<module>/<env>/configs/<service_name>/`

---

## How to Run Locally

```bash
# Run a playbook against a specific environment
ansible-playbook -i inventories/mat_fixed_network/test/hosts \
  playbook/<app_name>.yaml \
  --vault-password-file .vault

# Override target hosts
ansible-playbook -i inventories/mat_fixed_network/prod/hosts \
  playbook/clickhouse_server.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=clickhouse_server_port"
```

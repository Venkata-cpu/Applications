---
inclusion: fileMatch
fileMatchPattern: "roles/kubernetes/**/*"
description: "Conventions specific to Kubernetes roles deployed via kubectl/helm from master nodes"
---

# Kubernetes Role Standards

## Execution Model

All K8s roles run on the Ansible target host (typically `kubernetes_master_init`) and execute `kubectl`/`helm` commands as the Kubernetes ansible user (`config_k8s.ansible_user`, typically `app-manager`).

## kubectl Execution Pattern (MANDATORY)

```yaml
- name: Apply manifest
  shell: sudo -u {{ <role>_ansible_user }} --set-home kubectl apply -f /tmp/manifest.yaml
  args:
    executable: /bin/bash
```

**Rules:**
- NEVER use `become_user` / `become_method: su` — fails in CI/GitLab Runner environments
- ALWAYS prefix kubectl/helm commands with `sudo -u {{ <role>_ansible_user }} --set-home`
- The `--set-home` flag ensures HOME and KUBECONFIG resolve correctly
- Every K8s role defines `<role_prefix>_ansible_user` in defaults (from `config_k8s.ansible_user`)

## Deploy Method

Most roles use **raw K8s manifests** (no Helm dependency) via `template` + `kubectl apply`:

```yaml
- name: Template manifest
  template:
    src: my-resource.yaml.j2
    dest: /tmp/my-resource.yaml
    mode: "0644"

- name: Apply manifest
  shell: sudo -u {{ <role>_ansible_user }} --set-home kubectl apply -f /tmp/my-resource.yaml
  args:
    executable: /bin/bash
```

Roles using Helm (harbor, longhorn, supabase, etc.) use:
```yaml
- name: Helm install/upgrade
  shell: |
    sudo -u {{ <role>_ansible_user }} --set-home helm upgrade --install \
      {{ release_name }} {{ chart }} \
      --namespace {{ namespace }} --create-namespace \
      -f /tmp/values.yaml \
      --timeout {{ timeout }}
  args:
    executable: /bin/bash
```

## Variable Prefix Convention

Every K8s role uses a unique prefix for its defaults:
- `k8s_mon_*` — kubernetes/operations/monitoring
- `k8s_es_*` — kubernetes/database/elasticsearch
- `k8s_loki_*` — kubernetes/database/loki
- `k8s_grafana_*` — kubernetes/frontend/grafana
- `k8s_librefs_*` — kubernetes/storage/librefs
- `k8s_minio_*` — kubernetes/storage/minio
- `headlamp_*` — kubernetes/frontend/headlamp
- `harbor_*` — kubernetes/platform/harbor
- `longhorn_*` — kubernetes/storage/longhorn
- `cnpg_*` — kubernetes/database/postgres
- `pgadmin_*` — kubernetes/database/pgadmin
- `supabase_*` — kubernetes/database/supabase
- `falkordb_*` — kubernetes/falkordb

## Config Source

All K8s roles read from `config_k8s.<sub_role>.*` in `config_kubernetes.yml`:
```yaml
# In defaults/main.yml
<role>_namespace: "{{ config_k8s.<sub_role>.namespace | default('default') }}"
```

## Resource Ordering (CRITICAL)

When a Deployment/StatefulSet mounts ConfigMaps or Secrets as volumes:

1. Create Namespace
2. Apply Secrets
3. Apply ConfigMaps
4. Apply Deployment/StatefulSet
5. Wait for rollout

Wrong ordering causes `MountVolume.SetUp failed: configmap "..." not found`.

## Ingress Standard

When exposing via Ingress with a context path:
- The application handles the path prefix internally (CLI arg, env var, or config)
- Ingress uses `pathType: Prefix` — NO path-rewrite annotations
- Liveness/readiness probes include the path prefix
- `ingressClassName: haproxy` (project-standard ingress controller)

## Verify Pattern

```yaml
- name: Wait for pod ready
  shell: |
    sudo -u {{ <role>_ansible_user }} --set-home \
      kubectl wait --for=condition=Ready pods -l app={{ label }} \
      -n {{ namespace }} --timeout=120s
  args:
    executable: /bin/bash
  retries: "{{ <role>_wait_retries }}"
  delay: "{{ <role>_wait_delay }}"
  register: result
  until: result.rc == 0
```

## Node Targeting (Optional)

For workload-specific nodes, use label-based affinity:
```yaml
nodeAffinity:
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
      - matchExpressions:
          - key: "{{ <role>_node_label_key }}"
            operator: In
            values:
              - "{{ <role>_node_label_value }}"
```

## Topology Spread (Multi-DC)

For zone-aware scheduling across data centres:
```yaml
topologySpreadConstraints:
  - maxSkew: {{ max_skew }}
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: ScheduleAnyway
    labelSelector:
      matchLabels:
        app: {{ app_label }}
```

## Playbook Structure (K8s roles)

```yaml
- hosts: "{{ target_host | default('kubernetes_master_init') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/kubernetes/<category>/<role_name> }
```

## Proxy Awareness

All roles define proxy variables and inject them where needed:
- Helm: `--set global.httpProxy={{ proxy }}`
- Pods: environment variables `HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY`
- Downloads: `get_url` tasks use proxy vars

Standard no_proxy: `localhost,127.0.0.1,.svc,.cluster.local,10.96.0.0/12,192.168.0.0/16,.bt.com,.nat.bt.com`

---
inclusion: fileMatch
fileMatchPattern: "pipeline/**/*.yml,.gitlab-ci.yml"
description: "GitLab CI pipeline structure and conventions for the MAT Ansible project"
---

# CI/CD Pipeline Conventions

## Pipeline Architecture

```
.gitlab-ci.yml (entrypoint)
├── pipeline/martini-ran-ci.yml      (APP_INSTANCE == "RAN")
├── pipeline/mat-fn-ci.yml           (APP_INSTANCE == "Fixed Network")
├── pipeline/barista-ci.yml          (APP_INSTANCE == "Barista")
├── pipeline/bhrigu-ci.yml           (APP_INSTANCE == "Bhrigu")
├── pipeline/martini-ran-fn-ci.yml   (APP_INSTANCE == "RAN-FN")
└── pipeline/mat-common-ci.yml       (APP_INSTANCE == "MAT Common")
```

## Pipeline Variables

| Variable | Purpose | Options |
|----------|---------|---------|
| `APP_INSTANCE` | Target module | Barista, Fixed Network, MAT Common, RAN, RAN-FN, Bhrigu |
| `ENV` | Target environment | Test, Pre-Prod, Prod, Dr, Geo-Prod, Automation-Pre-Prod, Dev-Test |
| `ZONE` | Network zone | zone-1 (HAProxy/LB), zone-2 (backend services) |
| `APP_GROUP` | Playbook subfolder | _misc, coordination, data_storage, database, elk, frontend, kafka, kubernetes, load_balancing, monitoring, platform |
| `APP` | Playbook name (no .yaml) | See .gitlab-ci.yml for full list |
| `TARGET_HOST` | Optional host group override | Leave empty for playbook default |

## Job Template Pattern (APP_GROUP-based pipelines)

```yaml
.instance_base: &instance_base
  stage: install
  script:
    - echo $ansible_vault_pass >> .vault
    - echo "Running $APP on <instance>/$INVENTORY_ENV"
    - |
      INVENTORY_PATH="inventories/<module>/${INVENTORY_ENV}/hosts"
      PLAYBOOK_PATH="playbook/${APP_GROUP}/${APP}.yaml"
      if [ ! -f "$INVENTORY_PATH" ]; then
        echo "ERROR: Inventory file not found: $INVENTORY_PATH"
        exit 1
      fi
      if [ ! -f "$PLAYBOOK_PATH" ]; then
        echo "ERROR: Playbook not found: $PLAYBOOK_PATH"
        exit 1
      fi
      EXTRA_VARS=""
      if [ -n "$TARGET_HOST" ]; then
        EXTRA_VARS="--extra-vars=target_host=$TARGET_HOST"
      fi
      ansible-playbook -f ${FORKS:-4} \
        $EXTRA_VARS \
        -D --vault-password-file .vault \
        -e "ansible_user=$ANSIBLE_USER" \
        -i "$INVENTORY_PATH" \
        "$PLAYBOOK_PATH"
  after_script:
    - rm -f .vault
```

## Runner Tags

| APP_INSTANCE | ENV | ZONE | Runner Tag |
|-------------|-----|------|------------|
| Fixed Network | Test | any | `MAT-Ansible-TEST` |
| Fixed Network | Dr | zone-1 | `MAT-Ansible-DRZ1` |
| Fixed Network | Dr/Prod | zone-2 | `MAT-Ansible-DRZ2` |
| MAT Common | Test | any | `MAT-Ansible-TEST` |
| MAT Common | Pre-Prod | any | `MAT-Ansible-DRZ2` |
| Barista | Test | any | `barista-test-ansible-z2` |
| Barista | Pre-Prod | any | `MAT-Ansible-DRZ2` |
| Barista | Prod | zone-2 | `barista-prod-ansible-z2` |
| Bhrigu | Test | any | `barista-test-ansible-z2` |
| Bhrigu | Pre-Prod | any | `MAT-Ansible-DRZ2` |
| RAN-FN | Pre-Prod | any | `MAT-Ansible-DRZ2` |

## Adding a New Pipeline Job

1. Identify the APP_INSTANCE and ENV it belongs to
2. Open the relevant `pipeline/<instance>-ci.yml`
3. Add a new job using the `&<instance>_base` YAML anchor
4. Set the correct `tags:` (runner tag), `INVENTORY_ENV`, and `FORKS`
5. Add appropriate `rules:` conditions (ENV, ZONE matching)
6. All jobs MUST be `when: manual` — no auto-deploy

## Adding a New APP to the Pipeline

1. Add the playbook name to `.gitlab-ci.yml` under the `APP.options` list (alphabetical order)
2. Ensure the APP_GROUP matches the playbook subdirectory
3. Test locally first:
   ```bash
   ansible-playbook -i inventories/<module>/test/hosts \
     playbook/<app_group>/<app>.yaml \
     --vault-password-file .vault
   ```

## Key Rules

- All jobs are **manual** — no auto-deploy to any environment
- Vault password injected via `$ansible_vault_pass` CI variable
- The `.vault` file is ALWAYS cleaned up in `after_script`
- `FORKS` defaults to 4 but can be overridden per job (e.g., 6 for pre-prod, 3 for small test)
- Zone separation: zone-1 for HAProxy/load balancers, zone-2 for backend services
- Path validation: newer pipelines validate that inventory and playbook files exist before running

---
inclusion: manual
description: "Step-by-step checklist for adding a new service to the MAT Ansible platform"
---

# New Service Checklist

Use this when adding a completely new service (role + playbook + inventory config + CI integration).

## Step 1: Create the Role

Location: `roles/<category>/<service_name>/`

Categories:
- `coordination/` — distributed coordination (ZooKeeper)
- `data_storage/` — file/object storage (HDFS, MinIO, LibreFS, NFS)
- `database/` — databases (ClickHouse, MySQL, Druid, Prometheus)
- `elk/` — ELK stack (Elasticsearch, Kibana, Loki)
- `frontend/` — web UIs (Grafana)
- `kafka/` — streaming (Kafka KRaft, Schema Registry)
- `kubernetes/<sub_category>/` — K8s-deployed services
- `load_balancing/` — load balancers (HAProxy)
- `monitoring/` — exporters and monitoring tools
- `platform/` — platform tooling (Java, Docker, GitLab Runner)
- `_misc/` — reusable utilities

Required structure:
```
roles/<category>/<service_name>/
├── defaults/main.yml       # All configurable variables with defaults
├── tasks/
│   ├── main.yml            # Orchestrates task file imports
│   ├── validate.yml        # Pre-flight checks
│   ├── create_user.yml     # System user creation (if needed)
│   ├── pre_install.yml     # Version check, download, conditional stop
│   ├── install.yml         # Extract, symlink
│   ├── cleanup.yml         # Remove old version
│   ├── config.yml          # Deploy config files
│   ├── service.yml         # Systemd unit, enable, conditional restart
│   └── verify.yml          # Health checks
├── templates/              # Jinja2 templates (service unit, config files)
├── handlers/main.yml       # restart/reload handlers
└── README.md               # Documentation (follow README standards)
```

## Step 2: Create the Playbook

Location: `playbook/<app_group>/<service_name>.yaml`

```yaml
- hosts: "{{ target_host | default('<host_group>') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/<category>/<service_name> }
```

## Step 3: Add Inventory Configuration

For each target environment (`inventories/<module>/<env>/group_vars/all/`):

1. **versions.yml** — Add version number:
   ```yaml
   version:
     <service_name>: "x.y.z"
   ```

2. **paths.yml** — Add base directory:
   ```yaml
   paths:
     <service_name>:
       base_dir: /apps
   ```

3. **networks.yml** — Add port(s):
   ```yaml
   ports:
     <service_name>:
       service: <port_number>
   ```

4. **config_<group>.yml** — Add service-specific config:
   ```yaml
   config_<group>:
     <service_name>:
       user: <service_user>
       group: <service_group>
       memory_limit: 2G
       nofile_limit: 65536
       # ... service-specific settings
   ```

5. **all_secrets.yml** — Add any secrets (vault-encrypted):
   ```yaml
   <service_name>_<purpose>_vault: !vault |
     $ANSIBLE_VAULT;1.1;AES256
     ...
   ```

## Step 4: Add Host Group to Inventory

In `inventories/<module>/<env>/hosts`:
```ini
[<service_name>]
<hostname>    ansible_host=<IP>
```

## Step 5: Register in CI Pipeline

1. Add playbook name to `.gitlab-ci.yml` `APP.options` list (alphabetical order)
2. Verify `APP_GROUP` matches your playbook subdirectory
3. Test the pipeline path construction: `playbook/${APP_GROUP}/${APP}.yaml`

## Step 6: Update Documentation

1. **ChangeTracker.md** — Add entry under new section for the role
2. **roles/ROLE_STRUCTURE.md** — Add to the appropriate category in the visual tree
3. Role **README.md** — Must follow all 12 sections from the README standard

## Step 7: Verify

```bash
# Test locally
ansible-playbook -i inventories/<module>/test/hosts \
  playbook/<app_group>/<service_name>.yaml \
  --vault-password-file .vault \
  --check --diff

# Then run for real
ansible-playbook -i inventories/<module>/test/hosts \
  playbook/<app_group>/<service_name>.yaml \
  --vault-password-file .vault
```

## Quick Reference: Version Sources

Always check the latest stable version before implementation:
- GitHub releases: `https://github.com/<org>/<repo>/releases`
- Apache downloads: `https://downloads.apache.org/`
- Docker Hub: `https://hub.docker.com/_/<image>/tags`
- Elastic: `https://www.elastic.co/downloads/`
- Confluent: `https://packages.confluent.io/`

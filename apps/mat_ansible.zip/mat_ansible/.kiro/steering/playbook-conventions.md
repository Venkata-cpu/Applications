---
inclusion: fileMatch
fileMatchPattern: "playbook/**/*.yaml"
description: "Standards for creating and editing Ansible playbooks in the MAT project"
---

# Playbook Conventions

## Standard Playbook Template

```yaml
- hosts: "{{ target_host | default('<host_group>') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/<category>/<role_name> }
```

## Required Elements

| Element | Rule |
|---------|------|
| `hosts` | Must use `target_host` variable with `default('<host_group>')` for override support |
| `become` | Always `true` — roles run as root |
| `gather_facts` | `true` if role uses `ansible_host`, `ansible_os_family`, `password_hash`; `false` otherwise |
| `ansible_python_interpreter` | Always `auto_silent` |
| `vars_files` | Always include `../_global_vars/all.yml`; add `common_config.yml` if role uses yum/dnf |
| `disable_external_repos` | MUST be first role if any yum/dnf operations occur |

## Playbook Location

Playbooks are organized by APP_GROUP subdirectories:

```
playbook/
├── _global_vars/              # Shared vars (all.yml, common_config.yml)
├── _misc/                     # Utility playbooks
├── coordination/              # ZooKeeper
├── data_storage/              # HDFS, MinIO, LibreFS, NFS
├── database/                  # ClickHouse, MySQL, Postgres, Druid
├── elk/                       # Elasticsearch, Kibana, Loki
├── frontend/                  # Grafana
├── kafka/                     # Kafka KRaft, Schema Registry, Kafdrop, Exporters
├── kubernetes/                # All K8s-related playbooks
├── load_balancing/            # HAProxy
├── monitoring/                # Prometheus, exporters, Pushgateway
└── platform/                  # Java, Docker, GitLab Runner, Gradle, NVD Sync
```

## Naming Rules

- File name matches the CI `APP` variable (without `.yaml`)
- Use snake_case: `kafka_kraft.yaml`, `node_exporter.yaml`
- Kubernetes playbooks prefix with `kubernetes_`: `kubernetes_monitoring.yaml`
- One playbook per service — keeps blast radius small

## Environment Variables in Playbooks

Some playbooks support environment-variable-driven behaviour:

```yaml
vars:
  <role>_action: "{{ lookup('env', '<ROLE>_ACTION') | default('install') }}"
```

Used by: `longhorn`, `librefs`, `falkordb`, `hdfs`, `gitlab_runner`

## Adding a New Playbook

1. Create `playbook/<app_group>/<service_name>.yaml`
2. Follow the standard template above
3. Add the playbook name to `.gitlab-ci.yml` under `APP` options list
4. Ensure the role exists at `roles/<category>/<role_name>/`
5. Ensure the host group exists in target inventories

## Multi-Play Playbooks

Some services require ordered plays targeting different host groups:

```yaml
# Play 1: Init master
- hosts: "{{ target_host | default('kubernetes_master_init') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/kubernetes/cluster/docker_less, tags: [master-init] }

# Play 2: Join masters
- hosts: "{{ target_host | default('kubernetes_master_join') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/kubernetes/cluster/docker_less, tags: [master-join] }
```

## Target Host Override

All playbooks support runtime host override:
```bash
ansible-playbook -i inventories/<module>/<env>/hosts \
  playbook/<app_group>/<service>.yaml \
  --vault-password-file .vault \
  --extra-vars="target_host=<specific_group>"
```

This enables running against a subset of hosts without modifying the playbook.

## CI Pipeline Integration

The CI constructs the path as: `playbook/${APP_GROUP}/${APP}.yaml`

Both `APP_GROUP` and `APP` must match exactly for the pipeline to find the playbook.

---
inclusion: auto
description: "Standards and conventions for writing Ansible roles in the MAT Ansible project"
---

# Ansible Role Standards

## Task File Structure (mandatory for all roles)

Every role MUST follow this task execution order:

```
validate.yml → pre_install.yml → install.yml → cleanup.yml → config.yml → service.yml → verify.yml
```

Where applicable (not all roles need all files):
- `validate.yml` — Pre-flight checks before any changes. Must include deep validation (e.g., memory_limit > heap_size for Java services, port not zero, required vars defined, base_dir exists).
- `pre_install.yml` — Check current running version, set facts (installed, current version, upgrade_needed), download tarball/binary while service is still running, then stop service if upgrade needed. Download-before-stop minimises service downtime (downloads can take minutes over proxy).
- `install.yml` — Extract, set permissions, create symlink. Only runs if upgrade needed or fresh install. Download is already completed in pre_install.
- `cleanup.yml` — Remove old version directory and tarball. MUST use the version fact captured in pre_install (e.g., `es_current`). NEVER use glob patterns like `*` or `[0-9]*` for deletion.
- `config.yml` — Deploy configuration files (templates, static files from inventory).
- `service.yml` — Deploy systemd unit, enable, start. Only restart if config or binary changed. Never unconditionally restart.
- `verify.yml` — Health checks: service active, port listening, endpoint responding, version confirmation.

For complex roles (e.g., Kubernetes sub-roles), `install.yml` can be split into multiple files but the overall order must be preserved.

## Systemd Service Template Standards

Every systemd service MUST include:

```ini
Restart=always
RestartSec=10s
LimitNOFILE={{ <role>_nofile_limit }}
MemoryAccounting=true
MemoryMax={{ <role>_memory_limit }}
```

- `LimitNOFILE` and `MemoryMax` must be configurable via `config.<role>.nofile_limit` and `config.<role>.memory_limit` with sensible defaults.
- Never hardcode resource limits in the template — always use variables from defaults/main.yml.
- Use `Restart=always` for all production services (ensures auto-recovery from any exit).
- `RestartSec` should be 5-30s depending on service startup time.

## Validation Standards

`validate.yml` MUST include:
- Check all required variables are defined and non-empty.
- Check base directory exists (stat + failed_when).
- Check port is valid integer > 0.
- Cross-validate related settings (e.g., `memory_limit` must be greater than JVM `heap_size` for Java services).
- Validate webhook/external URLs are defined when features are enabled.
- Display a summary debug message at the end showing key configuration.

## Download-Before-Stop Standard (Minimum Downtime)

All roles that download tarballs/binaries MUST follow this order in `pre_install.yml`:

1. **Version check** — determine if upgrade is needed or fresh install
2. **Download** — fetch the tarball/binary while the service is STILL RUNNING
3. **Stop** — only stop the service AFTER download completes successfully

This ensures the service stays online during the (potentially slow) download phase. Downtime starts only from the stop → extract → config → start window.

**Standard pattern:**
```yaml
# pre_install.yml
- name: Set version facts
  set_fact:
    <role>_upgrade_needed: "{{ ... }}"

- name: Download <software> {{ <role>_version }} (service still running)
  get_url:
    url: "..."
    dest: "{{ <role>_base_dir }}/<tarball>"
    timeout: "{{ <role>_download_timeout }}"
  when: <role>_upgrade_needed | bool or not <role>_installed | bool

- name: Stop <service> before upgrade
  systemd:
    name: <service>
    state: stopped
  when: <role>_upgrade_needed | bool
  failed_when: false
```

**install.yml then starts from extract** (download already completed):
```yaml
# install.yml
- name: Extract <software> tarball
  unarchive:
    src: "{{ <role>_base_dir }}/<tarball>"
    ...
  when: <role>_upgrade_needed | bool or not <role>_installed | bool
```

**Fresh install note:** On fresh installs (`not <role>_installed`), there is no running service to stop, so only the download + extract runs. The stop task is guarded by `when: <role>_upgrade_needed | bool` (which is false on fresh installs).

## Cleanup Standards

- NEVER use glob/wildcard patterns for file deletion.
- NEVER leave unused/stale variables in defaults/main.yml — they create confusion. If a variable is not referenced in any task, template, or other variable expression, remove it immediately.
- ALWAYS get the old version from the running binary in `pre_install.yml` and store it as a fact.
- `cleanup.yml` uses that fact to target only the exact previous version directory and tarball.
- All cleanup tasks MUST have `when` guards checking the version fact is defined, non-empty, and different from target version.

## defaults/main.yml Standards

- All variables MUST read from `config_<group>.<role>.*` with `| default(<value>)`, UNLESS the value is a hard constraint imposed by an external dependency (e.g., a username required by a third-party SQL schema). In that case, hardcode the value with a comment explaining the constraint.
- The `<group>` prefix matches the inventory config file (e.g., `config_k8s` for Kubernetes roles, `config_platform` for platform roles, `config_monitoring` for monitoring roles).
- Group variables into logical sections with comment headers in this order:
  1. `# --- Core ---` — version, base_dir, port (from versions.yml, paths.yml, networks.yml)
  2. `# --- User ---` — service user and group
  3. `# --- Service/Runtime ---` — listen address, log level, feature flags, arch
  4. `# --- Resource Limits ---` — memory_limit, nofile_limit
  5. `# --- Network/Proxy ---` — http_proxy, https_proxy, download_timeout
  6. `# --- Timeouts ---` — wait retries, delays (if applicable)
  7. `# --- Component-Specific ---` — anything unique to this role (e.g., heap_size for ES, retention for Prometheus)
- Each section MUST have a blank line before and after the comment header.
- Resource limits (memory_limit, nofile_limit) MUST be in their own `# --- Resource Limits ---` section.
- Never hardcode values — always use `| default()`.
- Assume `config.<role>` section always exists in inventory.

## README Standards

Every role README MUST contain (in this order):

1. **Title + Description** — One paragraph explaining what the role does.
2. **Latest Version** — Table with links to check latest version for ALL components involved (GitHub releases page, official download page).
3. **Prerequisites** — Table with columns: Requirement, Details, How to Check.
4. **How to Run** — Copy-paste ansible-playbook commands.
5. **Variable Reference** — Two sub-sections:
   - Required variables (from inventory) — table with Source, Variable, Example, Description.
   - Optional variables (with defaults) — table with Variable, Default, Description, Impact of Change. The "Impact" column must explain what happens when you increase or decrease the value.
6. **What Gets Installed** — Filesystem tree showing what ends up on disk after deployment.
7. **Task Execution Flow** — ASCII tree showing the order of task files and what each does.
8. **Post-Deployment Verification** — Numbered steps with exact commands and expected output.
9. **Upgrade Process** — Step-by-step instructions.
10. **Troubleshooting** — Common failure scenarios with diagnostic commands.
11. **File Structure** — Role directory tree.
12. **Security Notes** — What to be aware of (unprivileged user, cert validation, etc.).

Never mention internal fixes or known issues that are already resolved in the code.

## Service Restart Rules

- `service.yml` MUST register the template task result.
- MUST use `state: started` (not `restarted`) for the enable+start task.
- MUST have a separate conditional restart task: `when: service_file_result.changed or (<role>_upgrade_needed | default(false) | bool)`
- This ensures: no restart on idempotent re-run, restart only on actual changes.

## Port and Host in wait_for/uri

- Always use `host: 127.0.0.1` (not `0.0.0.0` or `localhost`).
- Always cast port to int: `port: "{{ var | int }}"`.
- Always add `retries` and `delay` on `uri` health checks.


## Task Naming Standards

- Every task MUST have a `name:` field — no unnamed tasks.
- Task names MUST be descriptive and start with a verb: "Create", "Download", "Template", "Verify", "Remove", "Stop", "Set".
- Never include variable values in task names that could leak secrets (e.g., passwords, tokens).
- For loops, use `loop_control: label:` to avoid dumping large objects in output.

## Idempotency Rules

- Roles MUST be idempotent — running the same playbook twice with no config change should produce zero changes (or minimal: service already started).
- Use `creates:` parameter on `unarchive` tasks to skip if already extracted.
- Use `when:` guards on download/extract tasks (only run if upgrade needed or not installed).
- Use `register:` + `changed_when:` on shell tasks to properly report changes.
- Never use `shell:` where an Ansible module exists (e.g., use `unarchive` not `tar -xf`, use `file:` not `rm -rf`).

## Shared Role / Multi-App Safety Rules

- Roles are shared across multiple APP_INSTANCE modules (Barista, Fixed Network, RAN, etc.). Never include one-time fix or migration logic (e.g., deleting leftover resources from a failed run, renaming existing objects) inside a role's tasks.
- Deletions and cleanups ARE acceptable when they are part of a deliberate operational action (e.g., uninstall, fresh reinstall, version-based cleanup of old binaries after upgrade). These are repeatable and useful for all consumers of the role.
- One-time fixes needed after a failed job (e.g., removing stale PVs with wrong naming, patching broken state) MUST be performed manually by the operator — not baked into the role. Such fixes are environment-specific and won't apply to other apps using the same role.
- When changing resource naming schemes (e.g., PV names from index-based to hostname-based), document the migration steps in the role's README under an "Upgrade/Migration" section so operators know what manual steps are required.

## Error Handling Standards

- `failed_when: false` ONLY on tasks that are expected to fail on first run (e.g., stopping a service that doesn't exist yet).
- All download tasks MUST have `timeout:` set.
- All `uri:` health checks MUST have `retries:` and `delay:` with `until:` condition.
- Use `stat:` + `register:` to check existence before acting — don't rely on `creates:` alone.

## Security Standards

- System service users: `system: true`, `shell: /sbin/nologin`, `create_home: false`.
- Systemd unit files: `mode: "0644"`, owned by `root:root`.
- Config files with secrets: `mode: "0640"`, `no_log: true` on tasks that handle passwords.
- Binary directories: owned by service user, mode `0755`.
- Never store secrets in templates/files — always reference vault variables.
- Use `validate_certs: false` only with a comment explaining why (corporate proxy MITM).

## kubectl Execution Standard (Kubernetes Roles)

All Kubernetes roles that run `kubectl` or `helm` commands MUST use the `sudo -u` pattern — NEVER use `become_user` / `become_method: su` (fails in CI/GitLab Runner environments).

**Required pattern:**
```yaml
- name: Apply manifest
  shell: sudo -u {{ <role>_ansible_user }} --set-home kubectl apply -f /tmp/manifest.yaml
  args:
    executable: /bin/bash
```

**Forbidden patterns (will fail in CI):**
```yaml
# BAD — do NOT use become_user for kubectl
- name: Apply manifest
  shell: kubectl apply -f /tmp/manifest.yaml
  become: true
  become_user: "{{ <role>_ansible_user }}"
  become_method: su
```

**Rules:**
- Every K8s role MUST define a `<role_prefix>_ansible_user` variable in defaults (sourced from `config_k8s.ansible_user`)
- All `kubectl` / `helm` commands must be prefixed with `sudo -u {{ <role_prefix>_ansible_user }} --set-home`
- The `--set-home` flag ensures `HOME` and `KUBECONFIG` resolve correctly for the target user
- The playbook-level `become: true` (running as root) provides the privilege for `sudo -u` to work
- Never run kubectl as root directly — always switch to the ansible user for security and audit trail

## Kubernetes Ingress Standard

When a K8s role exposes a service via Ingress with a context path (e.g., `/alertmanager`, `/grafana`, `/headlamp`):

**Pattern:** The application handles the path prefix internally — the Ingress just routes traffic without rewriting.

**Required:**
1. The application MUST be configured to serve from the sub-path (via CLI arg, env var, or config):
   - AlertManager: `--web.route-prefix=/alertmanager`
   - Grafana: `GF_SERVER_SERVE_FROM_SUB_PATH=true` + `GF_SERVER_ROOT_URL`
   - Headlamp: `-base-url=/headlamp` + `HEADLAMP_BASE_PATH` env
2. The Ingress MUST use `pathType: Prefix` matching — no path-rewrite annotations
3. Liveness/readiness probes MUST include the path prefix (e.g., `/alertmanager/-/healthy`, not `/-/healthy`)
4. Prometheus scrape annotations `prometheus.io/path` MUST include the prefix if metrics are under it

**Forbidden:**
- `haproxy.org/path-rewrite` — causes redirect loops when the app also handles the prefix
- `nginx.ingress.kubernetes.io/rewrite-target` — same issue
- Any annotation that strips/rewrites the path prefix before forwarding to the backend

**Example (correct):**
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: myapp-ingress
  namespace: myapp
spec:
  ingressClassName: haproxy
  rules:
    - host: example.com
      http:
        paths:
          - path: /myapp
            pathType: Prefix
            backend:
              service:
                name: myapp
                port:
                  number: 8080
```

No annotations needed — the app handles `/myapp/*` internally.

## Kubernetes Resource Ordering Standard

When a Deployment/StatefulSet mounts ConfigMaps or Secrets as volumes, those resources **MUST be applied BEFORE** the Deployment/StatefulSet. Otherwise, the pod will fail with `MountVolume.SetUp failed: configmap "..." not found`.

**Correct order in install/deploy tasks:**
1. Create Namespace
2. Apply Secrets
3. Apply ConfigMaps (prometheus config, LDAP config, alert rules, etc.)
4. Apply Deployment/StatefulSet (mounts the above)
5. Wait for rollout

**Wrong order** (causes CrashLoop):
1. Create Namespace
2. Apply Deployment ← pod starts, tries to mount ConfigMap that doesn't exist yet
3. Apply ConfigMap ← too late, pod already failed

## Service Account User Access

Roles that create service accounts with `/sbin/nologin` shell MUST include a section in the README under "Troubleshooting" (or as a standalone section titled "Service Account Access") documenting how to switch to the service account from root:

```bash
# Switch to the service account (from root)
su -s /bin/bash <service_user>

# Run a single command as the service account
su -s /bin/bash -c "<command>" <service_user>
```

This MUST be included in every role README where `create_user.yml` creates a user with `shell: /sbin/nologin`.

## Playbook Standards

- All playbooks MUST use `become: true`.
- All playbooks MUST set `ansible_python_interpreter: auto_silent`.
- All playbooks that run yum/dnf tasks (directly or via roles) MUST include `../_global_vars/common_config.yml` in `vars_files` AND add `roles/_misc/disable_external_repos` as the first role BEFORE the actual role. This disables unreachable external repos (e.g., Docker CE) that cause yum timeouts.
- Use `gather_facts: true` if the role needs `ansible_host`, `ansible_os_family`, or uses `password_hash` filter.
- Use `gather_facts: false` if the role only uses inventory variables and shell commands.
- Default target host MUST match the inventory host group name.

Example playbook with yum-dependent role:
```yaml
- hosts: "{{ target_host | default('my_service') }}"
  become: true
  gather_facts: true
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
    - ../_global_vars/common_config.yml
  roles:
    - { role: roles/_misc/disable_external_repos }
    - { role: roles/my_service }
```

## Template Standards

- All `.j2` templates MUST have a header comment: `# Managed by Ansible - do not edit manually`.
- Systemd unit templates MUST be under `templates/` (or `templates/service/` if multiple).
- Config templates sourced from inventory use `{{ inventory_dir }}/configs/<service>/` path.
- Role-local templates use `src: <filename>.j2` (relative to `templates/` directory).

## Handler Standards

- Handler names MUST be short and descriptive: `restart <service>`, `reload <service>`.
- Handlers MUST include `daemon_reload: true` for systemd restarts.
- Handlers MUST include `enabled: true` to ensure service stays enabled.
- Only use handlers for restart/reload — never for verification or cleanup.

## Inventory Variable Structure

Variables in inventory follow this hierarchy:
- `version.<role>` — in `versions.yml`
- `paths.<role>.base_dir` — in `paths.yml`
- `ports.<role>.service` — in `networks.yml`
- `config_<group>.<role>.*` — in `config_<group>.yml` (e.g., `config_k8s.longhorn.*` in `config_kubernetes.yml`, `config_platform.nvd_sync.*` in `config_platform.yml`)
- `<role>_<secret>_vault` — in `all_secrets.yml` (vault-encrypted)

**Config file naming convention:**
- Each config file uses a unique top-level key matching its filename pattern: `config_<group>`
- `config_kubernetes.yml` → top-level key: `config_k8s` → accessed as `config_k8s.<sub_role>.*` (e.g., `config_k8s.harbor.*`, `config_k8s.docker_less.*`)
- `config_platform.yml` → top-level key: `config_platform` → accessed as `config_platform.<role>.*` (e.g., `config_platform.nvd_sync.*`)
- `config_monitoring.yml` → top-level key: `config_monitoring` (example)
- This prevents Ansible from overwriting one config dict with another (Ansible does NOT deep-merge vars from multiple files with the same top-level key)
- Do NOT nest the group name again inside the key (e.g., use `config_k8s.harbor.*` NOT `config_k8s.kubernetes.harbor.*`)

All roles MUST follow this convention for consistency across environments.


## Log Rotation Standards

Services that write log files to disk (not stdout/journald) MUST include a logrotate configuration:

- Deploy a logrotate config file at `/etc/logrotate.d/<service_name>`.
- Default rotation: daily, 7 days retention, compress, missingok, notifempty.
- Rotation parameters (days, size, count) should be configurable via `config.<role>.log_*` variables.
- Use `copytruncate` for services that don't support log reopening via signal (most Go/Java binaries).
- Use `postrotate` with `kill -HUP` or service reload for services that support it (e.g., Elasticsearch, Nginx).
- Logrotate config is part of the `config.yml` task file.
- Services that log only to journald (via systemd stdout) do NOT need logrotate — journald handles its own rotation.


## ChangeTracker Standards

After making changes to any role, the agent MUST update `ChangeTracker.md` at the project root with an entry under the relevant role section.

Format:
```
## <role_name>

<date>: <brief description of what changed>
```

Rules:
- Date format: `DD-MM-YYYY`
- One line per logical change (not per file).
- Description should be brief but include what was added/changed/removed and why.
- If a new role is added, create a new section in ChangeTracker.md with the application table and the change entry.
- This update MUST happen automatically at the end of every role modification session — the agent should not need to be reminded.


## Auto-Update Rules

After making any changes to a role, the agent MUST automatically (without being asked):

1. **Update the role's README.md** — ensure it reflects the current task flow, file structure, variables, and defaults. If a task file was added/removed/renamed, the README must be updated to match.
2. **Update ChangeTracker.md** — add a dated entry under the relevant role section describing what changed.
3. **Update roles/ROLE_STRUCTURE.md** — if a role was added, deleted, renamed, or moved to a different category/path, update the visual tree in `roles/ROLE_STRUCTURE.md` to reflect the new structure. Update the "At a Glance" counts table as well.

These updates are mandatory and must not be skipped or deferred.

---
inclusion: fileMatch
fileMatchPattern: "inventories/**/*"
description: "Conventions for working with inventory files (hosts, group_vars, configs)"
---

# Inventory Conventions

## Directory Structure

Each inventory follows this layout:

```
inventories/<module>/<environment>/
├── hosts                     # INI-format host inventory
├── group_vars/all/           # Variable files loaded for all hosts
│   ├── versions.yml          # Software versions (top-level key: version)
│   ├── paths.yml             # Base directory paths (top-level key: paths)
│   ├── networks.yml          # Ports, host addresses, DNS (top-level key: ports, hosts)
│   ├── app_configs.yml       # Legacy app-specific config (top-level key: config)
│   ├── config_kubernetes.yml # K8s config (top-level key: config_k8s)
│   ├── config_platform.yml   # Platform tools (top-level key: config_platform)
│   ├── config_monitoring.yml # Monitoring config (top-level key: config_monitoring)
│   ├── config_kafka.yml      # Kafka config (top-level key: config_kafka)
│   ├── config_elk.yml        # ELK config (top-level key: config_elk)
│   ├── config_database.yml   # Database config (top-level key: config_database)
│   ├── all_secrets.yml       # Vault-encrypted secrets
│   └── all_host_secrets.yml  # Vault-encrypted per-host secrets
└── configs/                  # Per-service Jinja2 config templates
    └── <service>/            # e.g., kafka_kraft/, haproxy/, prometheus/
```

## Hosts File Format (INI)

```ini
[group_name]
hostname    ansible_host=<IP>    optional_host_var=value

[parent:children]
child_group_1
child_group_2
```

- Host naming: `blt*` for test, `blp*` for pre-prod/prod/DR
- Always include `ansible_host=<IP>` for each host
- Use `:children` syntax for group hierarchies
- Application-specific groups (kafka_workers, mongodb_workers) use one node per site for zone-awareness

## Variable File Rules

### Top-Level Keys (CRITICAL — no merging)

Ansible does NOT deep-merge variables from multiple files with the same top-level key. Each config file MUST use a unique top-level key:

| File | Top-Level Key | Access Pattern |
|------|--------------|----------------|
| `versions.yml` | `version` | `version.<service>` |
| `paths.yml` | `paths` | `paths.<service>.base_dir` |
| `networks.yml` | `ports`, `hosts` | `ports.<service>.<port_name>` |
| `app_configs.yml` | `config` | `config.<service>.*` |
| `config_kubernetes.yml` | `config_k8s` | `config_k8s.<sub_role>.*` |
| `config_platform.yml` | `config_platform` | `config_platform.<role>.*` |
| `config_monitoring.yml` | `config_monitoring` | `config_monitoring.<role>.*` |
| `config_kafka.yml` | `config_kafka` | `config_kafka.<host_group>.*` |
| `config_elk.yml` | `config_elk` | `config_elk.<role>.*` |
| `config_database.yml` | `config_database` | `config_database.<role>.*` |

### Adding a New Service Config

1. Determine which config group it belongs to (k8s, platform, monitoring, database, etc.)
2. Add it under the appropriate file's top-level key
3. Follow the existing nesting pattern: `config_<group>.<service>.<setting>`
4. Use snake_case for all keys
5. Add defaults in the role's `defaults/main.yml` with `| default(<value>)`

### Secrets Convention

- Variable naming: `<role>_<purpose>_vault` (e.g., `kafka_ssl_keystore_password_vault`)
- All secrets go in `all_secrets.yml` (vault-encrypted)
- Per-host secrets (different per machine) go in `all_host_secrets.yml`
- Never store secrets in plain-text config files

## Config Templates (configs/ directory)

- Templates are `.j2` files deployed by roles via `{{ inventory_dir }}/configs/<service>/`
- Each service gets its own subdirectory
- Template variables reference inventory group_vars (versions, ports, hosts, config)
- Only services that need per-environment customisation beyond what role defaults provide should have templates here

## Adding a New Environment

1. Create `inventories/<module>/<env>/` directory
2. Add `hosts` file with all required host groups
3. Create `group_vars/all/` with at minimum: `versions.yml`, `paths.yml`, `networks.yml`
4. Copy and adapt `all_secrets.yml` (re-encrypt with vault)
5. Add service configs as needed in `config_*.yml` files
6. Add any per-service config templates under `configs/`
7. Add the pipeline job in `pipeline/<module>-ci.yml`

---
inclusion: manual
description: "Automate the full deploy pipeline: commit, push, create GitLab CI pipeline, play the manual job, and follow logs until completion"
---

# Deploy Pipeline Skill

Automates the end-to-end workflow of deploying changes via the MAT Ansible GitLab CI pipeline.

## Workflow Overview

```
git add → git commit → git push → create pipeline (with variables) → wait for job → play manual job → poll logs → report result
```

## When to Use

Activate this skill when the user says things like:
- "Deploy this to Barista prod"
- "Run the pipeline"
- "Push and deploy"
- "Commit and run on Fixed Network test"
- "Trigger the CI for kafka_kraft on DR"

## Prerequisites

Before starting, confirm you have:
1. The GitLab project path: `robt/app20919/mat_ansible`
2. The user is on a working branch (typically `Martini_DevOps_Ansible` or a feature branch)
3. There are staged or unstaged changes to commit (or the user explicitly says to push existing commits)

---

## Step 1: Stage and Commit Changes

Ask the user for a commit message if not provided. Stage only the relevant changed files (prefer specific paths over `git add .`).

```bash
git add <specific_files>
git commit -m "<commit_message>"
```

Rules:
- Never use `git add .` unless the user explicitly asks — stage specific files
- If there are no changes to commit but the user wants to re-run, skip to Step 2
- Show the user what files will be committed before proceeding

## Step 2: Push to Remote

Push to the current branch with tracking:

```bash
git push -u origin <current_branch>
```

Rules:
- Detect the current branch via `git branch --show-current`
- The default working branch is `Martini_DevOps_Ansible` — never push to `main` or `master`
- If push fails (e.g., diverged), inform the user and suggest `git pull --rebase`

## Step 3: Determine Pipeline Variables

The user MUST provide or confirm these variables before pipeline creation:

| Variable | Required | Description | Valid Values |
|----------|----------|-------------|--------------|
| `APP_INSTANCE` | Yes | Target module | `Barista`, `Fixed Network`, `MAT Common`, `RAN`, `RAN-FN`, `Bhrigu` |
| `ENV` | Yes | Target environment | `Test`, `Pre-Prod`, `Prod`, `Dr`, `Geo-Prod` |
| `ZONE` | Yes | Network zone | `zone-1` (HAProxy/LB), `zone-2` (backend services) |
| `APP_GROUP` | Yes | Playbook subfolder | `kubernetes`, `monitoring`, `kafka`, `elk`, `database`, `data_storage`, `load_balancing`, `frontend`, `platform`, `_misc` |
| `APP` | Yes | Playbook name (no .yaml) | See `.gitlab-ci.yml` for full list |
| `TARGET_HOST` | No | Host group override | Leave empty for playbook default |

### Variable Inference Rules

If the user gives a natural language description, infer the variables:

- "Deploy kafka_kraft to Fixed Network test" → `APP_INSTANCE=Fixed Network`, `ENV=Test`, `ZONE=zone-2`, `APP_GROUP=kafka`, `APP=kafka_kraft`
- "Run haproxy on FN prod" → `APP_INSTANCE=Fixed Network`, `ENV=Prod`, `ZONE=zone-1`, `APP_GROUP=load_balancing`, `APP=haproxy`
- "Deploy longhorn to Barista prod" → `APP_INSTANCE=Barista`, `ENV=Prod`, `ZONE=zone-2`, `APP_GROUP=kubernetes`, `APP=longhorn`
- "Run node exporter on DR zone 2" → `APP_INSTANCE=Fixed Network`, `ENV=Dr`, `ZONE=zone-2`, `APP_GROUP=monitoring`, `APP=node_exporter`

Zone heuristics:
- HAProxy/load balancer playbooks → `zone-1`
- Everything else → `zone-2`

APP_GROUP mapping (common patterns):
- `kafka_kraft`, `kafka_exporter`, `kafdrop`, `schema_registry` → `kafka`
- `clickhouse_server`, `clickhouse_keeper`, `mysql_*`, `postgres`, `pgadmin` → `database`
- `node_exporter`, `process_exporter`, `prometheus`, `pushgateway`, `blackbox_exporter` → `monitoring`
- `haproxy`, `haproxy_click` → `load_balancing`
- `elasticsearch`, `kibana`, `logstash`, `loki` → `elk`
- `kubernetes_*`, `longhorn`, `helm` → `kubernetes`
- `grafana_monitor`, `grafana_user`, `kubernetes_grafana`, `kubernetes_headlamp` → `frontend`
- `gitlab_runner`, `gradle`, `containerd_nerdctl`, `java`, `nvd_sync`, `onepatch`, `crypto_policy` → `platform`
- `minio`, `nfs_mount`, `nfs_server`, `librefs`, `kubernetes_librefs`, `kubernetes_minio` → `data_storage`
- `falcon_memory_limit`, `librefs_wipe_data` → `_misc`

Always confirm the inferred variables with the user before creating the pipeline.

## Step 4: Create the Pipeline

Use the GitLab MCP tool to create the pipeline:

```
Tool: gitlab_create_pipeline
Project: robt/app20919/mat_ansible
Ref: <current_branch>
Variables:
  - { key: "APP_INSTANCE", value: "<value>" }
  - { key: "ENV", value: "<value>" }
  - { key: "ZONE", value: "<value>" }
  - { key: "APP_GROUP", value: "<value>" }
  - { key: "APP", value: "<value>" }
  - { key: "TARGET_HOST", value: "<value>" }  # only if provided
```

After creation:
- Record the `pipeline_id` from the response
- Report the pipeline URL to the user

## Step 5: Get the Job ID

Use `gitlab_get_pipeline` with `include_jobs: true` to retrieve the jobs list.

```
Tool: gitlab_get_pipeline
Project: robt/app20919/mat_ansible
Pipeline ID: <pipeline_id>
Include Jobs: true
```

Rules:
- There should be exactly ONE manual job in the pipeline (the `install_*` job matching the ENV/ZONE)
- If the job status is `manual`, proceed to play it
- If there's a `select_options` job, ignore it — it's the fallback placeholder
- Record the `job_id` of the manual install job

## Step 6: Play the Manual Job

Trigger the manual job:

```
Tool: gitlab_play_job
Project: robt/app20919/mat_ansible
Job ID: <job_id>
```

After playing:
- Confirm to the user that the job has been triggered
- Report the job web URL

## Step 7: Poll Job Logs (Adaptive Interval)

Follow the job logs until completion using an adaptive polling strategy:

### Polling Schedule

| Poll # | Wait Before | Rationale |
|--------|-------------|-----------|
| 1 | 10 seconds | Quick check — catches immediate failures (bad playbook path, vault errors) |
| 2 | 15 seconds | Early execution — SSH connection, fact gathering |
| 3 | 20 seconds | Role setup phase |
| 4+ | 30 seconds | Steady state — role tasks executing |

### Polling Loop

```
1. Wait the appropriate interval
2. Call gitlab_get_job_log with tail_lines: 60
3. Check the job status:
   - "running" → show new log lines to user, continue polling
   - "success" → show final logs, report SUCCESS
   - "failed" → show final logs, report FAILURE with error context
   - "canceled" → report CANCELED
4. Repeat until terminal state
```

### Log Display Rules

- On each poll, show only NEW lines (compare with previous output to avoid repetition)
- If the log contains `TASK [` lines, highlight the current task being executed
- If the log contains `fatal:` or `FAILED!`, immediately flag it even if job status is still "running"
- If the log contains `PLAY RECAP`, the playbook has finished — next poll should show final status
- Truncate very long outputs (e.g., package install listings) — summarise with "Installing packages..."
- Maximum polls: 60 (30 minutes at steady-state interval). If exceeded, inform the user and provide the job URL for manual monitoring

### Getting Job Status

To check if the job is still running, use `gitlab_get_pipeline` with `include_jobs: true` and check the job's status field. Alternatively, if the log output contains `Job succeeded` or the final `PLAY RECAP` with `failed=0`, the job is complete.

## Step 8: Report Final Result

### On Success
```
✅ Pipeline #<id> completed successfully
   Job: <job_name>
   Duration: <time>
   Branch: <branch>
   Target: <APP_INSTANCE> / <ENV> / <APP>
```

### On Failure
```
❌ Pipeline #<id> FAILED
   Job: <job_name>
   Failed task: <extracted from logs>
   Error: <extracted from logs>
   Full logs: <job_url>
```

Extract the failing task name and error message from the logs (look for `fatal:` and the preceding `TASK [...]` line).

## Step 9: Optional — Check Kubernetes Deployment (Headlamp)

If the deployed playbook is a Kubernetes service AND the Headlamp MCP power is available, optionally verify the deployment:

- For `kubernetes_*` playbooks, check the relevant namespace for pod health
- Use `list_pods` with the appropriate namespace and label selector
- Report pod status (Running/Pending/CrashLoopBackOff)

Only do this if:
1. The job succeeded
2. The APP starts with `kubernetes_` or is `longhorn`, `helm`, `kubernetes-ingress-controller`
3. The headlamp-k8s MCP power is available

---

## Runner Tag Reference

| APP_INSTANCE | ENV | ZONE | Runner Tag |
|-------------|-----|------|------------|
| Fixed Network | Test | any | `MAT-Ansible-TEST` |
| Fixed Network | Dr | zone-1 | `MAT-Ansible-DRZ1` |
| Fixed Network | Dr | zone-2 | `MAT-Ansible-DRZ2` |
| Fixed Network | Prod | zone-1 | `MAT-Ansible-DRZ1` |
| Fixed Network | Prod | zone-2 | `MAT-Ansible-DRZ2` |
| MAT Common | Test | any | `MAT-Ansible-TEST` |
| Barista | Test | zone-1 | `barista-test-ansible-z1` |
| Barista | Test | zone-2 | `barista-test-ansible-z2` |
| Barista | Pre-Prod | any | `MAT-Ansible-DRZ2` |
| Barista | Prod | zone-2 | `barista-prod-ansible-z2` |
| Bhrigu | Test | any | `barista-test-ansible-z2` |
| Bhrigu | Pre-Prod | any | `MAT-Ansible-DRZ2` |
| RAN-FN | Pre-Prod | any | `MAT-Ansible-DRZ2` |

Note: The runner tag determines which GitLab runner picks up the job. This is handled by the CI pipeline definitions — you don't need to pass it as a variable. It's listed here for reference if jobs are stuck in "pending" (runner not available).

---

## Error Recovery

### Push Fails
- Check if the branch exists on remote: `git ls-remote --heads origin <branch>`
- If diverged: suggest `git pull --rebase origin <branch>` then retry

### Pipeline Creation Fails
- Verify the branch name matches what's on GitLab
- Verify the project path is correct: `robt/app20919/mat_ansible`
- Check if the variables are valid (no typos in APP_INSTANCE etc.)

### Job Stays "Pending"
- The runner for that tag may be offline
- Report the runner tag to the user and suggest checking GitLab Runner status
- Provide the pipeline URL for manual inspection

### Job Fails Immediately
- Common causes: vault password not set (`$ansible_vault_pass` CI variable), playbook path wrong, inventory not found
- Extract the error from logs and report clearly

---

## Example Interaction

User: "Deploy the kafka_kraft changes to Fixed Network test"

Agent workflow:
1. `git add roles/kafka/kafka_kraft/...` (the changed files)
2. `git commit -m "kafka_kraft: <contextual message>"`
3. `git push -u origin Martini_DevOps_Ansible`
4. Confirm: APP_INSTANCE=Fixed Network, ENV=Test, ZONE=zone-2, APP_GROUP=kafka, APP=kafka_kraft
5. `gitlab_create_pipeline` → pipeline #12345
6. `gitlab_get_pipeline` (include_jobs) → job_id 67890 (status: manual)
7. `gitlab_play_job` → job triggered
8. Poll logs: 10s → 15s → 20s → 30s... until complete
9. Report: ✅ Success / ❌ Failure with details

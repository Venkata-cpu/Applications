# Implementation Plan: ClickStack Observability — Barista Prod

## Overview

Deploy a full-stack observability platform (ClickStack) on the Barista prod multi-DC Kubernetes cluster using 3 Ansible roles and 3 playbooks. Tasks follow deployment dependency order: ClickHouse → OTel Collector → HyperDX, with Prometheus integration woven into the monitoring role extension. MongoDB for HyperDX state is provisioned as a database/user within the existing Percona MongoDB cluster already running in Barista prod.

## Tasks

- [ ] 1. Inventory variable additions (shared foundation)
  - [ ] 1.1 Add ClickStack versions to `inventories/barista/prod/group_vars/all/versions.yml`
    - Add `version.kubernetes.clickstack.clickhouse`, `.otel_collector`, `.hyperdx`, `.hyperdx_browser`, `.otel_python.*` keys
    - _Requirements: 9.5, 6.4, 7.4_

  - [ ] 1.2 Add ClickStack ports to `inventories/barista/prod/group_vars/all/networks.yml`
    - Add `ports.kubernetes.clickstack.clickhouse_http: 49700`, `.hyperdx_ui: 49701`, `.otel_health: 49702`
    - _Requirements: 11.1, 11.2, 11.3, 11.4_

  - [ ] 1.3 Add ClickStack config block to `inventories/barista/prod/group_vars/all/config_kubernetes.yml`
    - Add full `config_k8s.clickstack.*` block covering clickhouse, otel_collector, hyperdx, hyperdx_mongodb (reuse existing), and prometheus sections as defined in design
    - _Requirements: 1.6, 2.8, 4.6, 5.5, 9.7_

  - [ ] 1.4 Add ClickStack secrets to `inventories/barista/prod/group_vars/all/all_secrets.yml`
    - Add vault-encrypted variables: `clickstack_clickhouse_admin_password_vault`, `clickstack_mongodb_hyperdx_password_vault`, `clickstack_hyperdx_api_key_vault`
    - _Requirements: 1.7, 5.3, 4.7, 9.8_

- [ ] 2. ClickHouse Observability role (deploy first — OTel and HyperDX dependency)
  - [ ] 2.1 Create `roles/kubernetes/observability/clickhouse/defaults/main.yml`
    - Define all `clickstack_ch_*` variables sourced from `config_k8s.clickstack.clickhouse.*` with defaults
    - Include version, image, namespace, replicas, storage, network, retention, resource limits, topology, secrets, timeouts
    - _Requirements: 1.6, 9.4_

  - [ ] 2.2 Create `roles/kubernetes/observability/clickhouse/tasks/main.yml`
    - Wire task execution order: validate → install → verify
    - _Requirements: 9.3_

  - [ ] 2.3 Create `roles/kubernetes/observability/clickhouse/tasks/validate.yml`
    - Validate required variables, NodePort within range 49400–49799, storage_size between 50Gi and 100Gi, kubectl connectivity
    - _Requirements: 8.4, 11.5, 9.4_

  - [ ] 2.4 Create `roles/kubernetes/observability/clickhouse/templates/clickhouse-secret.yaml.j2`
    - Template K8s Secret `clickhouse-observability-credentials` with admin password from vault
    - _Requirements: 1.7_

  - [ ] 2.5 Create `roles/kubernetes/observability/clickhouse/templates/clickhouse-configmap.yaml.j2`
    - Template ConfigMap with ClickHouse server configuration (ports, memory settings)
    - _Requirements: 1.1_

  - [ ] 2.6 Create `roles/kubernetes/observability/clickhouse/templates/clickhouse-init-sql.yaml.j2`
    - Template ConfigMap with TTL ALTER statements for log (7d), trace (7d), and metric (30d) tables
    - _Requirements: 1.5, 8.1, 8.2, 8.3, 8.5_

  - [ ] 2.7 Create `roles/kubernetes/observability/clickhouse/templates/clickhouse-statefulset.yaml.j2`
    - Template StatefulSet with configurable replicas, Longhorn PVCs, conditional topologySpreadConstraints (only when `clickstack_ch_topology_enabled`), health probes on `/ping`, env from Secret
    - When replicas=1: no topology constraints, suitable for single-node test clusters
    - When replicas>1: topology spread across DCs using configurable key (default `topology.kubernetes.io/region`)
    - _Requirements: 1.1, 1.2, 1.3, 10.1_

  - [ ] 2.8 Create `roles/kubernetes/observability/clickhouse/templates/clickhouse-service.yaml.j2` and `clickhouse-service-nodeport.yaml.j2`
    - Template ClusterIP Service (8123, 9000) and NodePort Service (configurable port for HTTP access)
    - _Requirements: 1.4, 11.1_

  - [ ] 2.9 Create `roles/kubernetes/observability/clickhouse/tasks/install.yml`
    - Create namespace, apply Secret, ConfigMap, init-sql ConfigMap, StatefulSet, Services via `kubectl apply` using `sudo -u` pattern
    - Follow K8s Resource Ordering: Secret → ConfigMaps → StatefulSet
    - _Requirements: 1.1, 9.4_

  - [ ] 2.10 Create `roles/kubernetes/observability/clickhouse/tasks/verify.yml`
    - Wait for all 3 ClickHouse pods Ready, health check via HTTP GET `/ping` on port 8123
    - _Requirements: 1.1, 10.3_

  - [ ] 2.11 Create `playbook/kubernetes/clickstack_clickhouse.yaml`
    - Standard playbook targeting `kubernetes_master_init`
    - _Requirements: 9.2_

  - [ ] 2.12 Create `roles/kubernetes/observability/clickhouse/README.md`
    - Document role purpose, prerequisites, variables, task flow, verification, upgrade process
    - _Requirements: 9.1_

- [ ] 3. Checkpoint - Ensure ClickHouse role is complete
  - Ensure all templates render correctly, ask the user if questions arise.

- [ ] 4. OTel Collector role (deploy second — requires ClickHouse endpoint)
  - [ ] 4.1 Create `roles/kubernetes/observability/otel_collector/defaults/main.yml`
    - Define all `clickstack_otel_*` variables sourced from `config_k8s.clickstack.otel_collector.*` with defaults
    - Include version, image, namespace, ports (gRPC 4317, HTTP 4318, FluentForward 24225, health 13133), CORS, resources, exporters, timeouts
    - _Requirements: 2.8, 9.4_

  - [ ] 4.2 Create `roles/kubernetes/observability/otel_collector/tasks/main.yml`
    - Wire task execution order: validate → install → verify
    - _Requirements: 9.3_

  - [ ] 4.3 Create `roles/kubernetes/observability/otel_collector/tasks/validate.yml`
    - Validate required variables, ClickHouse endpoint reachable, NodePort in range, kubectl connectivity
    - _Requirements: 2.8, 11.5_

  - [ ] 4.4 Create `roles/kubernetes/observability/otel_collector/templates/otel-configmap.yaml.j2`
    - Template OTel Collector config with receivers (otlp grpc/http with CORS, fluentforward), processors (batch, resourcedetection, memory_limiter), exporters (clickhouse, prometheusremotewrite), pipelines (logs, traces, metrics), health_check extension
    - _Requirements: 2.3, 2.4, 2.5, 2.6, 2.9_

  - [ ] 4.5 Create `roles/kubernetes/observability/otel_collector/templates/otel-daemonset.yaml.j2`
    - Template DaemonSet with container ports, resource limits, volumeMounts for config, liveness/readiness probes on health endpoint
    - _Requirements: 2.1, 2.2_

  - [ ] 4.6 Create `roles/kubernetes/observability/otel_collector/templates/otel-service.yaml.j2` and `otel-service-nodeport.yaml.j2`
    - Template ClusterIP Service (4317, 4318, 24225, 13133) and NodePort Service for health check
    - _Requirements: 2.7, 11.3_

  - [ ] 4.7 Create `roles/kubernetes/observability/otel_collector/tasks/install.yml`
    - Apply ConfigMap, DaemonSet, Services via `kubectl apply` using `sudo -u` pattern
    - ConfigMap applied before DaemonSet (K8s Resource Ordering)
    - _Requirements: 2.1, 9.4_

  - [ ] 4.8 Create `roles/kubernetes/observability/otel_collector/tasks/verify.yml`
    - Wait for all 15 OTel Collector pods Ready (DaemonSet on all worker nodes), health check on port 13133
    - _Requirements: 2.1, 10.5_

  - [ ] 4.9 Create `playbook/kubernetes/clickstack_otel_collector.yaml`
    - Standard playbook targeting `kubernetes_master_init`
    - _Requirements: 9.2_

  - [ ] 4.10 Create `roles/kubernetes/observability/otel_collector/README.md`
    - Document role purpose, pipeline config, CORS, variables, task flow, verification
    - _Requirements: 9.1_

- [ ] 5. Checkpoint - Ensure OTel Collector role is complete
  - Ensure all templates render correctly, ask the user if questions arise.

- [ ] 6. HyperDX UI role (deploy third — requires ClickHouse and existing MongoDB)
  - [ ] 6.1 Create `roles/kubernetes/observability/hyperdx/defaults/main.yml`
    - Define all `clickstack_hdx_*` variables sourced from `config_k8s.clickstack.hyperdx.*` with defaults
    - Include version, image, namespace, replicas, SMTP settings, resources, NodePort, secrets, MongoDB connection (existing cluster in `mongodb` namespace)
    - _Requirements: 4.6, 9.4_

  - [ ] 6.2 Create `roles/kubernetes/observability/hyperdx/tasks/main.yml`
    - Wire task execution order: validate → install → verify
    - _Requirements: 9.3_

  - [ ] 6.3 Create `roles/kubernetes/observability/hyperdx/tasks/validate.yml`
    - Validate required variables, ClickHouse endpoint accessible, existing MongoDB cluster accessible (in `mongodb` namespace), NodePort in range, kubectl connectivity
    - _Requirements: 4.6, 11.5_

  - [ ] 6.4 Create `roles/kubernetes/observability/hyperdx/templates/hyperdx-mongodb-init.js.j2`
    - Template MongoDB init script to create `hyperdx` database and user with `readWrite` role on existing cluster
    - _Requirements: 5.1, 5.2_

  - [ ] 6.5 Create `roles/kubernetes/observability/hyperdx/templates/hyperdx-secret.yaml.j2`
    - Template K8s Secret `hyperdx-credentials` with API key and MongoDB connection URI (including password for existing cluster)
    - _Requirements: 4.7, 5.3_

  - [ ] 6.6 Create `roles/kubernetes/observability/hyperdx/templates/hyperdx-deployment.yaml.j2`
    - Template Deployment with environment variables for ClickHouse, MongoDB (existing cluster URI), SMTP connection, resource limits, liveness/readiness probes
    - _Requirements: 4.1, 4.2, 4.3, 4.5, 5.4_

  - [ ] 6.7 Create `roles/kubernetes/observability/hyperdx/templates/hyperdx-service.yaml.j2`
    - Template NodePort Service exposing web UI on configurable port
    - _Requirements: 4.4, 11.2_

  - [ ] 6.8 Create `roles/kubernetes/observability/hyperdx/tasks/install.yml`
    - Provision MongoDB database/user on existing cluster (via `mongosh` exec into running pod in `mongodb` namespace), apply Secret, Deployment, Service via `kubectl apply` using `sudo -u` pattern
    - Secret applied before Deployment (K8s Resource Ordering)
    - _Requirements: 4.1, 5.1, 5.2, 9.4_

  - [ ] 6.9 Create `roles/kubernetes/observability/hyperdx/tasks/verify.yml`
    - Wait for HyperDX pod Ready, health check on web UI port
    - _Requirements: 4.1_

  - [ ] 6.10 Create `playbook/kubernetes/clickstack_hyperdx.yaml`
    - Standard playbook targeting `kubernetes_master_init`
    - _Requirements: 9.2_

  - [ ] 6.11 Create `roles/kubernetes/observability/hyperdx/README.md`
    - Document role purpose, environment variables, MongoDB provisioning (reuses existing cluster in `mongodb` namespace), SMTP alerting, variables, task flow, verification
    - _Requirements: 9.1_

- [ ] 7. Checkpoint - Ensure HyperDX role is complete
  - Ensure all templates render correctly, ask the user if questions arise.

- [ ] 8. Prometheus integration (extend existing monitoring role)
  - [ ] 8.1 Add ClickStack scrape targets to the existing Prometheus ConfigMap template
    - Add `clickhouse-observability`, `otel-collector`, and `hyperdx` job definitions to the monitoring role's Prometheus config template
    - Ensure existing scrape targets are preserved (append, not replace)
    - _Requirements: 3.1, 3.5_

  - [ ] 8.2 Add ClickStack alert rules ConfigMap
    - Create alert rules file with `OtelCollectorPodRestart` (P2), `ClickHouseReplicaLag` (P1), `ClickHouseDiskUsageHigh` (P2), `HyperDXUnavailable` (P1), `OtelExportFailures` (P2) rules
    - Assign severity labels, route to `martini.asg@bt.com` via existing AlertManager
    - _Requirements: 3.3, 3.4_

  - [ ] 8.3 Enable remote write receiver on Prometheus
    - Add `--web.enable-remote-write-receiver` arg to existing Prometheus Deployment template
    - _Requirements: 3.2_

- [ ] 9. Checkpoint - Ensure Prometheus integration is complete
  - Ensure existing monitoring targets and alert rules are preserved, ask the user if questions arise.

- [ ] 10. Instrumentation documentation and templates
  - [ ] 10.1 Create Python instrumentation environment template in OTel Collector role
    - Add `templates/otel-python-env.yaml.j2` with OTEL_SERVICE_NAME, OTEL_EXPORTER_OTLP_ENDPOINT, OTEL_RESOURCE_ATTRIBUTES, etc.
    - Define `clickstack_otel_python_packages` list in defaults
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

  - [ ] 10.2 Document Angular frontend instrumentation in HyperDX role README
    - Add `@hyperdx/browser` SDK integration pattern, OTLP HTTP endpoint configuration, CORS-allowed origins, W3C Traceparent propagation
    - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [ ] 11. Final checkpoint - Ensure all roles integrate correctly
  - Ensure all templates render correctly, cross-role references (ClickHouse endpoint in OTel, MongoDB connection in HyperDX) are consistent, ask the user if questions arise.

## Notes

- Tasks are ordered by deployment dependency: ClickHouse → OTel Collector → HyperDX (MongoDB is reused from existing Barista prod cluster)
- Each role follows mat_ansible conventions: validate → install → verify task flow
- All kubectl commands use `sudo -u {{ <role>_ansible_user }} --set-home` pattern (never `become_user`)
- K8s Resource Ordering enforced: Secrets/ConfigMaps applied before Deployments/StatefulSets
- No Helm charts used — all manifests applied via `kubectl apply` (MongoDB provisioning uses `mongosh` exec into existing pod)
- Checkpoints ensure incremental validation between deployment phases
- Prometheus integration preserves all existing scrape targets and alert rules (additive only)
- Instrumentation is documentation-only — no application code changes required
- HyperDX reuses the existing Percona MongoDB cluster (`mongodb-rs` in `mongodb` namespace) — no new MongoDB infrastructure deployed

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1", "1.2", "1.3", "1.4"] },
    { "id": 1, "tasks": ["2.1", "2.2", "2.3", "2.11", "2.12"] },
    { "id": 2, "tasks": ["2.4", "2.5", "2.6", "2.7", "2.8"] },
    { "id": 3, "tasks": ["2.9", "2.10", "4.1", "4.2", "4.3", "4.9", "4.10"] },
    { "id": 4, "tasks": ["4.4", "4.5", "4.6", "4.7", "4.8"] },
    { "id": 5, "tasks": ["6.1", "6.2", "6.3", "6.10", "6.11"] },
    { "id": 6, "tasks": ["6.4", "6.5", "6.6", "6.7", "6.8", "6.9"] },
    { "id": 7, "tasks": ["8.1", "8.2", "8.3"] },
    { "id": 8, "tasks": ["10.1", "10.2"] }
  ]
}
```

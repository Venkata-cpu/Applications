# Design Document: ClickStack Observability — Barista Prod

## Overview

This design describes the architecture and implementation of a full-stack observability platform (ClickStack) deployed on the Barista prod multi-DC Kubernetes cluster. The platform provides unified log, trace, and metric collection via OpenTelemetry, persisted in ClickHouse, and visualised through HyperDX — all managed by Ansible roles following mat_ansible conventions.

## Architecture

### High-Level Architecture Diagram

```mermaid
graph TB
    subgraph "Barista Prod Cluster (3 DCs)"
        subgraph "Namespace: clickstack"
            CH[ClickHouse StatefulSet<br/>3 replicas]
            OTEL[OTel Collector DaemonSet<br/>15 pods]
            HDX[HyperDX Deployment<br/>1 replica]
            MONGO[HyperDX MongoDB<br/>3 replicas - Percona]
        end

        subgraph "Namespace: monitoring"
            PROM[Prometheus<br/>existing]
            AM[AlertManager<br/>existing]
        end

        subgraph "Namespace: kube-system"
            FB[Fluent Bit DaemonSet<br/>existing]
        end

        subgraph "Application Namespaces"
            PY[Python Services<br/>OTel instrumented]
            ANG[Angular Frontend<br/>@hyperdx/browser SDK]
        end
    end

    ANG -->|OTLP HTTP :4318| OTEL
    PY -->|OTLP gRPC :4317| OTEL
    FB -->|FluentForward :24225| OTEL
    OTEL -->|clickhouse exporter| CH
    OTEL -->|remote_write| PROM
    HDX -->|SQL queries| CH
    HDX -->|state persistence| MONGO
    PROM -->|scrape /metrics| CH
    PROM -->|scrape /metrics| OTEL
    PROM -->|scrape /metrics| HDX
    PROM -->|alert rules| AM
```

### Component Interaction Diagram

```mermaid
graph LR
    subgraph "Signal Sources"
        A[Python Backend<br/>opentelemetry-instrument]
        B[Angular Frontend<br/>@hyperdx/browser]
        C[Fluent Bit<br/>container logs]
        D[K8s Pods<br/>stdout/stderr]
    end

    subgraph "Collection Layer"
        E[OTel Collector<br/>per-node DaemonSet]
    end

    subgraph "Storage Layer"
        F[ClickHouse<br/>logs + traces + metrics]
        G[Prometheus<br/>app metrics via remote_write]
    end

    subgraph "Presentation Layer"
        H[HyperDX UI<br/>unified search + alerts]
        I[Grafana<br/>existing dashboards]
    end

    subgraph "State Store"
        J[MongoDB<br/>HyperDX config]
    end

    A -->|traces, metrics, logs| E
    B -->|traces, sessions, errors| E
    C -->|logs| D
    D -->|FluentForward| E
    E -->|logs, traces| F
    E -->|metrics| F
    E -->|metrics remote_write| G
    H --> F
    H --> J
    I --> G
```

### Data Flow

#### Logs
1. Application containers write to stdout/stderr
2. Fluent Bit (existing DaemonSet) collects container logs
3. Fluent Bit forwards to OTel Collector via FluentForward protocol (port 24225)
4. OTel Collector processes (adds resource attributes, batches)
5. OTel Collector exports to ClickHouse `otel_logs` database
6. ClickHouse enforces 7-day TTL on log tables
7. HyperDX queries ClickHouse for unified log search

#### Traces
1. Python services instrumented via `opentelemetry-instrument` (zero-code)
2. Angular frontend instrumented via `@hyperdx/browser` SDK
3. Both emit OTLP spans to local OTel Collector (gRPC :4317 / HTTP :4318)
4. W3C Traceparent headers propagate context between frontend → backend
5. OTel Collector batches and exports to ClickHouse `otel_traces` database
6. ClickHouse enforces 7-day TTL on trace tables
7. HyperDX provides trace waterfall visualisation

#### Metrics
1. Application services expose Prometheus-compatible `/metrics` endpoints
2. OTel Collector scrapes or receives OTLP metrics
3. OTel Collector dual-exports:
   - To ClickHouse `otel_metrics` database (30-day retention)
   - To Prometheus via remote_write (existing alerting/Grafana)
4. Prometheus scrapes ClickHouse, OTel, and HyperDX health metrics directly

## Components and Interfaces

### 1. ClickHouse Observability StatefulSet

**Image:** `clickhouse/clickhouse-server` (pinned via `version.kubernetes.clickstack.clickhouse`)

**Deployment:** StatefulSet with configurable replicas (default 3, set to 1 for test environments). Topology spread constraints are conditionally applied only when replicas > 1.

**Storage:** Longhorn PVCs, configurable 50–100Gi per replica (default 100Gi).

**ClickHouse Configuration:**
- Single-node mode per replica (no inter-replica coordination — each replica receives writes independently from its local OTel Collector)
- OTel standard schema: databases `otel_logs`, `otel_traces`, `otel_metrics` created automatically by the ClickStack OTel exporter
- TTL policies applied via init SQL configmap
- When replicas=1 (test): single instance, no topology constraints, reduced resource requests

**Networking:**
- ClusterIP Service: `clickhouse-observability` (port 8123 HTTP, 9000 native TCP)
- NodePort Service: exposes HTTP 8123 on configurable NodePort for external access

**Health Probes:**
- Liveness: HTTP GET `/ping` on port 8123
- Readiness: HTTP GET `/ping` on port 8123

### 2. OTel Collector DaemonSet

**Image:** `clickhouse/clickstack-otel-collector` (pinned via `version.kubernetes.clickstack.otel_collector`)

**Deployment:** DaemonSet — one pod per worker node (15 pods total across 3 DCs).

**Pipeline Configuration:**

```yaml
# OTel Collector config structure (rendered from Jinja2 template)
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318
        cors:
          allowed_origins: ["*"]
          allowed_headers: ["*"]
  fluentforward:
    endpoint: 0.0.0.0:24225

processors:
  batch:
    timeout: 5s
    send_batch_size: 10000
  resourcedetection:
    detectors: [env, system]
  memory_limiter:
    check_interval: 1s
    limit_mib: 512
    spike_limit_mib: 128

exporters:
  clickhouse:
    endpoint: "tcp://clickhouse-observability.clickstack.svc.cluster.local:9000"
    database: default
    logs_table_name: otel_logs
    traces_table_name: otel_traces
    metrics_table_name: otel_metrics
    ttl_days_logs: 7
    ttl_days_traces: 7
    ttl_days_metrics: 30
  prometheusremotewrite:
    endpoint: "http://prometheus.monitoring.svc.cluster.local:9090/api/v1/write"

service:
  pipelines:
    logs:
      receivers: [otlp, fluentforward]
      processors: [memory_limiter, resourcedetection, batch]
      exporters: [clickhouse]
    traces:
      receivers: [otlp]
      processors: [memory_limiter, resourcedetection, batch]
      exporters: [clickhouse]
    metrics:
      receivers: [otlp]
      processors: [memory_limiter, resourcedetection, batch]
      exporters: [clickhouse, prometheusremotewrite]
  extensions: [health_check]

extensions:
  health_check:
    endpoint: 0.0.0.0:13133
```

**Networking:**
- Ports exposed on each node: 4317 (OTLP gRPC), 4318 (OTLP HTTP), 24225 (FluentForward)
- NodePort Service for health check endpoint (port 13133)
- ClusterIP headless service for internal pod discovery

### 3. HyperDX UI Deployment

**Image:** `clickhouse/clickstack-all-in-one` (pinned via `version.kubernetes.clickstack.hyperdx`)

**Deployment:** Single-replica Deployment (stateless — state in MongoDB).

**Environment Variables (key):**
- `CLICKHOUSE_HOST`: `clickhouse-observability.clickstack.svc.cluster.local`
- `CLICKHOUSE_PORT`: `8123`
- `MONGO_URI`: `mongodb://hyperdx:<password>@mongodb-rs-0.mongodb-rs.mongodb.svc.cluster.local:27017,mongodb-rs-1.mongodb-rs.mongodb.svc.cluster.local:27017,mongodb-rs-2.mongodb-rs.mongodb.svc.cluster.local:27017/hyperdx?replicaSet=mongodb-rs`
- `SMTP_HOST`: `smtpb.intra.bt.com`
- `SMTP_PORT`: `25`
- `SMTP_FROM`: `noreply.martini@bt.com`

**Networking:**
- NodePort Service: exposes web UI on configurable NodePort
- ClusterIP Service: internal metrics endpoint

### 4. HyperDX MongoDB (Existing Cluster)

**Approach:** Reuse the existing Percona MongoDB cluster (`mongodb-rs` in namespace `mongodb`) that is already deployed in Barista prod with 3 geo-resilient replicas.

**Provisioning:** The HyperDX role's install task creates:
- Database `hyperdx` in the existing cluster
- User `hyperdx` with `readWrite` role on the `hyperdx` database

**Connection String:**
```
mongodb://hyperdx:<password>@mongodb-rs-0.mongodb-rs.mongodb.svc.cluster.local:27017,mongodb-rs-1.mongodb-rs.mongodb.svc.cluster.local:27017,mongodb-rs-2.mongodb-rs.mongodb.svc.cluster.local:27017/hyperdx?replicaSet=mongodb-rs
```

**Networking:**
- No new Services or NodePorts — uses existing ClusterIP headless Service in `mongodb` namespace
- Cross-namespace access: `clickstack` → `mongodb` namespace (K8s allows by default)

**No new infrastructure deployed** — the existing 3-replica geo-resilient MongoDB handles HyperDX state (dashboards, saved searches, alerts — <1GB total).

### 5. Prometheus Integration

**Approach:** Extend existing `monitoring` role's Prometheus ConfigMap with additional scrape targets and alert rules.

**Scrape Targets Added:**
```yaml
- job_name: 'clickhouse-observability'
  static_configs:
    - targets: ['clickhouse-observability.clickstack.svc.cluster.local:8123']
  metrics_path: /metrics

- job_name: 'otel-collector'
  kubernetes_sd_configs:
    - role: pod
      namespaces:
        names: ['clickstack']
  relabel_configs:
    - source_labels: [__meta_kubernetes_pod_label_app]
      regex: otel-collector
      action: keep

- job_name: 'hyperdx'
  static_configs:
    - targets: ['hyperdx.clickstack.svc.cluster.local:8080']
  metrics_path: /metrics
```

**Alert Rules:**
- `OtelCollectorPodRestart`: P2 — `increase(kube_pod_container_status_restarts_total{namespace="clickstack",container="otel-collector"}[15m]) > 3`
- `ClickHouseReplicaLag`: P1 — `clickhouse_replicas_lag > 60`
- `ClickHouseDiskUsageHigh`: P2 — `clickhouse_disk_usage_percent > 80`
- `HyperDXUnavailable`: P1 — `kube_deployment_status_replicas_available{namespace="clickstack",deployment="hyperdx"} == 0`
- `OtelExportFailures`: P2 — `rate(otel_exporter_send_failed_spans_total[5m]) > 0`

**Remote Write:** Prometheus Deployment patched with `--web.enable-remote-write-receiver` arg.

## Network Topology

### NodePort Assignments

| Service | Variable Path | Default | Internal Port |
|---------|--------------|---------|---------------|
| ClickHouse HTTP | `ports.kubernetes.clickstack.clickhouse_http` | 49700 | 8123 |
| HyperDX UI | `ports.kubernetes.clickstack.hyperdx_ui` | 49701 | 8080 |
| OTel Health | `ports.kubernetes.clickstack.otel_health` | 49702 | 13133 |

All NodePorts within the permitted range 49400–49799, assigned from the upper end to avoid conflicts with existing services (existing assignments are in the 49400–49410 and 61xxx ranges).

### ClusterIP Services

| Service | DNS Name | Ports |
|---------|----------|-------|
| ClickHouse | `clickhouse-observability.clickstack.svc.cluster.local` | 8123 (HTTP), 9000 (native) |
| OTel Collector | `otel-collector.clickstack.svc.cluster.local` | 4317, 4318, 24225, 13133 |
| HyperDX | `hyperdx.clickstack.svc.cluster.local` | 8080 |
| MongoDB (existing) | `mongodb-rs-0.mongodb-rs.mongodb.svc.cluster.local` | 27017 |

### Ingress

No HAProxy Ingress paths — all external access via NodePorts (consistent with existing Barista prod pattern for non-web-app services like FalkorDB, Kafka UI).

## Role Directory Structure

```
roles/kubernetes/observability/
├── clickhouse/
│   ├── defaults/main.yml
│   ├── tasks/
│   │   ├── main.yml          # validate → install → verify
│   │   ├── validate.yml      # Pre-flight checks
│   │   ├── install.yml       # Namespace, Secret, ConfigMap, StatefulSet, Service
│   │   └── verify.yml        # Wait for pods ready, health check
│   ├── templates/
│   │   ├── clickhouse-statefulset.yaml.j2
│   │   ├── clickhouse-service.yaml.j2
│   │   ├── clickhouse-service-nodeport.yaml.j2
│   │   ├── clickhouse-configmap.yaml.j2
│   │   ├── clickhouse-secret.yaml.j2
│   │   └── clickhouse-init-sql.yaml.j2
│   └── README.md
├── otel_collector/
│   ├── defaults/main.yml
│   ├── tasks/
│   │   ├── main.yml          # validate → install → verify
│   │   ├── validate.yml
│   │   ├── install.yml       # ConfigMap (otel-config), DaemonSet, Services
│   │   └── verify.yml        # Wait for all 15 pods ready
│   ├── templates/
│   │   ├── otel-daemonset.yaml.j2
│   │   ├── otel-configmap.yaml.j2
│   │   ├── otel-service.yaml.j2
│   │   └── otel-service-nodeport.yaml.j2
│   └── README.md
└── hyperdx/
    ├── defaults/main.yml
    ├── tasks/
    │   ├── main.yml          # validate → install → verify
    │   ├── validate.yml
    │   ├── install.yml       # MongoDB user provisioning, Secret, Deployment, Service
    │   └── verify.yml
    ├── templates/
    │   ├── hyperdx-deployment.yaml.j2
    │   ├── hyperdx-service.yaml.j2
    │   ├── hyperdx-secret.yaml.j2
    │   └── hyperdx-mongodb-init.js.j2
    └── README.md
```

### Playbook Structure

```
playbook/kubernetes/
├── clickstack_clickhouse.yaml
├── clickstack_otel_collector.yaml
└── clickstack_hyperdx.yaml
```

Each playbook follows the standard pattern:
```yaml
- hosts: "{{ target_host | default('kubernetes_master_init') }}"
  become: true
  gather_facts: false
  vars:
    ansible_python_interpreter: auto_silent
  vars_files:
    - ../_global_vars/all.yml
  roles:
    - { role: roles/kubernetes/observability/<sub_role> }
```

## Inventory Variable Structure

### `versions.yml` additions

```yaml
version:
  kubernetes:
    clickstack:
      clickhouse: "25.8.2.29"
      otel_collector: "0.116.0"
      hyperdx: "2.1.0"
      hyperdx_browser: "0.22.0"
      otel_python:
        distro: "0.51b0"
        exporter_otlp: "1.30.0"
        instrumentation_fastapi: "0.51b0"
        instrumentation_requests: "0.51b0"
        instrumentation_sqlalchemy: "0.51b0"
        instrumentation_redis: "0.51b0"
        instrumentation_kafka: "0.51b0"
```

### `networks.yml` additions

```yaml
ports:
  kubernetes:
    clickstack:
      clickhouse_http: 49700
      hyperdx_ui: 49701
      otel_health: 49702
```

### `config_kubernetes.yml` additions

```yaml
config_k8s:
  clickstack:
    # --- ClickHouse Observability ---
    clickhouse:
      namespace: clickstack
      replicas: 3                    # Set to 1 for test environments
      storage_class: longhorn
      storage_size: 100Gi            # Set to 20Gi for test
      image: clickhouse/clickhouse-server
      retention:
        logs_days: 7
        traces_days: 7
        metrics_days: 30
      resources:
        requests_cpu: "500m"         # Set to 250m for test
        requests_memory: "2Gi"       # Set to 1Gi for test
        limits_cpu: "4000m"          # Set to 2000m for test
        limits_memory: "8Gi"         # Set to 4Gi for test
      topology:
        topology_key: topology.kubernetes.io/region
        max_skew: 1
        # topology is automatically disabled when replicas=1

    # --- OTel Collector ---
    otel_collector:
      namespace: clickstack
      image: clickhouse/clickstack-otel-collector
      cors_allowed_origins:
        - "*"
      fluentforward_port: 24225
      resources:
        requests_cpu: "100m"
        requests_memory: "256Mi"
        limits_cpu: "1000m"
        limits_memory: "1Gi"

    # --- HyperDX ---
    hyperdx:
      namespace: clickstack
      image: clickhouse/clickstack-all-in-one
      replicas: 1
      smtp:
        host: "smtpb.intra.bt.com"
        port: 25
        from: "noreply.martini@bt.com"
      resources:
        requests_cpu: "250m"
        requests_memory: "512Mi"
        limits_cpu: "2000m"
        limits_memory: "4Gi"

    # --- HyperDX MongoDB (reuse existing cluster) ---
    hyperdx_mongodb:
      existing_cluster: true
      namespace: mongodb
      cluster_name: mongodb-rs
      database: hyperdx
      user: hyperdx

    # --- Prometheus Integration ---
    prometheus:
      remote_write_enabled: true
      alert_rules_enabled: true
      alert_email_to: "martini.asg@bt.com"
```

### `all_secrets.yml` additions (vault-encrypted)

```yaml
# ClickHouse
clickstack_clickhouse_admin_password_vault: "..."

# HyperDX MongoDB user (in existing cluster)
clickstack_mongodb_hyperdx_password_vault: "..."

# HyperDX
clickstack_hyperdx_api_key_vault: "..."
```

## Version Pinning Strategy

All container images are pinned to exact versions in `versions.yml`:
- No `latest` tags permitted
- Version updates require explicit `versions.yml` change + pipeline run
- OTel Collector and HyperDX versions must be compatible (ClickStack distribution)
- ClickHouse version matches the OTel exporter's supported range

## Secret Management

| Secret | Source Variable | K8s Secret Name | Mounted As |
|--------|----------------|-----------------|------------|
| ClickHouse admin password | `clickstack_clickhouse_admin_password_vault` | `clickhouse-observability-credentials` | env `CLICKHOUSE_PASSWORD` |
| MongoDB user password | `clickstack_mongodb_hyperdx_password_vault` | `hyperdx-credentials` | env `MONGO_URI` (embedded in connection string) |
| HyperDX API key | `clickstack_hyperdx_api_key_vault` | `hyperdx-credentials` | env `HYPERDX_API_KEY` |

All secrets created before their consuming Deployments/StatefulSets (per K8s Resource Ordering Standard).

## Data Models

### ClickHouse Table Schema

The ClickStack OTel Collector exporter auto-creates tables using the OpenTelemetry standard schema. The init SQL ConfigMap ensures TTL policies and retention settings:

```sql
-- Applied via clickhouse-init-sql ConfigMap (mounted as /docker-entrypoint-initdb.d/)

-- Log table TTL (auto-created by OTel exporter, TTL added via ALTER)
ALTER TABLE otel_logs MODIFY TTL Timestamp + INTERVAL {{ retention_logs_days }} DAY;

-- Trace table TTL
ALTER TABLE otel_traces MODIFY TTL Timestamp + INTERVAL {{ retention_traces_days }} DAY;

-- Metrics table TTL
ALTER TABLE otel_metrics MODIFY TTL TimeUnix + INTERVAL {{ retention_metrics_days }} DAY;
```

## Geo-Resilient Topology

### ClickHouse Distribution (prod — 3 replicas)
```
Reigate (10.6.103.x)   → clickhouse-observability-0
Derby (10.55.4.x)       → clickhouse-observability-1
St Albans (10.13.92.x)  → clickhouse-observability-2
```

### ClickHouse Distribution (test — 1 replica)
```
Any available node      → clickhouse-observability-0
```
No topology constraints applied when replicas=1.

### MongoDB Distribution

**Reuses existing** `mongodb-rs` cluster in `mongodb` namespace (already 3 replicas, 1 per DC). No new MongoDB infrastructure deployed.

### OTel Collector Distribution
All 15 worker nodes (5 per DC) — DaemonSet with no nodeSelector restrictions.

### Failure Mode: Single DC Loss
- **ClickHouse:** 2/3 replicas remain. Writes continue to surviving replicas. OTel Collectors on surviving nodes export to any available ClickHouse replica (ClusterIP load-balances). Data from lost DC unavailable until recovery.
- **MongoDB:** Existing 3-replica cluster. 2/3 members form majority. HyperDX continues reading/writing. Automatic primary election if lost DC hosted primary.
- **OTel Collector:** 10/15 pods remain. Local collection continues on surviving nodes. Pods on lost DC stop (expected — no data loss, just collection gap).
- **HyperDX:** If running on lost DC node, pod reschedules to surviving node (Deployment — no anti-affinity constraint). Temporary downtime during reschedule.

## Capacity Planning

### ClickHouse Storage

| Signal | Est. Daily Volume | 7-day Retention | 30-day Retention |
|--------|-------------------|-----------------|------------------|
| Logs | ~5 GB/day (15 nodes × ~30 pods each) | 35 GB | N/A |
| Traces | ~2 GB/day (moderate Python traffic) | 14 GB | N/A |
| Metrics | ~1 GB/day (all scraped metrics) | N/A | 30 GB |
| **Total per replica** | | **~50 GB** | +30 GB = **~80 GB** |

Default 100Gi per replica provides ~20% headroom. Minimum 50Gi supported for low-traffic scenarios.

### OTel Collector Resources
- Per-pod memory: 256Mi request, 1Gi limit (memory_limiter processor at 512MiB)
- Per-pod CPU: 100m request, 1000m limit
- Total cluster: 15 × 256Mi = 3.75 Gi memory, 15 × 100m = 1500m CPU (requests)

### MongoDB Storage
- HyperDX state: saved searches, alert definitions, user sessions
- Expected volume: < 1 GB total (metadata only)
- 10Gi per replica provides substantial headroom

## Failure Modes and Recovery

| Failure | Impact | Automatic Recovery | Manual Action |
|---------|--------|-------------------|---------------|
| OTel pod crash | Local node loses collection | DaemonSet restarts pod | None |
| ClickHouse pod crash | Queries degrade | StatefulSet restarts pod, PVC preserves data | None |
| ClickHouse PVC full | Writes fail on that replica | TTL cleanup frees space (runs hourly) | Increase `storage_size`, recreate PVC |
| HyperDX pod crash | UI unavailable | Deployment restarts pod | None |
| MongoDB primary loss | Brief write pause for HyperDX state | Percona operator triggers election | None |
| Full DC loss | See Geo-Resilient section | Automatic failover | Verify recovery when DC returns |
| OTel export backpressure | Memory_limiter drops spans | Batch processor retries | Check ClickHouse capacity |
| Prometheus remote_write failure | Metrics not in Prometheus | OTel retries with backoff | Check Prometheus health |

## Python Backend Instrumentation Pattern

### Zero-Code Instrumentation Template

The role provides a reusable environment variable block for Kubernetes Deployments:

```yaml
# Template: otel-python-env.yaml.j2
# Applied to any Python service Deployment's container spec
env:
  - name: OTEL_SERVICE_NAME
    value: "{{ service_name }}"
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://localhost:4317"
  - name: OTEL_EXPORTER_OTLP_PROTOCOL
    value: "grpc"
  - name: OTEL_RESOURCE_ATTRIBUTES
    value: "deployment.environment=barista-prod,service.namespace=clickstack"
  - name: OTEL_TRACES_SAMPLER
    value: "parentbased_traceidratio"
  - name: OTEL_TRACES_SAMPLER_ARG
    value: "1.0"
  - name: OTEL_PYTHON_LOG_CORRELATION
    value: "true"
```

### Required Packages (defined in defaults)
```yaml
clickstack_otel_python_packages:
  - opentelemetry-distro
  - opentelemetry-exporter-otlp
  - opentelemetry-instrumentation-fastapi
  - opentelemetry-instrumentation-requests
  - opentelemetry-instrumentation-sqlalchemy
  - opentelemetry-instrumentation-redis
  - opentelemetry-instrumentation-kafka-python
```

### Container Command Override
```yaml
command: ["opentelemetry-instrument"]
args: ["python", "-m", "app.main"]
```

## Angular Frontend Instrumentation Pattern

### SDK Integration (documented in role README)
```typescript
// Angular app main.ts — documented pattern
import HyperDX from '@hyperdx/browser';

HyperDX.init({
  apiKey: '<HYPERDX_API_KEY>',
  service: 'barista-angular-frontend',
  tracePropagationTargets: [/api\.barista\.nat\.bt\.com/i],
  consoleCapture: true,
  advancedNetworkCapture: true,
  endpoint: 'http://<cluster-node>:49702/v1/traces',
});
```

### CORS Configuration
The OTel Collector HTTP receiver CORS configuration accepts browser SDK requests:
```yaml
cors:
  allowed_origins: {{ clickstack_otel_cors_origins | to_json }}
  allowed_headers: ["*"]
  max_age: 7200
```

## Defaults/main.yml Structure (per role)

### clickhouse/defaults/main.yml
```yaml
# --- Core ---
clickstack_ch_version: "{{ version.kubernetes.clickstack.clickhouse | default('25.8.2.29') }}"
clickstack_ch_image: "{{ config_k8s.clickstack.clickhouse.image | default('clickhouse/clickhouse-server') }}"
clickstack_ch_namespace: "{{ config_k8s.clickstack.clickhouse.namespace | default('clickstack') }}"
clickstack_ch_replicas: "{{ config_k8s.clickstack.clickhouse.replicas | default(3) }}"

# --- User ---
clickstack_ch_ansible_user: "{{ config_k8s.ansible_user | default('app-manager') }}"

# --- Storage ---
clickstack_ch_storage_class: "{{ config_k8s.clickstack.clickhouse.storage_class | default('longhorn') }}"
clickstack_ch_storage_size: "{{ config_k8s.clickstack.clickhouse.storage_size | default('100Gi') }}"

# --- Network ---
clickstack_ch_http_port: 8123
clickstack_ch_native_port: 9000
clickstack_ch_nodeport: "{{ ports.kubernetes.clickstack.clickhouse_http | default(49700) }}"

# --- Retention ---
clickstack_ch_retention_logs_days: "{{ config_k8s.clickstack.clickhouse.retention.logs_days | default(7) }}"
clickstack_ch_retention_traces_days: "{{ config_k8s.clickstack.clickhouse.retention.traces_days | default(7) }}"
clickstack_ch_retention_metrics_days: "{{ config_k8s.clickstack.clickhouse.retention.metrics_days | default(30) }}"

# --- Resource Limits ---
clickstack_ch_requests_cpu: "{{ config_k8s.clickstack.clickhouse.resources.requests_cpu | default('500m') }}"
clickstack_ch_requests_memory: "{{ config_k8s.clickstack.clickhouse.resources.requests_memory | default('2Gi') }}"
clickstack_ch_limits_cpu: "{{ config_k8s.clickstack.clickhouse.resources.limits_cpu | default('4000m') }}"
clickstack_ch_limits_memory: "{{ config_k8s.clickstack.clickhouse.resources.limits_memory | default('8Gi') }}"

# --- Topology (conditional — only applied when replicas > 1) ---
clickstack_ch_topology_enabled: "{{ (clickstack_ch_replicas | int) > 1 }}"
clickstack_ch_topology_key: "{{ config_k8s.clickstack.clickhouse.topology.topology_key | default('topology.kubernetes.io/region') }}"
clickstack_ch_topology_max_skew: "{{ config_k8s.clickstack.clickhouse.topology.max_skew | default(1) }}"

# --- Secrets ---
clickstack_ch_admin_password: "{{ clickstack_clickhouse_admin_password_vault }}"

# --- Timeouts ---
clickstack_ch_wait_retries: 20
clickstack_ch_wait_delay: 15
```

### otel_collector/defaults/main.yml
```yaml
# --- Core ---
clickstack_otel_version: "{{ version.kubernetes.clickstack.otel_collector | default('0.116.0') }}"
clickstack_otel_image: "{{ config_k8s.clickstack.otel_collector.image | default('clickhouse/clickstack-otel-collector') }}"
clickstack_otel_namespace: "{{ config_k8s.clickstack.otel_collector.namespace | default('clickstack') }}"

# --- User ---
clickstack_otel_ansible_user: "{{ config_k8s.ansible_user | default('app-manager') }}"

# --- Network ---
clickstack_otel_grpc_port: 4317
clickstack_otel_http_port: 4318
clickstack_otel_fluentforward_port: "{{ config_k8s.clickstack.otel_collector.fluentforward_port | default(24225) }}"
clickstack_otel_health_port: 13133
clickstack_otel_health_nodeport: "{{ ports.kubernetes.clickstack.otel_health | default(49702) }}"

# --- CORS ---
clickstack_otel_cors_origins: "{{ config_k8s.clickstack.otel_collector.cors_allowed_origins | default(['*']) }}"

# --- Resource Limits ---
clickstack_otel_requests_cpu: "{{ config_k8s.clickstack.otel_collector.resources.requests_cpu | default('100m') }}"
clickstack_otel_requests_memory: "{{ config_k8s.clickstack.otel_collector.resources.requests_memory | default('256Mi') }}"
clickstack_otel_limits_cpu: "{{ config_k8s.clickstack.otel_collector.resources.limits_cpu | default('1000m') }}"
clickstack_otel_limits_memory: "{{ config_k8s.clickstack.otel_collector.resources.limits_memory | default('1Gi') }}"

# --- Exporters ---
clickstack_otel_clickhouse_endpoint: "tcp://clickhouse-observability.clickstack.svc.cluster.local:9000"
clickstack_otel_prometheus_endpoint: "http://prometheus.monitoring.svc.cluster.local:9090/api/v1/write"

# --- Timeouts ---
clickstack_otel_wait_retries: 15
clickstack_otel_wait_delay: 10
```

## Deployment Order

The roles must be executed in this order due to inter-component dependencies:

1. **clickstack_clickhouse** — ClickHouse must be available before OTel Collector exports and HyperDX queries
2. **clickstack_otel_collector** — Requires ClickHouse endpoint (and optionally Prometheus remote_write)
3. **clickstack_hyperdx** — Requires ClickHouse and existing MongoDB (provisions db/user as part of install)

Each playbook is independent and idempotent — re-running in any order after initial deployment is safe.

## Error Handling

### Validation Phase Errors

Each role's `validate.yml` performs pre-flight checks before any changes:

- **Required variables undefined:** Fail with message listing missing variables
- **NodePort conflict:** Fail with message identifying the conflicting port and owning service
- **Storage size out of range:** Fail if ClickHouse `storage_size` < 50Gi or > 100Gi
- **Namespace already exists with conflicting resources:** Warning only — idempotent design handles re-runs
- **Kubernetes API unreachable:** Fail with connection error (kubectl connectivity check)

### Runtime Errors

- **Pod scheduling failure (topology constraint):** Pod stays Pending — alert `ClickHouseReplicaLag` or `HyperDXUnavailable` fires
- **PVC provisioning failure (Longhorn):** Pod stays Pending — operator investigation required
- **OTel export timeout:** Memory limiter drops oldest spans/logs to prevent OOM, `OtelExportFailures` alert fires
- **ClickHouse OOM:** Pod restarts via StatefulSet, `OtelCollectorPodRestart`-style alert fires
- **MongoDB election timeout:** Percona operator handles re-election automatically (< 12 seconds typical)

### Rollback Strategy

All manifests are applied via `kubectl apply` — rollback is achieved by:
1. Running the playbook with previous version in `versions.yml`
2. StatefulSet performs rolling update back to previous image
3. PVCs are retained (data preserved across upgrades)

## Testing Strategy

### Unit Tests (Example-Based)
- Verify rendered YAML manifests contain expected fields (name, namespace, replicas, ports)
- Verify OTel Collector config template routes signals to correct exporters
- Verify alert rules contain correct PromQL expressions and severity labels
- Verify defaults/main.yml references correct variable paths

### Integration Tests
- Deploy to pre-prod Barista cluster and verify end-to-end signal flow
- Verify Fluent Bit → OTel Collector → ClickHouse log pipeline
- Verify DC failure simulation (cordon one DC's nodes, verify continued operation)

### Property Tests
- NodePort range validation across all configured ports
- Prometheus config merge preserves existing targets
- kubectl/helm commands use correct sudo pattern
- Python instrumentation template produces complete environment blocks

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Prometheus scrape config preservation

*For any* existing Prometheus scrape configuration set, the clickstack Ansible role's ConfigMap patch SHALL produce a superset that contains all original scrape targets unchanged, plus the new clickstack targets. No existing target shall be removed or modified.

**Validates: Requirements 3.5**

### Property 2: kubectl/helm command sudo pattern

*For any* shell task in the observability Ansible roles that invokes `kubectl` or `helm`, the command SHALL be prefixed with `sudo -u {{ <role>_ansible_user }} --set-home` to ensure proper user context and audit trail.

**Validates: Requirements 9.4**

### Property 3: NodePort range validation

*For any* NodePort value assigned to a clickstack service (ClickHouse HTTP, HyperDX UI, OTel health), the port number SHALL be within the range 49400–49799 inclusive.

**Validates: Requirements 11.1, 11.2, 11.3**

### Property 4: NodePort conflict detection

*For any* port value that already exists in the `ports.*` variable hierarchy of the Barista prod inventory, the clickstack role's validate step SHALL fail with an error message identifying the conflicting service and port number.

**Validates: Requirements 11.5**

### Property 5: Python instrumentation environment template completeness

*For any* valid service name string, the Python OTel instrumentation environment variable template SHALL produce a YAML block containing all three required variables: `OTEL_SERVICE_NAME` (set to the provided service name), `OTEL_EXPORTER_OTLP_ENDPOINT` (set to a valid gRPC endpoint), and `OTEL_RESOURCE_ATTRIBUTES` (containing the deployment environment).

**Validates: Requirements 6.3**

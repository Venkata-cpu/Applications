# Requirements Document

## Introduction

Deploy a full-stack observability platform (ClickStack) on the Barista prod multi-DC Kubernetes cluster. The stack comprises ClickHouse for telemetry storage, an OpenTelemetry Collector DaemonSet for signal ingestion, HyperDX for unified search and alerting, and application-level instrumentation for Python and Angular services. All components are deployed via Ansible roles following mat_ansible conventions, with geo-resilient topology spread across the three data centres (Reigate, Derby, St Albans).

## Glossary

- **Barista_Cluster**: The Barista prod 3-site multi-DC Kubernetes cluster (3 masters, 15 workers across Reigate, Derby, St Albans)
- **ClickStack**: The ClickHouse-based observability distribution combining ClickHouse storage, OTel Collector (ClickStack variant), and HyperDX UI
- **OTel_Collector**: The OpenTelemetry Collector DaemonSet running the ClickStack distribution image (`clickhouse/clickstack-otel-collector`), responsible for receiving, processing, and exporting telemetry signals
- **ClickHouse_Observability**: A 3-replica ClickHouse StatefulSet in the `clickstack` namespace used exclusively for observability data (logs, traces, metrics)
- **HyperDX_UI**: The HyperDX web application providing unified log, trace, and session search with SQL-based alerting
- **HyperDX_MongoDB**: A 3-replica Percona MongoDB cluster in the `clickstack` namespace used for HyperDX application state
- **Prometheus_Monitoring**: The existing Kubernetes monitoring Prometheus instance (namespace `monitoring`) extended with new scrape targets and alert rules
- **Ansible_Role**: An Ansible role following the mat_ansible task execution order (validate → pre_install → install → cleanup → config → service → verify)
- **Topology_Spread**: Kubernetes `topologySpreadConstraints` ensuring pods are distributed evenly across the three data centres using `topology.kubernetes.io/region` label
- **NodePort_Range**: The Barista prod permitted NodePort range 49400–49799
- **OTLP**: OpenTelemetry Protocol for transmitting telemetry data (gRPC on port 4317, HTTP on port 4318)
- **FluentForward**: The Fluent Bit forward protocol on port 24225 used for log ingestion from the existing Fluent Bit DaemonSet
- **Remote_Write**: Prometheus remote write protocol used by OTel_Collector to push application metrics to Prometheus_Monitoring
- **W3C_Traceparent**: The W3C Trace Context propagation header used for distributed tracing correlation between frontend and backend

## Requirements

### Requirement 1: ClickHouse Observability StatefulSet

**User Story:** As a platform engineer, I want a dedicated ClickHouse cluster for observability data, so that logs, traces, and metrics are stored with geo-resilient replication across all three data centres.

#### Acceptance Criteria

1. WHEN the clickhouse_observability Ansible role is executed, THE Ansible_Role SHALL deploy a StatefulSet named `clickhouse-observability` with a configurable number of replicas (sourced from `config_k8s.clickstack.clickhouse.replicas`, default 3) in the `clickstack` namespace on the Barista_Cluster.
2. THE ClickHouse_Observability SHALL use Longhorn as the StorageClass for persistent volume claims with a configurable storage size (default 100Gi per replica).
3. WHEN `config_k8s.clickstack.clickhouse.replicas` is greater than 1, THE ClickHouse_Observability SHALL distribute replicas across data centres using Topology_Spread constraints on a configurable topology key (default `topology.kubernetes.io/region`) with maxSkew of 1. WHEN replicas is 1, THE Ansible_Role SHALL omit topologySpreadConstraints entirely.
4. WHEN the ClickHouse_Observability starts, THE ClickHouse_Observability SHALL expose an HTTP interface on a configurable NodePort within the NodePort_Range for external query access.
5. THE ClickHouse_Observability SHALL configure a TTL-based retention policy of 7 days for log and trace tables and 30 days for metric tables (all configurable via inventory variables).
6. THE Ansible_Role SHALL source all configuration from `config_k8s.clickstack.clickhouse.*` variables in `config_kubernetes.yml` with sensible defaults.
7. THE Ansible_Role SHALL store the ClickHouse admin password in vault-encrypted `all_secrets.yml` and reference it via a Kubernetes Secret.

### Requirement 2: OTel Collector DaemonSet

**User Story:** As a platform engineer, I want an OpenTelemetry Collector running on every worker node, so that all telemetry signals are collected locally and routed to the appropriate backends.

#### Acceptance Criteria

1. WHEN the otel_collector Ansible role is executed, THE Ansible_Role SHALL deploy a DaemonSet named `otel-collector` in the `clickstack` namespace producing one pod per worker node (15 pods total).
2. THE OTel_Collector SHALL use the `clickhouse/clickstack-otel-collector` container image with a version sourced from `version.kubernetes.clickstack.otel_collector` in `versions.yml`.
3. THE OTel_Collector SHALL expose OTLP gRPC receiver on port 4317, OTLP HTTP receiver on port 4318, and FluentForward receiver on port 24225.
4. THE OTel_Collector SHALL enable CORS headers on the OTLP HTTP receiver to accept requests from browser-based instrumentation SDKs.
5. THE OTel_Collector SHALL export logs and traces exclusively to ClickHouse_Observability.
6. THE OTel_Collector SHALL export application metrics to both ClickHouse_Observability and Prometheus_Monitoring via Remote_Write.
7. THE OTel_Collector SHALL expose a health check endpoint on a configurable NodePort within the NodePort_Range.
8. THE Ansible_Role SHALL source all configuration from `config_k8s.clickstack.otel_collector.*` variables in `config_kubernetes.yml` with sensible defaults.
9. WHEN the existing Fluent Bit DaemonSet sends logs via FluentForward protocol, THE OTel_Collector SHALL accept and process those log records for export to ClickHouse_Observability.

### Requirement 3: Prometheus Integration

**User Story:** As a platform engineer, I want the existing Prometheus monitoring to scrape the new observability components and alert on their health, so that operational issues are detected early.

#### Acceptance Criteria

1. WHEN the clickstack Ansible roles are executed, THE Ansible_Role SHALL add Prometheus scrape targets for ClickHouse_Observability metrics, OTel_Collector metrics, and HyperDX_UI metrics to the existing Prometheus_Monitoring configuration.
2. THE Ansible_Role SHALL enable `--web.enable-remote-write-receiver` on the existing Prometheus_Monitoring to accept Remote_Write from OTel_Collector.
3. THE Ansible_Role SHALL deploy alert rules for observability stack health including: OTel Collector pod restarts, ClickHouse replica lag, ClickHouse disk usage above 80%, HyperDX pod unavailability, and OTel Collector export failures.
4. THE Ansible_Role SHALL assign P1, P2, and P3 severity labels to alert rules and route notifications to `martini.asg@bt.com` via SMTP using the existing AlertManager configuration.
5. THE Ansible_Role SHALL preserve all existing Prometheus scrape targets, alert rules, and AlertManager routing without modification.

### Requirement 4: HyperDX UI Deployment

**User Story:** As a developer, I want a unified search interface for logs, traces, and sessions, so that I can investigate production issues across all telemetry signals in one place.

#### Acceptance Criteria

1. WHEN the hyperdx Ansible role is executed, THE Ansible_Role SHALL deploy a Kubernetes Deployment named `hyperdx` in the `clickstack` namespace on the Barista_Cluster.
2. THE HyperDX_UI SHALL connect to ClickHouse_Observability for log, trace, and metric querying.
3. THE HyperDX_UI SHALL connect to HyperDX_MongoDB for application state persistence (saved searches, alert definitions, user sessions).
4. THE HyperDX_UI SHALL expose its web interface on a configurable NodePort within the NodePort_Range.
5. THE HyperDX_UI SHALL support SQL-based alert definitions that query ClickHouse_Observability and send notifications via SMTP.
6. THE Ansible_Role SHALL source all configuration from `config_k8s.clickstack.hyperdx.*` variables in `config_kubernetes.yml` with sensible defaults.
7. THE Ansible_Role SHALL store the HyperDX MongoDB connection credentials in vault-encrypted `all_secrets.yml`.

### Requirement 5: HyperDX MongoDB Database Provisioning

**User Story:** As a platform engineer, I want a dedicated database and user provisioned in the existing Barista MongoDB cluster for HyperDX, so that HyperDX state is persisted without deploying additional infrastructure.

#### Acceptance Criteria

1. WHEN the clickstack_hyperdx Ansible role is executed, THE Ansible_Role SHALL create a database named `hyperdx` in the existing Percona MongoDB cluster (`mongodb-rs` in namespace `mongodb`).
2. THE Ansible_Role SHALL create a MongoDB user `hyperdx` with `readWrite` permissions on the `hyperdx` database.
3. THE Ansible_Role SHALL store the HyperDX MongoDB user password in vault-encrypted `all_secrets.yml` as `clickstack_mongodb_hyperdx_password_vault`.
4. THE HyperDX_UI SHALL connect to the existing MongoDB cluster via the internal DNS `mongodb-rs-0.mongodb-rs.mongodb.svc.cluster.local:27017` (with replica set connection string).
5. THE Ansible_Role SHALL NOT deploy any new MongoDB StatefulSet, Operator, or PVC — it reuses the existing geo-resilient 3-replica cluster already running in Barista prod.

### Requirement 6: Python Backend Instrumentation

**User Story:** As a developer, I want zero-code OpenTelemetry instrumentation for Python services, so that traces, metrics, and logs are automatically collected without modifying application code.

#### Acceptance Criteria

1. THE Ansible_Role SHALL define the required Python OpenTelemetry packages in a configurable list: `opentelemetry-distro`, `opentelemetry-exporter-otlp`, `opentelemetry-instrumentation-fastapi`, `opentelemetry-instrumentation-requests`, `opentelemetry-instrumentation-sqlalchemy`, `opentelemetry-instrumentation-redis`, `opentelemetry-instrumentation-kafka-python`.
2. THE Ansible_Role SHALL provide a documented configuration pattern for wrapping Python services with `opentelemetry-instrument` CLI, exporting OTLP to the local OTel_Collector at `localhost:4317`.
3. THE Ansible_Role SHALL define environment variables (`OTEL_SERVICE_NAME`, `OTEL_EXPORTER_OTLP_ENDPOINT`, `OTEL_RESOURCE_ATTRIBUTES`) as a reusable template for Kubernetes Deployment manifests.
4. THE Ansible_Role SHALL source the instrumentation package versions from `version.kubernetes.clickstack.otel_python.*` in `versions.yml`.

### Requirement 7: Angular Frontend Instrumentation

**User Story:** As a developer, I want browser-level observability for Angular applications, so that session replays, network traces, Web Vitals, JavaScript exceptions, and user interactions are captured and correlated with backend traces.

#### Acceptance Criteria

1. THE Ansible_Role SHALL document the `@hyperdx/browser` SDK integration pattern including session replay, network request tracing, Web Vitals collection, JavaScript exception capture, and user interaction event recording.
2. THE Ansible_Role SHALL define the OTel Collector OTLP HTTP endpoint (`http://<cluster-ingress>:<otel-http-nodeport>/v1/traces`) as the browser SDK target with W3C_Traceparent header propagation.
3. THE Ansible_Role SHALL include CORS-allowed origins configuration in the OTel_Collector OTLP HTTP receiver to accept requests from the Angular application domains.
4. THE Ansible_Role SHALL source the browser SDK version from `version.kubernetes.clickstack.hyperdx_browser` in `versions.yml`.

### Requirement 8: Data Retention and Storage Capacity

**User Story:** As a platform engineer, I want configurable retention policies and predictable storage consumption, so that observability data does not exhaust cluster storage.

#### Acceptance Criteria

1. THE ClickHouse_Observability SHALL enforce a 7-day TTL on log tables, removing rows older than 7 days automatically.
2. THE ClickHouse_Observability SHALL enforce a 7-day TTL on trace span tables, removing rows older than 7 days automatically.
3. THE ClickHouse_Observability SHALL enforce a 30-day TTL on metric tables, removing rows older than 30 days automatically.
4. THE ClickHouse_Observability SHALL allocate between 50Gi and 100Gi of Longhorn storage per replica (configurable via `config_k8s.clickstack.clickhouse.storage_size`).
5. THE Ansible_Role SHALL make all retention periods configurable via `config_k8s.clickstack.clickhouse.retention.*` variables with the stated defaults.

### Requirement 9: Ansible Role Structure and Conventions

**User Story:** As a platform engineer, I want the observability stack deployed via standard Ansible roles, so that it integrates with the existing CI/CD pipeline and inventory structure.

#### Acceptance Criteria

1. THE Ansible_Role SHALL create roles under `roles/kubernetes/observability/` with sub-roles: `clickhouse/`, `otel_collector/`, `hyperdx/`.
2. THE Ansible_Role SHALL create playbooks under `playbook/kubernetes/` named `clickstack_clickhouse.yaml`, `clickstack_otel_collector.yaml`, `clickstack_hyperdx.yaml`.
3. THE Ansible_Role SHALL follow the mat_ansible task execution order: validate → install → config → service → verify.
4. THE Ansible_Role SHALL use `sudo -u {{ <role>_ansible_user }} --set-home` for all kubectl and helm commands.
5. THE Ansible_Role SHALL define all versions in `inventories/barista/prod/group_vars/all/versions.yml` under a `kubernetes.clickstack.*` key hierarchy.
6. THE Ansible_Role SHALL define all ports in `inventories/barista/prod/group_vars/all/networks.yml` under `ports.kubernetes.clickstack.*`.
7. THE Ansible_Role SHALL define all application configuration in `inventories/barista/prod/group_vars/all/config_kubernetes.yml` under the `config_k8s.clickstack.*` key.
8. THE Ansible_Role SHALL store all secrets (ClickHouse admin password, MongoDB passwords, HyperDX API key) in vault-encrypted `all_secrets.yml`.

### Requirement 10: Geo-Resilient Topology

**User Story:** As a platform engineer, I want all stateful observability components spread across three data centres, so that a single-site failure does not cause data loss or service unavailability.

#### Acceptance Criteria

1. WHEN `config_k8s.clickstack.clickhouse.replicas` is greater than 1, THE ClickHouse_Observability SHALL schedule replicas across data centres using `topologySpreadConstraints` with a configurable topology key (default `topology.kubernetes.io/region`) and `whenUnsatisfiable: DoNotSchedule`. WHEN replicas is 1, THE topologySpreadConstraints SHALL be omitted entirely.
2. WHILE one data centre is unavailable AND replicas > 1, THE ClickHouse_Observability SHALL continue accepting writes and serving queries from the remaining replicas.
3. WHILE one data centre is unavailable, THE existing MongoDB cluster SHALL continue serving HyperDX reads and writes via the remaining majority (2 of 3 replicas).
4. THE OTel_Collector DaemonSet SHALL run on all worker nodes regardless of data centre count, collecting telemetry locally on each node.

### Requirement 11: NodePort Assignments

**User Story:** As a platform engineer, I want dedicated NodePort assignments for observability services, so that external access is controlled and does not conflict with existing services.

#### Acceptance Criteria

1. THE Ansible_Role SHALL assign a NodePort from the range 49400–49799 for ClickHouse_Observability HTTP access, configurable via `ports.kubernetes.clickstack.clickhouse_http`.
2. THE Ansible_Role SHALL assign a NodePort from the range 49400–49799 for HyperDX_UI web interface access, configurable via `ports.kubernetes.clickstack.hyperdx_ui`.
3. THE Ansible_Role SHALL assign a NodePort from the range 49400–49799 for OTel_Collector health check endpoint, configurable via `ports.kubernetes.clickstack.otel_health`.
4. THE Ansible_Role SHALL document all assigned NodePorts in `networks.yml` under the `ports.kubernetes.clickstack.*` key to prevent future conflicts.
5. IF a requested NodePort is already in use by another service, THEN THE Ansible_Role validate step SHALL fail with a clear error message identifying the conflict.


--Before using this script - please change v_new_username and EIN no line 39
DECLARE
   v_old_username users.account_name%TYPE   := 'THATIVS'; -- Depending on user change existing User Id
   v_new_username     users.account_name%TYPE   := 'MADHUK'; -- This has to be BOAT Id of requested User

   CURSOR c_get_group_name (cp_role_name ROLES.NAME%TYPE)
   IS
      SELECT NAME
        FROM user_groups
       WHERE role_name = cp_role_name;

  CURSOR c_chk_role_exists (cp_role_name ROLES.NAME%TYPE)
   IS
      SELECT 1
        FROM session_roles--dba_role_privs  --SESSION_ROLES
       WHERE role = cp_role_name;
	   
   v_per_id       users.per_id%TYPE;
   v_group_name   user_groups.NAME%TYPE;
   v_role_exists  PLS_INTEGER := 0;
   v_error_number           NUMBER; 

BEGIN

   EXECUTE IMMEDIATE 'CREATE USER ' || v_new_username ||
      ' IDENTIFIED BY change00 account unlock';

   SELECT PER_ID_SEQ.NEXTVAL INTO v_per_id FROM DUAL;

   INSERT INTO DBSEC.PERSONS (ID,
                               NAME,
                               CUST_NAME,
                               POSTAL_ADDR, EIN_no, JOB_TITLE)
      VALUES   (v_per_id,
                'MADHU', -- Name of the User
                'CUSTOMER',
                'BOTH',617357115, -- EIN of the User
				'TECHM' -- -- Role of the User
				);


   INSERT INTO DBSEC.USERS (ACCOUNT_NAME,
                             PER_ID,
                             ROLE_NAME,
                             APPLICATION_TIMEOUT,
                             POLLING_INTERVAL,
                             NEW_NOTIFICATION_BEEP,
                             NOTIFY_GRAPHICS,
                             NG_SYSID,
							 DESCRIPTION)
      VALUES   (v_new_username,
                v_per_id,
                'GB_GRAPHICAL_BROWSER',
                60,
                1,
                'Y',
                'N',
                1,
				'PROFILE BY PACS PLATFORM');

   FOR v_rec IN (SELECT * FROM v_amy_user_roles WHERE account_name=
      v_old_username)
   LOOP

         OPEN c_get_group_name (v_rec.role_name);
            FETCH c_get_group_name INTO v_group_name;

         IF c_get_group_name%FOUND THEN
           INSERT INTO dbsec.work_persons
                       (per_id, usergrp_name
                       )
                VALUES (v_per_id, v_group_name
                       );

              OPEN c_chk_role_exists(v_rec.role_name);
                FETCH c_chk_role_exists INTO v_role_exists;


              IF c_chk_role_exists%FOUND THEN
               EXECUTE IMMEDIATE 'GRANT ' || v_rec.role_name || ' TO ' || v_new_username;
              END IF;
              
              CLOSE c_chk_role_exists;

         END IF;

         CLOSE c_get_group_name;
   END LOOP;

   EXECUTE IMMEDIATE 'GRANT CREATE SESSION TO ' ||v_new_username;

   EXECUTE IMMEDIATE 'GRANT SV_APPLICATION_USER TO ' ||v_new_username;

   EXECUTE IMMEDIATE 'ALTER USER ' || v_new_username || ' GRANT CONNECT THROUGH NCLRPACSWEB';
   
   EXECUTE IMMEDIATE 'ALTER USER ' || v_new_username || ' IDENTIFIED BY Raag6022_171222 ACCOUNT UNLOCK'; 
   
   --EXECUTE IMMEDIATE 'ALTER USER ' || v_new_username || ' PROFILE NEW_APPLICATION_USERS'; 
   
   --admin_security.change_profile (v_new_username                                     ,'NEW_APPLICATION_USERS'                                     ,v_error_number);

   
   COMMIT;
   
   lbacsys.sa_user_admin.set_user_privs ('SDH_RESTRICT_POLICY',v_new_username,'FULL,PROFILE_ACCESS');
   
EXCEPTION
   WHEN OTHERS
   THEN
      ROLLBACK;
      DBMS_OUTPUT.put_line ('ERROR OCCURED: ' || SQLCODE || '-' || SQLERRM);
       DBMS_OUTPUT.put_line (DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;
